package com.adp.tlmbdd.pages.editors;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class TimeCalcProgram {
	
	@FindBy(xpath = ".//*[@id='txtTimeCalcProgramID']")
	private WebElementFacade TimeCalcProgTxtBox;
	
	@FindBy(xpath = ".//*[@id='multDesc']")
	private WebElementFacade TimeCalcProgDescTxtBox;
	
	@FindBy(xpath = ".//*[@id='lkpDailyRule']")
	private WebElementFacade WorkDayRulelkp;
	
	@FindBy(xpath = ".//*[@id='lkpPeriodWeekRule']")
	private WebElementFacade PeriodWeekRulelkp;
	
	@FindBy(xpath = ".//*[@id='barButtons_btnSubmit']")
	private WebElementFacade TimeCalcProgSubmit;
	
	public void CreateTimeCalcProgram()
	{
		TimeCalcProgTxtBox.sendKeys("");
		TimeCalcProgDescTxtBox.sendKeys("");
		WorkDayRulelkp.sendKeys("");
		PeriodWeekRulelkp.sendKeys("");
		TimeCalcProgSubmit.click();
	}

}
