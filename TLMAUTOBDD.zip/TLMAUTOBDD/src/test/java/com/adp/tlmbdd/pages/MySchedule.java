package com.adp.tlmbdd.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;


public class MySchedule extends GenericPageObject{

	public static Logger log = Logger.getLogger(MySchedule.class);
	
	@FindBy(xpath = "//table[@id='ShiftSwapToolTip_TABLE']")
	private WebElementFacade shiftSwapToolTipTable;
	
	@FindBy(xpath = "//button[@id='ShiftSwapToolTip.ShiftSwap']")
	private WebElementFacade shiftSwapButton;
	
	@FindBy(xpath = "//div[@id='ShiftSwapSlideIn']")
	private WebElementFacade shiftSwapSlideIn;
	
	@FindBy(xpath = "//textarea")
	private WebElementFacade commentBoxShiftSwapSlider;
	
	@FindBy(xpath = "//button[@id='TargetSwapSlideInView.Submit']")
	private WebElementFacade sendShiftSwapRequest;
	
	@FindBy(xpath = "//div[@id='ShiftSwapRecievedRequestDetailsPopUp.dialog']")
	private WebElementFacade shiftSwapRequestDialog;
	
	@FindBy(xpath = "//span[@id='ShiftSwapRecievedRequestDetailsPopUp.Accept.label']")
	private WebElementFacade shiftSwapAcceptButton;
	
	@FindBy(xpath = "//textarea[@id='SwapActionConfirmationDialog.Comment.textArea']")
	private WebElementFacade shiftSwapComment;
	
	@FindBy(xpath = "//button[@id='SwapActionConfirmationDialog.Yes']")
	private WebElementFacade shiftSwapAcceptYes;
	
	@FindBy(xpath = "//div[text()='You have successfully accepted the shift swap request.']")
	private WebElementFacade successMessage;
	
	
	public void createShiftSwapRequestOnSpecificDate(String date, String comment,String recipientname)
	{
		WaitForPageLoad();
		waitABit(5000);
		String day = date.split("/")[1].toString();
		getDriver().findElement(By.xpath("//div[text()='"+day+"']/..//div[@class='swapEligibleBox']")).click();
		waitForElementToLoad(shiftSwapToolTipTable);
		shiftSwapButton.click();
		WaitForPageLoad();
		waitForElementToLoad(shiftSwapSlideIn);
		getDriver().findElement(By.xpath("(//span[text()='"+recipientname+"']/ancestor::tr[contains(@id,'TargetSwapSlideInView')]//span[@class='shiftSpan'])[1]")).click();
		waitABit(2000);
		commentBoxShiftSwapSlider.clear();
		commentBoxShiftSwapSlider.sendKeys(comment);
		sendShiftSwapRequest.click();
		waitABit(3000);
	}
	
	public void acceptShiftSwapRequest(String date,String comment)
	{
		WaitForPageLoad();
		waitABit(5000);
		String day = date.split("/")[1].toString();
		getDriver().findElement(By.xpath("//div[text()='"+day+"']/..//div[@class='swapInfoBox']")).click();
		waitForElementToLoad(shiftSwapRequestDialog);
		shiftSwapAcceptButton.click();
		waitABit(2000);
		shiftSwapComment.clear();
		shiftSwapComment.sendKeys(comment);
		waitABit(2000);
		shiftSwapAcceptYes.click();
		waitForElementToLoad(successMessage);
		
	}
	
}

