package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.Report;
import com.adp.tlmbdd.pages.editors.PayClasses;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class ReportsSteps extends ScenarioSteps {

	Report report;

	@Step
	public void filterReport(String reportName) {
		
		// To delete Existing reports in the shared path
		report.clearOldReports(reportName);
		// TODO Auto-generated method stub
		report.filterReport(reportName);
	}

	@Step
	public void verifyReportAfterSearch(String reportName) {
		report.verifyReportAfterSearch(reportName);
	}

	@Step
	public void runNowandVerifyItinOutputsection() {
		report.runNowandVerifyItinOutputsection();
		
	}

	@Step
	public void verifyContentinReport(String reportName,String OutPut_FileType) {

		report.verifyContentInReport(reportName,OutPut_FileType);
	}
	
	@Step
	public void RunWithSpecficFormatAndVerifyItinOutputsection(String Report_Output_Format) {
		
		report.RunWithSpecficFormatAndVerifyItinOutputsection(Report_Output_Format);
	}


}
