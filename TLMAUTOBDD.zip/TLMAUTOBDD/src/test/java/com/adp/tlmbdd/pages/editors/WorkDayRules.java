package com.adp.tlmbdd.pages.editors;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.adp.tlmbdd.pages.GenericPageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;


public class WorkDayRules extends GenericPageObject{

	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElement mainiframe;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame1_iframe']")
	private WebElement subframe;
	
	@FindBy(xpath = "//*[@id='numMaxShiftHours']")
	private WebElementFacade maxShiftHours;
	
	@FindBy(xpath = "//*[contains(text(),'This value is out of range')]")
	private WebElementFacade  outOfrangeerror;
	
	@FindBy(xpath = "//*[@id='barButtons_btnSubmit']")
	private WebElementFacade  shiftHoursSubmit;
	
	@FindBy(xpath = "//*[text()='Operation Successful']")
	private WebElementFacade  operationSuccessfulMessage;
	
	@FindBy(xpath = "//*[@id='btnAddNew']")
	private WebElementFacade  addNewWorkDayRule;
	
	@FindBy(xpath = "//*[@id='txtDailyRule']")
	private WebElementFacade  ruleName;
	
	@FindBy(xpath = "//*[@id='multDesc']")
	private WebElementFacade  ruleDesc;
	
	@FindBy(xpath = "//*[contains(text(),'24 Hour Period Calculation Type')]")
	private WebElementFacade hourPeriodCalculation;
	
	@FindBy(xpath = "//*[@id='ddlCalcType']")
	private WebElementFacade calculationTypeDropdown;
	
	@FindBy(xpath = "//*[@id='tdRollTime']")
	private WebElementFacade RollTime;
	
	@FindBy(xpath = "//*[@id='barButtons_btnSubmit']")
	private WebElementFacade submitButton;
	
	
	By payDateTypeDropDown = By.xpath("//*[@id='ddlRollDirection']");
	
	
	
	
	public void clickOnWorkdayRule(String rule)
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		getDriver().findElement(By.xpath("//*[@id='objZoomTable']//*[contains(text(),'"+rule+"')]")).click();
		WaitForAjax();
		switchToDefaultContent();
	}
	
	public void verifyMaximumShiftHours(String number)
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		maxShiftHours.clear();
		maxShiftHours.sendKeys(number);
		if(Float.valueOf(number)>999.99)
		{
			boolean flag = checkElementVisible(outOfrangeerror);
			Assert.assertEquals(true, flag);
		}
		else if(Float.valueOf(number)<999.99)
		{
			boolean flag = checkElementVisible(outOfrangeerror);
			Assert.assertEquals(false, flag);
		}
		switchToDefaultContent();
		
	}
	
	public void enterMaximumShiftHours(String number)
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		maxShiftHours.clear();
		maxShiftHours.sendKeys(number);
		shiftHoursSubmit.click();
		WaitForAjax();
		Assert.assertTrue(checkElementVisible(operationSuccessfulMessage));
		switchToDefaultContent();
		
	}
	
	public void addWorkDayRule(String shifthours)
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		addNewWorkDayRule.click();
		WaitForAjax();
		ruleName.sendKeys("Rule"+RandomStringUtils.randomNumeric(5));
		ruleDesc.sendKeys("Rule Desc"+RandomStringUtils.randomNumeric(5));
		maxShiftHours.sendKeys(shifthours);
		shiftHoursSubmit.click();
		WaitForAjax();
		Assert.assertTrue(checkElementVisible(operationSuccessfulMessage));
		switchToDefaultContent();
		
	}
	
	public void verifyCalculationTypeDropDownValues()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		Assert.assertTrue(checkElementVisible(hourPeriodCalculation));
		List<String> expectedList = new ArrayList<String>();
		List<String> actualList = new ArrayList<String>();
		expectedList.add("Day by Pay Date");
		expectedList.add("Day by First In Punch of the Pay Period");
		expectedList.add("Day by First In Punch of the Day");
		expectedList.add("Day by First In Punch if Greater of 24 Reset");
		expectedList.add("Day by Recurring Schedule");
		expectedList.add("Day by Reset Time");
		List<WebElement> actualWebElementList = getDriver().findElements(By.xpath("//*[@id='ddlCalcType']/option"));
		for (WebElement webElement : actualWebElementList) {
			actualList.add(webElement.getText());
		}		
				
		Assert.assertEquals(expectedList, actualList);
		switchToDefaultContent();
	}
	
	public void verifyPayDateTypeDropDownValues()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		List<String> expectedList = new ArrayList<String>();
		List<String> actualList = new ArrayList<String>();
		expectedList.add("None");
		expectedList.add("Backward");
		expectedList.add("Forward");
		expectedList.add("As per Every First In Actual Punch");
		List<WebElement> actualWebElementList = getDriver().findElements(By.xpath("//*[@id='ddlRollDirection']/option"));
		for (WebElement webElement : actualWebElementList) {
			actualList.add(webElement.getText());
		}		
				
		Assert.assertEquals(expectedList, actualList);
		switchToDefaultContent();
	}
	
	public void verifyRollTimeGreyedOut()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		waitABit(2000);
		selectValueFromDropDownByVisibleText(payDateTypeDropDown, "As per Every First In Actual Punch");
		Assert.assertTrue(RollTime.getAttribute("disabled")==null);
		submitButton.click(); 
		switchToDefaultContent();
	}
	
	
	
	
	
}
