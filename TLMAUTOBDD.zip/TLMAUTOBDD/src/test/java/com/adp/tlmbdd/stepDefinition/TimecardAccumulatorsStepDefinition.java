package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.TimecardAccumulatorSteps;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class TimecardAccumulatorsStepDefinition {

	@Steps
	TimecardAccumulatorSteps accumulatorSteps;
	
	@Then("^I verify ACROSSPRDTOT is available in Timecard Accumulators$")
	public void i_verify_ACROSSPRDTOT_is_available_in_Accumulator_Balances() throws Throwable {
	    accumulatorSteps.verifyAcrossPrdTotVisible();
	}
	
	@Then("^I verify description$")
	public void i_verify_description() throws Throwable {
	    accumulatorSteps.verifyDescription();
	}
}
