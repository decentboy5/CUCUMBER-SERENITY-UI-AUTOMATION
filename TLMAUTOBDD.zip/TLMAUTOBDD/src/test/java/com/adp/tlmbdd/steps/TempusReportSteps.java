package com.adp.tlmbdd.steps;

import net.thucydides.core.annotations.Step;
import com.adp.tlmbdd.pages.editors.TempusReport;
public class TempusReportSteps {
	
	TempusReport tempusReport;
	
	@Step
	public void runAsExcel() {
		tempusReport.runAsExcel();
	}
	
	@Step
	public void runAsPDF() {
		tempusReport.runAsPDF();
	}
	
	@Step
	public void runAsCSV() {
		tempusReport.runAsCSV();
	}
	
	@Step
	public void employeeList() {
		tempusReport.employeeList();
	}
	
	@Step 
	public void companyCode() {
		tempusReport.companyCode();
	}
	
	@Step
	public void selectOneCompany() {
		tempusReport.selectOneCompany();
	}
	@Step
	public void navigateToWhoAppearsOnTheReport() {
		tempusReport.navigateToWhoAppearsOnTheReport();
	}
	@Step
	public void navigateToWhatIsDisplayedSection() {
		tempusReport.navigateToWhatIsDisplayedSection();
	}
	@Step
	public void navigateToAppearanceSection() {
		tempusReport.navigateToAppearanceSection();
	}
	@Step
	public void runAs(String runFormat) {
		tempusReport.runAs(runFormat);
	}
	
	@Step
	public void selectEmployeeType(String employeeType) {
		tempusReport.selectEmployeeType(employeeType);
	}
	@Step
	public void selectEmployeeType(String employeeType, String employeeType1) {
		tempusReport.selectEmployeeType(employeeType,employeeType1);
	}
	@Step
	public void selectAllTypesOfEmployees() {
		tempusReport.selectAllTypesOfEmployees();
	}
	
	@Step
	public void verifySaveMySettings() {
		tempusReport.verifySaveMySettings();
	}
	@Step
	public void apply() {
		tempusReport.apply();
	}
	@Step 
	public void selectOneDepartment() {
		tempusReport.selectOneDepartment();
	}
	
	@Step
	public void selectAllDepartment() {
		tempusReport.selectAllDepartment();
	}
	
	@Step
	public void selectTimeFrame(String timeFrame) {
		tempusReport.selectTimeFrame(timeFrame);
	}
	@Step
	public void enterDatesForTimeFrame(String date) {
		tempusReport.enterDatesForTimeFrame(date);
	}
	@Step
	public void searchForReport(String reportName) {
		tempusReport.searchForReport(reportName);
	}
	
	@Step
	public void clickOnTimeframe() {
		tempusReport.clickOnTimeframe();
	}
	@Step 
	public void department() {
		tempusReport.department();
	}
	@Step
	public void selectSpecificEmployee() {
		tempusReport.selectSpecificEmployee();
	}
	@Step
	public void selectFiveEmployees() {
		tempusReport.selectFiveEmployees();
	}
	@Step
	public void selectAllFields() {
		tempusReport.selectAllFields();
	}
	@Step
	public void selectSomeFields() {
		tempusReport.selectSomeFields();
	}
	@Step
	public void selectSomeOtherFields() {
		tempusReport.selectSomeOtherFields();
	}
	@Step
	public void includeNotes() {
		tempusReport.includeNotes();
	}
	@Step
	public void includePendingTimeOff() {
		tempusReport.includePendingTimeOff();
	}
	@Step
	public void includePayrollAdjustment(int i) {
		tempusReport.includePayrollAdjustment(i);
	}
	@Step
	public void includePayrollAdjustmentHours() {
		tempusReport.includePayrollAdjustmentHours();
	}
	@Step
	public void includePrintOption() {
		tempusReport.includePrintOption();
	}
	@Step
	public void selectAllOptionsInAppearance() {
		tempusReport.selectAllOptionsInAppearance();
	}
	@Step
	public void addNotes() {
		tempusReport.addNotes();
	}
	@Step
	public void selectAllOptionsInWhoApppears() {
		tempusReport.selectAllOptionsInWhoApppears();
	}
	@Step
	public void selectAllOptionsInWhatIsDisplayedSection() {
		tempusReport.selectAllOptionsInWhatIsDisplayedSection();
	}
	@Step 
	public void selectOnlyCompanyCode() {
		tempusReport.selectOnlyCompanyCode();
	}
	@Step
	public void cancelButton() {
		tempusReport.cancelButton();
	}
	@Step
	public void saveSettingsWithDEfaultOptions() {
		tempusReport.saveSettingsWithDEfaultOptions();
	}
	@Step
	public void saveSettingsWithNonDefaultOptions() {
		tempusReport.saveSettingsWithNonDefaultOptions();
	}
	@Step 
	public void validateReport() {
		tempusReport.validateReport();
	}
	
	@Step
	public void saveSettingsAsCSV() {
		tempusReport.saveSettingsAsCSV();
	}
	@Step
	public void saveSettingsAsCSVWithNonDefaultOptions() {
		tempusReport.saveSettingsAsCSVWithNonDefaultOptions();
	}
	@Step
	public void validateReportAsCSV() {
		tempusReport.validateReportAsCSV();
	}
	@Step
	public void saveSettingsAsExcel() {
		tempusReport.saveSettingsAsExcel();
	}
	@Step
	public void saveSettingsAsExcelWithNonDefaultOptions() {
		tempusReport.saveSettingsAsExcelWithNonDefaultOptions();
	}
	@Step
	public void validateReportAsExcel() {
		tempusReport.validateReportAsExcel();
	}
	@Step
	public void clickOnReport(String reportname) {
		tempusReport.clickOnReport(reportname);
	}
	@Step
	public void saveSettingAndCancel() {
		tempusReport.saveSettingAndCancel();
	}
	@Step 
	public void gotoStandardTab() {
		tempusReport.gotoStandardTab();
	}
	@Step
	public void gotoOutputTab() {
		tempusReport.gotoOutputTab();
	}
	@Step
	public void runAsExcelAndOpenReport() {
		tempusReport.runAsExcelAndOpenReport();
	}
	@Step
	public void runAsPDFAndOpenReport() {
		tempusReport.runAsPDFAndOpenReport();
	}
	@Step
	public void runAsCSVAndOpenReport() {
		tempusReport.runAsCSVAndOpenReport();
	}
	@Step
	public void gotoReportsTab() {
		tempusReport.gotoReportsTab();
	}
	@Step
	public void clickOnThreeDots() {
		tempusReport.clickOnThreeDots();
	}
	@Step 
	public void verifyHeaders() {
		tempusReport.verifyHeaders();
	}
	@Step 
	public void verifyAllOptionsDisplayed() {
		tempusReport.verifyAllOptionsDisplayed();
	}
	@Step
	public void verifyAllComponentsAreDisplayed() {
		tempusReport.verifyAllComponentsAreDisplayed();
	}
	@Step
	public void navigateToReportsTab() {
		tempusReport.navigateToReportsTab();
	}
}
