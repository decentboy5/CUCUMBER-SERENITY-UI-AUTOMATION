package com.adp.tlmbdd.steps;

import java.io.IOException;

import com.adp.tlmbdd.pages.editors.EmploymentProfileTechRefresh;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class EmploymentProfileTechRefreshSteps  extends ScenarioSteps  {
	
	EmploymentProfileTechRefresh employmentProfileTechRefresh;
	
	  	  
	  @Step
		public void ValidateTimeTile(String employeeName) {
			employmentProfileTechRefresh.ValidateTimeTileForTimeEmployee(employeeName);

		}
	 
	  @Step
		public void NavigateToTimeTile(String employeeName) throws Exception {
		  employmentProfileTechRefresh.NavigateToEmploymentProfile(employeeName);
			employmentProfileTechRefresh.NonTimeToTimeusingAddButton("Shaun");
           
		}
	  
	  @Step
		public void ValidateOnHistoryPage() throws Exception {		
			employmentProfileTechRefresh.ValidateOnHistoryPage();
		} 

	  
	  @Step
		public void ConvertNonTimeToTime(String supervisorName) throws Exception {		
			employmentProfileTechRefresh.NonTimeToTimeusingAddButton(supervisorName);
		}
	  
	  @Step
			public void NavigateToTimeTile() throws Exception {		
				employmentProfileTechRefresh.NavigateToTimeTileSlideIn();
			} 
	  
	  @Step
		public void ConvertTimeToNonTime() throws Exception {		
			employmentProfileTechRefresh.TimeToNonTimeusingAddButton();
		} 
	  
	  //Test 4
	 
	  @Step
		public void NavigateToHistoryPageFromTile() throws Exception {		
			employmentProfileTechRefresh.NavigateToHistoryPageFromTimeTile();
		} 
	  @Step
		public void EditDateOnHistoryPage() throws Exception {		
			employmentProfileTechRefresh.EditDateOnHistoryPage();
		} 
	  
	  //Test 5
	  @Step
		public void DeleteEffectiveDatedRecordOnHistoryPage() throws Exception {		
			employmentProfileTechRefresh.ValidateTimeLineAndDeleteRecordFromHistoryPage();
		} 
	  //Test 6
	  @Step
		public void ValidateInfoAndErrorMessages(String EmployeeName, String SupervisorName) throws Exception {		
			employmentProfileTechRefresh.ValidateInfoAndErrorMessageAndUpdatePayclass(EmployeeName,SupervisorName);
		} 
	  //Test 7
	  @Step
		public void ValidateFuturePropogationmessage() throws Exception {		
			employmentProfileTechRefresh.ValidateFuturePropogation();
		} 
	
	  //Test 8
	  @Step
		public void DeleteRecordAndValidate() throws Exception {		
			employmentProfileTechRefresh.DeleteRecordOnSlideIn();
		} 
	  
	  @Step
		public void DeleteRecordFromHistoryPage() throws Exception {		
			employmentProfileTechRefresh.DeleteRecordOnSlideIn();
		} 
	
	//Test 9  
	  
	  @Step
		public void SelectTimeTile() throws Exception {		
		  employmentProfileTechRefresh.NavigateToTimeTileSlideIn();
		} 
	  
	  @Step
		public void ValidatPayClassSummary() throws Exception {		
			employmentProfileTechRefresh.validatePayClassSummary();
		} 
//Test 10 
	  
	  @Step
		public void ValidateAdditionalLinks() throws Exception {		
		  employmentProfileTechRefresh. validateAdditionalDates();
		} 
	  
	  @Step
		public void ValidateTimeClocks() throws Exception {		
		  employmentProfileTechRefresh. TimeClocks(); 
		} 
	  
	  @Step
			public void ValidateOtherRates() throws Exception {		
			  employmentProfileTechRefresh. validateOtherRates(); 
			} 
	  
	  @Step
		public void PhoneAccess() throws Exception {		
		  employmentProfileTechRefresh.phoneaccess(); 
		}
	  
	  @Step
		public void DeptJobRates() throws Exception {		
		  employmentProfileTechRefresh.validateDeptJobRates(); 
		}
	  
	  @Step
		public void ValidateMobile(String Location) throws Exception {		
		  employmentProfileTechRefresh.ValidateMobile(Location); 
		}
	  
	  @Step
		public void ValidateNotification(String Notification) throws Exception {		
		  employmentProfileTechRefresh.ValidateMobile(Notification); 
		}
	  
	  
	  
	  
	  /***********Prac Supervisor Employee  cases***********/
	  
	  @Step
			public void PracReadOnly() throws Exception {		
			  employmentProfileTechRefresh.PractitionerReadOnlyModeValidations(); 
			}
	  
	  public void ValidateManager(String EmployeeName) throws Exception {		
		  employmentProfileTechRefresh.ManagerOnlyValidation(EmployeeName); 
		}
		  	
	  
	  public void ValidateSupervisor() throws Exception {		
		  employmentProfileTechRefresh.SupervisorOnlyValidation(); 
		}
	  
	  public void ValdiateSupermanAsManagerAndSupervisor(String EmployeeOne, String EmployeeTwo) throws Exception {		
		  employmentProfileTechRefresh.SupermanValidation(EmployeeOne,EmployeeTwo); 
		}
	  
	  public void ValdiateSuperman(String EmployeeThree) throws Exception {		
		  employmentProfileTechRefresh.SupermanAsSupervisor(EmployeeThree); 
		}
	  
	  public void ValidateEmployee() throws Exception {		
		  employmentProfileTechRefresh.EmployeeValidation(); 
		}
	  
}
