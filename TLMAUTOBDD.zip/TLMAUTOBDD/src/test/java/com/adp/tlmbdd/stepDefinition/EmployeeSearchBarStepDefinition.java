package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.EmployeeBarSteps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class EmployeeSearchBarStepDefinition {
	@Steps
	EmployeeBarSteps employeeBarSteps;
	
	@Given("^I Selected Employee \"([^\"]*)\"$")
	public void i_selected_employee(String employeeName) throws Throwable {
		employeeBarSteps.selectEmployee(employeeName);
	}
}
