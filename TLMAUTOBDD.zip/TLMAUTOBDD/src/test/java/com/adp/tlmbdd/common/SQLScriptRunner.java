package com.adp.tlmbdd.common;

import java.io.InputStream;
import java.io.StringReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import com.ibatis.common.jdbc.ScriptRunner;

public class SQLScriptRunner {
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static Connection getConnection() throws Exception {
		Properties dbProperties = getDbPropertiees();
		// Create Oracle Connection
		Connection con = DriverManager.getConnection(
				"jdbc:oracle:thin:@" + dbProperties.getProperty("HOST") + ":1521/" + dbProperties.getProperty("SID"),
				dbProperties.getProperty("USERNAME"), dbProperties.getProperty("DBPASSWORD"));
		return con;
	}

	public static void run(String sql, Map<String, Object> queryParams) throws Exception {
		try (Connection con = getConnection()) {
			setVPDContext(con);
			// Initialize object for ScripRunner
			ScriptRunner sr = new ScriptRunner(con, false, false);
			// Give the input file to Reader
			sql = setQueryParams(sql, queryParams);
			sr.runScript(new StringReader(sql));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void executeUpdate(String sql, Map<String, Object> queryParams) throws Exception {
		Statement stmt = null;
		try (Connection con = getConnection()) {
			setVPDContext(con);
			// Initialize object for ScripRunner
			stmt = con.createStatement();
			// Give the input file to Reader
			sql = setQueryParams(sql, queryParams);
			System.out.println(sql);
			stmt.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void executeUpdate(String sqlWithPositionalParameters, List<String> params) throws Exception {
		try (Connection con = getConnection()) {
			setVPDContext(con);
			// Initialize object for ScripRunner
			PreparedStatement stmt = con.prepareStatement(sqlWithPositionalParameters); 
			// Give the input file to Reader
			setPreparedQueryParams(stmt, params);
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void setPreparedQueryParams(PreparedStatement stmt, List<String> params) throws SQLException {
		for(int i = 0;i<params.size();i++){
			if(params.get(i) == null){
				stmt.setNull(i+1, java.sql.Types.VARCHAR);
			}else{
				stmt.setString(i+1, params.get(i));
			}
		}
	}

	public static List<Map<String, String>> executeQuery(String sql, Map<String, Object> queryParams) throws Exception {
		List<Map<String, String>> data = null;
		try (Connection con = getConnection()) {
			setVPDContext(con);
			
			Statement stmt = con.createStatement();
			sql = setQueryParams(sql, queryParams);
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			List<String> columns = new ArrayList(rsmd.getColumnCount());
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				columns.add(rsmd.getColumnName(i));
			}
			data = new ArrayList<Map<String, String>>();
			while (rs.next()) {
				Map<String, String> row = new HashMap<String, String>(columns.size());
				for (String col : columns) {
					row.put(col, rs.getString(col));
				}
				data.add(row);
			}
			System.out.println(data);
			rs.close();
			stmt.close();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return data;
	}
	public static void setVPDContext(Connection con) throws Exception{
		String call = "{ call SP_SET_CONNMGRCLIENTCTX(?, ?) }";
			Properties dbProperties = getDbPropertiees();
			CallableStatement cstmt = con.prepareCall(call);
			cstmt.setString(1, "8yf4MSiiMueJ41nwn5RQxeb8p~"+dbProperties.getProperty("VPD_KEY"));
			cstmt.setString(2, dbProperties.getProperty("USERNAME"));
			cstmt.executeQuery();
	}

	public static Properties getDbPropertiees() throws Exception {
		Properties prop = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream stream = loader.getResourceAsStream(SQLQueryConstant.DB_PROPS);
		prop.load(stream);
		return prop;
	}

	private static String setQueryParams(String sql, Map<String, Object> queryParams) {
		for (Entry<String, Object> entry : queryParams.entrySet()) {
			System.out.println(entry);
			if (entry.getValue() != null && entry.getValue() instanceof Collection) {
				// iterate and form in params like "a","b","c"
				// TODO
			} else if (entry.getValue() == null) {
				sql = sql.replaceAll(":" + entry.getKey(), "null");
			} else {
				sql = sql.replaceAll(":" + entry.getKey(), "'" + entry.getValue() + "'");
			}
		}
		return sql;
	}

	/*
	 * public static String getSQLString(String filename) throws
	 * FileNotFoundException { StringBuilder sql = new StringBuilder();
	 * ClassLoader classLoader = SQLScriptRunner.class.getClassLoader(); File
	 * file = new File(classLoader.getResource(filename).getFile());
	 * System.out.println(file.getAbsolutePath()); Scanner sc = new
	 * Scanner(file); while (sc.hasNext()) { sql.append(sc.nextLine()); }
	 * sc.close(); return sql.toString(); }
	 */
}
