package com.adp.tlmbdd.pages.editors;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class TimecardAccumulators extends GenericPageObject{

	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElement mainiframe;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame1_iframe']")
	private WebElement subframe;
	
	@FindBy(xpath = "//span[text()='ACROSSPRDTOT']")
	private WebElementFacade acrossPRDTOTButton;
	
	@FindBy(xpath = "//span[text()='Across Period Total']")
	private WebElementFacade description;
	
	
	public void verifyAcrossPrdTotInTimecardAccumulators()
	{
		Assert.assertTrue(checkElementVisible(acrossPRDTOTButton));
	}
	
	public void verifyDescription()
	{
		Assert.assertTrue(checkElementVisible(description));
	}
	
}
