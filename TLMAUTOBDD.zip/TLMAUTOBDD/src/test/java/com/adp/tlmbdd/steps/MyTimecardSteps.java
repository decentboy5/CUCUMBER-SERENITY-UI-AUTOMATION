package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.MyTimecard;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class MyTimecardSteps extends ScenarioSteps {

	MyTimecard mytimecard;

	@Step
	public void empEnterTime(String payPeriod,String hours,String department, String job) {
		mytimecard.addTimePair(payPeriod, hours,department,job);	
		saveTimecard();
	}
		
	public boolean saveTimecard()
	{
		mytimecard.saveTimecard();
		return true;
	}
	
	@Step
	public void approveTimecard(String payPeriod) {
		mytimecard.approveTimecard(payPeriod);
	}	
	
	@Step
	public void selectPayPeriod(String payPeriod) {
	mytimecard.selectpayPeriod(payPeriod);
	}
}

