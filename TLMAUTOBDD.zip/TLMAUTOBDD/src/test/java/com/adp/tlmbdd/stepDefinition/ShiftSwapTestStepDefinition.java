package com.adp.tlmbdd.stepDefinition;


import com.adp.tlmbdd.steps.*;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class ShiftSwapTestStepDefinition {
	@Steps
	ShiftSwapTestSteps shiftSwapTestSteps;
	
	@Then("^I delete all notifications$")
	public void i_delete_all_notifications() throws Throwable {
		shiftSwapTestSteps.deleteNotifications();
	}
	
	@Then("^I cancel all previous swap requests$")
     public void i_cancel_all_previous_swap_requests() throws Throwable {
	    
		shiftSwapTestSteps.senderCancelAllSwapRequests();
	    //throw new PendingException();
	}
	
	@Then("^I cancel all previous swap requests pending for approval$")
	public void i_cancel_all_previous_swap_requests_pending_for_approval() throws Throwable {
		shiftSwapTestSteps.senderCancelAllSwapRequestsPendingForApproval();
		//throw new PendingException();
	}
	
	@When("^I create shift swap request with \"([^\"]*)\"$")
	public void i_create_shift_swap_request_with(String reciever) throws Throwable {
		
		shiftSwapTestSteps.createShiftSwapRequest(reciever);
	}

	@Then("^I verify that shift swap request created successfully by success Popup$")
	public void i_verify_that_shift_swap_request_created_successfully_by_success_popup() throws Throwable {
		shiftSwapTestSteps.verifyShiftSwapRequestBySuccessPopUp();
	  //  throw new PendingException();
	}
	
	@Then("^I verify sent Swap box in my schedule page$")
	public void i_verify_sent_Swap_box_in_my_schedule_page() throws Throwable {
		shiftSwapTestSteps.verifySentSwapBox();
	    //throw new PendingException();
	}
	
/*	@Then("^I Verify that request notfication is sent to \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_Verify_that_request_notfication_is_sent_to_and(String Supervisor, String Recipient) throws Throwable {
		shiftSwapTestSteps.verifyNotificationSentToSuperVisorAndRecipient(Supervisor, Recipient);
	    //throw new PendingException();
	}   */
	
    ///////////////////scenario 2/////////
	
	@Then("^I observ recieved Swap request box in my schedule page$")
	public void i_observ_recieved_Swap_request_box_in_my_schedule_page() throws Throwable {
		shiftSwapTestSteps.observRecivedRequest();
	}
	
/*(	//reciever is verifying in its notification
	@Then("^I verify the request with sender in notification \"([^\"]*)\"$")
	public void i_verify_the_request_with_sender(String sender, String reciever) throws Throwable {
		shiftSwapTestSteps.verifyRequestInNotification( sender, reciever);
		//throw new PendingException();
	}
*/	
	
	@Then("^I verify the sent request notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void i_verify_the_sent_request_notification_with_sender_and_reciever(String sender, String reciever) throws Throwable {
		shiftSwapTestSteps.verifyRequestInNotification( sender, reciever);
		//throw new PendingException();
	}
	
	
	
	@Then("^I verify the accept request notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void i_verify_the_accept_request_notification_with_sender_and_reciever(String sender, String reciever) throws Throwable {
		shiftSwapTestSteps.verifyAcceptedRequestInNotification( sender, reciever);
	}
	
	/*
	//Supervisor is verifying in its notification
	@Then("^I verify in the notification that sender \"([^\"]*)\" request for swap with recipient \"([^\"]*)\"$")
	public void i_verify_in_the_notification_that_sender_request_for_swap_with_recipient(String sender, String recipient) throws Throwable {
		shiftSwapTestSteps.SuperVerifyRequestInNotification(sender,recipient);
	}
*/
	@Then("^I search active swap request$")
	public void i_search_active_swap_request() throws Throwable {
		shiftSwapTestSteps.searchActiveSwapRequest();
		//throw new PendingException();
	}


	@Then("^I accept swap request$")
	public void i_accept_swap_request() throws Throwable {
		shiftSwapTestSteps.acceptSwapRequestFromSlider();
		//throw new PendingException();
	}
	
	@Then("^I accept swap request through popup$")
	public void i_accept_swap_request_through_popup() throws Throwable {
		shiftSwapTestSteps.acceptSwapRequestThroughPopUp();
	}
	
	@Then("^I verify pending approval indicator$")
	public void i_verify_pending_approval_indicator() throws Throwable {
		shiftSwapTestSteps.verifyPendingApprovalBox();
	}
	

	@Then("^I verfiy the request accepted successfully$")
	public void i_verfiy_the_request_accepted_successfully() throws Throwable {
		shiftSwapTestSteps.verifyAcceptanceBySuccessMessage();
		//throw new PendingException();
	}
	
	@Then("^I vefify accept request notification$")
	public void i_vefify_accept_request_notification() throws Throwable {
		shiftSwapTestSteps.verifyAcceptNotification();
	}

	
	
	//////////////////Scenario 3--> supervisor///////////
	
	@Then("^I  search and view notification of approval at schedule page$")
	public void i_search_and_view_notification_of_approval_at_schedule_page() throws Throwable {
		shiftSwapTestSteps.viewApprovalRequest();
	}

	@Then("^I verify request with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_verify_request_with_and(String requester, String recipient) throws Throwable {
		shiftSwapTestSteps.verifyApprovalRequestFromSlider(requester, recipient);
	   // throw new PendingException();
	}

	
	
	@Then("^I Approve the request through banner$")
	public void i_Approve_the_request_through_banner() throws Throwable {
		shiftSwapTestSteps.ApproveRequestFromViewSlider(); 
	}

	@Then("^I verify the approved request notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void i_verify_the_approved_request_notification_with_sender_and_reciever(String sender, String recipient) throws Throwable {
		shiftSwapTestSteps.verifyApprovedNotification(sender, recipient);
	}
	
	@Then("^I verify request notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\" is approved by \"([^\"]*)\"$")
	public void i_verify_request_notification_with_sender_and_reciever_is_approved_by(String sender, String recipient, String supervisor) throws Throwable {
		shiftSwapTestSteps.verifyApprovedNotification(sender, recipient, supervisor);
	}
	
	@Then("^I verify pending approval request rejected by \"([^\"]*)\" notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void i_verify_pending_approval_request_rejected_by_notification_with_sender_and_reciever(String supervisor, String sender, String recipient ) throws Throwable {
		shiftSwapTestSteps.verifyRejectRequestNotification(supervisor, sender, recipient);
	}


	@Then("^I decline swap request through popup$")
	public void i_decline_swap_request_through_popup() throws Throwable {
		shiftSwapTestSteps.declineSwapRequestThroughPopup();
	}

	@Then("^I verfiy the request declined successfully$")
	public void i_verfiy_the_request_declined_successfully() throws Throwable {
		shiftSwapTestSteps.verifyDeclinedRequest();
	}

	@Then("^I verify the decline request notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void i_verify_the_decline_request_notification_with_sender_and_reciever(String sender, String recipient) throws Throwable {
		shiftSwapTestSteps.verifyDeclineRequestNotification(sender,recipient);
	}

	@Then("^I decline swap request through slider$")
	public void i_decline_swap_request_through_slider() throws Throwable {
		shiftSwapTestSteps.declineRequestThrughSlider();
	}
	
	@Then("^I verify that recieved request declined successfully by my schedule page$")
	public void i_verify_that_recieved_request_declined_successfully_by_my_schedule_page() throws Throwable {
	    shiftSwapTestSteps.verifyDeclinedRecievedRequestMyschedule();
	}

	
	@Then("^I reject pending approval request through banner$")
	public void i_reject_pending_approval_request_through_banner() throws Throwable {
		shiftSwapTestSteps.rejectRequestThroughBannner();
	}
	

	@Then("^I verify rejected request notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void i_verify_rejected_request_notification_with_sender_and_reciever(String sender, String recipient) throws Throwable {
	    shiftSwapTestSteps.verifyRejectRequestNotification(sender, recipient);
	}

	
	@Then("^I approve pending approval request through Popup \"([^\"]*)\"$")
	public void i_approve_pending_approval_request_through_Popup(String sender) throws Throwable {
	    shiftSwapTestSteps.ApproveRequestThroughPopUp(sender);
	}

	
	@Then("^I reject pending approval request through Popup \"([^\"]*)\"$")
	public void i_reject_pending_approval_request_through_Popup(String sender) throws Throwable {
		shiftSwapTestSteps.rejectRequestThroughPopUp(sender);
	}
	
	@Then("^I cancel all sent requests through slider$")
	public void i_cancel_all_sent_requests_through_slider() throws Throwable {
	   shiftSwapTestSteps.cancelAllSentRequestThroughSlider();
	}
	
	
	//////////  Multiple Swap request/////////
/*	
	@When("^I create multiple (\\d+) shift swap request with \"([^\"]*)\"$")
	public void i_create_multiple_shift_swap_request_with(int number, String recipient) throws Throwable {
	    shiftSwapTestSteps.createMultipleSwapRequest(number,recipient);
	}
*/	
	
	
	@When("^I create single shift swap request with multiple employee \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_create_single_shift_swap_request_with_multiple_employee_and(String recipient1, String recipient2) throws Throwable {
		 shiftSwapTestSteps.createMultipleSwapRequest(recipient1,recipient2);
	}
	
	@Then("^I verify the sent request notification with sender \"([^\"]*)\" and multiple recipient \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_verify_the_sent_request_notification_with_sender_and_multiple_recipient_and(String sender, String recipient1, String recipient2) throws Throwable {
	    shiftSwapTestSteps.verifyMultipleEmpRequestNotification(sender, recipient1, recipient2);
	}
	
	@Then("^I verify notification that request is automatically canceled with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_verify_notification_that_request_is_automatically_canceled_with_and(String sender, String reciever) throws Throwable {
	    shiftSwapTestSteps.verfyNotificationForAutomaticallyCancelledRequest(sender,reciever);
	}
	
	@When("^I create shift swap request with \"([^\"]*)\" on last day of the month for next month$")
	public void i_create_shift_swap_request_with_on_last_day_of_the_month_for_next_month(String recipient) throws Throwable {
	    shiftSwapTestSteps.createRequestLastDayForNextMonthStep(recipient);
	}
	
	@Then("^I verify that the holiday shift is not available for shift swap with recipient \"([^\"]*)\"$")
	public void i_verify_that_the_holiday_shift_is_not_available_for_shift_swap_with_recipient(String recipient) throws Throwable {
	    shiftSwapTestSteps.verifyHolidayShiftNotOnTargetSlider(recipient);
	}
	
	@Then("^I verify that the PTO is not available for shift swap with recipient \"([^\"]*)\"$")
	public void i_verify_that_the_PTO_is_not_available_for_shift_swap_with_recipient(String recipient) throws Throwable {
		shiftSwapTestSteps.verifyPTONotOnTargetSlider(recipient);
	}
    
	@Then("^I verify that shift swap is not allowed after allowed (\\d+)$")
	public void i_verify_that_shift_swap_is_not_allowed_after_allowed(int maxDaySwapAllowed) throws Throwable {
	    shiftSwapTestSteps.verifyMaxDaySwapAllowed(maxDaySwapAllowed);
	}
	
	@When("^I create shift swap request with \"([^\"]*)\" with expiration time (\\d+) minutes$")
	public void i_create_shift_swap_request_with_with_expiration_time_minutes(String recipient, int expirationTime) throws Throwable {
	   shiftSwapTestSteps.createSwapRequestWithExpirationTime(recipient,expirationTime);
	}

	@Then("^I wait for (\\d+) minutes and refresh$")
	public void i_wait_for_minutes_and_refresh(int expirationTime) throws Throwable {
	    shiftSwapTestSteps.waitAndRefresh( expirationTime );
	}

	@Then("^I observ that sent swap box in not displayed$")
	public void i_observ_that_sent_swap_box_in_not_displayed() throws Throwable {
		shiftSwapTestSteps.verifySentSwapRequestNotPresentAtMySchedule();
	}
	
	@Then("^I observ that pending approval box in not displayed$")
	public void i_observ_that_pending_approval_box_in_not_displayed() throws Throwable {
	   shiftSwapTestSteps.verifyPendingApprovalRequestNotPresentAtMySchedule();
	}
	
	@When("^I create single shift swap request with multiple employee \"([^\"]*)\" and \"([^\"]*)\" and expiration time (\\d+) minutes$")
	public void i_create_single_shift_swap_request_with_multiple_employee_and_and_expiration_time_minutes(String recipient1, String recipient2, int expirationTime) throws Throwable {
	    shiftSwapTestSteps.multipleEmpRequestWithExpiry(recipient1,recipient2,expirationTime);
	}

	@Then("^I observ that recieved request box in not displayed$")
	public void i_observ_that_recieved_request_box_in_not_displayed() throws Throwable {
	   shiftSwapTestSteps.verifyRecievedRequestNotPresentAtMySchedule();
	}
	

	@Then("^I observ that there is no pending approval request in schedule page with sender \"([^\"]*)\"$")
	public void i_observ_that_there_is_no_pending_approval_request_in_schedule_page_with_sender(String sender) throws Throwable {
	    shiftSwapTestSteps.verifyNoPendingRequestAtSchedule(sender);
	}
	
	@Then("^I change Lunch Plan of sent swap request  through Popup of sender \"([^\"]*)\"$")
	public void i_change_Lunch_Plan_of_sent_swap_request_through_Popup_of_sender(String sender) throws Throwable {
		shiftSwapTestSteps.changeLunchPlanOfSentSwapRequest(sender);
	}
	
	@Then("^I change Lunch Plan of pending approval request through Popup of sender \"([^\"]*)\"$")
	public void i_change_Lunch_Plan_of_pending_approval_request_through_Popup_of_sender(String sender) throws Throwable {
	   shiftSwapTestSteps.changeLunchPlanOfPendingApprovalRequest(sender);
	}

	@Then("^I observ that there is no sent swap request in schedule page with sender \"([^\"]*)\"$")
	public void i_observ_that_there_is_no_sent_swap_request_in_schedule_page_with_sender(String sender) throws Throwable {
		shiftSwapTestSteps.noSentSwapRequestInSchedule(sender);
	}
	
	@Then("^I verify shift swap request Expiry notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void i_verify_shift_swap_request_Expiry_notification_with_sender_and_reciever(String sender, String recipient) throws Throwable {
		shiftSwapTestSteps.verifyShiftSwapRequestExpiryNotification(sender, recipient);
	}
	
	@Then("^I verify notification for auto cancel by editing shift with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_verify_notification_for_auto_cancel_by_editing_shift_with_and(String sender, String recipient) throws Throwable {
	    shiftSwapTestSteps.verifyAutoCancelNotificationOnShiftEdit(sender, recipient);
	}
	
	@Then("^I review all notifications$")
	public void i_review_all_notifications() throws Throwable {
	    shiftSwapTestSteps.reviewTLMNotification();
	}
	
	
	
	@Then("^I verify the sent request notification in TLM Sup with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void iVerifyTheSentRequestNotificationInTLMSupWithSenderAndReciever(String sender, String reciever) throws Throwable {
	//	shiftSwapTestSteps.TLMSupSentRequestNotification(sender,reciever);
		
	}

	
	@Then("^I observ that there is no target shift for lock period \"([^\"]*)\" with \"([^\"]*)\"$")
	public void iObservThatThereIsNoTargetShiftForLockPeriodWith(String lockPeriod,String reciever) throws Throwable {
	//	shiftSwapTestSteps.observTargetShiftsForLockPeriod(lockPeriod,reciever);
	}

	@Then("^I verify the sender cancel request notification with sender \"([^\"]*)\" and reciever \"([^\"]*)\"$")
	public void iVerifyTheSenderCancelRequestNotificationWithSenderAndReciever(String sender, String reciever) throws Throwable {
	//	shiftSwapTestSteps.senderCancelRequestNotification(sender, reciever);
	}
	

	
}
