package com.adp.tlmbdd.steps;


import com.adp.tlmbdd.pages.AdditionalConfiguration;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class AdditionalConfigurationSteps extends ScenarioSteps  {

	AdditionalConfiguration additionalConf;
	
	@Step
	public void clickCompanyPreferences()
	{
		additionalConf.clickCompanyPreferences();
	}
	
	@Step
	public void clickWorkDayRules()
	{
		additionalConf.clickWorkDayRules();
	}
	
	@Step
	public void clickPayClasses()
	{
		additionalConf.clickPayClasses();
	}
	
	@Step
	public void clickTimecardAccumulators()
	{
		additionalConf.clickTimecardAccumulators();
	}
	
	@Step
	public void clickHourDistributionRule()
	{
		additionalConf.clickHourDistributionRules();
	}
	
	@Step
	public void clickPayCodes()
	{
		additionalConf.clickPayCodes();
	}
}
