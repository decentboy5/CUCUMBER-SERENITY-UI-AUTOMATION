package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.WorkDayRuleSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class WorkDayRulesStepDefinition {

	@Steps WorkDayRuleSteps dayRuleSteps;
	
	@And("^I select a work day rule as \"([^\"]*)\"$")
	public void i_select_a_work_day_rule_as(String rule) throws Throwable {
	    
		dayRuleSteps.clickOnWorkdayRule(rule);
	}

	@Then("^I verify work day rule takes \"([^\"]*)\"$")
	public void i_verify_work_day_rule_takes(String number) throws Throwable {
	    
		dayRuleSteps.verifyMaximumShiftHours(number);
	}
	
	@Then("^I Verify after adding \"([^\"]*)\" hours and clicking submit$")
	public void i_Verify_after_adding_hours_and_clicking_submit(String number) throws Throwable {
	    dayRuleSteps.enterMaximumShiftHours(number);
	}
	
	@Then("^I add a new workday rule with shift hours \"([^\"]*)\"$")
	public void i_add_a_new_workday_rule_with_shift_hours(String shifthours) throws Throwable {
	 
		dayRuleSteps.addAndVerifyNewWorkdayrule(shifthours);
	}
	
	@Then("^I verify all dropdown values of Period Caluculation Type$")
	public void i_verify_all_dropdown_values_of_Period_Caluculation_Type() throws Throwable {
	 
		dayRuleSteps.verifyDropDownValues();
	}
	
	@Then("^I verify all dropdown values of Pay Date Type$")
	public void i_verify_all_dropdown_values_of_Pay_Date_Type() throws Throwable {
	   dayRuleSteps.verifyPayDateDropdownValues();
	}

	@Then("^I select As per Every First In Actual Punch option and verify roll time is greyed out$")
	public void i_select_As_per_Every_First_In_Actual_Punch_option_and_verify_roll_time_is_greyed_out() throws Throwable {
	   dayRuleSteps.verifyRollTimeGreyedOut();
	}
	
	
	
	
}
