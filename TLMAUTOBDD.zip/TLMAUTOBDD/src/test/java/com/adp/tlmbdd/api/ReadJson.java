package com.adp.tlmbdd.api;

import java.io.FileNotFoundException;
import java.io.FileReader;

import org.junit.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ReadJson
{
	
	@Test
	public void JsonRead()
	{		
			
			try
			{
			JsonParser parser = new JsonParser();
			//JsonParser to convert JSON string into Json Object			
			Object obj = parser.parse(new FileReader("C:\\AutomationRuns\\newfile.json"));
			//parsing the JSON string inside the file that we created earlier.
			JsonObject jsonObject = (JsonObject)obj;
			System.out.println(jsonObject);
			//Json string has been converted into JSONObject
			String jsonStr = jsonObject.toString();				
			RestAssured.baseURI = "http://adminportal-fit1.es.ad.adp.com/ELAdminPortal/api/WFNOTGClient/CreateNewClient";
		    RequestSpecification httpRequest = RestAssured.given();
		    httpRequest.header("Content-Type","application/json");
			httpRequest.body(jsonStr);    
		    Response response = httpRequest.post();				
		    System.out.println("Request Body is => " + jsonObject);
		    System.out.println("Response is =>  " + response.asString());
		    System.out.println("Response code is =>  " + response.getStatusCode());    		  
			}	
			catch (FileNotFoundException e) {
			e.printStackTrace();
	}
	}
}
