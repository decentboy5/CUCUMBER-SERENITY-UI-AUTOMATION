package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.HourDistributionRuleSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class HourDistributionRuleStepDefinition {

	@Steps
	HourDistributionRuleSteps distributionRuleSteps;
	
	@And("^I click on \"([^\"]*)\"$")
	public void i_click_on(String rule) throws Throwable {
	    distributionRuleSteps.clickHourDistributionRule(rule);
	}

	@Then("^I Verify ACROSSPRDTOT is not present in time card in hour distribution rule$")
	public void i_Verify_ACROSSPRDTOT_is_not_present_in_time_card_in_hour_distribution_rule() throws Throwable {
		distributionRuleSteps.verifyACROSSPRDTOTNotAvailable();
	}
	
	@And("^I click on add new button$")
	public void i_click_on_add_new_button() throws Throwable {
	    distributionRuleSteps.addNewHourDistributionRule();
	}
	
	@And("^I click on copy button$")
	public void i_click_on_add_copy_button() throws Throwable {
	    distributionRuleSteps.copyHourDistributionRule();
	}

}
