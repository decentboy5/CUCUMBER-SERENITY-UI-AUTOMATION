package com.adp.tlmbdd.stepDefinition;
import com.adp.tlmbdd.steps.*;

import net.thucydides.core.annotations.Steps;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GenerateTimeBatchStepDefinition {
	@Steps
	GenerateTimeBatchSteps timeBatchSteps;
	
	@Then("^I generate Time batch for \"([^\"]*)\" and \"([^\"]*)\"$")
	public void  I_generate_Time_batch_for_and(String compCode, String payCycleID) throws Throwable {
	   
		timeBatchSteps.timeBatchsingle(compCode, payCycleID);
	}
	

}
