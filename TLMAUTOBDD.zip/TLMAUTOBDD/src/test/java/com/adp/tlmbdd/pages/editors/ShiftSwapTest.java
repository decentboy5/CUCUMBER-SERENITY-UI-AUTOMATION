package com.adp.tlmbdd.pages.editors;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.pages.GenericPageObject;

public class ShiftSwapTest extends GenericPageObject {

	@FindBy(xpath = "//*[@id='ShiftSwapRecievedRequestDetailsPopUp.Decline']")
	private WebElementFacade popupPendingApprovalRequestCancelBtn;
	// *[@id='ShiftSwapRecievedRequestDetailsPopUp.Decline']

	@FindBy(xpath = "//*[@id='ShiftSwapSentRequestPopupDetails.Cancel']")
	private WebElementFacade popupRequestCancelBtn;

	@FindBy(xpath = "//*[@id='SwapActionConfirmationDialog.Yes']")
	private WebElementFacade popupRequestConfirmCancelBtn;

	@FindBy(xpath = "//*[@id='TargetSwapSlideInView.Submit']")
	private WebElementFacade TargetSwapSendBtn;

	@FindBy(xpath = "(//*[@class='shiftSpan'])[1]")
	private WebElementFacade TargetSwapBox;

	@FindBy(xpath = "//*[@id='TargetSwapSlideInView.ExpiryDate']")
	private WebElementFacade ExpiryDateSetUpAtTargetSlider;

	@FindBy(xpath = "//*[@id='TargetSwapSlideInView.ExpiryTime.input']")
	private WebElementFacade ExpiryTimeSetUpAtTargetSlider;

	@FindBy(xpath = "//*[@id='SchedulingCalendarMonthlyView.btnNextMonth']")
	private WebElementFacade nextMonthButtonAtMySchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarMonthlyView.btnPrevMonth']")
	private WebElementFacade prevMonthButtonAtMySchedule;

	@FindBy(xpath = ".//*[@id='SchedulingCalendarMonthlyView.MonthWeekToggleButton.switch']")
	private WebElementFacade ToggleButton;

	// @FindBy(xpath
	// ="(//div[@class='emp-shift emp-disabled-shift overflowElipses emp-regular-shift'])[1]")
	// private WebElementFacade TargetSwapBox;

	@FindBy(xpath = "(//div[@class='swapEligibleBox'])[1]")
	private WebElementFacade SwapEligiblebox;

	@FindBy(xpath = ".//*[@id='ShiftSwapToolTip.ShiftSwap']")
	private WebElementFacade ShiftSwapButton;

	@FindBy(xpath = "//*[@id='ShiftSwapSentRequestPopupDetails.dialog_Title']/div")
	private WebElementFacade ShiftSwapPopup;

	@FindBy(xpath = "//*[@id='ShiftSwapSentRequestPopupDetails.Close']")
	private WebElementFacade SentRequestPopupCancelBtn;

	@FindBy(xpath = "//*[@id='TargetSwapSlideInView.SearchEmployee.button']")
	private WebElementFacade TargetSwapEmpSearch;

	@FindBy(xpath = ".//*[@id='TargetSwapSlideInView.SearchEmployee']")
	private WebElementFacade TargetSwapEmpSearchSlider;

	@FindBy(xpath = ".//*[@id='SchedulingCalendarMonthlyView.History']")
	private WebElementFacade SchedulingCalendar;

	@FindBy(xpath = ".//*[@id='SchedulingCalendarMonthlyView.txtCurrentDate.wrapper']")
	private WebElementFacade currentMonthByMySchedule;

	@FindBy(xpath = ".//*[@id='ShiftSwapSlideIn_Close']")
	private WebElementFacade TargetSliderBackButton;

	@FindBy(xpath = "//*[@id='TargetSwapSlideInView.Message.textArea']")
	private WebElementFacade commentBoxRequestCreation;

	// ///////////Scenario2///////////

	@FindBy(xpath = "//*[@id='enhancedMessageCenter'   or  @title='Message Center']")
	private WebElementFacade messageCentre;

	@FindBy(xpath = "//*[@id='enhancedMessageCenter']")
	private WebElementFacade WFNmessageCentre;

	@FindBy(xpath = "//*[text()='View All messages']")
	private WebElementFacade viewAllMessage;

	@FindBy(xpath = "//*[text()='View All Messages']/parent::span")
	private WebElementFacade viewAllMessageTLM;

	@FindBy(xpath = "//*[@class='fa fa-angle-right']")
	private WebElementFacade rightAngleSignForReviewTLMNotification;

	@FindBy(xpath = "//*[@class='dijitTabInnerDiv']")
	private WebElementFacade IsTLMNotification;

	// *[@id='btnGoToMessageCenter']
	@FindBy(xpath = ".//*[@class='BTN_Row']//span[@id='btnGoToMessageCenter']//span[text()='Go to Message Center']")
	private WebElementFacade afterReviewRequestGoToMessageCentreTLM;

	@FindBy(xpath = "//*[text()='Shift Swap Approved']/parent::a/parent::td/parent::tr//*[@class='table-grid-cell ACTION']//*[@class='fa fa-angle-right']")
	private WebElementFacade shiftApprovedTLMNotification;

	@FindBy(xpath = "//*[text()='Shift Swap Requested']/parent::a/parent::td/parent::tr//*[@class='table-grid-cell ACTION']//*[@class='fa fa-angle-right']")
	private WebElementFacade shiftRequestTLMNotification;

	@FindBy(xpath = "//*[text()='Shift Swap Rejected']/parent::a/parent::td/parent::tr//*[@class='table-grid-cell ACTION']//*[@class='fa fa-angle-right']")
	private WebElementFacade shiftRejectedTLMNotification;

	@FindBy(xpath = "//*[text()='Shift Swap Accepted - Ready for Approval']/parent::a/parent::td/parent::tr//*[@class='table-grid-cell ACTION']//*[@class='fa fa-angle-right']")
	private WebElementFacade shiftPendingApprovalTLMNotification;

	// *[@class=' gridActionLink ']

	@FindBy(xpath = "//*[@class=' gridActionLink ']")
	private WebElementFacade reviewTLMNotification;

	@FindBy(xpath = "//*[@id='emcNorNot']")
	private WebElementFacade notificationsBtn;

	@FindBy(xpath = "//*[@class='messagesTable']/tbody/tr[2]/td/div[2]/h2[1]/b")
	private WebElementFacade notification;

	@FindBy(xpath = "//*[@id='SchedulingCalendarMonthlyView.SwapRequestDetailsLink']")
	private WebElementFacade activeSwapRequest;

	// @FindBy(xpath ="//*[contains(text(), 'ACTIVE SWAP REQUESTS'')]")
	// private WebElementFacade activeSwapRequest;

	@FindBy(xpath = "//*[@id='RequestFilter_SENT']")
	private WebElementFacade activeSwapRequestSent;
	
	@FindBy(xpath = "//a[contains(text(),'Sent Requests')]")
	private WebElementFacade activeSwapRequestSentV19;

	@FindBy(xpath = "//*[@id='ShiftSwapSentRequestSlideIn.SentRequestSection_0.CancelRequest']")
	private WebElementFacade CancelSentRequestButton;

	@FindBy(xpath = "//span[contains(text(),'Cancel Request')]/..")
	private WebElementFacade CancelSentRequestButtonV19;
	
	
	@FindBy(xpath = "//div[contains(text(),'You have successfully canceled the shift swap request.')]")
	private WebElementFacade CancelMessageV19;
	
	
	@FindBy(xpath = "//div[contains(text(),'You have successfully declined the shift swap request.')]")
	private WebElementFacade DeclineMessageV19;
	
	
	@FindBy(xpath = ".//*[@id='ShiftSwapSlideIn_Close']")
	private WebElementFacade BackButton;
	
	
		
	@FindBy(xpath = "//*[@id='RequestFilter_RECEIVED']")
	private WebElementFacade activeSwapRequestRecieved;

	@FindBy(xpath = "//*[@id='ShiftSwapRecievedRequests.RecievedRequest_0.Accept']")
	private WebElementFacade acceptActiveSwapRequestRecieved;
	
	
	@FindBy(xpath = "//span[text()='ACCEPT']/..")
	private WebElementFacade acceptActiveSwapRequestRecievedV19;
	

	@FindBy(xpath = "//span[text()='DECLINE']/..")
	private WebElementFacade declineActiveSwapRequestRecievedV19;

	
	
	@FindBy(xpath = "//*[@id='ShiftSwapRecievedRequests.RecievedRequest_0.Deny']")
	private WebElementFacade declineSwapRequestSlider;


	
	@FindBy(xpath = "//div[contains(text(),'Your Received Requests')]")
	private WebElementFacade declineSwapRequestSliderV19;
				
	
	@FindBy(xpath = "//*[@id='SchedulingCalendarMonthlyView_MESSAGES']")
	private WebElementFacade myScheduleMessageBar;

	@FindBy(xpath = "//*[contains(text(), 'You have successfully accepted the shift swap request')]")
	private WebElementFacade SuccessAcceptRequestMessageAtSlider;

	@FindBy(xpath = "//*[contains(text(), 'You have successfully declined the shift swap request')]")
	private WebElementFacade SuccessDeclineRequestMessageAtSlider;

	@FindBy(xpath = "//*[@id='ShiftSwapRequestSlideIn_MESSAGES']")
	private WebElementFacade SliderMessageBar;

	// ///Scenario 3 --> Supervisor///////

	@FindBy(xpath = "//*[@id='SchedulingCalendar.Search']")
	private WebElementFacade SupSearchEmpTextBox;

	@FindBy(xpath = ".//*[@id='SchedulingCalendar.SchedulingGrid_Header.1']")
	private WebElementFacade SupScheduleLoadIndicator;

	@FindBy(xpath = "//*[@id='SchedulingCalendar.Search.button']")
	private WebElementFacade SupSearchEmpButton;

	@FindBy(xpath = "//*[@class='emp-approval-swap-status']/parent::div/parent::div ")
	private WebElementFacade supPendingApprovalShiftInfoBox;

	@FindBy(xpath = "//*[@class ='emp-swap-status']/parent::div/parent::div")
	private WebElementFacade supShiftSwapRequestInfoBox;

	@FindBy(xpath = "//*[@class ='emp-swap-status']/parent::div/parent::div")
	private List<WebElementFacade> supShiftSwapRequestInfoList;

	@FindBy(xpath = "//*[@class ='emp-approval-swap-status']/parent::div/parent::div")
	private List<WebElementFacade> pendingApprovalRequestListAtSchedule;

	// *[@class='emp-approval-swap-status']/parent::div/following-sibling::div//i[@class='shift-actions
	// shift-edit-action fa fa-edit']

	@FindBy(xpath = "//*[@class='emp-approval-swap-status']/parent::div/following-sibling::div//*[@class='shift-actions shift-edit-action fa fa-edit']")
	private WebElementFacade EditPendingApprovalrequestAtSchedule;

	@FindBy(xpath = "//*[@class='emp-swap-status']/parent::div/following-sibling::div//*[@class='shift-actions shift-edit-action fa fa-edit']")
	private WebElementFacade EditSentSwapRequestAtSchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.Department.button']")
	private WebElementFacade selectDepartmentDropDownWhileShiftEditAtSchedule;

	// *[@id='SchedulingCalendarAddEditDialog.LunchPlan.button']
	// *[@id='SchedulingCalendarAddEditDialog.LunchPlan.option.2']

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.Department.input']")
	private WebElementFacade departmentInputBoxWhileShiftEditAtSchedule;

	// *[@id='SchedulingCalendarAddEditDialog.Department.input']

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.Department.option.3']")
	private WebElementFacade select3rdDepartmentWhileShiftEditAtSchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.LunchPlan.input']")
	private WebElementFacade lunchPlanInputBoxWhileShiftEditAtSchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.LunchPlan.button']")
	private WebElementFacade selectLunchPlanDropDownWhileShiftEditAtSchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.LunchPlan.option.2']")
	private WebElementFacade select2ndLunchPlanWhileShiftEditAtSchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.LunchPlan.option.1']")
	private WebElementFacade select1stLunchPlanWhileShiftEditAtSchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.Save']")
	private WebElementFacade saveShiftAtSchedule;

	@FindBy(xpath = "//*[@id='SchedulingCalendarAddEditDialog.ViewSwap']")
	private WebElementFacade pendingApprovalRequestDetailPopUp;

	@FindBy(xpath = "//*[@id='ShiftSwapPendingApprovalPopUp.Approve'  or @id='ShiftSwapAdditionalDetailsPopUp.Approve']")
	private WebElementFacade ApproveRequestPopUpButton;

	@FindBy(xpath = "//*[@id='ShiftSwapPendingApprovalPopUp.Reject'  or @id='ShiftSwapAdditionalDetailsPopUp.Reject']")
	private WebElementFacade rejectRequestPopUpButton;

	@FindBy(xpath = "//*[@id='SwapActionConfirmationDialog.Yes']")
	private WebElementFacade ApprovalPendingActionConfirmButton;

	@FindBy(xpath = "//*[contains(text(), 'You have 1 pending Shift Swap requests')]")
	private WebElementFacade ApprovalRequestNotification;

	@FindBy(xpath = "//*[@id='SchedulingCalendar.SwapRequestDetailsButton']")
	private WebElementFacade viewApprovalRequestButton;

	@FindBy(xpath = "//*[@id='RequestFilter_PENDING_APPROVAL']")
	private WebElementFacade PendingApprovalRequestAtSlider;
	
	@FindBy(xpath = "(//span[contains(text(),'Pending Approval')])[1]")
	private WebElementFacade PendingApprovalRequestAtSliderV19;
	
	@FindBy(xpath = ".//*[@id='pendingSwapRequest_root']//div[@class='vdl-row swap-info']/div[1]")
	private WebElementFacade RequesterDetailAtSliderV19;
	
	
	@FindBy(xpath = ".//*[@id='pendingSwapRequest_root']//div[@class='vdl-col-xs shift2']")
	private WebElementFacade RecieverDetailAtSliderV19;
	
	
	@FindBy(xpath = "//*[@id='ShiftSwapPendingRequests.PendingApprovalRequest_0.RequestorDetails.node']")
	private WebElementFacade RequesterDetailAtSlider;

	@FindBy(xpath = "//*[@id='ShiftSwapPendingRequests.PendingApprovalRequest_0.TargetShiftDetails.node']")
	private WebElementFacade RecieverDetailAtSlider;

	@FindBy(xpath = "//*[@id='ShiftSwapPendingRequests.PendingApprovalRequest_0.Accept']")
	private WebElementFacade ApproveRequestButtonAtSlider;
	
	@FindBy(xpath = "(//span[text()='APPROVE']/..)[2]")
	private WebElementFacade ApproveRequestButtonAtSliderV19;
		
		
	@FindBy(xpath = "//*[@id='ShiftSwapPendingRequests.PendingApprovalRequest_0.Message.textArea' or  @id='SwapActionConfirmationDialog.Comment.textArea']")
	private WebElementFacade ScheduleViewBannerCommentBox;

	
	@FindBy(xpath = "//div[@class='vdl-row swap-component']/div[3]/div/textarea[@class='B1 vdl-col-xs comment-box vdl-textarea']")
	private WebElementFacade ScheduleViewBannerCommentBoxV19;	

	
	@FindBy(xpath = "//*[@id='ShiftSwapPendingRequests.PendingApprovalRequest_0.Deny']")
	private WebElementFacade rejectRequestForApprovalButtonView;
	
	
	@FindBy(xpath = "//span[text()='REJECT']/..")
	private WebElementFacade rejectRequestForApprovalButtonViewV19;


	@FindBy(xpath = "(//div[@class='sentSwapRequestBox'])")
	public List<WebElementFacade> sentSwapRequestBox;

	@FindBy(xpath = "(//div[@class='approvalPendingSwapRequestBox'])")
	public List<WebElementFacade> approvalPendingSwapRequestBoxList;

	@FindBy(xpath = "(//div[@class='approvalPendingSwapRequestBox'])")
	public WebElementFacade approvalPendingSwapRequestBox;

	@FindBy(xpath = "(//*[@class='shiftSpan'])")
	private List<WebElementFacade> TargetSwapBoxList;

	@FindBy(xpath = "(//*[@class='holidayBox'])")
	private List<WebElementFacade> HolidayBoxList;

	@FindBy(xpath = "(//*[@class='holidayBox'])")
	private WebElementFacade HolidayBox;

	@FindBy(xpath = "(//*[@class='ptoBox'])")
	private List<WebElementFacade> ptoBoxList;

	@FindBy(xpath = "(//*[@class='ptoBox'])")
	private WebElementFacade ptoBox;

	@FindBy(xpath = "(//div[@class='recievedSwapRequestBox'])")
	public List<WebElementFacade> recievedSwapRequestBoxList;

	@FindBy(xpath = "(//div[@class='recievedSwapRequestBox'])")
	public WebElementFacade recievedSwapRequestBox;

	@FindBy(xpath = "//*[@id='ShiftSwapRecievedRequestDetailsPopUp.Accept']")
	public WebElementFacade AcceptrecievedSwapRequestPopup;

	@FindBy(xpath = "//*[@id='ShiftSwapRecievedRequestDetailsPopUp.Decline']")
	public WebElementFacade declineRecievedSwapRequestPopup;

	@FindBy(xpath = "//*[@id='ShiftSwapRecievedRequests.RecievedRequest_0.Message.textArea']")
	public WebElementFacade commentBoxRecivedRequestAtSlider;
	
	@FindBy(xpath = "//div[@class='vdl-row swap-component']/div[3]/div[2]/textarea")
	public WebElementFacade commentBoxRecivedRequestAtSliderV19;
		
	@FindBy(xpath = "//*[@id='SwapActionConfirmationDialog.Comment.textArea']")
	public WebElementFacade commentBoxConfirmationActionPopUp;

	// for deleting notifications
	@FindBy(xpath = "//*[contains(text(), 'Show All Messages')]")
	private WebElementFacade selectAllMessageCheckBox;

	@FindBy(xpath = "//*[contains(text(), 'Select All')]")
	private WebElementFacade selectAllCheckBox;

	@FindBy(xpath = "//*[contains(text(), 'ARCHIVE')]")
	private WebElementFacade ArchiveIcon;

	@FindBy(xpath = "//button[@type='button' and contains(., 'Confirm')]")
	private WebElementFacade ConfirmArchiveButton;

	@FindBy(xpath = ".//*[@class='dijitReset dijitInline alert alert-1-chars']")
	private WebElementFacade IsNotification;

	@FindBy(xpath = ".//*[@id='TargetSwapSlideInView.NextWeek']")
	private WebElementFacade NextWeekOnTargetSlider;

	public void deleteAllNotifications() {

		WaitForAjax();

		messageCentre.waitUntilVisible();
		waitABit(2000);
		if (IsNotification.isPresent()) {
			WaitForAjax();
			messageCentre.click();
			waitABit(2000);
			WaitForAjax();
			waitABit(2000);
			viewAllMessage.waitUntilVisible();
			WaitForAjax();
			waitABit(2000);
			viewAllMessage.click();
			WaitForAjax();

			notificationsBtn.waitUntilVisible();
			waitABit(2000);
			notificationsBtn.click();
			waitABit(2000);
			WaitForAjax();
			selectAllMessageCheckBox.waitUntilVisible();
			selectAllMessageCheckBox.click();
			WaitForAjax();
			selectAllCheckBox.waitUntilVisible();
			selectAllCheckBox.click();
			WaitForAjax();
			ArchiveIcon.waitUntilVisible();
			ArchiveIcon.click();
			WaitForAjax();
			ConfirmArchiveButton.waitUntilVisible();
			ConfirmArchiveButton.click();
			WaitForAjax();
		}

	}

	public void cancelAllSwapRequestsBySender() {
		WaitForAjax();
		System.out
				.println("Scenario 1,Testcase 1: User(Sender) is going to cancel all previous swap requests");
		ToggleButton.waitUntilVisible();

		int count = sentSwapRequestBox.size();

		System.out
				.println(" Scenario 1,Testcase 1: number of Sent Swap Request are calculated");

		while (count != 0) {
			WaitForAjax();
			if (getDriver().findElement(
					By.xpath("(//div[@class='sentSwapRequestBox'])[" + count
							+ "]")).isDisplayed()) {
				getDriver().findElement(
						By.xpath("(//div[@class='sentSwapRequestBox'])["
								+ count + "]")).click();
				popupRequestCancelBtn.waitUntilClickable();
				popupRequestCancelBtn.click();
				WaitForAjax();
				popupRequestConfirmCancelBtn.waitUntilClickable();
				popupRequestConfirmCancelBtn.click();
				System.out.println(" Scenario 1,Testcase 1: Request" + count
						+ "is cancelled");
				count--;
			}
		}
	}

	public void cancelAllSwapRequestsBySenderPendingForApproval() {

		System.out
				.println("Scenario 1,Testcase 2: User(Sender) is going to cancel all previous swap requests pending for Approval");
		ToggleButton.waitUntilVisible();

		int count = approvalPendingSwapRequestBoxList.size();

		System.out
				.println(" Scenario 1,Testcase 1: number of Sent Swap Request pending for approval are calculated");

		while (count != 0) {
			WaitForAjax();
			if (getDriver().findElement(
					By.xpath("(//div[@class='approvalPendingSwapRequestBox'])["
							+ count + "]")).isDisplayed()) {
				getDriver()
						.findElement(
								By.xpath("(//div[@class='approvalPendingSwapRequestBox'])["
										+ count + "]")).click();
				popupPendingApprovalRequestCancelBtn.click();
				WaitForAjax();
				popupRequestConfirmCancelBtn.click();
				System.out.println(" Scenario 1,Testcase 1: Request" + count
						+ "is cancelled");
				count--;
			}
		}
	}

	public void createSwapRequest(String reciever) {

		try {
			WaitForAjax();
			System.out
					.println(" Scenario 1,Testcase 2: User(sender) is going to create a swap request with "
							+ reciever);

			SchedulingCalendar.waitUntilVisible();
			System.out
					.println(" Scenario 1,Testcase 2: My schedule Page is Loaded");
			WaitForAjax();
			waitABit(2000);
			WebDriver driver = getDriver();
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("scroll(0, 250);");
			SwapEligiblebox.isEnabled();
			SwapEligiblebox.waitUntilClickable();
			SwapEligiblebox.click();
			System.out.println("eligible shift is selected");
			ShiftSwapButton.waitUntilClickable();
			ShiftSwapButton.click();
			WaitForAjax();
			waitABit(2000);
			TargetSwapEmpSearchSlider.sendKeys(reciever);

			System.out.println(" Scenario 1,Testcase 2: Recipient is selected");
			waitABit(3000);
			WaitForAjax();
			// TargetSwapEmpSearch.waitUntilVisible();
			TargetSwapEmpSearch.waitUntilClickable().then().click();
			
			WaitForAjax();
			waitABit(2000);
			TargetSwapBox.waitUntilClickable().then().click();
			
			commentBoxRequestCreation
					.sendKeys("please accept the request, its urgent");
			waitABit(1000);
			TargetSwapSendBtn.click();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void verifySwapRequestBySuccessPopUp() {
		WaitForAjax();
		String Status = ShiftSwapPopup.getText().toString();
		if ("Swap request sent successfully".equals(Status)) {
			System.out
					.println(" Scenario 1,Testcase 3: Swap is send to the recipient");
		} else {
			System.out
					.println("Scenario 1,Testcase 3: Error in creating Shift Swap Request");
			return;
		}
		SentRequestPopupCancelBtn.waitUntilClickable();
		SentRequestPopupCancelBtn.click();
		ToggleButton.waitUntilVisible();

	}

	public void verifySentSwapRequest() {

		WaitForAjax();
		ToggleButton.waitUntilVisible();
		int count = sentSwapRequestBox.size();
		if (count == 1) {
			System.out.println("Sent swap request indicator box is verified");
		} else {
			System.out.println("error : sent swap box is not there");
			return;
		}
	}

	public void verifyRequestInNotification(String sender, String reciever) {
		WaitForAjax();
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Requested");
		else
			goToNotification();

		WaitForAjax();
		waitABit(1000);
		String msg = sender + " is requesting";
		checkNotifications(InTLM, msg, reciever, "", "");
		waitABit(1500);
		if (!InTLM)
			deleteAllNotification();

	}

	public void verifyAcceptRequestInNotification(String sender, String reciever) {
		WaitForAjax();
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Accepted - Ready for Approval");
		else
			goToNotification();

		String msg = reciever + " has accepted";
		checkNotifications(InTLM, msg, sender, "", "");

		if (!InTLM)
			deleteAllNotification();

	}

	public void verifyApproveNotication(String sender, String recipient) {
		goToNotification();
		recipient = "'" + recipient + "'";
		sender = "'" + sender + "'";
		String xpathVal = "//div[contains(@class, 'accordianDiv ng-binding') and contains(.//h2, 'approved by Supervisor') and contains(.,"
				+ sender + ")  and contains(. , " + recipient + ")]";
		getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		System.out.println("request is approved by Supervisor(Notification)");
		deleteAllNotification();
	}

	public void verifyApproveNotication(String sender, String recipient,
			String supervisor) {
		WaitForAjax();
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Approved");
		else
			goToNotification();
		String msg = "approved by " + supervisor;
		checkNotifications(InTLM, msg, sender, recipient, "");

		/*
		 * recipient = "'" + recipient + "'"; sender = "'" + sender + "'";
		 * String xpathVal =
		 * "//div[contains(@class, 'accordianDiv ng-binding') and contains(.//h2, 'approved by "
		 * + supervisor + "') and contains(.," + sender+ ")  and contains(. , "
		 * + recipient + ")]";
		 * getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		 * System.out.println
		 * ("request is approved by Supervisor(Notification)");
		 */
		if (!InTLM)
			deleteAllNotification();
	}

	// verify cancel pending for approval request
	public void verifyRejectedRequestNotication(String sender, String recipient) {
		goToNotification();
		recipient = "'" + recipient + "'";
		sender = "'" + sender + "'";
		String xpathVal = "//div[contains(@class, 'accordianDiv ng-binding') and contains(.//h2, 'rejected by Supervisor') and contains(.,"
				+ sender + ")  and contains(. , " + recipient + ")]";
		getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		System.out
				.println("Supervisor cancel pending request for approval(Notification)");
		deleteAllNotification();
	}

	// verify notification for declining request

	public void verifyDeclinedNotication(String sender, String recipient) {
		WaitForAjax();
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Declined");
		else
			goToNotification();

		String msg = recipient + " has declined";
		checkNotifications(InTLM, msg, sender, "", "");
		/*
		 * String msg = "'" + recipient + " has declined'"; sender = "'" +
		 * sender + "'"; String xpathVal=""; if(InTLM) xpathVal =
		 * "//div[contains(.," + msg + ")  and contains(. , " + sender + ")]";
		 * else xpathVal =
		 * "//div[contains(@class, 'accordianDiv ng-binding') and contains(.," +
		 * msg + ")  and contains(. , " + sender + ")]";
		 * 
		 * getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		 * System.out.println("request is Declined by Recipient(Notification)");
		 */
		if (!InTLM)
			deleteAllNotification();
	}

	public void observRecivedBox() {
		WaitForAjax();
		ToggleButton.waitUntilVisible();
		WebDriver driver = getDriver();
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, 250);");
		waitABit(2000);
		if (!recievedSwapRequestBox.isPresent()) {
			nextMonthButtonAtMySchedule.click();
			WaitForAjax();
			waitABit(2000);
			ToggleButton.waitUntilVisible();
			recievedSwapRequestBox.isEnabled();
			System.out.println("Recieved swap request indicator is verified");
		}
		System.out.println("Recieved swap request indicator is verified");

	}

	public void activeRequest() {
		System.out.println("i m searching active request button");
		WaitForAjax();
		activeSwapRequest.waitUntilVisible();
		activeSwapRequest.click();
		WaitForAjax();
		activeSwapRequestRecieved.click();
	}

	public void acceptRequestFromSlider() {
		WaitForAjax();
		
		// FOR V19
		waitABit(2000);
		if(activeSwapRequest.isDisplayed())
		{			
			activeSwapRequest.click();
			waitABit(2000);
		}
			
		
		if(acceptActiveSwapRequestRecievedV19.isDisplayed())
		{
			commentBoxRecivedRequestAtSliderV19.sendKeys("Sure.");
			acceptActiveSwapRequestRecievedV19.click();
		}			
		else
		{
		acceptActiveSwapRequestRecieved.waitUntilPresent();
		commentBoxRecivedRequestAtSlider.sendKeys("Sure.");
		acceptActiveSwapRequestRecieved.click();
		}
	}

	public void acceptRequestThroughPopUp() {
		WaitForAjax();
		recievedSwapRequestBox.waitUntilVisible();
		recievedSwapRequestBox.waitUntilClickable();
		recievedSwapRequestBox.click();
		AcceptrecievedSwapRequestPopup.waitUntilVisible();
		AcceptrecievedSwapRequestPopup.waitUntilClickable();
		AcceptrecievedSwapRequestPopup.click();
		waitABit(1000);
		popupRequestConfirmCancelBtn.waitUntilVisible();
		commentBoxConfirmationActionPopUp.sendKeys("Sure.");
		waitABit(1000);
		popupRequestConfirmCancelBtn.waitUntilClickable();
		popupRequestConfirmCancelBtn.click();

	}

	public void verifyAcceptanceBySuccessBar() {
		WaitForAjax();
		// SliderMessageBar.waitUntilVisible();
		waitABit(2000);

		if (SuccessAcceptRequestMessageAtSlider.isEnabled()) {
			System.out.println("Swap Request is accepted successfully");
		} else {
			System.out.println("Error in accepting Swap Request");
		}
		WaitForAjax();

		if (TargetSliderBackButton.isPresent()) {
			TargetSliderBackButton.click();
		}
	}

	public void declineSwapRequestPopup() {
		waitABit(2000);
		recievedSwapRequestBox.click();
		waitABit(2000);
		declineRecievedSwapRequestPopup.click();
		waitABit(1000);
		commentBoxConfirmationActionPopUp
				.sendKeys("Sorry I can't, I have some urgent work");
		waitABit(1000);
		popupRequestConfirmCancelBtn.click();

	}

	public void declineSwapRequestSlider() {
		
		if(declineSwapRequestSliderV19.isDisplayed())
		{
			declineSwapRequestSliderV19.click();
			waitABit(2000);
			commentBoxRecivedRequestAtSliderV19.sendKeys("Sorry, I can't.");
			waitABit(2000);
			declineActiveSwapRequestRecievedV19.click();
			waitABit(2000);
			DeclineMessageV19.isDisplayed();
			BackButton.click();
		}
		else
		{
		declineSwapRequestSlider.waitUntilPresent();
		commentBoxRecivedRequestAtSlider.sendKeys("Sorry, I can't.");
		waitABit(1000);
		declineSwapRequestSlider.click();
		}
	}

	public void verifyDeclineBySuccessBar() {
		WaitForAjax();
		// SliderMessageBar.waitUntilVisible();
		waitABit(2000);

		if (SuccessDeclineRequestMessageAtSlider.isEnabled()) {
			System.out.println("Swap Request is declined successfully");
		} else {
			System.out.println("Error in declining Swap Request");
			return;
		}
		WaitForAjax();

		if (TargetSliderBackButton.isPresent()) {
			TargetSliderBackButton.click();
		}
	}

	public void verifyDeclinedRecieveRequestByMySchedule() {

		WaitForAjax();
		waitABit(2000);
		ToggleButton.waitUntilVisible();
		int count = recievedSwapRequestBoxList.size();
		if (count == 0) {
			System.out
					.println("Recieved swap request is declined successfully by  Recieved Shift Indicator");
		}

		else {
			System.out
					.println("Error : Recieved swap request is NOT declined successfully by  Recieved Shift Indicator ");
			return;
		}
	}

	public void acceptNotification() {

	}

	public void verifyPendingApproval() {
		WaitForAjax();
		ToggleButton.waitUntilVisible();
		WebDriver driver = getDriver();
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, 250);");
		waitABit(2000);
		if (!approvalPendingSwapRequestBox.isPresent()) {
			nextMonthButtonAtMySchedule.click();
			WaitForAjax();
			waitABit(2000);
			ToggleButton.waitUntilVisible();
			approvalPendingSwapRequestBox.isEnabled();
			System.out.println("pending Approval indicator box is verified");
		}
		System.out.println("pending Approval indicator box is verified");
	}

	public void ViewApprovalRequestAtSchedule() {
		WaitForAjax();
		waitABit(3000);
		System.out.println("i m checking the approval request");
		waitABit(2000);
		viewApprovalRequestButton.waitUntilClickable();
		viewApprovalRequestButton.click();
		WaitForAjax();

	}

	public void verifyApprovalRequest(String requester, String reciever) {
		WaitForAjax();
		
		// FOR V19
		
		if(PendingApprovalRequestAtSliderV19.isDisplayed())
		{
			PendingApprovalRequestAtSliderV19.click();
			WaitForAjax();
			RequesterDetailAtSliderV19.waitUntilVisible();
			RecieverDetailAtSliderV19.waitUntilVisible();
			if (RequesterDetailAtSliderV19.containsText(requester)
					&& RecieverDetailAtSliderV19.containsText(reciever)) {
				System.out
						.println("Approval Request is Verified with requester and reciever");
			} else {
				System.out.println("No request for approval");
				return;
			}
			
		}
		else
		{
		PendingApprovalRequestAtSlider.waitUntilVisible();
		PendingApprovalRequestAtSlider.click();
		WaitForAjax();
		RequesterDetailAtSlider.waitUntilVisible();
		RecieverDetailAtSlider.waitUntilVisible();
		if (RequesterDetailAtSlider.containsText(requester)
				&& RecieverDetailAtSlider.containsText(reciever)) {
			System.out
					.println("Approval Request is Verified with requester and reciever");
		} else {
			System.out.println("No request for approval");
			return;
		}
		}
	}

	public void approveRequestThroughViewSlider() {

		WaitForAjax();
		
		//FOR V19
		
		if(PendingApprovalRequestAtSliderV19.isDisplayed())
		{
			RequesterDetailAtSliderV19.waitUntilClickable();
			RecieverDetailAtSliderV19.waitUntilVisible();
			WaitForAjax();
			ScheduleViewBannerCommentBoxV19.clear();
			ScheduleViewBannerCommentBoxV19.sendKeys("Ok.. I accept your request");
			WaitForAjax();
			ApproveRequestButtonAtSliderV19.waitUntilClickable();
			ApproveRequestButtonAtSliderV19.click();
			//TO DO - Verify if the approval was successful
		}
		else
		{
		PendingApprovalRequestAtSlider.waitUntilClickable();
		PendingApprovalRequestAtSlider.click();
		WaitForAjax();
		RequesterDetailAtSlider.waitUntilClickable();
		RecieverDetailAtSlider.waitUntilVisible();
		WaitForAjax();
		ScheduleViewBannerCommentBox.clear();
		ScheduleViewBannerCommentBox.sendKeys("Ok.. I accept your request");
		WaitForAjax();
		ApproveRequestButtonAtSlider.waitUntilClickable();
		ApproveRequestButtonAtSlider.click();
		WaitForAjax();
		}

	}

	public void rejectRequestThroughViewSlider() {

		WaitForAjax();
		//FOR V19
		
		if(PendingApprovalRequestAtSliderV19.isDisplayed())
		{
			PendingApprovalRequestAtSliderV19.waitUntilVisible();
			PendingApprovalRequestAtSliderV19.click();
			WaitForAjax();
			RequesterDetailAtSliderV19.waitUntilVisible();
			RecieverDetailAtSliderV19.waitUntilVisible();
			WaitForAjax();
			ScheduleViewBannerCommentBoxV19.clear();
			ScheduleViewBannerCommentBoxV19
					.sendKeys("There's is some more urgent work.");
			WaitForAjax();
			rejectRequestForApprovalButtonViewV19.waitUntilVisible();
			rejectRequestForApprovalButtonViewV19.click();
			WaitForAjax();			
		}
		
		else
		{
		PendingApprovalRequestAtSlider.waitUntilVisible();
		PendingApprovalRequestAtSlider.click();
		WaitForAjax();
		RequesterDetailAtSlider.waitUntilVisible();
		RecieverDetailAtSlider.waitUntilVisible();
		WaitForAjax();
		ScheduleViewBannerCommentBox.clear();
		ScheduleViewBannerCommentBox
				.sendKeys("There's is some more urgent work.");
		WaitForAjax();
		rejectRequestForApprovalButtonView.waitUntilVisible();
		rejectRequestForApprovalButtonView.click();
		WaitForAjax();
		}
	}

	public void rejectRequestThroughPopUp(String sender) {
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpTextBox.sendKeys(sender);
		waitABit(2000);
		SupSearchEmpButton.waitUntilClickable();
		SupSearchEmpButton.click();
		waitABit(2000);
		WaitForAjax();
		supPendingApprovalShiftInfoBox.waitUntilClickable();
		supPendingApprovalShiftInfoBox.click();
		WaitForAjax();
		waitABit(3000);
		EditPendingApprovalrequestAtSchedule.waitUntilClickable();
		EditPendingApprovalrequestAtSchedule.click();
		WaitForAjax();
		waitABit(2000);
		pendingApprovalRequestDetailPopUp.waitUntilClickable();
		pendingApprovalRequestDetailPopUp.click();
		waitABit(2000);
		rejectRequestPopUpButton.waitUntilClickable();
		rejectRequestPopUpButton.click();
		waitABit(2000);
		WaitForAjax();
		ScheduleViewBannerCommentBox.waitUntilClickable();
		ScheduleViewBannerCommentBox.clear();
		ScheduleViewBannerCommentBox
				.sendKeys("Sorry.. Some work urgent work for u");
		WaitForAjax();
		ApprovalPendingActionConfirmButton.waitUntilClickable();
		ApprovalPendingActionConfirmButton.click();
		WaitForAjax();

	}

	public void ApproveRequestThroughPopUp(String sender)
			throws InterruptedException {

		WaitForAjax();
		waitABit(2000);
		SupSearchEmpTextBox.waitUntilVisible();
		SupSearchEmpTextBox.sendKeys(sender);
		waitABit(2000);
		SupSearchEmpButton.waitUntilClickable().then().click();

		waitABit(2000);
		WaitForAjax();
		supPendingApprovalShiftInfoBox.waitUntilClickable().then().click();
		waitABit(3000);
		EditPendingApprovalrequestAtSchedule.waitUntilClickable().then().click();
		WaitForAjax();
		waitABit(2000);
		pendingApprovalRequestDetailPopUp.waitUntilVisible();
		pendingApprovalRequestDetailPopUp.waitUntilClickable().then().click();
		waitABit(2000);
		ApproveRequestPopUpButton.waitUntilVisible();
		ApproveRequestPopUpButton.waitUntilClickable().then().click();
		waitABit(2000);
		WaitForAjax();
		ScheduleViewBannerCommentBox.clear();
		ScheduleViewBannerCommentBox.sendKeys("Approved");
		WaitForAjax();
		ApprovalPendingActionConfirmButton.waitUntilVisible();
		ApprovalPendingActionConfirmButton.waitUntilClickable().then().click();
		WaitForAjax();

	}

	public void cancelSentRequestsThroughSlider() {

		WaitForAjax();
		activeSwapRequest.waitUntilClickable();
		activeSwapRequest.click();
		WaitForAjax();
		
		if(activeSwapRequestSentV19.isDisplayed())
		{
			//activeSwapRequestSentV19.waitUntilClickable();
			//activeSwapRequestSentV19.click();
			waitABit(3000);
			WaitForAjax();
			CancelSentRequestButtonV19.waitUntilClickable();
			CancelSentRequestButtonV19.click();
			waitABit(2000);
			CancelMessageV19.isDisplayed();
			BackButton.click();
		}
			
		else
		{	
			CancelSentRequestButton.waitUntilClickable();
			CancelSentRequestButton.click();
			waitABit(2000);
		
		}
	}

	/*
	 * public void verifyApproveNotication(String sender, String recipient){
	 * 
	 * WaitForAjax(); waitABit(2000); messageCentre.waitUntilVisible();
	 * messageCentre.click(); waitABit(2000); viewAllMessage.waitUntilVisible();
	 * viewAllMessage.click(); waitABit(2000); WaitForAjax(); //wait(1000);
	 * notificationsBtn.waitUntilVisible(); notificationsBtn.click();
	 * waitABit(2000); WaitForAjax();
	 * 
	 * Boolean Status = getDriver().findElement(By.xpath(
	 * "//div[contains(@class, 'accordianDiv ng-binding') and contains(., 'EHours EH has accepted')  and contains(. , 'ETime ET')]"
	 * )).isEnabled(); if(Status){
	 * System.out.println("request is accepted by recipient(Notification)"); }
	 * else{
	 * System.out.println("request is not accepted by recipient(Notification)");
	 * }
	 * 
	 * }
	 */
	/*
	 * ///multiple swap request public void createMultipleSwapRequest(int
	 * number, String reciever) {
	 * 
	 * WaitForAjax(); System.out.println(
	 * " User(sender) is going to create mutiple swap request with " + reciever
	 * );
	 * 
	 * SchedulingCalendar.waitUntilVisible();
	 * 
	 * System.out.println(" My schedule Page is Loaded");
	 * 
	 * SwapEligiblebox.click(); ShiftSwapButton.click();
	 * TargetSwapEmpSearchSlider.sendKeys(reciever);
	 * 
	 * System.out.println(" Recipient is selected");
	 * 
	 * TargetSwapEmpSearch.waitUntilVisible(); TargetSwapEmpSearch.click();
	 * WaitForAjax(); int count = TargetSwapBoxList.size(); if( count < number)
	 * {
	 * System.out.println("Can not perform multiple Swap as Target swap are less"
	 * ); return; }
	 * 
	 * while(count!=0){ WaitForAjax(); waitABit(2000);
	 * getDriver().findElement(By.xpath("(//div[@class='shiftSpan'])[" + count +
	 * "]")).click(); } waitABit(2000); TargetSwapSendBtn.click(); }
	 */

	public void createMultipleSwapRequest(String recipient1, String recipient2) {
		WaitForAjax();
		System.out
				.println(" Scenario 10,Testcase 2: User(sender) is going to create a multiple swap request with recieveras");

		SchedulingCalendar.waitUntilVisible();

		System.out
				.println(" Scenario 1,Testcase 2: My schedule Page is Loaded");
		SwapEligiblebox.waitUntilClickable();
		SwapEligiblebox.click();
		ShiftSwapButton.waitUntilClickable();
		ShiftSwapButton.click();
		waitABit(2000);
		WaitForAjax();
		// TargetSwapBox.click();
		getDriver().findElement(
				By.xpath("(//*[contains(@title, '" + recipient1
						+ "')]//span[@class='shiftSpan'])[1]")).click();
		WaitForAjax();
		getDriver().findElement(
				By.xpath("(//*[contains(@title, '" + recipient2
						+ "')]//span[@class='shiftSpan'])[1]")).click();
		waitABit(1000);
		TargetSwapSendBtn.click();
	}

	public void verifyMultipleRecipientRequestInNotification(String sender,
			String reciever1, String reciever2) {
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Request Notification");
		else
			goToNotification();

		WaitForAjax();
		String msg = sender + " is requesting";
		checkNotifications(InTLM, msg, reciever1, reciever2, "");
		if (!InTLM)
			deleteAllNotification();
		/*
		 * goToNotification(); String msg = "'" + sender + " is requesting'";
		 * reciever1 = "'" + reciever1 + "'"; reciever2 = "'" + reciever2 + "'";
		 * sender = "'" + sender + "'"; String xpathVal =
		 * "//div[contains(@class, 'accordianDiv ng-binding') and contains(.," +
		 * msg + ")  and contains(. , " + reciever1 + ")  and contains(. , " +
		 * reciever2 + ")]";
		 * getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		 * System.out.println(
		 * "request for multiple employee  have arrived from the sender(Notification)"
		 * );
		 */
	}

	public void verifyAutomaticCanceledRequest(String sender, String reciever) {

		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Canceled Notification");
		else
			goToNotification();

		WaitForAjax();
		String msg = "automatically canceled";
		checkNotifications(InTLM, msg, reciever, "", "");
		if (!InTLM)
			deleteAllNotification();
		/*
		 * goToNotification(); String msg = "'automatically canceled'"; reciever
		 * = "'" + reciever + "'"; sender = "'" + sender + "'"; String xpathVal
		 * = "//div[contains(@class, 'accordianDiv ng-binding') and contains(.,"
		 * + msg + ")  and contains(. , " + sender + ")  and contains(. , " +
		 * reciever + ")]";
		 * getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		 * System.out.println("request is Declined by Recipient(Notification)");
		 * deleteAllNotification();
		 */

	}

	public void createRequestLastDayForNextMonth(String recipient) {
		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();

		int lastDay = Calendar.getInstance().getActualMaximum(
				Calendar.DAY_OF_MONTH);

		String xpathVal = "//div[@class='dayCell']//div[contains(text(),'"
				+ lastDay
				+ "')]/following-sibling::div//div//div[@class='swapEligibleBox']";
		getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		getDriver().findElement(By.xpath(xpathVal)).click();
		ShiftSwapButton.click();
		waitABit(2000);
		TargetSwapEmpSearchSlider.sendKeys(recipient);

		waitABit(2000);
		TargetSwapEmpSearch.waitUntilVisible();
		TargetSwapEmpSearch.click();
		WaitForAjax();
		int count = TargetSwapBoxList.size();
		// (//*[@class='shiftSpan']/parent::div)

		String xPathLastTargetBoxParent = "(//*[@class='shiftSpan']/parent::div)["
				+ count + " ]";
		String LastTargetBoxTitle = getDriver().findElement(
				By.xpath(xPathLastTargetBoxParent)).getAttribute("Title");
		String Attribute[] = LastTargetBoxTitle.split(",");
		String DateAttribute[] = Attribute[2].split(" ");
		String lastTargetDate = DateAttribute[2];
		int Targetdate = Integer.parseInt(lastTargetDate);

		if (Targetdate >= 1 && Targetdate <= 6) {
			String xpathLastTargerBox = "(//*[@class='shiftSpan'])[" + count
					+ " ]";
			getDriver().findElement(By.xpath(xpathLastTargerBox)).click();

		} else {
			WaitForAjax();
			waitABit(1000);
			NextWeekOnTargetSlider.click();
			WaitForAjax();
			waitABit(2000);
			TargetSwapBox.isEnabled();
			TargetSwapBox.click();
		}

		// TargetSwapBox.click();
		commentBoxRequestCreation
				.sendKeys("please accept the request, its urgent");
		waitABit(1000);
		TargetSwapSendBtn.click();

	}

	public void verifyHolidayShiftNotInTargetSlider(String recipient) {

		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();
		int HolidayDateInt = 0;
		int DEFAULTMAXDAYSSHIFTALLOWED = 14;
		int numberOfHolidays = HolidayBoxList.size();
		// HolidayBox.isEnabled();
		int i = 1;
		String currentMonthBymySchedule = currentMonthByMySchedule.getText()
				.toString();
		String firstDayOfMonth = currentMonthBymySchedule.substring(0, 3)
				+ " 1";
		int lastDayOfMonth = Calendar.getInstance().getActualMaximum(
				Calendar.DAY_OF_MONTH);
		Date date = new Date();
		String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		String currentDateArray[] = currentDate.split("-");
		int currentDayOnly = Integer.parseInt(currentDateArray[2]);
		while (i <= numberOfHolidays) {
			String xpathHolidayBoxDate = "(//*[@class = 'holidayBox'])["
					+ i
					+ "]/parent::div/parent::div/parent::div//div[@class='dayCellHeader']";
			String HolidayDate = getDriver()
					.findElement(By.xpath(xpathHolidayBoxDate)).getText()
					.toString();
			if (HolidayDate.equals(firstDayOfMonth)) {
				HolidayDateInt = 1;
			} else {
				HolidayDateInt = Integer.parseInt(HolidayDate);
			}
			if (HolidayDateInt >= currentDayOnly) {
				break;
			}
			i++;
		}

		// && (HolidayDateInt <= currentDayOnly + DEFAULTMAXDAYSSHIFTALLOWED )
		int j = 1;
		if (numberOfHolidays == 0 || (i > numberOfHolidays)) {
			nextMonthButtonAtMySchedule.click();
			WaitForAjax();
			waitABit(2000);
			numberOfHolidays = HolidayBoxList.size();
			currentMonthBymySchedule = currentMonthByMySchedule.getText()
					.toString();
			firstDayOfMonth = currentMonthBymySchedule.substring(0, 3) + " 1";

			while (j <= numberOfHolidays) {
				String xpathHolidayBoxDate = "(//*[@class = 'holidayBox'])["
						+ j
						+ "]/parent::div/parent::div/parent::div//div[@class='dayCellHeader']";
				String HolidayDate = getDriver()
						.findElement(By.xpath(xpathHolidayBoxDate)).getText()
						.toString();
				if (HolidayDate.equals(firstDayOfMonth)) {
					HolidayDateInt = 1;
				} else {
					HolidayDateInt = Integer.parseInt(HolidayDate);
				}
				if (HolidayDateInt <= DEFAULTMAXDAYSSHIFTALLOWED
						- (lastDayOfMonth - currentDayOnly - 1)) {
					break;
				}
				j++;
			}

		}

		if (numberOfHolidays == 0 || j > numberOfHolidays) {
			System.out.println("No Holiday date is present for swap");
			return;
		}

		SwapEligiblebox.click();
		WaitForAjax();
		ShiftSwapButton.click();
		TargetSwapEmpSearchSlider.sendKeys(recipient);
		System.out.println("Recipient is selected");
		waitABit(2000);
		TargetSwapEmpSearch.waitUntilVisible();
		TargetSwapEmpSearch.click();

		String DateToSearch = null;
		if (HolidayDateInt < 10) {
			DateToSearch = currentMonthBymySchedule.substring(0, 3)
					.toUpperCase() + " 0" + HolidayDateInt;
		}

		else {
			DateToSearch = currentMonthBymySchedule.substring(0, 3)
					.toUpperCase() + " 0" + HolidayDateInt;
		}

		String xpathDatetoSearch = "//*[contains(text(),'" + DateToSearch
				+ "')]";

		do {
			try {
				getDriver().findElement(By.xpath(xpathDatetoSearch))
						.isEnabled();
				break;
			} catch (Exception ex) {
				NextWeekOnTargetSlider.isEnabled();
				NextWeekOnTargetSlider.click();
				WaitForAjax();
				waitABit(2000);
			}
		} while (true);

		String xpathHolidayColumn = "//*[contains(text(), '" + DateToSearch
				+ "')]/following-sibling::i";
		String ColumnAttribute = getDriver().findElement(
				By.xpath(xpathHolidayColumn)).getAttribute("id");
		String ColumnAttributeArray[] = ColumnAttribute.split("\\.");
		String xpathTargetDiv = "//td[@id='TargetSwapSlideInView_ShiftSwapGrid.0."
				+ ColumnAttributeArray[2] + "']//*[@class='shiftSpan']";

		try {
			System.out.println("Before search...");
			getDriver().findElement(By.xpath(xpathTargetDiv));
			System.out.println("Error!!! Target Shift is available on holiday");
			recievedSwapRequestBox.isEnabled();
		} catch (Exception ex) {
			System.out.println("By.xpath(xpathTargetDiv) Returns\n"
					+ ex.getMessage());
			System.out.println("Target Holiday shift is not available");
		}

	}

	public void verifyPTOShiftNotInTargetSlider(String recipient) {

		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();
		int PTODateInt = 0;
		int DEFAULTMAXDAYSSHIFTALLOWED = 14;
		int ptoCounts = ptoBoxList.size();

		int i = 1;
		String currentMonthBymySchedule = currentMonthByMySchedule.getText()
				.toString();
		String firstDayOfMonth = currentMonthBymySchedule.substring(0, 3)
				+ " 1";
		int lastDayOfMonth = Calendar.getInstance().getActualMaximum(
				Calendar.DAY_OF_MONTH);

		Date date = new Date();
		String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		String currentDateArray[] = currentDate.split("-");
		int currentDayOnly = Integer.parseInt(currentDateArray[2]);

		while (i <= ptoCounts) {
			String xpathPTOBoxDate = "(//*[@class = 'ptoBox'])["
					+ i
					+ "]/parent::div/parent::div/parent::div//div[@class='dayCellHeader']";
			String PTODate = getDriver().findElement(By.xpath(xpathPTOBoxDate))
					.getText().toString();
			if (PTODate.equals(firstDayOfMonth)) {
				PTODateInt = 1;
			} else {
				PTODateInt = Integer.parseInt(PTODate);
			}

			if (PTODateInt >= currentDayOnly) {
				break;
			}
			i++;
		}

		int j = 1;
		if (ptoCounts == 0 || (i > ptoCounts)) {
			nextMonthButtonAtMySchedule.click();
			WaitForAjax();
			waitABit(2000);
			ptoCounts = ptoBoxList.size();
			currentMonthBymySchedule = currentMonthByMySchedule.getText()
					.toString();
			firstDayOfMonth = currentMonthBymySchedule.substring(0, 3) + " 1";

			while (j <= ptoCounts) {
				String xpathPTOBoxDate = "(//*[@class = 'ptoBox'])["
						+ j
						+ "]/parent::div/parent::div/parent::div//div[@class='dayCellHeader']";
				String PTODate = getDriver()
						.findElement(By.xpath(xpathPTOBoxDate)).getText()
						.toString();
				if (PTODate.equals(firstDayOfMonth)) {
					PTODateInt = 1;
				} else {
					PTODateInt = Integer.parseInt(PTODate);
				}
				if (PTODateInt <= DEFAULTMAXDAYSSHIFTALLOWED
						- (lastDayOfMonth - currentDayOnly - 1)) {
					break;
				}
				j++;
			}

		}

		if (ptoCounts == 0 || j > ptoCounts) {
			System.out.println("No Holiday date is present for swap");
			return;
		}

		SwapEligiblebox.click();
		WaitForAjax();
		waitABit(2000);
		ShiftSwapButton.click();
		TargetSwapEmpSearchSlider.sendKeys(recipient);
		System.out.println("Recipient is selected");
		waitABit(2000);
		TargetSwapEmpSearch.waitUntilVisible();
		TargetSwapEmpSearch.click();

		String DateToSearch = null;
		if (PTODateInt < 10) {
			DateToSearch = currentMonthBymySchedule.substring(0, 3)
					.toUpperCase() + " 0" + PTODateInt;
		}

		else {
			DateToSearch = currentMonthBymySchedule.substring(0, 3)
					.toUpperCase() + " " + PTODateInt;
		}

		String xpathDatetoSearch = "//*[contains(text(),'" + DateToSearch
				+ "')]";

		do {
			try {
				getDriver().findElement(By.xpath(xpathDatetoSearch))
						.isEnabled();
				break;
			} catch (Exception ex) {
				NextWeekOnTargetSlider.isEnabled();
				NextWeekOnTargetSlider.click();
				WaitForAjax();
				waitABit(2000);
			}
		} while (true);

		getDriver().findElement(By.xpath(xpathDatetoSearch)).isEnabled();
		String xpathPTOColumn = "//*[contains(text(), '" + PTODateInt
				+ "')]/following-sibling::i";
		String ColumnAttribute = getDriver().findElement(
				By.xpath(xpathPTOColumn)).getAttribute("id");
		String ColumnAttributeArray[] = ColumnAttribute.split("\\.");
		String xpathTargetDiv = "//td[@id='TargetSwapSlideInView_ShiftSwapGrid.0."
				+ ColumnAttributeArray[2] + "']//*[@class='shiftSpan']";

		try {
			System.out.println("Before search...");
			getDriver().findElement(By.xpath(xpathTargetDiv));
			System.out.println("Error!!! Target Shift is available on PTO");
			recievedSwapRequestBox.isEnabled();
		} catch (Exception ex) {
			System.out.println("By.xpath(xpathTargetDiv) Returns\n"
					+ ex.getMessage());
			System.out.println("Target PTO shift is not available");
		}

	}

	public void verifyMaxSwapAllowedDays(int defaultSwapAllowedDays) {

		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();
		int lastDayOfMonth = Calendar.getInstance().getActualMaximum(
				Calendar.DAY_OF_MONTH);
		int lastEligibleSwapDate = 0;
		int FirstNonEligibleSwapDate = 0;
		Date date = new Date();
		String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		String currentDateArray[] = currentDate.split("-");
		int currentDayOnly = Integer.parseInt(currentDateArray[2]);

		boolean IsLastSwapEligibleDay = false, IsFirstNonSwapEligibleDay = false;
		boolean IsLastSwapEligibleDayHoliday = false, IsFirstNonSwapEligibleDayHoliday = false;

		if (lastDayOfMonth > currentDayOnly + defaultSwapAllowedDays - 1) {
			// nextMonthButtonAtMySchedule.click();
			WaitForAjax();
			waitABit(2000);
			lastEligibleSwapDate = defaultSwapAllowedDays
					+ (currentDayOnly - 1);
			FirstNonEligibleSwapDate = lastEligibleSwapDate + 1;
			String xPathlastEligibleSwapDate = "//div[@class='dayCell']//div[contains(text(),'"
					+ lastEligibleSwapDate
					+ "')]/following-sibling::div//*[@class ='swapEligibleBox']";
			String xPathFirstNonEligibleSwapDate = "//div[@class='dayCell']//div[contains(text(),'"
					+ FirstNonEligibleSwapDate
					+ "')]/following-sibling::div//*[@class ='shiftBox']";

			try {
				getDriver().findElement(By.xpath(xPathlastEligibleSwapDate))
						.isEnabled();
				IsLastSwapEligibleDay = true;
			} catch (Exception ex) {
				IsFirstNonSwapEligibleDay = false;
				String xPathlastEligibleSwapDateHolidayCheck = "//div[@class='dayCell']//div[contains(text(),'"
						+ lastEligibleSwapDate
						+ "')]/following-sibling::div//*[@class ='holidayBox']";
				getDriver().findElement(
						By.xpath(xPathlastEligibleSwapDateHolidayCheck))
						.isEnabled();
				IsLastSwapEligibleDayHoliday = true;
			}

			try {
				getDriver()
						.findElement(By.xpath(xPathFirstNonEligibleSwapDate))
						.isEnabled();
				IsFirstNonSwapEligibleDay = true;
			} catch (Exception ex) {
				IsFirstNonSwapEligibleDay = false;
				String xPathFirstNonEligibleSwapDateHolidayCheck = "//div[@class='dayCell']//div[contains(text(),'"
						+ FirstNonEligibleSwapDate
						+ "')]/following-sibling::div//*[@class ='holidayBox']";
				getDriver().findElement(
						By.xpath(xPathFirstNonEligibleSwapDateHolidayCheck))
						.isEnabled();
				IsFirstNonSwapEligibleDayHoliday = true;
			}
		}

		else if (lastDayOfMonth == currentDayOnly + defaultSwapAllowedDays - 1) {
			lastEligibleSwapDate = lastDayOfMonth;
			String xPathlastEligibleSwapDate = "//div[@class='dayCell']//div[contains(text(),'"
					+ lastEligibleSwapDate
					+ "')]/following-sibling::div//*[@class ='swapEligibleBox']";

			try {
				getDriver().findElement(By.xpath(xPathlastEligibleSwapDate))
						.isEnabled();
				IsLastSwapEligibleDay = true;
			} catch (Exception ex) {
				IsFirstNonSwapEligibleDay = false;
				String xPathlastEligibleSwapDateHolidayCheck = "//div[@class='dayCell']//div[contains(text(),'"
						+ lastEligibleSwapDate
						+ "')]/following-sibling::div//*[@class ='holidayBox']";
				getDriver().findElement(
						By.xpath(xPathlastEligibleSwapDateHolidayCheck))
						.isEnabled();
				IsLastSwapEligibleDayHoliday = true;
			}
			nextMonthButtonAtMySchedule.click();
			WaitForAjax();
			waitABit(2000);

			FirstNonEligibleSwapDate = 1;
			String xPathFirstNonEligibleSwapDate = "//div[@class='dayCell']//div[contains(text(),'"
					+ FirstNonEligibleSwapDate
					+ "')]/following-sibling::div//*[@class ='shiftBox']";
			try {
				getDriver()
						.findElement(By.xpath(xPathFirstNonEligibleSwapDate))
						.isEnabled();
				IsFirstNonSwapEligibleDay = true;
			} catch (Exception ex) {
				IsFirstNonSwapEligibleDay = false;
				String xPathFirstNonEligibleSwapDateHolidayCheck = "//div[@class='dayCell']//div[contains(text(),'"
						+ FirstNonEligibleSwapDate
						+ "')]/following-sibling::div//*[@class ='holidayBox']";
				getDriver().findElement(
						By.xpath(xPathFirstNonEligibleSwapDateHolidayCheck))
						.isEnabled();
				IsFirstNonSwapEligibleDayHoliday = true;
			}

		}

		else {
			nextMonthButtonAtMySchedule.click();
			WaitForAjax();
			waitABit(2000);
			lastEligibleSwapDate = defaultSwapAllowedDays
					- (lastDayOfMonth - currentDayOnly) - 1;
			FirstNonEligibleSwapDate = lastEligibleSwapDate + 1;
			String xPathlastEligibleSwapDate = "//div[@class='dayCell']//div[contains(text(),'"
					+ lastEligibleSwapDate
					+ "')]/following-sibling::div//*[@class ='swapEligibleBox']";
			String xPathFirstNonEligibleSwapDate = "//div[@class='dayCell']//div[contains(text(),'"
					+ FirstNonEligibleSwapDate
					+ "')]/following-sibling::div//*[@class ='shiftBox']";

			try {
				getDriver().findElement(By.xpath(xPathlastEligibleSwapDate))
						.isEnabled();
				IsLastSwapEligibleDay = true;
			} catch (Exception ex) {
				IsFirstNonSwapEligibleDay = false;
				String xPathlastEligibleSwapDateHolidayCheck = "//div[@class='dayCell']//div[contains(text(),'"
						+ lastEligibleSwapDate
						+ "')]/following-sibling::div//*[@class ='holidayBox']";
				getDriver().findElement(
						By.xpath(xPathlastEligibleSwapDateHolidayCheck))
						.isEnabled();
				IsLastSwapEligibleDayHoliday = true;
			}

			try {
				getDriver()
						.findElement(By.xpath(xPathFirstNonEligibleSwapDate))
						.isEnabled();
				IsFirstNonSwapEligibleDay = true;
			} catch (Exception ex) {
				IsFirstNonSwapEligibleDay = false;
				String xPathFirstNonEligibleSwapDateHolidayCheck = "//div[@class='dayCell']//div[contains(text(),'"
						+ FirstNonEligibleSwapDate
						+ "')]/following-sibling::div//*[@class ='holidayBox']";
				getDriver().findElement(
						By.xpath(xPathFirstNonEligibleSwapDateHolidayCheck))
						.isEnabled();
				IsFirstNonSwapEligibleDayHoliday = true;
			}
		}
		if (IsLastSwapEligibleDay == true && IsFirstNonSwapEligibleDay == true) {
			System.out
					.println("max allowed days able to swap and later days are not allowed to shift");
		} else if (IsLastSwapEligibleDayHoliday == true
				|| IsFirstNonSwapEligibleDayHoliday) {
			System.out
					.println("Holiday is on Last Eligible day or its next day So we can't determine");
		}

	}

	public void createSwapRequestWithExpiry(String recipient, int expirationTime)
			throws ParseException {

		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();
		SwapEligiblebox.click();
		ShiftSwapButton.click();
		waitABit(2000);
		WaitForAjax();
		TargetSwapEmpSearchSlider.waitUntilVisible();
		TargetSwapEmpSearchSlider.sendKeys(recipient);
		waitABit(2000);
		WaitForAjax();
		TargetSwapEmpSearch.waitUntilClickable();
		TargetSwapEmpSearch.click();
		WaitForAjax();
		TargetSwapBox.waitUntilClickable();
		TargetSwapBox.click();
		commentBoxRequestCreation
				.sendKeys("please accept the request, its urgent");
		waitABit(1000);

		SimpleDateFormat Dateformat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		Dateformat.setTimeZone(TimeZone.getTimeZone("PST"));
		String currentCST = Dateformat.format((new Date()));

		System.out.println("before add = " + currentCST);

		Date CurrentCSTdate = Dateformat.parse(currentCST);

		Calendar cal = Calendar.getInstance();
		cal.setTime(CurrentCSTdate);
		cal.add(Calendar.MINUTE, expirationTime);

		SimpleDateFormat DateOnlyFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat TimeOnlyFormat = new SimpleDateFormat("HH:mm a");

		DateOnlyFormat.setTimeZone(TimeZone.getTimeZone("PST"));
		TimeOnlyFormat.setTimeZone(TimeZone.getTimeZone("PST"));

		String newDateOnly = DateOnlyFormat.format(cal.getTime());
		String newTimeOnly = TimeOnlyFormat.format(cal.getTime());

		String newTime = Dateformat.format(cal.getTime());

		System.out.println("fianl result = " + newTime);

		ExpiryDateSetUpAtTargetSlider.clear();
		ExpiryTimeSetUpAtTargetSlider.clear();
		ExpiryDateSetUpAtTargetSlider.sendKeys(newDateOnly);
		ExpiryTimeSetUpAtTargetSlider.sendKeys(newTimeOnly);

		TargetSwapSendBtn.click();

	}

	public void waitAndRefreshMySchedule(int expirationTime) {
		int totalMiliSeconds = expirationTime * 60 * 1000;
		waitABit(totalMiliSeconds);
		nextMonthButtonAtMySchedule.click();
		WaitForAjax();
		waitABit(2000);
		prevMonthButtonAtMySchedule.waitUntilVisible();
		WaitForAjax();
		prevMonthButtonAtMySchedule.click();
		WaitForAjax();
	}

	public void verifySentSwapRequestNotInMySchedule() {

		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();

		int sentSwapRequestCount = sentSwapRequestBox.size();
		if (sentSwapRequestCount == 0) {
			System.out.println("No Sent Swap Request ");
		} else {
			System.out
					.println("Sent Swap Request is Still Present!!! ERROR!! ");
			approvalPendingSwapRequestBox.isEnabled();
			// this will show wrong error.. need to change it later
			// System.out.println("Sent Swap Request is Still Present!!! ERROR!! ");
			// assert false;

		}

	}

	public void verifyPendingApprovalRequestNotInMySchedule() {
		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();

		int pendingApprovalRequestCount = approvalPendingSwapRequestBoxList
				.size();
		if (pendingApprovalRequestCount == 0) {
			System.out.println("No Pending Approval Request ");
		} else {
			recievedSwapRequestBox.isEnabled();
			// this will show wrong error.. need to change it later
		}
	}

	public void requestMultipleEmployeeWithExpiry(String recipient1,
			String recipient2, int expirationTime) throws ParseException {

		WaitForAjax();
		SchedulingCalendar.waitUntilVisible();
		SwapEligiblebox.click();
		ShiftSwapButton.click();
		waitABit(2000);
		WaitForAjax();
		TargetSwapEmpSearchSlider.waitUntilVisible();
		// TargetSwapEmpSearchSlider.sendKeys(recipient1);
		waitABit(2000);
		// WaitForAjax();
		// TargetSwapEmpSearch.waitUntilVisible();
		// TargetSwapEmpSearch.click();
		WaitForAjax();
		// TargetSwapBox.click();
		commentBoxRequestCreation
				.sendKeys("please accept the request, its urgent");
		waitABit(1000);

		String xpathEmp1 = "(//*[contains(@title, '" + recipient1
				+ "')]//span[@class='shiftSpan'])[1]";
		String xpathEmp2 = "(//*[contains(@title, '" + recipient2
				+ "')]//span[@class='shiftSpan'])[1]";

		getDriver().findElement(By.xpath(xpathEmp1)).click();
		WaitForAjax();
		getDriver().findElement(By.xpath(xpathEmp2)).click();
		WaitForAjax();
		waitABit(1000);

		SimpleDateFormat Dateformat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		Dateformat.setTimeZone(TimeZone.getTimeZone("PST"));
		String currentCST = Dateformat.format((new Date()));

		System.out.println("before add = " + currentCST);

		Date CurrentCSTdate = Dateformat.parse(currentCST);

		Calendar cal = Calendar.getInstance();
		cal.setTime(CurrentCSTdate);
		cal.add(Calendar.MINUTE, expirationTime);

		SimpleDateFormat DateOnlyFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat TimeOnlyFormat = new SimpleDateFormat("HH:mm a");

		DateOnlyFormat.setTimeZone(TimeZone.getTimeZone("PST"));
		TimeOnlyFormat.setTimeZone(TimeZone.getTimeZone("PST"));

		String newDateOnly = DateOnlyFormat.format(cal.getTime());
		String newTimeOnly = TimeOnlyFormat.format(cal.getTime());

		String newTime = Dateformat.format(cal.getTime());

		System.out.println("fianl result = " + newTime);

		ExpiryDateSetUpAtTargetSlider.clear();
		ExpiryTimeSetUpAtTargetSlider.clear();
		ExpiryDateSetUpAtTargetSlider.sendKeys(newDateOnly);
		ExpiryTimeSetUpAtTargetSlider.sendKeys(newTimeOnly);

		TargetSwapSendBtn.click();

	}

	public void verifyRecievedRequestNotInMySchedule() {
		WaitForAjax();
		waitABit(2000);
		ToggleButton.waitUntilVisible();
		int count = recievedSwapRequestBoxList.size();
		if (count == 0) {
			System.out
					.println("Recieved swap request is declined successfully by  Recieved Shift Indicator");
		}

		else {
			System.out
					.println("Error : Recieved swap request is NOT declined successfully by  Recieved Shift Indicator ");
			approvalPendingSwapRequestBox.isEnabled();
			// this will show wrong error.. need to change it later
		}
	}

	public void changeLunchPlanOfPendingApproval(String sender) {
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpTextBox.sendKeys(sender);
		waitABit(2000);
		SupSearchEmpButton.waitUntilClickable();
		SupSearchEmpButton.click();

		waitABit(2000);
		WaitForAjax();
		supPendingApprovalShiftInfoBox.click();
		waitABit(3000);
		EditPendingApprovalrequestAtSchedule.click();
		WaitForAjax();
		waitABit(2000);
		String inputBoxText = lunchPlanInputBoxWhileShiftEditAtSchedule
				.getValue().toString();
		selectLunchPlanDropDownWhileShiftEditAtSchedule.click();
		select2ndLunchPlanWhileShiftEditAtSchedule.waitUntilClickable();
		String lunchPlanOptionValue = select2ndLunchPlanWhileShiftEditAtSchedule
				.getText().toString();
		if (inputBoxText.equals(lunchPlanOptionValue)) {
			select1stLunchPlanWhileShiftEditAtSchedule.click();
		} else {
			select2ndLunchPlanWhileShiftEditAtSchedule.click();
		}
		WaitForAjax();
		waitABit(1000);
		saveShiftAtSchedule.click();
		WaitForAjax();

	}

	public void changeLunchPlanOfSentSwapRequest(String sender) {

		// SupScheduleLoadIndicator.waitUntilVisible();
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpTextBox.waitUntilVisible();
		SupSearchEmpTextBox.sendKeys(sender);
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpButton.waitUntilVisible();
		waitABit(2000);
		SupSearchEmpButton.click();

		waitABit(2000);
		WaitForAjax();

		supShiftSwapRequestInfoBox.click();
		waitABit(3000);
		EditSentSwapRequestAtSchedule.click();
		WaitForAjax();
		waitABit(2000);
		String inputBoxText = lunchPlanInputBoxWhileShiftEditAtSchedule
				.getValue().toString();
		selectLunchPlanDropDownWhileShiftEditAtSchedule.click();
		select2ndLunchPlanWhileShiftEditAtSchedule.waitUntilClickable();
		String lunchPlanOptionValue = select2ndLunchPlanWhileShiftEditAtSchedule
				.getText().toString();
		if (inputBoxText.equals(lunchPlanOptionValue)) {
			select1stLunchPlanWhileShiftEditAtSchedule.click();
		} else {
			select2ndLunchPlanWhileShiftEditAtSchedule.click();
		}
		WaitForAjax();
		waitABit(1000);
		saveShiftAtSchedule.click();
		WaitForAjax();

	}

	public void expireShiftSwapRequestNotification(String sender,
			String recipient) {
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Request Expired");
		else
			goToNotification();

		// recipient = "'" + recipient + "'";
		// sender = "'" + sender + "'";
		String msg = "shift swap request has expired";
		checkNotifications(InTLM, msg, sender, recipient, "");

		/*
		 * String xpathVal=""; if(InTLM) xpathVal =
		 * "//div[contains(., 'shift swap request has expired') and contains(.,"
		 * + sender + ")  and contains(. , " + recipient + ")]"; else xpathVal =
		 * "//div[contains(@class, 'accordianDiv ng-binding') and contains(.//h2, 'shift swap request has expired') and contains(.,"
		 * + sender + ")  and contains(. , " + recipient + ")]";
		 * 
		 * getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		 * System.out.println("Notification for Shift Swap Request expired");
		 */
		if (!InTLM)
			deleteAllNotification();
	}

	public void ObservNoSentSwapRequestInSchedule(String sender) {
		// SupScheduleLoadIndicator.waitUntilVisible();
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpTextBox.waitUntilVisible();
		SupSearchEmpTextBox.clear();
		SupSearchEmpTextBox.sendKeys(sender);
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpButton.waitUntilVisible();
		waitABit(2000);
		SupSearchEmpButton.click();

		waitABit(2000);
		WaitForAjax();

		int count = pendingApprovalRequestListAtSchedule.size();
		if (count == 0) {
			System.out
					.println("Pending approval Shift Automatically canceled by editing shift");
		} else {
			System.out
					.println("pendig approval Shift is not Automatically canceled by editing shift!! ERROR!!");
			recievedSwapRequestBox.isEnabled();
			// this will throw wrong error
		}

	}

	public void verifyNoPendingRequestAtSchedulePage(String sender) {
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpTextBox.waitUntilVisible();
		SupSearchEmpTextBox.clear();
		SupSearchEmpTextBox.sendKeys(sender);
		WaitForAjax();
		waitABit(2000);
		SupSearchEmpButton.waitUntilVisible();
		waitABit(2000);
		SupSearchEmpButton.click();

		waitABit(2000);
		WaitForAjax();

		int count = supShiftSwapRequestInfoList.size();
		if (count == 0) {
			System.out.println("Shift Automatically canceled by editing shift");
		} else {
			System.out
					.println("Shift is not Automatically canceled by editing shift!! ERROR!!");
			recievedSwapRequestBox.isEnabled();
			// this will throw wrong error
		}

	}

	public void verifyNotificationForAutoCancelOnshiftEdit(String sender,
			String recipient) {

		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Canceled Notification");
		else
			goToNotification();

		WaitForAjax();
		String msg1 = "request has been automatically canceled";
		String msg2 = "change in one of the scheduled shifts in the request";
		checkNotifications(InTLM, msg1, msg2, sender, recipient);
		if (!InTLM)
			deleteAllNotification();

		/*
		 * goToNotification(); recipient = "'" + recipient + "'"; sender = "'" +
		 * sender + "'"; String xpathVal =
		 * "//div[contains(@class, 'accordianDiv ng-binding') and contains(.//h2, 'request has been automatically canceled') and contains(.//h2, 'change in one of the scheduled shifts in the request') and contains(.,"
		 * + sender + ")  and contains(. , " + recipient + ")]";
		 * getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		 * System.out.println
		 * ("Notification for AutoCancel swap Request when shift Edit");
		 * deleteAllNotification();
		 */
	}

	public void goToNotification() {
		waitABit(4000);
		WaitForAjax();
		messageCentre.waitUntilClickable();
		messageCentre.click();
		WaitForAjax();
		waitABit(2000);
		viewAllMessage.waitUntilClickable().then().click();
		
		WaitForAjax();
		waitABit(4000);
		notificationsBtn.waitUntilClickable().then().click();
		
		WaitForAjax();
		waitABit(4000);
	}

	public void deleteAllNotification() {
		waitABit(4000);
		WaitForAjax();
		selectAllMessageCheckBox.waitUntilClickable().then().click();
		waitABit(3000);
		WaitForAjax();
		selectAllCheckBox.waitUntilClickable().then().click();
		
		WaitForAjax();
		waitABit(3000);
		ArchiveIcon.waitUntilClickable().then().click();
		
		WaitForAjax();
		waitABit(2000);
		ConfirmArchiveButton.waitUntilClickable().then().click();
		
		WaitForAjax();
	}

	public void goToTLMNotificationCentre(String notificationType) {
		waitABit(2000);
		WaitForAjax();
		messageCentre.waitUntilClickable();
		messageCentre.click();
		WaitForAjax();
		waitABit(3000);
		viewAllMessageTLM.waitUntilClickable();
		viewAllMessageTLM.click();
		WaitForAjax();
		waitABit(2000);
		WaitForAjax();
		waitABit(2000);
		System.out.println("In TLM notification centre");
		// [contains(text(),'Shift Swap Request')]
		String xPathNotification = "//*[text()='"
				+ notificationType
				+ "']/parent::a/parent::td/parent::tr//*[@class='table-grid-cell ACTION']//*[@class='fa fa-angle-right']";
		WebElement Notification = getDriver().findElement(
				By.xpath(xPathNotification));
		WaitForAjax();
		waitABit(2000);
		System.out.println("In TLM notification clicked");
		waitABit(2000);
		Notification.click();
		WaitForAjax();
		waitABit(2000);
		reviewTLMNotification.waitUntilClickable();
		reviewTLMNotification.click();
		WaitForAjax();
	}

	/*
	 * public void goToTLMNotification(String notificationType){ WaitForAjax();
	 * System.out.println("In TLM notification centre"); String
	 * xPathNotification = "//*[text()='"+ notificationType +
	 * "']/parent::a/parent::td/parent::tr//*[@class='table-grid-cell ACTION']//*[@class='fa fa-angle-right']"
	 * ; WebElement Notification =
	 * getDriver().findElement(By.xpath(xPathNotification)); WaitForAjax();
	 * Notification.click(); reviewTLMNotification.waitUntilVisible();
	 * reviewTLMNotification.waitUntilClickable();
	 * reviewTLMNotification.click(); WaitForAjax();
	 * 
	 * }
	 */
	public void checkNotifications(boolean InTLM, String msg, String user1,
			String user2, String user3) {
		String xpathVal = "";

		WaitForAjax();
		waitABit(3000);
		if (InTLM) {
			xpathVal = "//div[contains(.,'" + msg + "')  and contains(. , '"
					+ user1 + "') and contains(. , '" + user2
					+ "') and contains(. , '" + user3 + "')  ]";
		} else {
			xpathVal = "//div[contains(@class, 'accordianDiv ng-binding') and contains(.,'"
					+ msg
					+ "')  and contains(. , '"
					+ user1
					+ "') and contains(. , '"
					+ user2
					+ "') and contains(. , '"
					+ user3 + "')  ]";
		}
		getDriver().findElement(By.xpath(xpathVal)).isEnabled();
		System.out.println("Notification is arrived for " + msg);
		WaitForAjax();
	}

	public void verifyRejectNotification(String supervisor, String sender,
			String recipient) {
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Rejected");
		else
			goToNotification();

		String msg = "rejected by " + supervisor;
		checkNotifications(InTLM, msg, sender, recipient, "");
		if (!InTLM)
			deleteAllNotification();
	}

	public void reviewAllTLMNotification() {
		waitABit(2000);
		WaitForAjax();
		messageCentre.waitUntilVisible();
		messageCentre.click();
		WaitForAjax();
		waitABit(3000);
		viewAllMessageTLM.waitUntilVisible();
		viewAllMessageTLM.waitUntilClickable();
		viewAllMessageTLM.click();
		WaitForAjax();
		waitABit(2000);
		WaitForAjax();
		System.out.println("In TLM notification centre");
		while (rightAngleSignForReviewTLMNotification.isPresent()) {
			rightAngleSignForReviewTLMNotification.waitUntilClickable();
			rightAngleSignForReviewTLMNotification.click();
			WaitForAjax();
			reviewTLMNotification.waitUntilClickable();
			reviewTLMNotification.click();
			WaitForAjax();
			// WebDriver driver = getDriver();
			// JavascriptExecutor jse = (JavascriptExecutor)driver;
			// jse.executeScript("scroll(0, 250);");
			WaitForAjax();
			// afterReviewRequestGoToMessageCentreTLM.waitUntilClickable();
			waitABit(2000);
			System.out.println("reviewing notification");
			messageCentre.click();
			WaitForAjax();
			waitABit(3000);
			viewAllMessageTLM.waitUntilVisible();
			viewAllMessageTLM.waitUntilClickable();
			viewAllMessageTLM.click();
			WaitForAjax();
			waitABit(2000);
			WaitForAjax();
			System.out.println("reviewed notification");
			WaitForAjax();
			waitABit(2000);
		}
	}

	public void observNoTargetShiftForLockPeriod(String lockPeriod,
			String reciever) throws ParseException {
		WaitForAjax();
		try {
			WaitForAjax();
			System.out
					.println(" User(sender) is going to create a swap request with "
							+ reciever);

			SchedulingCalendar.waitUntilVisible();
			System.out.println(" My schedule Page is Loaded");
			WaitForAjax();
			waitABit(2000);
			WebDriver driver = getDriver();
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("scroll(0, 250);");

			SwapEligiblebox.waitUntilClickable();
			SwapEligiblebox.click();
			System.out.println("eligible shift is selected");
			ShiftSwapButton.waitUntilClickable();
			ShiftSwapButton.click();
			TargetSwapEmpSearchSlider.sendKeys(reciever);

			System.out.println("Recipient is selected");
			waitABit(2000);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		int targetShiftCount = TargetSwapBoxList.size();
		int i = 0;
		String lockTime[] = lockPeriod.split("-");
		String lockStartTime = lockTime[0].substring(0,
				lockTime[0].length() - 1);
		String lock24HoursStartTime = convert12HoursTo24HoursFormat(lockStartTime);
		String lockEndTime = lockTime[1].substring(1, lockTime[1].length());
		String lock24HoursEndTime = convert12HoursTo24HoursFormat(lockEndTime);
		String shiftTime;
		if (Integer.parseInt(lockStartTime.split(":")[0]) < Integer
				.parseInt(lockEndTime.split(":")[0])) {
			while (i != targetShiftCount) {
				i++;
				String TargetShiftXpathval = "(//*[@class='shiftSpan'])[" + i
						+ "]";
				shiftTime = getDriver()
						.findElement(By.xpath(TargetShiftXpathval)).getText()
						.toString();
				System.out.println(shiftTime);
				String shiftTiming[] = shiftTime.split("-");
				String inTime = shiftTiming[0].split("\\r?\\n")[0];
				String outTime = shiftTiming[1].split("\\r?\\n")[1];
				String inTime24HoursFormat = convert12HoursTo24HoursFormat(inTime);
				String outTime24HoursFormat = convert12HoursTo24HoursFormat(outTime);
				String inTimeComparationLockStartTime = comparingTimeStamp(
						inTime24HoursFormat, lock24HoursStartTime);
				String inTimeComparationLockEndTime = comparingTimeStamp(
						inTime24HoursFormat, lock24HoursEndTime);

				if ((inTimeComparationLockStartTime == "after" || inTimeComparationLockStartTime == "equals")
						&& (inTimeComparationLockEndTime == "before" || inTimeComparationLockEndTime == "equals")) {

					System.out.println("Shift Found in lock period Error!!!!!");
					recievedSwapRequestBox.isEnabled();
					// throw wrong error

				}
			}
		}

	}

	public void SentRequestNotificationTLMSup(String sender, String reciever) {
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Request Notification");
		else
			goToNotification();

		WaitForAjax();
		String msg = sender + " is requesting";
		checkNotifications(InTLM, msg, reciever, "", "");
		if (!InTLM)
			deleteAllNotification();
	}

	public String convert12HoursTo24HoursFormat(String time)
			throws ParseException {
		SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm");
		SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
		Date date = parseFormat.parse(time);
		String dateIn24HoursFormat = displayFormat.format(date).toString();
		return dateIn24HoursFormat;

	}

	public String comparingTimeStamp(String intime, String lockTime)
			throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		Date date1 = dateFormat.parse(intime);
		Date date2 = dateFormat.parse(lockTime);

		Timestamp timestamp1 = new Timestamp(date1.getTime());
		System.out.println(timestamp1);

		Timestamp timestamp2 = new Timestamp(date2.getTime());
		System.out.println(timestamp2);

		// Test if timestamp1 is after timestamp2
		if (timestamp1.after(timestamp2)) {
			return "after";
		}

		// Test if timestamp1 is before timestamp2
		if (timestamp1.before(timestamp2)) {
			return "before";
		}

		if (timestamp1.equals(timestamp2)) {
			return "equals";
		}
		return null;

	}

	public void verifyNotificationForSenderCancelRequest(String sender,String reciever)
	{
		boolean InTLM = false;
		//InTLM = !WFNmessageCentre.isPresent();
		// InTLM is always false because notification made same as wfn 
		if (InTLM)
			goToTLMNotificationCentre("Shift Swap Canceled Notification");
		else
			goToNotification();

		WaitForAjax();
		//String msg = "Shift Swap Canceled Notification";
		String msg = "shift swap request has been  canceled";
		checkNotifications(InTLM, msg, sender, reciever, "");
		if (!InTLM)
			deleteAllNotification();

	}

}