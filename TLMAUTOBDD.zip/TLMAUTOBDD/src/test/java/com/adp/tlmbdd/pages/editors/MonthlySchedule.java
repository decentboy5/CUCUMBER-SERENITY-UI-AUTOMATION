package com.adp.tlmbdd.pages.editors;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.assertj.core.api.Fail;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import com.adp.tlmbdd.pages.AdditionalConfiguration;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.reports.history.SystemDateProvider;
import net.thucydides.core.steps.ScenarioSteps;
import com.adp.tlmbdd.pages.Navigation;
//import com.restrallyapi.RallyUpdateTests;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import com.adp.tlmbdd.common.*;


public class MonthlySchedule extends GenericPageObject{

	Navigation nav;

	@FindBy(xpath = "//div[@id='MonthlyScheduleCalender']/table/tr[2]/td[1]/div/button[@class='vdl-action-menu__button vdl-action-menu__button--md vdl-button vdl-button--link']")
	private WebElementFacade MonthlyScheduleRowGrabber;


	@FindBy(xpath = "//a[contains(text(),'Remove Schedule Deviations')]")
	private WebElementFacade SchedDeviations;

	@FindBy(xpath = "//a[contains(text(),'Non-Work Scheduler')]")
	private WebElementFacade NonWorkScheduler;

	@FindBy(id = "action-0-0")
	private WebElementFacade ScheduleGrid;

	@FindBy(xpath ="//tr[contains(@id,'SchedulingCalendar.SchedulingGridUnlocked')]")
	private List<WebElementFacade> SchedulesList;

	@FindBy(xpath ="(//td[contains(@class,'unselectable reactSpreadsheetCellPadding SchedulingCalendar_SchedulingGridColumn')])[3]")
	private WebElementFacade ScheduleCell;

	@FindBy(xpath = "//div[@id='timepair.0.2.0']/div[2]/i[2]")
	private WebElementFacade Scheduleadd;

	@FindBy(xpath = "//span[contains(text(),'Schedule Template')]")
	private WebElementFacade SchedTemplateLink;

	@FindBy(xpath = ".//*[@id='MonthlyScheduleCalender']")
	private WebElementFacade Calender;


	@FindBy(xpath = "//div[@id='MonthlyScheduleCalender']/table/tr[2]/td[2]/div[2]/div[@class='emp-add-container']/div[@class='shift-add-action fa fa-2x fa-plus-circle']")
	private WebElementFacade AddScheduleButton;

	@FindBy(xpath = ".//*[@id='MonthlyScheduleCalender.1.2']/div[2]/div[2]/")
	private WebElementFacade MonthlyScheduleCell;


	@FindBy(xpath = "//input[@aria-describedby='popover-1']")
	private WebElementFacade ShiftDurationTextBox;

	@FindBy(xpath = "(//input[@class='vdl-date-time-picker__input'])[1]")
	private WebElementFacade StartTimeTextBox;

	@FindBy(xpath = "(//input[@class='vdl-date-time-picker__input'])[2]")
	private WebElementFacade EndTimeTextBox;

	@FindBy(xpath = "(//input[@class='vdl-textbox vdl-textbox--touched'])")
	private WebElementFacade TotalHoursTextBox;


	@FindBy(xpath = "//table/tr/td/button[1]")
	private WebElementFacade SaveButton;

	@FindBy(xpath = "//div[contains(text(),'Add Shift')]")
	private WebElementFacade AddShiftDialog;

	@FindBy(xpath = "//div[contains(text(),'Delete Shift')]")
	private WebElementFacade DeleteShiftDialog;

	@FindBy(xpath = "//div[contains(text(),'Edit Shift')]")
	private WebElementFacade EditShiftDialog;

	@FindBy(xpath = "//span[text()='YES']/..")
	private WebElementFacade Confirmation;

	@FindBy(xpath = "(//*[@id='MonthlyScheduleCalender']//button)[1]")
	private WebElementFacade weekpopoverlink;

	@FindBy(xpath = "//a[text()='Remove Schedule Deviations']")
	private WebElementFacade removeScheduleDevaitionDropDownLink;

	@FindBy(xpath = "//span[contains(text(),'Annual Summary')]")
	private WebElementFacade AnnualSummaryLink;

	@FindBy(xpath ="//span[@class='vdl-modal-title']")
	private WebElementFacade popupTitle;


	@FindBy(xpath ="//div[contains(@class,'rsd-information-message')]")
	private WebElementFacade removeScheduleDeviationsInfoTextContainer;

	@FindBy(xpath ="//button[contains(@class,'fsd-button vdl-button') and span='Cancel']")
	private WebElementFacade removeScheduleDeviationsPopupCloseButton;

	@FindBy(xpath ="//button[contains(@class,'fsd-button vdl-button') and span='Submit']")
	private WebElementFacade removeScheduleDeviationsPopupSubmitButton;

	@FindBy(xpath =".//div[contains(@class,'vdl-alert')]//span")
	private WebElementFacade alertMessage;

	@FindBy(xpath ="//span[contains(text(),'Deviations Successfully Removed')]")
	private WebElementFacade DeviationsRemovalMessage;


	@FindBy(xpath = "(//button[@class='vdl-date-time-picker__select__picker'])[2]")
	private WebElementFacade DateControl;

	/*@FindBy(xpath = "(//div[@class='vdl-dropdown-list__input'])[3]")
	private WebElementFacade Departmentlookup;*/

	@FindBy(xpath = "//div[contains(text(),'Department')]/following-sibling::div/div/div/span")
	private WebElementFacade Departmentlookup;

	@FindBy(xpath = "//div[contains(text(),'Meal Plan')]/following-sibling::div/div/div/span")
	private WebElementFacade MealPlanlookup;

	@FindBy(xpath = "(//div[@class='vdl-dropdown-list__filter'])[3]/following-sibling::ul/li[2]")
	private WebElementFacade Departmentfirst;

	@FindBy(xpath = "(//div[@class='vdl-dropdown-list__filter'])[2]/following-sibling::ul/li[2]")
	private WebElementFacade MealPlanfirst;

	@FindBy(xpath = "((//td[@class='currentMonthCell'])[1]/div[2]/div/div[@class='emp-cell-action-container']/div[@class='shift-edit-action fa fa-edit'])[1]")
	private WebElementFacade EditButton;

	@FindBy(xpath ="//div[@id='MonthlyScheduleCalender']/table/tr[2]")
	public List<WebElementFacade> MonthlyCalender;

	@FindBy(xpath = ".//*[@id='MonthlyScheduleCalender.0.1']/div[2]/div[2]/div[2]/div[1]")
	public WebElementFacade EditIcon;

	@FindBy(xpath = "(//*[@class='shift-edit-action fa fa-trash-o'])[1]")
	public WebElementFacade DeleteIcon;


	@FindBy(xpath = "(//*[@class='shift-edit-action fa fa-edit'])[1]")
	public WebElementFacade EditIconNew;


	@FindBy(xpath = "(//td[@class='currentMonthCell'])")
	public List <WebElementFacade> AddIcon;

	@FindBy(xpath = "//div[@id='MonthlyScheduleCalender']/table/tr")
	public List <WebElementFacade> RowCount;


	@FindBy(xpath = "//div[@class='vdl-toggle-switch__label vdl-toggle-switch__label--unchecked']")
	public WebElementFacade ScheduleTemplateToggleButton;

	@FindBy(xpath = ".//*[@id='MonthlyScheduleCalender.0.1']/div[2]/div[1]/div[3]/div")
	public WebElementFacade ScheduleIcon;

	@FindBy(xpath = ".//*[@id='SchedulingTemplateList.NewTemplate']")
	public WebElementFacade NewTemplateButton;

	@FindBy(xpath = ".//*[@id='SchedulingTemplateCreator.TemplateName']")
	public WebElementFacade TemplateID;

	@FindBy(xpath = ".//*[@id='SchedulingTemplateCreator.TemplateDescription']")
	public WebElementFacade TemplateDesc;

	@FindBy(xpath = ".//*[@id='SchedulingTemplateCreator.TemplateVersionsView_0.TemplateStartDate']")
	public WebElementFacade TemplateDate;

	@FindBy(xpath = "(//button[@class='vdl-date-time-picker__select__picker'])[1]")
	public WebElementFacade PreviousMonth;

	@FindBy(xpath = "(//button[@class='vdl-date-time-picker__select__picker'])[3]")
	public WebElementFacade NextMonth;

	@FindBy(xpath = "(//div[@class='schedule emp-regular-shift'])[1]")
	public List <WebElementFacade> ShiftCount;

	@FindBy(xpath = "//td[@class='currentMonthCell']")
	public WebElementFacade FirstDay;

	@FindBy(xpath = "//div[contains(text(),'Pay Code')]/following-sibling::div/div/div/span[@class='vdl-dropdown-list__picker']")
	public WebElementFacade PayCodeDropdown;	

	@FindBy(xpath = "//div[contains(text(),'Department')]/following-sibling::div/div/div/span[@class='vdl-dropdown-list__picker']")
	public WebElementFacade DepartmentDropdown;		

	@FindBy(xpath = ".//*[@id='vdl_9__listbox__option__1']")
	public WebElementFacade FirstPayCode;

	@FindBy(xpath = ".//*[@id='vdl_11__listbox__option__1']")
	public WebElementFacade FirstDepartment;

	@FindBy(xpath = "(//div[@class='schedule emp-holiday-shift'])[1]")
	public WebElementFacade HolidayIdentifier;

	@FindBy(xpath = "//textarea[@class='custom-textarea-style vdl-textarea']")
	public WebElementFacade NotesTextArea;

	@FindBy(xpath = "(.//*[@id='monthlyScheduleLanding_root']/div/div[@class='vdl-row MonthlyScheduleCalender']/div/div/div/div[1]/label)[1]")
	public WebElementFacade MonthandYear;

	@FindBy(xpath = "//div[@class='emp-shift-details']/div")
	public List <WebElementFacade> AllShifts;

	@FindBy(xpath = ".//*[@id='monthlyScheduleLanding_root']//span[contains(text(),'More')]")
	public WebElementFacade MoreLink;

	@FindBy(xpath = "//li[text()='Preferences']")
	public WebElementFacade PrefLink;

	@FindBy(xpath = "//input[@value='CURRENT_DATE_WEEK']")
	public WebElementFacade DefaultStartWeek;

	@FindBy(xpath = "//input[@value='FIRST_WEEK']")
	public WebElementFacade FirstWeek;

	@FindBy(xpath = "//span[text()='Close']")
	public WebElementFacade PrefSliderClose;

	@FindBy(xpath = "//span[text()='Apply']")
	public WebElementFacade PrefSliderApply;

	@FindBy(xpath = "//td[@class='currentMonthCell' or @class='currentMonthCell currentDay ' or @class='closedCell']")
	public List <WebElementFacade> DaysInMonth; 


	@FindBy(xpath = "//span[@id='employeeIdBarEmpListTooltipBtn']")
	public WebElementFacade empSearchButton;

	@FindBy(id = "empIdBarFilterId")
	public WebElementFacade currentListTextBox;

	@FindBy(xpath = "//div[@id='employeeIdBarEmpListTooltipDialog']")
	public WebElementFacade employeeSearchDailog;

	@FindBy(xpath = "//input[@id='idBarSscrollGrid_search']")
	public WebElementFacade searchTextBox;

	@FindBy(xpath = "//a[@id='idBarSscrollGridIdCol_Id_1']")
	public WebElementFacade searchEmployee;





	public void ValidateMonthlySchedule()
	{

		//MonthlyScheduleRowGrabber.isDisplayed();
		WaitForAjax();
		waitABit(10000);
		Calender.waitUntilVisible();
		int shiftcount = AllShifts.size();

		for(int i=0;i<=shiftcount;i++)
		{
			System.out.println(i);
			if(AllShifts.contains("undefined"))
			{
				System.out.println("Shifts are not defined, UI issue");
			}
		}

	}

	public void ValidateEmpDet()
	{
		WaitForAjax();
		waitABit(10000);
		Calender.waitUntilVisible();				
		MonthlyScheduleRowGrabber.waitUntilPresent();
		MonthlyScheduleRowGrabber.click();
		SchedDeviations.waitUntilClickable();
		SchedDeviations.isEnabled();
		NonWorkScheduler.isEnabled();

	}

	public void ValidateSched()
	{
		Calender.isEnabled();
		MonthlyScheduleRowGrabber.waitUntilPresent();
		MonthlyScheduleRowGrabber.click();
		SchedDeviations.isEnabled();
		NonWorkScheduler.isEnabled();

	}

	public void AddSched()
	{		
		waitABit(10000);
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		if((getDriver().findElements(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift'])[1]"))).isEmpty())
		{
			while (true)
			{
				//getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]")).click();
				waitABit(1000);
				//getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]/div[2]/div/div[@class='emp-cell-action-container']/div[@class='shift-edit-action fa fa-trash-o']")).click();
				//if(!(getDriver().findElements(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift '])[1])")).isEmpty()))
				//{
				getDriver().findElement(org.openqa.selenium.By.xpath(".//*[@id='MonthlyScheduleCalender.0.1']/div[2]/div[1]")).click();
				withAction().doubleClick(DeleteIcon);
				waitABit(1000);
				DeleteIcon.click();  
				DeleteShiftDialog.waitUntilVisible();
				System.out.println("Dialog opened");
				Confirmation.click();
				waitABit(2000);		

				getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]")).click();
				waitABit(3000);
				//getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]//div[@class='emp-add-container']/div[@class='shift-add-action fa fa-2x fa-plus-circle']")).click();
				//}
				waitABit(3000);
				AddShiftDialog.waitUntilVisible();
				System.out.println("Dialog opened");
				StartTimeTextBox.sendKeys("1:30");
				StartTimeTextBox.sendKeys(Keys.TAB);
				EndTimeTextBox.sendKeys("2:30");

				//ShiftDurationTextBox.sendKeys("8");
				waitABit(2000);
				ShiftDurationTextBox.sendKeys(Keys.TAB);
				SaveButton.click();
				break;
			}
			System.out.println("Pop up opened");
		}
		else
		{
			getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]")).click();
			waitABit(3000);
			AddShiftDialog.waitUntilVisible();
			System.out.println("Dialog opened");
			StartTimeTextBox.sendKeys("1:30");
			StartTimeTextBox.sendKeys(Keys.TAB);
			EndTimeTextBox.sendKeys("2:30");

			//ShiftDurationTextBox.sendKeys("8");
			waitABit(2000);
			ShiftDurationTextBox.sendKeys(Keys.TAB);
			SaveButton.click();
		}

	}

	public void AddSchedwjobdept()
	{		
		waitABit(10000);
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");

		if((ShiftCount.size() > 0))
		{
			while (true)
			{
				waitABit(1000);
				getDriver().findElement(org.openqa.selenium.By.xpath("((//td[contains(@id,'MonthlyScheduleCalender') and @class='currentMonthCell']))[1]")).click();

				waitABit(1000);
				getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift'])[1]")).click();
				waitABit(1000);
				//withAction().moveToElement(FirstDay).click().build().perform();
				waitABit(2000);
				//withAction().doubleClick(DeleteIcon);
				getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift']/div/div[@class='shift-edit-action fa fa-trash-o'])[1]")).click();

				waitABit(1000);
				//DeleteIcon.click();  
				DeleteShiftDialog.waitUntilVisible();
				System.out.println("Dialog opened");
				waitABit(1000);
				Confirmation.click();
				waitABit(2000);		

				getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]")).click();
				waitABit(3000);
				getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]//div[@class='emp-add-container']/div[@class='shift-add-action fa fa-2x fa-plus-circle']")).click();
				//}
				waitABit(3000);
				AddShiftDialog.waitUntilVisible();
				System.out.println("Dialog opened");
				StartTimeTextBox.sendKeys("1:30");
				StartTimeTextBox.sendKeys(Keys.TAB);
				EndTimeTextBox.sendKeys("2:30");
				waitABit(2000);
				ShiftDurationTextBox.clear();

				ShiftDurationTextBox.sendKeys("3");
				PayCodeDropdown.click();
				waitABit(1000);

				FirstPayCode.click();         		
				waitABit(1000);
				//String paycodetext1 = getDriver().findElement(By.xpath("(//div[@class='vdl-dropdown-list__input'])[1]")).getText();
				//System.out.println("Paycode selected is " + paycodetext1);
				DepartmentDropdown.click();
				waitABit(1000);
				FirstDepartment.click();
				waitABit(1000);
				SaveButton.click();
				waitABit(1000);
				MonthlyScheduleRowGrabber.waitUntilPresent();
				getDriver().findElement(org.openqa.selenium.By.xpath("((//td[contains(@id,'MonthlyScheduleCalender') and @class='currentMonthCell']))[1]")).click();
				waitABit(1000);
				EditIconNew.click();
				//String paycodetext2 = FirstPayCode.getText();
				//System.out.println("Paycode selected after edit is " + paycodetext2);
				waitABit(1000); 			
				break;
			}
			System.out.println("Pop up opened");
		}
		else
		{
			getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]")).click();
			waitABit(3000);
			getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]//div[@class='emp-add-container']/div[@class='shift-add-action fa fa-2x fa-plus-circle']")).click();
			AddShiftDialog.waitUntilVisible();
			System.out.println("Dialog opened");
			StartTimeTextBox.sendKeys("1:30");
			StartTimeTextBox.sendKeys(Keys.TAB);
			EndTimeTextBox.sendKeys("2:30");
			waitABit(2000);
			ShiftDurationTextBox.clear();

			ShiftDurationTextBox.sendKeys("3");
			PayCodeDropdown.click();
			waitABit(1000);		
			FirstPayCode.click();       		
			waitABit(1000);
			//String paycodetext3 = FirstPayCode.getText();
			//System.out.println("Paycode selected is " + paycodetext3);
			DepartmentDropdown.click();
			waitABit(1000);
			FirstDepartment.click();
			waitABit(1000);
			SaveButton.click();
			waitABit(1000);
			MonthlyScheduleRowGrabber.waitUntilPresent();
			getDriver().findElement(org.openqa.selenium.By.xpath("((//td[contains(@id,'MonthlyScheduleCalender') and @class='currentMonthCell']))[1]")).click();      
			waitABit(1000);
			EditIconNew.click();

			waitABit(1000); 	
			//String paycodetext4 = FirstPayCode.getText();  
			//System.out.println("Paycode selected after edit is " + paycodetext4);

		}

	}









	public void AddSchedAll()
	{		
		waitABit(10000);
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");

		int AddIconcount = AddIcon.size();
		System.out.println("Add Icon count is " + AddIconcount);
		int rowcount = RowCount.size();
		System.out.println("Row count is " + rowcount);

		for (int j=0;j<rowcount-2;j++)
		{	
			for (int i=1;i<=AddIconcount-1;i++)
			{	
				waitABit(2000);

				if((getDriver().findElements(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift '])["+ i +"]"))).isEmpty())
				{		
					getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])["+ (i+1) +"]")).click();
					waitABit(2000);
					getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])["+ (i+1) +"]/div/div/div[@class='shift-add-action fa fa-2x fa-plus-circle']")).click();
					//getDriver().findElement(org.openqa.selenium.By.xpath(".//*[@id='MonthlyScheduleCalender."+ j +"."+ i +"']/div[2]/div/div")).click();	
					System.out.println("Add Icon clicked");
					waitABit(5000);
					AddShiftDialog.waitUntilVisible();
					System.out.println("Dialog opened");
					StartTimeTextBox.sendKeys("1:30");
					StartTimeTextBox.sendKeys(Keys.TAB);
					EndTimeTextBox.sendKeys("2:30");
					EndTimeTextBox.sendKeys(Keys.TAB);
					//ShiftDurationTextBox.sendKeys("8");
					waitABit(2000);
					//ShiftDurationTextBox.sendKeys(Keys.TAB);
					SaveButton.click();
				}
			}

		}
	}

	public void SelectDate()
	{		
		waitABit(10000);
		MonthlyScheduleRowGrabber.waitUntilPresent();
		String monthvalcurrent = getDriver().findElement(By.xpath("//div[@class='vdl-col-lg-8']/div/label")).getText();
		PreviousMonth.click();
		waitABit(3000);
		String monthvalprev = getDriver().findElement(By.xpath("//div[@class='vdl-col-lg-8']/div/label")).getText();
		if(monthvalcurrent!=monthvalprev)
		{
			System.out.println("Month changed");
		}
	}

	public void EditSched()
	{		
		waitABit(10000);
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		waitABit(10000);
		if (getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]/div[2]/div[@class='emp-add-container']|(//td[@class='currentMonthCell'])[1]/div[2]/div/div[@class='emp-shift-details']")).isEnabled())
		{
			while (true)
			{
				getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell']/div[2]/div/div[@class='emp-shift-details'])[1]/../../..")).click();
				waitABit(3000);
				System.out.println("Cell click completed");
				// getDriver().findElement(org.openqa.selenium.By.xpath(".//*[@id='MonthlyScheduleCalender.0.1']/div[2]/div[1]")).click();
				//getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='emp-cell-action-container'])[1]")).click();

				waitABit(2000);
				getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift']/div/div[@class='shift-edit-action fa fa-edit'])[1]")).click();
				//withAction().doubleClick(EditButton);
				waitABit(1000);
				System.out.println("Hover completed");               
				EditIconNew.click();

				break;
			}
			System.out.println("Pop up opened");
		}


		EditShiftDialog.waitUntilVisible();
		System.out.println("Dialog opened");
		ShiftDurationTextBox.clear();
		ShiftDurationTextBox.sendKeys("9");
		waitABit(2000);
		ShiftDurationTextBox.sendKeys(Keys.TAB);
		SaveButton.click();

	}

	public void DeleteSched()
	{	
		waitABit(10000);

		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");

		if (getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]/div[2]/div[@class='emp-add-container']|(//td[@class='currentMonthCell'])[1]/div[2]/div/div[@class='emp-shift-details']")).isEnabled())
		{
			while (true)
			{
				getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell']/div[2]/div/div[@class='emp-shift-details'])[1]/../../..")).click();
				waitABit(3000);
				System.out.println("Cell click completed");
				// getDriver().findElement(org.openqa.selenium.By.xpath(".//*[@id='MonthlyScheduleCalender.0.1']/div[2]/div[1]")).click();
				//getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='emp-cell-action-container'])[1]")).click();

				waitABit(2000);
				getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift']/div/div[@class='shift-edit-action fa fa-trash-o'])[1]")).click();
				//withAction().doubleClick(EditButton);
				//withAction().doubleClick(DeleteIcon);
				waitABit(1000);
				//System.out.println("Hover completed");               
				//DeleteIcon.click();  


				break;
			}
			System.out.println("Pop up opened");
		}	

		waitABit(2000);		

		DeleteShiftDialog.waitUntilVisible();
		System.out.println("Dialog opened");
		Confirmation.click();
		waitABit(2000);		

	}


	public void RemoveSchedDeviation()
	{	
		waitABit(10000);
		removeScheduleDevaitionDropDownLink.waitUntilVisible();
		removeScheduleDevaitionDropDownLink.click();
		removeScheduleDeviationsPopupSubmitButton.click();
	}

	public void RemoveDeviationsMessage()
	{	
		DeviationsRemovalMessage.waitUntilVisible();
		DeviationsRemovalMessage.isVisible();

	}


	public void EnableScheduleTemplate()
	{
		ScheduleTemplateToggleButton.click();
	}

	public void AssignTemplate()
	{
		getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell']/div[2]/div/div[@class='emp-shift-details'])[1]/../../..")).click();
		ScheduleIcon.click();
		NewTemplateButton.waitUntilVisible();
		NewTemplateButton.click();
		TemplateDate.sendKeys("test");
	}

	public void ValidateAnnualSummary()
	{
		AnnualSummaryLink.isCurrentlyEnabled();
	}

	public void ClickPref()
	{
		waitABit(5000);
		MoreLink.click();
		waitABit(3000);
		PrefLink.isDisplayed();
		PrefLink.click();
	}

	public void ValidatePref()
	{
		DefaultStartWeek.isVisible();
		PrefSliderClose.click();
	}

	public void ValidateHoliday()
	{
		waitABit(5000);
		HolidayIdentifier.isDisplayed();
	}

	public void ValidateCalendar()
	{
		DateControl.click();
	}

	public void ValidateFirstWeekintheMonth(String DefaultStartWeek)
	{
		waitABit(5000);
		if(DefaultStartWeek.equals("FirstWeek"))
		{
			WebElement rbfirstweek = getDriver()
					.findElement(By.xpath("//input[@value='FIRST_WEEK']"));
			if (!rbfirstweek.isSelected()) {

				JavascriptExecutor js = (JavascriptExecutor)getDriver(); 
				js.executeScript("arguments[0].click();", rbfirstweek);
				PrefSliderApply.click();
				//System.out.println("First week not selected by default");
			}

			PrefSliderClose.click();
		}

		else if(DefaultStartWeek.equals("ThisWeek"))
		{
			WebElement rbthisweek = getDriver()
					.findElement(By.xpath("//input[@value='CURRENT_DATE_WEEK']"));
			if (!rbthisweek.isSelected()) {

				//getDriver().findElement(By.xpath("//input[@value='CURRENT_DATE_WEEK']/../label")).click();
				JavascriptExecutor js = (JavascriptExecutor)getDriver(); 
				js.executeScript("arguments[0].click();", rbthisweek);
				PrefSliderApply.click();

			}
		}
		PrefSliderClose.click();
		waitABit(5000);
	}


	public void MovetoMonth(String Month)
	{	
		Map<String,Integer> Months = new HashMap<>();
		Months.put("January",31);
		Months.put("February",28);
		Months.put("March",31);
		Months.put("April",30);
		Months.put("May",31);
		Months.put("June",30);
		Months.put("July",31);
		Months.put("August",31);
		Months.put("Septemnber",30);
		Months.put("October",31);
		Months.put("November",30);
		Months.put("December",31);
		System.out.println(Months);
		//System.out.println(Months.get("January"));		

		for(int i=0;i<12;i++)
		{
			String currmonth = MonthandYear.getText();
			String[] curmonth = currmonth.split(",");		
			while(!curmonth[0].equals(Month))
			{						
				NextMonth.click();
				break;
			}		
		}
		waitABit(5000);
		int daysinthemonth = DaysInMonth.size();					

		if(daysinthemonth >= Months.get(Month))
		{
			System.out.println("Days in month matched with the Month in the calendar");
		}
		else
		{
			System.out.println("Days in month does not match with the Month in the calendar");

		}		

	}

	public void MovetoMonthCalendar(String Month)
	{	
		Map<String,Integer> Months = new HashMap<>();
		Months.put("January",31);
		Months.put("February",28);
		Months.put("March",31);
		Months.put("April",30);
		Months.put("May",31);
		Months.put("June",30);
		Months.put("July",31);
		Months.put("August",31);
		Months.put("Septemnber",30);
		Months.put("October",31);
		Months.put("November",30);
		Months.put("December",31);
		System.out.println(Months);
		//System.out.println(Months.get("January"));		

		for(int i=0;i<12;i++)
		{
			String currmonth = MonthandYear.getText();
			String[] curmonth = currmonth.split(",");	
			String month = Month.substring(0, 3);

			while(!curmonth[0].equals(Month))
			{
				DateControl.click();	
				getDriver().findElement(By.xpath("//div[contains(text(),'"+month+"')]")).click();
				break;
			}		
		}
		waitABit(5000);
		int daysinthemonth = DaysInMonth.size();					
		waitABit(5000);

		if(daysinthemonth >= Months.get(Month))
		{
			System.out.println("Days in month matched with the Month in the calendar");
		}
		else
		{
			System.out.println("Days in month does not match with the Month in the calendar");

		}		


	}



	public void ValidateCalendarMonth()
	{
		waitABit(8000);		
		WaitForAjax();
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		waitABit(8000);		
		String currmonth = MonthandYear.getText();
		System.out.println("Current Month is " + currmonth);
		String[] curmonth = currmonth.split(",");
		System.out.println(curmonth[0]);
		waitABit(3000);		
		String firstday = getDriver().findElement(By.xpath("//span[text()= '" + curmonth[0] + "']/../span[2]")).getText();
		if(firstday.equals("1"))
		{
			System.out.println("Entire calendar loaded");
		}
		else
		{
			Assert.fail("Entire calendar not loaded");
		}
	}

	public void ValidateThisWeek()
	{
		waitABit(8000);
		WaitForAjax();
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");			
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		waitABit(8000);		
		String currmonth = MonthandYear.getText();
		System.out.println("Current Month is " + currmonth);
		String[] curmonth = currmonth.split(",");
		System.out.println(curmonth[0]);
		String firstday = getDriver().findElement(By.xpath("//span[text()= '" + curmonth[0] + "']/../span[2]")).getText();
		if(!firstday.equals("1"))
		{
			System.out.println("Week containing today's date is displayed");
		}
		else
		{
			Assert.fail("Week containing today's date is not displayed");
		}
	}



	public void SelectDateinPPP()
	{
		nav.wfnmainPageNavigation("People", "Time & Attendance", "Individual Timecard"); 
		String startdate = getDriver().findElement(By.xpath(".//*[@id='dateRangestart']")).getAttribute("value");
		System.out.println("start date is " + startdate);
		nav.wfnmainPageNavigation("People", "Time & Attendance", "Monthly Schedule");
		String months[]= {"January","February","March","April","May","June","July","August","September","October","November","December"};
		String numericmonths[] = {"1","2","3","4","5","6","7","8","9","10","11"};
	}

	public void SelectDateinPast()
	{
		ValidateCalendar();
		SelectDate();
	}


	public void ChangeDept()
	{	
		waitABit(10000);
		WaitForAjax();
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		waitABit(10000);		
		if (getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]/div[2]/div[@class='emp-add-container']|(//td[@class='currentMonthCell'])[1]/div[2]/div/div[@class='emp-shift-details']")).isEnabled())
		{
			while (true)
			{
				getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell']/div[2]/div/div[@class='emp-shift-details'])[1]/../../..")).click();
				waitABit(3000);
				System.out.println("Cell click completed");
				// getDriver().findElement(org.openqa.selenium.By.xpath(".//*[@id='MonthlyScheduleCalender.0.1']/div[2]/div[1]")).click();
				//getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='emp-cell-action-container'])[1]")).click();

				waitABit(2000);
				getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift']/div/div[@class='shift-edit-action fa fa-edit'])[1]")).click();
				//withAction().doubleClick(EditButton);
				waitABit(1000);
				System.out.println("Hover completed");               
				EditIconNew.click();

				break;
			}
			System.out.println("Pop up opened");
		}

		EditShiftDialog.waitUntilVisible();
		System.out.println("Dialog opened");

		ShiftDurationTextBox.sendKeys("9");
		waitABit(2000);
		ShiftDurationTextBox.sendKeys(Keys.TAB);
		waitABit(2000);
		Departmentlookup.click();
		waitABit(2000);
		System.out.println("Look up clicked");
		Departmentfirst.click();		
		System.out.println("Department selected");       
		NotesTextArea.clear();
		NotesTextArea.sendKeys("Test");
		SaveButton.click();
	}

	public void ChangeMeal()
	{	
		waitABit(10000);
		WaitForAjax();
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		waitABit(10000);		
		if (getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell'])[1]/div[2]/div[@class='emp-add-container']|(//td[@class='currentMonthCell'])[1]/div[2]/div/div[@class='emp-shift-details']")).isEnabled())
		{
			while (true)
			{
				getDriver().findElement(org.openqa.selenium.By.xpath("(//td[@class='currentMonthCell']/div[2]/div/div[@class='emp-shift-details'])[1]/../../..")).click();
				waitABit(3000);
				System.out.println("Cell click completed");
				// getDriver().findElement(org.openqa.selenium.By.xpath(".//*[@id='MonthlyScheduleCalender.0.1']/div[2]/div[1]")).click();
				//getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='emp-cell-action-container'])[1]")).click();

				waitABit(2000);
				getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='schedule emp-regular-shift']/div/div[@class='shift-edit-action fa fa-edit'])[1]")).click();
				//withAction().doubleClick(EditButton);
				waitABit(1000);
				System.out.println("Hover completed");               
				EditIconNew.click();

				break;
			}
			System.out.println("Pop up opened");
		}

		EditShiftDialog.waitUntilVisible();
		System.out.println("Dialog opened");

		ShiftDurationTextBox.sendKeys("9");
		waitABit(2000);
		ShiftDurationTextBox.sendKeys(Keys.TAB);
		waitABit(2000);
		MealPlanlookup.click();
		waitABit(2000);
		System.out.println("Look up clicked");
		MealPlanfirst.click();		
		System.out.println("Meal Plan selected");       
		NotesTextArea.clear();
		NotesTextArea.sendKeys("Test");
		SaveButton.click();
	}


	public void ChangeCalendar()
	{	
		waitABit(10000);
		WaitForAjax();
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		waitABit(10000);		
		String currmonth = MonthandYear.getText();
		System.out.println("Current Month is " + currmonth);
		String[] curmonth = currmonth.split(",");
		System.out.println(curmonth[0]);
		PreviousMonth.click();
		waitABit(1000);
		String prevmonth = MonthandYear.getText();
		String[] premonth = prevmonth.split(",");
		System.out.println(premonth[0]);
		if(curmonth!=premonth)
		{
			System.out.println("Calendar change successful");
		}
		else
		{			
			System.out.println("Calendar change not successful");
		}
	}		


	public void closeRemoveScheduleDeviationsPopup() {
		removeScheduleDeviationsPopupCloseButton.waitUntilVisible();
		removeScheduleDeviationsPopupCloseButton.click();
	}

	public void submitRemoveScheduleDeviationsPopup() {
		removeScheduleDeviationsPopupSubmitButton.waitUntilVisible();
		removeScheduleDeviationsPopupSubmitButton.click();
	}

	public void openRemoveScheduleDeviationsPopup() {
		weekpopoverlink.waitUntilClickable();
		weekpopoverlink.click();
		removeScheduleDevaitionDropDownLink.waitUntilVisible();
		removeScheduleDevaitionDropDownLink.click();
	}

	public void validateRemoveScheduleDeviationsPopup() {
		popupTitle.waitUntilVisible();
		popupTitle.isVisible();
	}

	public void validateRemoveScheduleDeviationsInfoTextInPopup() {
		removeScheduleDeviationsInfoTextContainer.waitUntilVisible();
		removeScheduleDeviationsInfoTextContainer.isVisible();
	}

	public void validateRemoveScheduleDeviationsOptionsInPopup() {

	}

	public void verifyRemoveScheduleDeviationsMessage(int noOfSChedules) {
		alertMessage.waitUntilVisible();
		assert alertMessage.getText().contains(("Deviations Successfully Removed: "+noOfSChedules));
	}

	public void clickActionItemsIntheFirstWeek() {
		weekpopoverlink.waitUntilVisible();
		weekpopoverlink.click();
	}

	public static Map<String,Integer> Months = new HashMap<>();
	static{
		Months.put("January",31);
		Months.put("February",28);
		Months.put("March",31);
		Months.put("April",30);
		Months.put("May",31);
		Months.put("June",30);
		Months.put("July",31);
		Months.put("August",31);
		Months.put("Septemnber",30);
		Months.put("October",31);
		Months.put("November",30);
		Months.put("December",31);
		System.out.println(Months);

	}


	public void searchEmployee(String empName) {
		try {
			empSearchButton.waitUntilPresent();
			empSearchButton.click();
			System.out.println(currentListTextBox.getTextValue());
			employeeSearchDailog.waitUntilVisible();
			if(!currentListTextBox.getTextValue().contains("status is active"))	{
				currentListTextBox.click();
				currentListTextBox.clear();
				currentListTextBox.typeAndEnter("<status is active>");
				waitABit(1000);		
			}
			selectEmployeeFromSearcLookup(empName);	
		}catch (Exception ex) {
			ex.printStackTrace();
		}
	}


	public void selectEmployeeFromSearcLookup(String empName) {
		String[] empNameText = empName.split(",");
		String empLastName = empNameText[0];
		String empFirstName = empNameText[1];
		String empFullName = empLastName + "," + " " + empFirstName;
		searchTextBox.click();
		searchTextBox.sendKeys(empFullName);
		//WebElementFacade employeeLink = getElementByDynamicValues("xpath", "empNameLink", empFullName);
		//waitABit(4000);
		//if(clickOnElementIfExists(employeeLink) == true)				
		waitABit(4000);
		searchEmployee.click();
		waitABit(5000);
		//assert empNamelabel.getText() == empFullName;
	}

	public void addSingleOrMultipleScheduleOnSpecificDay(String date,List<String> schedulelist)
	{
		waitABit(5000);
		MonthlyScheduleRowGrabber.waitUntilPresent();
		System.out.println("Page loaded");
		String dateextracted = date.split("/")[1];
		if(getObjectCount("//*[text()='"+dateextracted+"']/..//*[@class='emp-shift-details']")==1 && schedulelist.size()==1)
		{
			String intime = schedulelist.get(0).split("-")[0].trim();
			String outtime = schedulelist.get(0).split("-")[1].trim();
			String shiftdetails = getDriver().findElement(By.xpath("//*[text()='"+dateextracted+"']/..//*[@class='emp-shift-details']/div[1]")).getText();
			String shiftintime = shiftdetails.split("-")[0].trim();
			String shiftouttime = shiftdetails.split("-")[1].trim();
			if(!shiftintime.equals(intime) || !shiftouttime.equals(outtime))
			{
				Actions action = new Actions(getDriver());
				action.moveToElement(getDriver().findElement(By.xpath("//*[text()='"+dateextracted+"']/..//*[@class='emp-shift-details']"))).build().perform();
				waitABit(2000);
				getDriver().findElement(By.xpath("//*[text()='"+dateextracted+"']/..//*[@class='emp-shift-details']/..//*[@class='shift-edit-action fa fa-edit']")).click();
				waitABit(2000);
				System.out.println("Dialog opened");
				StartTimeTextBox.clear();
				StartTimeTextBox.sendKeys(intime);
				StartTimeTextBox.sendKeys(Keys.TAB);
				EndTimeTextBox.clear();
				EndTimeTextBox.sendKeys(outtime);
				EndTimeTextBox.sendKeys(Keys.TAB);
				waitABit(2000);
				SaveButton.click();
				waitABit(2000);
			}

		}

		else
		{
			int numberofshifts = getObjectCount("//*[text()='"+dateextracted+"']/..//*[@class='emp-shift-details']");
			for (int i = 1; i <= numberofshifts; i++) {

				Actions action = new Actions(getDriver());
				action.moveToElement(getDriver().findElement(By.xpath("(//*[text()='"+dateextracted+"']/..//*[@class='emp-shift-details'])[1]"))).build().perform();
				waitABit(2000);
				getDriver().findElement(By.xpath("(//*[text()='"+dateextracted+"']/..//*[@class='emp-shift-details']/..//*[@class='shift-edit-action fa fa-trash-o'])[1]")).click();
				waitABit(2000);
				DeleteShiftDialog.waitUntilVisible();
				getDriver().findElement(By.xpath("(//div[@modaltype='delete']//*[@role='document']//button//span)[1]/..")).click();
				waitABit(2000);

			}
			waitABit(5000);
			MonthlyScheduleRowGrabber.waitUntilPresent();
			for (int i = 0; i < schedulelist.size(); i++) {

				Actions action = new Actions(getDriver());
				action.moveToElement(getDriver().findElement(By.xpath("//*[text()='"+dateextracted+"']/.."))).build().perform();
				waitABit(2000);
				getDriver().findElement(org.openqa.selenium.By.xpath("//div[text()='"+dateextracted+"']/../div/div/div[@class='shift-add-action fa fa-2x fa-plus-circle']")).click();
				System.out.println("Add Icon clicked");
				AddShiftDialog.waitUntilVisible();
				waitABit(2000);
				System.out.println("Dialog opened");
				StartTimeTextBox.clear();
				StartTimeTextBox.sendKeys(schedulelist.get(i).split("-")[0].trim());
				StartTimeTextBox.sendKeys(Keys.TAB);
				EndTimeTextBox.clear();
				EndTimeTextBox.sendKeys(schedulelist.get(i).split("-")[1].trim());
				EndTimeTextBox.sendKeys(Keys.TAB);
				waitABit(2000);
				SaveButton.click();
				waitABit(2000);

			}

		}


	}

}
