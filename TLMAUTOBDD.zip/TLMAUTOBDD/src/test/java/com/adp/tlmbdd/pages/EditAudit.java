package com.adp.tlmbdd.pages;

public class EditAudit {

	public void Create(String EditorId)
	{
		
	}
	
	public void Update(String EditorId)
	{
		
	}
	
	public void Delete(String EditorId)
	{
		
	}
	
	public void ValidateEditAudit(String EditorId, String AuditType)
	{
		
	}
}
