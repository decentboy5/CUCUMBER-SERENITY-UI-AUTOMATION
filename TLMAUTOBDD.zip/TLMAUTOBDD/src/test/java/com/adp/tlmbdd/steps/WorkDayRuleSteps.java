package com.adp.tlmbdd.steps;

//import com.adp.tlmbdd.pages.editors.WorkDayRules;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class WorkDayRuleSteps extends ScenarioSteps{
	
//	WorkDayRules dayRules;
	
	@Step
	public void clickOnWorkdayRule(String rule)
	{
//		dayRules.clickOnWorkdayRule(rule);
	}
	
	@Step
	public void verifyMaximumShiftHours(String number)
	{
//		dayRules.verifyMaximumShiftHours(number);
	}
	
	@Step
	public void enterMaximumShiftHours(String number)
	{
//		dayRules.enterMaximumShiftHours(number);
	}
	
	@Step
	public void addAndVerifyNewWorkdayrule(String shifthours)
	{
//		dayRules.addWorkDayRule(shifthours);
	}
	
	@Step
	public void verifyDropDownValues()
	{
//		dayRules.verifyCalculationTypeDropDownValues();
	}
	
	@Step
	public void verifyPayDateDropdownValues()
	{
//		dayRules.verifyPayDateTypeDropDownValues();
	}
	
	@Step
	public void verifyRollTimeGreyedOut()
	{
//		dayRules.verifyRollTimeGreyedOut();
	}

}
