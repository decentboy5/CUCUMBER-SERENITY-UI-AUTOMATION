package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.NavigationSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class NavigationStepDefinition {

	@Steps
	 NavigationSteps   navigationSteps;
	
	@When("^I Navigate to \"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_Navigate_to_and(String megaMenu, String subMenu, String mainTab) throws Throwable {
		if(navigationSteps!=null) {    
			navigationSteps.wfnMainPageNavigationStep(megaMenu, subMenu, mainTab);
		}	
	}
		
	@When("^I Navigate to left pane \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_Navigate_to_left_pane_and(String leftPaneMainOption, String leftPaneSubOption) throws Throwable {
		navigationSteps.wfnEditorsLeftPaneNavigationStep(leftPaneMainOption,leftPaneSubOption);
	}

	
	@When("^I Navigate to Shell \"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iNavigateToShellAnd(String megaMenu, String subMenu, String mainTab) throws Throwable {
		if(navigationSteps!=null) {    
			navigationSteps.wfnMainPageNavigationStepShell(megaMenu, subMenu, mainTab);
		}
	}

	
}
