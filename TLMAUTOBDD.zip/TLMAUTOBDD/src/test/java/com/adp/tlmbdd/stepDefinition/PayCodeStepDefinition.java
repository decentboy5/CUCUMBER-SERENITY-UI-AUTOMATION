package com.adp.tlmbdd.stepDefinition;

import java.util.List;

import com.adp.tlmbdd.steps.PayCodeSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class PayCodeStepDefinition {

	@Steps
	PayCodeSteps codeSteps;

	@Given("^I click on add new paycode$")
	public void i_click_on_add_new_paycode() throws Throwable {

		codeSteps.addNewPayCode();
	}

	@Given("^I enter paycode details with culture as \"([^\"]*)\"$")
	public void i_enter_paycode_details_with_culture_as(String culture) throws Throwable {

		codeSteps.addPayCodeDetails(culture);
	}

	@Given("^I enter paycode type as \"([^\"]*)\" and include timecard columns as \"([^\"]*)\"$")
	public void i_enter_paycode_type_as_and_include_timecard_columns_as(String paycodetype, String inculdecoloumns) throws Throwable {

		codeSteps.addPayCodeAndIncludeColoumns(paycodetype, inculdecoloumns);
	}

	@Given("^I enter rate calculation type as \"([^\"]*)\" with values \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_enter_rate_calculation_type_as_with_values(String ratecalculationtype, String ratefactor, String rateamount) throws Throwable {

		codeSteps.selectRateClacType(ratecalculationtype, ratefactor, rateamount);
	}

	@Given("^I enter enrty type as \"([^\"]*)\" and worked type as \"([^\"]*)\"$")
	public void i_enter_enrty_type_as_and_worked_type_as(String entrytype, String workedtype) throws Throwable {

		codeSteps.addEntryTypeAndWorkedType(entrytype, workedtype);
	}

	@Given("^I click on submit button$")
	public void i_click_on_submit_button() throws Throwable {
		codeSteps.clickSubmitButton();
	}


	@Given("^I assign payclasses to the paycode$")
	public void i_assign_payclasses_to_the_paycode(List<String> payclasseslist) throws Throwable {
	    codeSteps.assignPayclasses(payclasseslist);
	}
	
	@And("^I verify paycode is added successfully$")
	public void i_verify_paycode_is_added_successfully() throws Throwable {
	   
		codeSteps.verifyPayCodeCreatedSuccessfully();
	}
	
	@And("^I click on created paycode$")
	public void i_click_on_created_paycode() throws Throwable {
	    codeSteps.clickOnCreatedPayCode();
	}
	
	@And("^I \"([^\"]*)\" payclass \"([^\"]*)\" and save and verify action is successful$")
	public void i_payclass_and_save_and_verify_action_is_successful(String operation, String payclassname) throws Throwable {
	    
		codeSteps.assignUnassignOrUpdatePayClass(operation, payclassname);
	}
	
	@And("^I delete paycode and verify it is deleted successfully$")
	public void i_delete_paycode_and_verify_it_is_deleted_successfully() throws Throwable {
	    codeSteps.deletePaycodeAndVerify();
	}
	
	@And("^I copy first paycode in the list$")
	public void i_copy_first_paycode_in_the_list() throws Throwable {
	    
		codeSteps.copyFirstPaycode();
	}
	
	@And("^I click on first paycode in the list$")
	public void i_click_on_first_paycode_in_the_list() throws Throwable {
		codeSteps.clickFirstPaycode();
	}

}
