package com.adp.tlmbdd.pages.objects;

import com.adp.tlmbdd.pages.GenericPageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class NewHirePlusTimeGen extends GenericPageObject {
    @FindBy(xpath ="//span[@id='btnAddNew']")
    public WebElementFacade additionalConfigAddNewBtn;

    @FindBy(xpath ="//input[@id='txtPayCycleID']")
    public WebElementFacade payCycleNameInput;

    @FindBy(xpath ="//input[@id='multiDesc']")
    public WebElementFacade AdditionalConfigDescriptionInput;

    @FindBy(xpath ="//input[@id='calCurrPayCyStDate']")
    public WebElementFacade payCycleStartDateInput;

    @FindBy(xpath ="//span[@id='barButtons_btnSubmit']")
    public WebElementFacade additionalConfigSubmitButton;

    @FindBy(xpath ="//span[@id='select_ddlCalcType']/..")
    public WebElementFacade payCyclePayFrequency;

    @FindBy(xpath ="//div[@id='revit_InlineDialog_0']")
    public WebElementFacade additionalConfigMsgDialog;

    @FindBy(xpath ="//input[@id='txtPayGroupID']")
    public WebElementFacade payClassNameInput;

    @FindBy(xpath ="//input[@id='multDesc']")
    public WebElementFacade payClassDescriptionInput;

    @FindBy(xpath ="//input[@id='lkpPayCycle']")
    public WebElementFacade payClassPayCycleInput;

    @FindBy(xpath ="//input[@id='lkpTimeCalcProgram']")
    public WebElementFacade payClassTimeCalcProgramInput;

    @FindBy(xpath ="//input[@id='lkpDailyCalcProgram']")
    public WebElementFacade payClassDailyCalcProgramInput;

    @FindBy(xpath ="//input[@id='lkpTimeEntryPlan']")
    public WebElementFacade payClassTimeEntryPlanInput;

    @FindBy(xpath ="//div[@class='card__middle_nh'][.='QuickHire + Time']")
    public WebElementFacade quickHirePlusTimeTemplate;

    @FindBy(xpath ="//div[@class='card__middle_nh'][contains(.,'HR + Payroll + Time')]")
    public WebElementFacade hrPlusPayrollPlusTimeTemplate;

    @FindBy(xpath ="//input[@id='Name.first']")
    public WebElementFacade newHireFirstName;

    @FindBy(xpath ="//input[@id='Name.last']")
    public WebElementFacade newHireLastName;

    @FindBy(xpath ="//input[@id='HireDate']")
    public WebElementFacade newHireDate;

    @FindBy(xpath ="//div[@id='ReasonForHire']/div")
    public WebElementFacade reasonForHire;

    @FindBy(xpath ="//input[@id='TaxIdComponent_taxid']")
    public WebElementFacade newHireSSN;

    @FindBy(xpath ="//div[@id='TaxIdComponent_taxidtype']//div[contains(@class, 'indicators')]/div")
    public WebElementFacade newHireTaxType;

    @FindBy(xpath ="//div[@id='TaxIdComponent_nationalidentifier']//div[contains(@class,'indicators')]/div")
    public WebElementFacade newHireTaxCountry;

    @FindBy(xpath ="//input[@id='BirthDate']")
    public WebElementFacade newHireDOB;

    @FindBy(xpath ="//div[@id='CompanyCode']/div")
    public WebElementFacade newHireCompanyCode;

    @FindBy(xpath ="//label[contains(., 'Country')]/following::div[@class='vdl-dropdown-list']")
    public WebElementFacade newHireAddressCountry;

    @FindBy(xpath ="//label[contains(., 'Address Line 1')]/following::input[contains(@class,'textbox--required')]")
    public WebElementFacade newHireAddressLineOne;

    @FindBy(xpath ="//label[contains(., 'City')]/following::input[contains(@class,'textbox--required')]")
    public WebElementFacade newHireAddressCity;

    @FindBy(xpath ="//label[contains(., 'Zip Code')]/following::input[contains(@class,'textbox--required')]")
    public WebElementFacade newHireAddressZipCode;

    @FindBy(xpath ="//div[@id='employmentSection']//div[contains(@class, 'expandPanelStyle')]")
    public WebElementFacade newHireExpandEmploymentSection;

    @FindBy(xpath ="//div[@id='payrollSection']//div[contains(@class, 'expandPanelStyle')]")
    public WebElementFacade newHireExpandPayrollSection;

    @FindBy(xpath ="//div[@id='taxSection']//div[contains(@class, 'expandPanelStyle')]")
    public WebElementFacade newHireExpandTaxSection;

    @FindBy(xpath ="//div[@id='Time Attendance']/preceding::div[1]")
    public WebElementFacade newHireExpandTimeAndAttendanceSection;

    @FindBy(xpath ="//label[.='Applied For']")
    public WebElementFacade newHireSSNappliedFor;

    @FindBy(xpath ="//label[contains(., 'State / Territory')]/following::div[@class='vdl-dropdown-list']")
    public WebElementFacade newHireState;

    @FindBy(xpath ="//input[@id='fileNumber']")
    public WebElementFacade newHireFileNumber;

    @FindBy(xpath ="//input[@name='selectedSuperVisor']/..")
    public WebElementFacade newHireSupervisor;

    @FindBy(xpath ="//div[@id='tlmSupervisorFlag']")
    public WebElementFacade newHireIsSupervisor;

    @FindBy(xpath ="//input[@name='suisdiTaxN']")
    public WebElementFacade newHireTaxCode;

    @FindBy(xpath ="//div[@id='workedInState']//div/input")
    public WebElementFacade newHireWorkState;

    @FindBy(xpath ="//input[@name='payclassSelect']")
    public WebElementFacade newHirePayclass;

    @FindBy(xpath ="//input[@id='badgeNumber']")
    public WebElementFacade newHireBadgeNumber;

    @FindBy(xpath ="//input[@name='DBLCFLOCATIONVALUEVIEW']")
    public WebElementFacade newHireTimeZone;

    @FindBy(xpath ="//div[@class='vdl-row tlm-next-button-style']/button")
    public WebElementFacade newHireDoneButton;

    @FindBy(xpath ="//div[.='Work Email']//input[@title='Enter email']")
    public WebElementFacade newHireWorkEmail;

    @FindBy(xpath ="//div[@id='Employment']//label[.='Use For Notification']/preceding::div[@class='vdl-checkbox']")
    public WebElementFacade useForNotificationCheckbox;

    @FindBy(xpath ="//div[@id='workedInState']/div")
    public WebElementFacade stateTax;

    @FindBy(xpath ="//span[@id='suisdiTaxSpan']/span")
    public WebElementFacade TaxCode;

    @FindBy(xpath ="//div[@role='option'][contains(@id,'option-0')]")
    public WebElementFacade dropDownFirstOption;

    @FindBy(xpath ="//div[@role='option'][contains(@id,'option-1')]")
    public WebElementFacade dropDownSecondOption;

    @FindBy(xpath ="//div[@id='payclassId']/div")
    public WebElementFacade payClass;

    @FindBy(xpath ="//input[@id='badgeNumber']")
    public WebElementFacade badgeNumber;

    @FindBy(xpath ="//div[@id='DBLCFLOCATIONVALUEVIEW']/div")
    public WebElementFacade timeZone;
}
