package com.adp.tlmbdd.pages.editors;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import com.adp.tlmbdd.pages.GenericPageObject;

public class TimeEntryPlan extends GenericPageObject {

	@FindBy(xpath = ".//*[@id='txtTimeEntryPlanID']")
	private WebElementFacade TimeEntryPlanTxtBox;
	
	@FindBy(xpath = ".//*[@id='multDesc']")
	private WebElementFacade TimeEntryPlanDescTxtBox;
	
	@FindBy(xpath = ".//*[@id='dtDefaultTime']")
	private WebElementFacade DefaultTime;
	
	@FindBy(xpath = ".//*[@id='ddlTimeEntryMethod']")
	private WebElementFacade TimeEntryMethods;
	
	
	@FindBy(xpath = ".//*[@id='barButtons_btnSubmit']")
	private WebElementFacade SubmitTimeEntryPlan;	
	

	
	public void CreateTimeEntryPlan(String TimeEntryMethod)
	{
		TimeEntryPlanTxtBox.sendKeys("");
		TimeEntryPlanDescTxtBox.sendKeys("");
		DefaultTime.sendKeys("12:00");
		SubmitTimeEntryPlan.click();
	}
}
