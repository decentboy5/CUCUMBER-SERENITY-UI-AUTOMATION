package com.adp.tlmbdd.pages.editors;

import java.util.ArrayList;

import java.util.List;

import net.serenitybdd.core.pages.WebElementFacade;

 import org.joda.time.DateTime;
 
 import org.apache.log4j.Logger;

public class NewHire {
	
//	final static Logger logger = Logger.getLogger(NewHire.class);

	
	public void AddandRegisterNewHire(String CompCode, String UserType, String SupervisorPos, String ManagerPosition)	
	{
	
        List<WebElementFacade> userInfo = new ArrayList<>();
        String currTimeStamp = DateTime.now().toString("MMddHHmmss");
        String FN = UserType + currTimeStamp;
        String LN = null;
        String UserNameemp = LN + ", " + FN;
        String UserTypeEmp = UserType;
        String EmployeeName = UserNameemp;
        
               
	}

}
