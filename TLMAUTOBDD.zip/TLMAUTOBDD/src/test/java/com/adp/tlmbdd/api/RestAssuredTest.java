package com.adp.tlmbdd.api;
import com.google.gson.Gson;

import org.apache.commons.io.IOUtils;
import org.junit.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


public class RestAssuredTest {
	
	
	EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();

	//String baseUrl = variables.getProperty(ThucydidesSystemProperty.WEBDRIVER_BASE_URL);
	String APIBaseURI = variables.getProperty("RestAssured.baseURI");
	
	@Test
	public void GETRequest()
	{
	//Sample GET Request
	RestAssured.baseURI = APIBaseURI;
    RequestSpecification httpRequest = RestAssured.given();
    httpRequest.header("orgoid","G3NXFJ5S5AP0088N").header("ProductID","WFNPortal");    
    Response response = httpRequest.get();    
    
    //String code = response.getContentType();
    System.out.println("Response Body is => " + response.asString());
    System.out.println("Response code is => " + response.getStatusCode());
    Assert.assertEquals(200, response.getStatusCode());    
	}
	
	@Test
	public void POSTRequest()
	{	
			
    Gson gsonObj = new Gson();		
    Map<String, String> inputMap = new HashMap<String, String>();
    inputMap.put("requestorEmailID","SivaSatyanarayana.Gundu@adp.com");
	inputMap.put("requestorFirstName","Siva");
	inputMap.put("requestorLastName","Gundu");
	inputMap.put("productOrderNo","1234");
	inputMap.put("clientName","Siva OTG2");
	inputMap.put("companyLocation","India");
	inputMap.put("requestedLogin","SivaOTG2");
	inputMap.put("businessUnit","MA");
	inputMap.put("region","0086");
	inputMap.put("comp","10733");
	inputMap.put("payrollProduct","PayeXpert");	
	inputMap.put("prod","8Y");
	inputMap.put("ClockTypes","");
	inputMap.put("iSIEnabled","true");
	inputMap.put("PortalEnabled","true");
	inputMap.put("iSIClientID","OLUS002");	
	inputMap.put("iSIRegPassCode","OLUS002");
	inputMap.put("baseCulture","en-CA");
	inputMap.put("Notes","test");
	inputMap.put("crossBorder","false");
	inputMap.put("primaryCountry","CA");	
	inputMap.put("phoneNo","1234");
	inputMap.put("OrgID","G3GA952S3HKME8SA");
	inputMap.put("WFNVersion","15.0.0");
	inputMap.put("DBUserID","WFN9SCH000033");
	inputMap.put("DBPassword","pxtadpadp");
	inputMap.put("VPDKey","WNVPD0000047044");
	inputMap.put("DBServerID","wfc33q_svc1");
	inputMap.put("OTG","true");
	inputMap.put("SCN","FOOO23");
    // convert map to JSON String
	String jsonStr = gsonObj.toJson(inputMap);
	//System.out.println(jsonStr);
	RestAssured.baseURI = "http://adminportal-fit1.es.ad.adp.com/ELAdminPortal/api/WFNOTGClient/CreateNewClient";
    RequestSpecification httpRequest = RestAssured.given();
    httpRequest.header("Content-Type","application/json");
	httpRequest.body(jsonStr);    
    Response response = httpRequest.post();	
    System.out.println("Request Body is => " + jsonStr);
    System.out.println("Response is =>  " + response.asString());
    System.out.println("Response code is =>  " + response.getStatusCode());
    Assert.assertEquals(200, response.getStatusCode());
	      
	}
	
	@Test
	public void SendResults()
	{
	      String to = "pavan.chinna.obireddy@adp.com";
	      String from = "ADPTLMQA@adp.com";
	      String host = "192.168.100.110";
	      Properties properties = System.getProperties();
	      properties.setProperty("mail.smtp.host", host);
	      Session session = Session.getDefaultInstance(properties);
	      try {
	          MimeMessage message = new MimeMessage(session);
	          message.setFrom(new InternetAddress(from));
	          message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
	          message.setSubject("BDD Framework - HTML Results");	 
	          Multipart multipart = new MimeMultipart();
	          String[] attachFiles = new String[1];
	          attachFiles[0] = "C:/JAVA_CUCUMBER_GIT/tlm_ezlmqa/TLMBDDAutomation/TLMAUTOBDD/target/site/serenity/0b9dfe0c604827cffe909773c04f9c603c425c560335aab5607ab7a24e51c485.html";	          
	          
	          // adds attachments
	          if (attachFiles != null && attachFiles.length > 0) {
	              for (String filePath : attachFiles) {
	                  MimeBodyPart attachPart = new MimeBodyPart();
	   
	                  try {
	                      attachPart.attachFile(filePath);
	                  } catch (IOException ex) {
	                      ex.printStackTrace();
	                  }
	   
	                  multipart.addBodyPart(attachPart);
	              }
	          }
	          
	          StringWriter writer = new StringWriter();
	          IOUtils.copy(new FileInputStream(new File(attachFiles[0])), writer);
	          String htmlFile = writer.toString();  
	          message.setContent(writer.toString(), "text/html");         
	          Transport.send(message);
	       
	    } 
	      catch (Exception ex) {
	            System.out.println("Could not send email.");
	            ex.printStackTrace();
	      
	      }
	}
	


}
