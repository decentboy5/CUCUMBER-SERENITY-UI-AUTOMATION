package com.adp.tlmbdd.pages.editors;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class CompanyPreferences extends GenericPageObject{
	
	@FindBy(xpath = "//*[@id='mnuCompanyPreferencesMenuItemCell1']")
	private WebElementFacade additionalFeatureSettings;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElement mainiframe;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame1_iframe']")
	private WebElement subframe;
	
	@FindBy(xpath = "//*[@id='chkAllowMultiDayShift']")
	private WebElementFacade multidayshiftcheckbox;
	
	@FindBy(xpath = "//*[@id='btnSubmit']")
	private WebElementFacade submitButton;
	
	@FindBy(xpath = "//*[text()='Operation Successful']")
	private WebElementFacade operationSuccesfulMessage;
	
	@FindBy(xpath = "//*[@id='fhAllowMultiDayShift']")
	private WebElementFacade helpButton;
	
	@FindBy(xpath = "//span[contains(text(),'Allow Multiple Day Shifts')]")
	private WebElementFacade helpText;
	
	@FindBy(xpath = "//*[@id='MDLHandle']/span[contains(@class,'Close')]")
	private WebElementFacade helpTextClose;
	
	@FindBy(xpath = "//*[@id='hypTurnOffDailyRule']")
	private WebElementFacade stepsToDisableLink;
	
	
	
	public void verifyMultiDayShiftCheckboxVisible()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		additionalFeatureSettings.click();
		WaitForAjax();
		boolean flag = multidayshiftcheckbox.isDisplayed();
		Assert.assertTrue(flag);
		String flag1 = multidayshiftcheckbox.getAttribute("aria-checked"); 
		Assert.assertEquals("false",flag1);
		switchToDefaultContent();
		
	}
	
	public void enableMultiDayShift()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		String flag = multidayshiftcheckbox.getAttribute("aria-checked");
		if(flag.equals("false"))
		{
			multidayshiftcheckbox.click();
			submitButton.click();
			WaitForAjax();
			Assert.assertTrue(checkElementVisible(operationSuccesfulMessage));
		}
		else
		{
			System.out.println("Multi day shift checkbox is already checked");
		}
		switchToDefaultContent();
	}
	
	public void verifyHelpAndHelpTextandStepsToDisablelink()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		Assert.assertTrue(checkElementVisible(helpButton));
		helpButton.click();
		WaitForAjax();
		Assert.assertTrue(checkElementVisible(helpText));
		helpTextClose.click();
		Assert.assertTrue(checkElementVisible(stepsToDisableLink));
		switchToDefaultContent();
	}
	
	
	
	
	
	

}
