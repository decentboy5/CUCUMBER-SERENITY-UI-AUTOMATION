package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.EmployeeScheduleSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class EmployeeScheduleStepDefinition {

	@Steps
	EmployeeScheduleSteps employeeScheduleSteps;

	@Then("^I validate date range dropdown$")
	public void i_search_for_an_employee() throws Throwable {
		employeeScheduleSteps.dateDropDown();
	}

	@Then("^I verify date input fields$")
	public void i_verify_date_input_fields() throws Throwable {
		employeeScheduleSteps.verifyDateInput();
	}

	@Then("^I verify date input error validation$")
	public void i_verify_date_input_error_validation() throws Throwable {
		employeeScheduleSteps.dateInputErrorValidation();
	}

	@When("^I search for an employee \"([^\"]*)\"$")
	public void i_search_for_an_employee(String name) throws Throwable {
		employeeScheduleSteps.searchEmployee(name);
	}

	@When("^I search for location \"([^\"]*)\"$")
	public void i_search_for_a_location(String location) throws Throwable {
		employeeScheduleSteps.searchForLocation(location);
	}

	@When("^I add shift to employee schedules \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_add_shift_to_employee_schedules(String dept, String paycode) throws Throwable {
		employeeScheduleSteps.addShiftToSchedule(dept, paycode);
	}

	@When("^I add shift inline with auto advanced$")
	public void add_shift_inline_auto_advance() throws Throwable {
		employeeScheduleSteps.inLineEditingAddShiftAutoAdvance();
	}

	@And("^I edit shift inline with enter key$")
	public void edit_shift_inline_with_enter_key() throws Throwable {
		employeeScheduleSteps.inLineEditingEditShiftWithEnterKey();
	}

	@And("^I insert shift inline with insert key$")
	public void insert_shift_inline_with_insert_key() throws Throwable {
		employeeScheduleSteps.inLineEditingInsertShiftWithInsertKey();
	}

	@And("^I verify shift overlap validation in inline edit$")
	public void i_delete_shifts() throws Throwable {
		employeeScheduleSteps.inLineEditingOverlapValidation();
	}

	@Then("^I delete inline edit shifts$")
	public void delete_inline_edit_shifts() throws Throwable {
		employeeScheduleSteps.inLineEditingCleanup();
	}

	@And("^I delete shift from employee schedules$")
	public void i_delete_shift_from_employee_schedules() throws Throwable {
		employeeScheduleSteps.deleteSingleShift();
	}

	@Then("^I validate like the change link is on displayed$")
	public void I_validate_like_the_change_link_is_on_displayed() throws Throwable {
		employeeScheduleSteps.likeTheChangeIsNotDisplayed();
	}

	@And("^I edit schedule shift \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_edit_schedule_shift(String dept, String paycode) throws Throwable {
		employeeScheduleSteps.editSingleShift(dept, paycode);
	}

	@When("^I edit multiple shifts across multiple employees \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_edit_multiple_shift_across_multiple_employees_and(String paycode, String dept, String job,
			String location) throws Throwable {
		employeeScheduleSteps.editMultipleShift(paycode, dept, job, location);
	}

	@When("^I delete multiple shifts across multiple employees$")
	public void delete_multiple_shift_across_multiple_employees() throws Throwable {
		employeeScheduleSteps.deleteMultipleShift();
	}

	@Then("^I validate multiple shift add \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_validate_multiple_shift_add_and(String paycode, String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.multipleShiftAddValidation(paycode, dept, job, location);
	}

	@Then("^I validate multiple shift edit \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_validate_multiple_shift_edit_and(String paycode, String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.multipleShiftEditValidation(paycode, dept, job, location);
	}

	@Then("^I validate multiple shift delete$")
	public void i_validate_multiple_shift_delete() throws Throwable {
		employeeScheduleSteps.multipleShiftDeleteValidation();
	}

	@When("^I add multiple shifts to multiple employees \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_add_multiple_shift_to_multiple_employees_and(String paycode, String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.addMultipleShift(paycode, dept, job, location);
	}

	@When("^I add a quick shift \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_add_a_quick_shift_and(String name, String paycode, String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.createQuickShift(name, paycode, dept, job, location);
	}

	@Then("^I edit a quick shift \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_edit_a_quick_shift_and(String name, String paycode, String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.quickShiftEdit(name, paycode, dept, job, location);
	}

	@Then("^I delete quick shift$")
	public void i_delete_quick_shift() throws Throwable {
		employeeScheduleSteps.quickShiftDelete();
	}

	@Then("^I assign quick shifts to employee \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_assign_quick_shifts_to_employee_and(String qs1, String qs2) throws Throwable {
		employeeScheduleSteps.quickShiftAssignment(qs1, qs2);
	}

	@When("^I copy and paste shift from action bar  \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_copy_and_paste_from_action_bar_and(String paycode, String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.copyPasteFromMenu(paycode, dept, job, location);
	}

	@Then("^I copy and paste shift using keyboard shortcuts$")
	public void i_copy_and_paste_shift_with_keyboard_shortcuts() throws Throwable {
		employeeScheduleSteps.copyPasteKeyboardShortcuts();
	}

	@When("^I navigate to schedule audit page$")
	public void I_navigate_to_schedule_audit_page() throws Throwable {
		employeeScheduleSteps.navigateToScheduleAuditPage();
	}

	@Then("^I validate shift add audit \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_validate_shift_add_audit(String newDept, String newPaycode) throws Throwable {
		employeeScheduleSteps.validateShiftAddAudit(newDept, newPaycode);
	}

	@Then("^I verify schedule update audit \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_verify_schedule_update_audit(String dept, String newDept, String paycode, String newPayCode)
			throws Throwable {
		employeeScheduleSteps.validateShiftUpdateAudit(dept, newDept, paycode, newPayCode);
	}

	@Then("^I verify schedule delete audit \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_verify_schedule_delete_audit(String dept, String paycode) throws Throwable {
		employeeScheduleSteps.validateShiftDeleteAudit(dept, paycode);
	}

	@Then("^I validate column sorting$")
	public void I_validate_column_sorting() throws Throwable {
		employeeScheduleSteps.validateShiftAuditSorting();
	}

	@Given("^I create a schedule template \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_create_a_schedule_template_and(String templateName, String paycode, String dept, String job,
			String location) throws Throwable {
		employeeScheduleSteps.createScheduleTemplate(templateName, paycode, dept, job, location);
	}

	@When("^I edit a schedule template \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_edit_a_schedule_template_and(String templateName, String paycode, String newPaycode, String dept,
			String newDept, String job, String newJob, String location, String newLocation) throws Throwable {
		employeeScheduleSteps.templateEdit(templateName, paycode, newPaycode, dept, newDept, job, newJob, location,
				newLocation);
	}

	@And("^I delete a schedule template \"([^\"]*)\"$")
	public void I_delete_a_schedule_template(String templateName) throws Throwable {
		employeeScheduleSteps.templateDelete(templateName);
	}

	@Then("^I validate template delete audit \"([^\"]*)\"$")
	public void I_validate_template_delete_audit(String templateName) throws Throwable {
		employeeScheduleSteps.templateDeleteAuditValidation(templateName);
	}

	@Then("^I validate template delete audit details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_validate_template_delete_audit_details(String templateName, String paycode, String newPaycode,
			String dept, String newDept, String job, String newJob, String location, String newLocation)
			throws Throwable {
		employeeScheduleSteps.templateDeleteAuditDetailsValidation(templateName, paycode, newPaycode, dept, newDept,
				job, newJob, location, newLocation);
	}

	@Then("^I validate template change audit \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_validate_template_change_audit_and(String templateName, String description, String effectiveDate)
			throws Throwable {
		employeeScheduleSteps.verifyTemplateChangeAudit(templateName, description, effectiveDate);
	}

	@Then("^I validate template audit details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_validate_template_audit_details(String templateName, String paycode, String newPaycode, String dept,
			String newDept, String job, String newJob, String location, String newLocation) throws Throwable {
		employeeScheduleSteps.validateTemplateAuditDetails(templateName, paycode, newPaycode, dept, newDept, job,
				newJob, location, newLocation);
	}

	@Then("^I validate template audit column sorting$")
	public void I_validate_template_audit_column_sorting() throws Throwable {
		employeeScheduleSteps.validateTemplateAuditColumnSorting();
	}

	@Then("^I validate template audit details column sorting$")
	public void I_validate_template_audit_details_column_sorting() throws Throwable {
		employeeScheduleSteps.validateTemplateAuditDetailsColumnSorting();
	}

	@Then("^I validate employee information slide-in \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_validate_employee_information_slidein(String payclass, String supervisor) throws Throwable {
		employeeScheduleSteps.empInfoSlideIn(payclass, supervisor);
	}

	@Then("^I validate view all notes slide-in$")
	public void I_validate_view_all_notes_slidein() throws Throwable {
		employeeScheduleSteps.viewAllNotesSlideIn();
	}

	@Then("^I validate monthly schedule slidein \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_validate_monthly_schedule_slidein(String dept, String job, String location) throws Throwable {
		employeeScheduleSteps.monthlyScheduleSlideInValidation(dept, job, location);
	}

	@Then("^I validate monthly schedule slidein shift details dialog \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_validate_monthly_schedule_slidein_shift_details(String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.monthlyScheduleSlideInShiftDetails(dept, job, location);
	}

	@Then("^I validate monthly schedule date selection and view toggle$")
	public void I_validate_date_selection_and_toggle() throws Throwable {
		employeeScheduleSteps.dateSelectionAndViewToggle();
	}

	@Then("^I validate timecard tab on individual timecard slide in \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_validate_timecard_tab_on_individual_timecard_slide_in_and(String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.timecardSlideinTimecardTab(dept, job, location);
	}

	@Then("^I validate schedule tab on individual timecard slide in \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_validate_schedule_tab_on_individual_timecard_slide_in_and(String dept, String job, String location)
			throws Throwable {
		employeeScheduleSteps.timecardSlideinScheduleTab(dept, job, location);
	}

	@Then("^I validate totals and time off balance tabs on individual timecard slide in$")
	public void i_validate_totals_and_timeoffBalance_tab_on_individual_timecard() throws Throwable {
		employeeScheduleSteps.timecardSlideInTotalAndTimeOffTabValidations();
	}

	@Then("^I validate time off balances slide in$")
	public void i_validate_timeoffBalance_slidein() throws Throwable {
		employeeScheduleSteps.timeOffBalancesValidations();
	}

	@Then("^I click on Manage Assignments for the template \"([^\"]*)\"$")
	public void I_click_on_Manage_Assignments(String templateName) throws Throwable {
		employeeScheduleSteps.clickManageAssignments(templateName);

	}

	@Then("^I select multiple employees$")
	public void i_select_multiple_employees() throws Throwable {
		employeeScheduleSteps.selectemployees();
	}

	@Then("^I enter multiple start date and end date$")
	public void i_enter_multiple_start_date_and_end_date() throws Throwable {
		employeeScheduleSteps.enterMultipleDateRanges();
	}

//	@Then("^I go back")
//	public void i_go_back() throws Throwable {
//		employeeScheduleSteps.goBack();
//	}
	@Then("^I navigate to assigned employees for the template \"([^\"]*)\"$")
	public void i_navigate_to_assigned_employees_for_the_template(String templateName) throws Throwable {
		employeeScheduleSteps.assignedEmployees(templateName);

	}
	
	@Then("^I validate template shifts on employee schedule \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_validate_template_shifts_on_employee_schedule(String inTime, String outTime, String empName)
			throws Throwable {
		employeeScheduleSteps.verifyTemplateShiftOnEmployee(inTime, outTime, empName);
	}


	@Then("^I select single employee$")
	public void i_select_single_employee() throws Throwable {
		employeeScheduleSteps.selectSingleEmployee();
	}
	
	@Then("^I navigate to templates")
	public void i_navigate_to_templates() throws Throwable {
		employeeScheduleSteps.navigateToTemplates();
	}

	@Then("^I remove template assignment$")
	public void i_remove_template_assignment() throws Throwable {
		employeeScheduleSteps.removeTemplateAssignment();
	}
	
	@Then("^I validate shifts are removed from employee schedule \"([^\"]*)\"$")
	public void i_validate_shifts_are_removed_from_employee_schedule(String empName) throws Throwable{
		employeeScheduleSteps.veriftTemplateRemovalOnEmployee(empName);
	}

	@Then("^I select all employees$")
	public void i_select_all_employees() throws Throwable {
		employeeScheduleSteps.selectAllEmployees();
	}

	@Then("^I set date range for all employees$")
	public void i_set_date_range_for_all_employees() throws Throwable {
		employeeScheduleSteps.selectSameDateRange();
	}
	
	@Then("^I validate assignments for multiple employee \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_validate_assignments_for_multiple_employees(String inTime, String outTime, String empName) throws Throwable {
		employeeScheduleSteps.validateAssignmentsForSameDateRange( inTime,  outTime,  empName);
	}

	@Then("^I close manage assignments")
	public void i_close_manage_assignments() throws Throwable {
		employeeScheduleSteps.goBack();
	}
	@Then("^I go back to schedules page$")
	public void i_go_back_to_schedules_page() throws Throwable {
		employeeScheduleSteps.navigateToSchedulesPage();
	}

	@Then("^I Validate overlap error message$")
	public void i_validate_overlap_error_message() throws Throwable {
		employeeScheduleSteps.validateOverlapErrorMessage();
	}

	@Given("^I create a multiple time template \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_create_a_multiple_time_template(String templateName, String startTime, String endTime)
			throws Throwable {
		employeeScheduleSteps.multipleTimesTemplate(templateName, startTime, endTime);
	}

	@Then("^I select the employee \"([^\"]*)\"$")
	public void i_select_the_employee(String employeeName) throws Throwable {
		employeeScheduleSteps.selectEmployee(employeeName);

	}

	@Then("^I add another shift to the template \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_add_another_shift_to_the_template_and(String templateName, String startTime, String endTime)
			throws Throwable {
		employeeScheduleSteps.multipleShiftsTemplate(templateName, startTime, endTime);
	}

	@Then("^I validate template details for the template \"([^\"]*)\"$")
	public void i_validate_template_details_for_the_template(String templateName) throws Throwable {
		employeeScheduleSteps.validateTemplateDetails(templateName);
	}

	@Then("^I go back to templates list$")
	public void i_go_back_to_templates_list() throws Throwable {
		employeeScheduleSteps.navigateToTemplatesList();
	}

	@Then("^I delete shifts for the template \"([^\"]*)\"$")
	public void I_delete_shifts_for_the_template(String templateName) throws Throwable {
		employeeScheduleSteps.deleteShiftsforTemplate(templateName);

	}

	@Then("^I enter the wrong date range for all employees$")
	public void i_enter_the_wrong_date_range_for_all_employees() throws Throwable {
		employeeScheduleSteps.setWrongDateRange();
	}

	@Then("^I validate error message for greater start date$")
	public void i_validate_error_message_for_greater_start_date() throws Throwable {
		employeeScheduleSteps.validateGreaterStartDate();
	}

	@Then("^I enter the wrong date range for multiple employees$")
	public void i_enter_the_wrong_date_range_for_multiple_employees() throws Throwable {
		employeeScheduleSteps.setWrongDateRangeForMultipleEmployees();
	}

	@Then("^I click assigned only toggle button$")
	public void i_click_assigned_only_toggle_button() throws Throwable {
		employeeScheduleSteps.assignedToggleOn();
	}

	@Then("^I click Cancel$")
	public void i_click_Cancel() throws Throwable {
		employeeScheduleSteps.clickAssignmentCancel();
	}

	@Then("^I go back to template list from Manage Assignments$")
	public void i_go_back_to_template_list_from_manage_assignments() throws Throwable {
		employeeScheduleSteps.navigateFromAssignmentsToTemplateList();

	}

	@Then("^I click next in schedule assignments$")
	public void i_click_next_in_schedule_assignments() throws Throwable {
		employeeScheduleSteps.scheduleAssignmentsClickNext();

	}

	@When("^I get the logged in users details$")
	public void i_get_the_logged_in_users_details() throws Throwable {
		employeeScheduleSteps.findUsername();
	}

	@Then("^I validate that the logged in user shows$")
	public void i_validate_that_the_logged_in_user_shows() throws Throwable {
		employeeScheduleSteps.validateUser("enabled");
	}
	@Then("^I validate the schedule is not shown")
	public void  i_validate_the_schedule_is_not_shown() throws Throwable {
		employeeScheduleSteps.validateScheduleDisable();
	}
	
	@Then("^I enable schedule edit privileges")
	public void i_enable_schedule_edit_privileges() throws Throwable {
		employeeScheduleSteps.editSchedulePrivileges(1);
	}
	

	@When("^I add shift to my schedule$")
	public void i_add_shift_to_my_schedule() throws Throwable {
		employeeScheduleSteps.addShiftToSchedule();
	}
	
	@Then("^I add non paying shift to my schedule")
	public void  i_add_non_paying_shift_to_my_schedule() throws Throwable {
		employeeScheduleSteps.addNonWorkedShiftToSchedule();
	}
	@And("^I check the employee count")
	public void i_check_the_employee_count() throws Throwable{
		employeeScheduleSteps.checkEmployeeCountBefore();
	}
	@Then("^I check the count of employee after filter")
	public void i_check_the_count_of_employee_after_filter() throws Throwable{
		employeeScheduleSteps.checkEmployeeCountAfter();
	}

	@Then("^I validate shift is added$")
	public void i_validate_shift_is_added() throws Throwable {
		employeeScheduleSteps.validateShift();
	}
	
	@When("^I validate the total worked hours")
	public void i_validate_the_total_worked_hours() throws Throwable {
		employeeScheduleSteps.validateWorkedHours();
	}
	
	@When("^I validate the total non worked hours")
	public void i_validate_the_total_non_worked_hours() throws Throwable {
		employeeScheduleSteps.validateNonWorkedHours();
	}
	
	@When("^I validate the total worked shifts")
	public void i_validate_the_total_worked_shifts() throws Throwable {
		employeeScheduleSteps.validateWorkedShifts();
	}
	
	@When("^I validate the total non worked shifts")
	public void i_validate_the_total_non_worked_shifts() throws Throwable {
		employeeScheduleSteps.validateNonWorkedShifts();
	}
	
	@When("^I select the filter")
	public void i_select_the_filter() throws Throwable {
		employeeScheduleSteps.scheduledFilter();
	}
	
	@When("^I validate that employee with schedules exists")
	public void i_validate_that_employee_with_schedules_exists() throws Throwable {
		employeeScheduleSteps.validateScheduleExists();
	}
	
	@When("^I select the unscheduled filter")
	public void i_select_the_unscheduled_filter() throws Throwable {
		employeeScheduleSteps.unscheduledFilter();
	}
	
	@When("^I validate that no employees with schedules exist")
	public void i_validate_that_no_employees_with_schedules_exist() throws Throwable {
		employeeScheduleSteps.validateNoScheduleExists();	
	}
	
	@When("^I delete the shift")
	public void i_delete_the_shift() throws Throwable{
		employeeScheduleSteps.deleteShift();
	}
	
	@And("^I give access to the supervisor")
	public void i_give_access_to_the_supervisor() throws Throwable {
		employeeScheduleSteps.access();
	}
	@And("^I disable schedule edit privileges")
	public void i_disable_schedule_edit_privileges() throws Throwable {
		employeeScheduleSteps.editSchedulePrivileges(0);
	}
	
	@Then("I enable self edit privileges")
	public void i_disable_self_edit_privileges() throws Throwable {
		employeeScheduleSteps.editSelfPrivileges();
	}

}
