package com.adp.tlmbdd.common;

import java.io.File;
import java.io.IOException;

import org.apache.fontbox.pfb.PfbParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.Assert;

import net.serenitybdd.core.SerenitySystemProperties;
import net.thucydides.core.ThucydidesSystemProperty;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

public class PDFReader {


	// Setting Default values LastPage of PDF
	public static int EndPageNum = -1;

	/**
	 * To Get the Total content of the PDF as Plain text
	 * 
	 * @param pdf
	 *            Absolute PDF path
	 * @return String document content in plain text
	 * 
	 */
	public static String getText(String pdf) {
		String Content = null;
		try {

			PDDocument doc = PDDocument.load(new File(pdf));
			PDFTextStripper stripper = new PDFTextStripper();
			Content = stripper.getText(doc);
			// System.out.println("Total PDF content: " + Content);
			return Content;
		} catch (Exception e) {

			System.out.println("Error Message whlie reading PDF" + e.getMessage());
			e.printStackTrace();
		}
		return Content;

	}

	/**
	 * To get Content from PDF from given startPage Number
	 * 
	 * @param pdf
	 *            Absolute PDF path
	 * @param StartPageNum
	 *            Starting page number of the PDF document
	 * @return It will return the Plain Text from PDF. from StartPageNum to Till End
	 */
	public static String getText(String pdf, int StartPageNum) {
		String Content = null;

		try {
			PDDocument doc = PDDocument.load(new File(pdf));
			PDFTextStripper stripper = new PDFTextStripper();
			EndPageNum = doc.getNumberOfPages();
			stripper.setStartPage(StartPageNum);
			stripper.setEndPage(EndPageNum);
			Content = stripper.getText(doc);
			System.out.println(Content);
			return Content;
		} catch (Exception e) {
			System.out.println("Error Message whlie reading PDF" + e.getMessage());
			e.printStackTrace();
		}
		return Content;

	}

	/**
	 * To Get PDF content as plain text based on Required page numbers
	 * 
	 * @param pdf
	 *            Absolute PDF path
	 * @param StartPageNum
	 *            Starting page number of the document
	 * 
	 * @param EndPageNum
	 *            End page number of the PDF document
	 * @return It will return the plain text from PDF (StartPageNum to EndPageNum)
	 * 
	 */
	public static String getText(String pdf, int StartPageNum, int EndPageNum) {

		String Content = null;
		try {
			PDDocument doc = PDDocument.load(new File(pdf));
			PDFTextStripper stripper = new PDFTextStripper();
			stripper.setStartPage(StartPageNum);
			stripper.setEndPage(EndPageNum);
			Content = stripper.getText(doc);
			System.out.println(Content);
			return Content;
		} catch (Exception e) {
			System.out.println("Error Message whlie reading PDF" + e.getMessage());
			e.printStackTrace();
		}
		return Content;
	}

	/**
	 * Used to Check whether specific text present in the PDF
	 * 
	 * @param pdf
	 *            Absolute PDF path
	 * @param texttoverify
	 *            Text which you want to verify in the PDF
	 * @return Returns true if Specific Text present in the PDF. else it returns
	 *         false.
	 */
	public static boolean verifyText_inPDFContent(String pdf, String texttoverify) {

		String PDFTotalContent = null;
		try {
			PDFTotalContent = getText(pdf);
			if (PDFTotalContent.toLowerCase().contains(texttoverify.toLowerCase())) {
				return true;
			} else {

				return false;
			}
		} catch (Exception e) {
			System.out.println("Error while checking the if condition" + e.getMessage());
			return false;
		}

	}

	public static int getPageCount(String pdf) throws IOException {
		PDDocument doc = PDDocument.load(new File(pdf));
		int pageCount = doc.getNumberOfPages();
		doc.close();
		return pageCount;
	}

	/**
	 * Used to Compare Two PDFs line by line
	 * 
	 * @param basePDF
	 *            Baseline PDF file
	 * @param newPDF
	 *            Newly Generated File
	 * @return
	 * @throws IOException
	 */
	public static boolean ComparePDFFilesLineByLine(String basePDF, String newPDF) throws IOException {

		boolean currentPageIsEqual = true;
		int basePDFPageCount = 0;
		int newPDFPageCount = 0;
		boolean pagesAreEqual = true;

		basePDFPageCount = getPageCount(basePDF);
		newPDFPageCount = getPageCount(newPDF);

		int lastPage_of_BasePDF = basePDFPageCount;

		if (basePDFPageCount != newPDFPageCount) {
			Assert.fail("Base PDF and Generated PDF pageCounts are not equal");
		}

		for (int currentPage = 1; currentPage <= lastPage_of_BasePDF; currentPage++) {

			String _basePDF = getText(basePDF, currentPage, currentPage).trim();
			String _newPDF = getText(newPDF, currentPage, currentPage).trim();

			String _basePDFLines[] = _basePDF.split("\\r?\\n");
			String _newPDFLines[] = _newPDF.split("\\r?\\n");

			for (int iLineNum = 1; iLineNum < _basePDFLines.length; iLineNum++) {
				boolean linesAreEqual = true;

				String line__basePDF = _basePDFLines[iLineNum];
				String line_newPDF = _newPDFLines[iLineNum];

				if (line__basePDF == null || line_newPDF == null)
					linesAreEqual = false;
				else if (!line_newPDF.equalsIgnoreCase(line_newPDF))
					linesAreEqual = false;

				currentPageIsEqual = currentPageIsEqual && linesAreEqual;
				String strTxtLocation = "PageNo:" + currentPage + ", LineNo:" + iLineNum;

				// for Logging only
				if (!linesAreEqual) {
					System.out.println("********** " + strTxtLocation + " **********");
					System.out.println("Expected :" + line__basePDF);
					System.out.println("Actual   :" + line_newPDF);
					Assert.fail("Base PDF and generated PDF data not equal");
				}

			}
			pagesAreEqual = pagesAreEqual && currentPageIsEqual;
		}

		return pagesAreEqual;
	}

	/**
	 * Run as java application to verify it locally.
	 * 
	 * @param args
	 * @throws IOException 
	 */

	public static void main(String[] args) throws IOException {
		
		
        
		String pdf = "C:\\Naidu\\NavyTeam\\Meal Attestation Report.pdf";
		ComparePDFFilesLineByLine("C:\\Naidu\\NavyTeam\\Meal Attestation Report.pdf","C:\\Naidu\\NavyTeam\\Meal Attestation Report.pdf");
		String content = getText(pdf);
		String pdftextbylines[] = content.trim().split("\\r?\\n");
		for (int i = 0; i < pdftextbylines.length; i++) {
			System.out.println(pdftextbylines[i]);
		}
		System.out.println(content);
		/*
		 * String pdf = "C:\\Naidu\\NavyTeam\\Meal Attestation Report.pdf"; boolean
		 * result = verifyText_inPDFContent(pdf, "Total Number of Employees"); Assert.
		 * assertTrue("Totqal Number of Employees Content doesnot exist in the report",
		 * result);
		 */
	}
	
	

}
