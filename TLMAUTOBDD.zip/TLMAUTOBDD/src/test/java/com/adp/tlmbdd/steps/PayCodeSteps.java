package com.adp.tlmbdd.steps;

import java.util.List;

import com.adp.tlmbdd.pages.editors.Paycode;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class PayCodeSteps extends ScenarioSteps{

	Paycode paycode;
	
	@Step
	public void addNewPayCode()
	{
		paycode.clickOnAddNewPayCode();
	}
	
	@Step
	public void addPayCodeDetails(String culture)
	{
		paycode.addPayCodeDetails(culture);
	}
	
	@Step
	public void addPayCodeAndIncludeColoumns(String paycodetype,String inculdecoloumns)
	{
		paycode.addPayCodeTypeAndIncludeColoumns(paycodetype, inculdecoloumns);
	}
	
	@Step
	public void selectRateClacType(String ratecalculationtype,String ratefactor,String rateamount)
	{
		paycode.selectRateCalcType(ratecalculationtype, ratefactor, rateamount);
	}
	
	@Step
	public void addEntryTypeAndWorkedType(String entrytype,String workedtype)
	{
		paycode.enrtyTypeAndWorkedType(entrytype, workedtype);
	}
	
	@Step
	public void clickSubmitButton()
	{
		paycode.clickSubmitPaycode();
	}
	
	@Step
	public void assignPayclasses(List<String> list)
	{
		paycode.selectPayClasses(list);
	}
	
	@Step
	public void verifyPayCodeCreatedSuccessfully()
	{
		paycode.verifyPayCodeAddedSuccesfully();
	}
	
	@Step
	public void clickOnCreatedPayCode()
	{
		paycode.clickOnCreatedpayCode();
	}
	
	@Step
	public void assignUnassignOrUpdatePayClass(String operation,String payclassname)
	{
		paycode.assignOrUnassignPayClasses(operation, payclassname);
	}
	
	@Step
	public void deletePaycodeAndVerify()
	{
		paycode.deletePayCodeAndVerify();
	}
	
	@Step
	public void copyFirstPaycode()
	{
		paycode.copyFirstPayCode();
	}
	

	@Step
	public void clickFirstPaycode()
	{
		paycode.clickFirstPayCode();
	}
	
}
