package com.adp.tlmbdd.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

//@DefaultUrl("https://wfn-fit.nj.adp.com/public/index.htm")
public class Logins extends GenericPageObject {

	// ************************ Login ************************//
	@FindBy(xpath = "//div[contains(@class, 'admin-login text-right')]//i[contains(@class, 'fa fa-sign-in')]")
	private WebElementFacade adminLoginLink;

	@FindBy(id = "adminLogin")
	private WebElementFacade adminSignInLink;

	// id="adminLogin" for auto env , // name="USER" for auto

	@FindBy(xpath = "//div[contains(@class,'user-id')]/descendant::input")
	private WebElementFacade userIdTextboxPrac;

	@FindBy(xpath = "//input[@name= 'USER' or @name='user']")
	private WebElementFacade userIdTextbox;

	// @FindBy(xpath = "//input[@name= 'USER' or
	// @name='user']|//span[contains(text(),'Next')]/preceding::input[1][2]")
	// private WebElementFacade userIdTextbox;

	// @FindBy(xpath = "//div[contains(@class, 'loginButton')]//div[contains(@class,
	// 'buttonMid') and contains(text(), 'Submit')]")
	// private WebElementFacade usUserSubmitButton;

	@FindBy(xpath = "//span[contains(text(),'Sign In')]/..")
	private WebElementFacade usUserSubmitButton;

	@FindBy(xpath = "//input[@value='Login']")
	private WebElementFacade usUserLoginButton;

	// @FindBy(name="PASSWORD") auto
	@FindBy(xpath = "//div[contains(@class,'password')]/descendant::input")
	private WebElementFacade uaPasswordTextBox;

	@FindBy(xpath = "//input[@id='password' or @name='PASSWORD']")
	private WebElementFacade empPasswordTextBox;

	@FindBy(id = "subBtn")
	private WebElementFacade empSignInButton;

	@FindBy(id = "portal.login.logIn")
	private WebElementFacade empLoginInButton;

	@FindBy(id = "home_navItem_label")
	private WebElementFacade homenavigationItem;

	@FindBy(xpath = "//span[contains(.,'Home')]")
	private WebElementFacade homenavigationItemRUN;
	
	@FindBy(xpath = "//span[contains(.,'Company List')]")
	private WebElementFacade homeNavigationNonTLMRUN;

	@FindBy(xpath = "//a[contains(.,'Dashboard')]")
	private WebElementFacade homenavigationMyADP;

	@FindBy(xpath = "//div[@class='wfn-masthead']/img")
	private WebElementFacade img_ADPLogo;

	@FindBy(id = "//h1[text()='Administrator Sign In']")
	private WebElementFacade admintext;

	@FindBy(xpath = "//input[@value='public']")
	private WebElementFacade publicReadioButton;

	@FindBy(xpath = "//input[@value='trusted']")
	private WebElementFacade trustedReadioButton;

	@FindBy(xpath = "//input[contains(@id,'txtLoginId')]")
	private WebElementFacade txt_userIdRUN;

	@FindBy(xpath = "//*[@id=\"btnNext\"]")
	private WebElementFacade btn_NextRUN;

	@FindBy(xpath = "//input[@id='PASSWORD']")
	private WebElementFacade txt_passwordRUN;

	@FindBy(xpath = "//input[@id='user']")
	private WebElementFacade txt_MyADPID;

	@FindBy(xpath = "//input[@id='password']")
	private WebElementFacade txt_MyADPpassword;

	// ************************ quickSearch *********************************//
	//@FindBy(id = "toolbarQuickSearch")
	//private WebElementFacade clientSearchTextBox;

	@FindBy(xpath = "//input[@id='searchBox']")
	public WebElementFacade clientSearchTextBox;

	@FindBy(xpath = "//*[@class='uaClientId']")
	public WebElementFacade searchResults;

	@FindBy(xpath = "//*[@class='uaActionList']/li[1]")
	public WebElementFacade selection;

	@FindBy(xpath = "(//div[contains(@id,'revit_TooltipDialog')])[2]")
	private WebElementFacade clientSearchPopup;

	@FindBy(xpath = "//span[@title='regmdfsch']")
	private WebElementFacade clientIdLink;

	@FindBy(xpath = "//a[text()='Practitioner Access']")
	private WebElementFacade accessTypeLink;

	// ************************* What's New dialog *************************//
	@FindBy(id = "whatsnewdialog")
	private WebElementFacade whatsNewPopup;

	@FindBy(xpath = "//div[@id='whatsnewdialog']//span[@title='Cancel']")
	private WebElementFacade whatsNewCloseButton;

	@FindBy(xpath = "//*[@id='wnCheckBox']")
	private WebElementFacade whatsNewDontShowCheckbox;

	// ************************************ Bridge dialog **********************//
	@FindBy(id = "pracTheBridgeLink_dropdown")
	private WebElementFacade bridgeLinkDropdown;

	@FindBy(id = "ssoBridgeGotItButton")
	private WebElementFacade bridgeGotItButton;

	@FindBy(id = "ssoBridgeDontShowAgain")
	private WebElementFacade bridgeDontshowCheckbox;

	@FindBy(xpath = "//div[contains(@id, 'popup_')]/div[contains(@id, 'revit_TooltipDialog_')]//tr[1]/td/a/span")
	private WebElementFacade clientsearch;

	@FindBy(xpath = "//span[contains(text(),'Next')]/..")
	private WebElementFacade NextButton;

	@FindBy(xpath = "//span[contains(text(),'Sign In')]")
	private WebElementFacade SignInButton;

	@FindBy(xpath = "//*[contains(text(),'Your session has timed out.')]")
	private WebElementFacade lblMsg_SessionTimeout;

	@FindBy(xpath = "//span[contains(text(),'Log In')]")
	private WebElementFacade btn_LoginMyADP;
	
		

	public void pracUserLogin(String p_userName, String p_password) {
		try {
			browserLaunch();
			if (!clickOnElementIfExists(adminLoginLink)) {
				clickOnElementIfExists(adminSignInLink);
			}
			waitABit(3000);
			/*
			 * @auto1 if(admintext.isVisible()) {
			 * 
			 * @auto1
			 */
			// For Auto1
			if (clickOnElementIfExists(userIdTextbox)) {
				userIdTextbox.waitUntilVisible();
				userIdTextbox.clear();
				userIdTextbox.sendKeys(p_userName);
				waitABit(3000);
				empPasswordTextBox.waitUntilVisible();
				empPasswordTextBox.clear();
				empPasswordTextBox.sendKeys(p_password);
				usUserLoginButton.click();
			}
			// For Other Envt
			if (clickOnElementIfExists(userIdTextboxPrac)) {
				userIdTextboxPrac.waitUntilVisible();
				userIdTextboxPrac.clear();
				userIdTextboxPrac.sendKeys(p_userName);
				NextButton.waitUntilClickable();
				NextButton.click();
				waitABit(3000);
				uaPasswordTextBox.waitUntilVisible();
				uaPasswordTextBox.clear();
				uaPasswordTextBox.sendKeys(p_password);
				usUserSubmitButton.click();
			}
			WaitForAjax();
			if (!checkElementVisible(lblMsg_SessionTimeout)) {
			} else {
				userIdTextboxPrac.clear();
				userIdTextboxPrac.sendKeys(p_userName);
				NextButton.waitUntilClickable();
				NextButton.click();
				waitABit(3000);
				uaPasswordTextBox.waitUntilVisible();
				uaPasswordTextBox.clear();
				uaPasswordTextBox.sendKeys(p_password);
				usUserSubmitButton.click();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			// getDriver().close();
			System.out.println("After driver close" + ex);
		}
	}

	/*// this method is used to enter clientID in quickSearch and select Practitioner
	public void searchForClientAccess(String clientId, String clientAccessType) {
		try {
			clientSearchTextBox.sendKeys(clientId);
			// clientSearchPopup.waitUntilVisible();
			String clientIdLoweCase = clientId.toLowerCase();
			// getElementByDynamicValues("xpath", "clientIdLinkXpath",
			// clientIdLoweCase).click();
			waitABit(5000);
			clientsearch.click();
			accessTypeLink.waitUntilVisible();
			accessTypeLink.click();
			waitFor(getElementByDynamicValues("xpath", "clientIdLabelXpath", clientIdLoweCase));
		} catch (Exception ex) {

		}
	}*/
	
	
	public void searchForClientAccess(String clientId, String clientAccessType) {
		try {
			clientSearchTextBox.sendKeys(clientId);
			// clientSearchPopup.waitUntilVisible();
			// String clientIdLoweCase = clientId.toLowerCase();
			// getElementByDynamicValues("xpath", "clientIdLinkXpath",
			// clientIdLoweCase).click();
			waitABit(5000);
			searchResults.waitUntilClickable();
			searchResults.click();
			waitABit(5000);
			selection.waitUntilClickable();
			selection.click();
			waitABit(10000);

			// waitFor(getElementByDynamicValues("xpath", "clientIdLabelXpath",
			// clientIdLoweCase));
		} catch (Exception ex) {
			System.out.println(ex.getStackTrace());
			System.out.println(ex);
		}
	}
	

	public void empUserLogin(String p_userName, String p_password) {
		try {
			browserLaunch();
			userIdTextbox.waitUntilVisible();
			userIdTextbox.clear();
			userIdTextbox.sendKeys(p_userName);
			empPasswordTextBox.clear();
			empPasswordTextBox.sendKeys(p_password);
			if (!clickOnElementIfExists(empSignInButton)) {
				empLoginInButton.click();
			}
		/*	waitFor(homenavigationItem);
			System.out.println("after wait for home page");
			// added this to avoid login issue in iAT(VM)
			if (!checkElementVisible(img_ADPLogo)) {
				System.out.println("ADP Logo visible");
				getDriver().navigate().refresh();
			}
			waitFor(homenavigationItem);*/
		} catch (Exception ex) {

		}
	}

	public void RUNNepLogin(String p_userName, String p_password) {
		try {
			browserLaunch();
			txt_userIdRUN.waitUntilVisible();
			txt_userIdRUN.clear();
			txt_userIdRUN.sendKeys(p_userName);
			waitABit(2000);
			btn_NextRUN.click();
			txt_passwordRUN.waitUntilVisible();
			txt_passwordRUN.clear();
			txt_passwordRUN.sendKeys(p_password);
			btn_NextRUN.click();

			waitFor(homenavigationItemRUN);

			System.out.println("after wait for home page");
			// added this to avoid login issue in iAT(VM)
			if (!checkElementVisible(homenavigationItemRUN)) {
				System.out.println("Home Page loaded");
				getDriver().navigate().refresh();
			}
			waitFor(homenavigationItemRUN);
			waitABit(3000);
			//code to hide unwanted blocking chatbot
			if(checkElementVisible("//img[@class='floatingChat']"))
			{
				waitABit(3000);
				JavascriptExecutor jsExecutor = (JavascriptExecutor) getDriver();
				jsExecutor.executeScript("document.getElementsByClassName('floatingChat')[0].setAttribute('style', 'display: none;')", "//img[@class='floatingChat']");
			}			
				
			
				
		} catch (Exception ex) {

		}
	}
	
	
	public void NonTLMLogin(String p_userName, String p_password) {
		try {
			browserLaunch();
			txt_userIdRUN.waitUntilVisible();
			txt_userIdRUN.clear();
			txt_userIdRUN.sendKeys(p_userName);
			waitABit(2000);
			btn_NextRUN.click();
			txt_passwordRUN.waitUntilVisible();
			txt_passwordRUN.clear();
			txt_passwordRUN.sendKeys(p_password);
			btn_NextRUN.click();

			waitFor(homeNavigationNonTLMRUN);

			System.out.println("after wait for home page");
			// added this to avoid login issue in iAT(VM)
			if (!checkElementVisible(homeNavigationNonTLMRUN)) {
				System.out.println("Home Page loaded");
				getDriver().navigate().refresh();
			}
			waitFor(homeNavigationNonTLMRUN);
		} catch (Exception ex) {

		}
	}

	public void MyADPLogin(String p_userName, String p_password, String p_URL) {
		try {
			browserLaunchbyURL(p_URL);
			txt_MyADPID.waitUntilVisible();
			txt_MyADPID.clear();
			txt_MyADPID.sendKeys(p_userName);
			waitABit(2000);
			txt_MyADPpassword.waitUntilVisible();
			txt_MyADPpassword.clear();
			txt_MyADPpassword.sendKeys(p_password);
			btn_LoginMyADP.click();
			waitFor(homenavigationMyADP);

			System.out.println("after wait for home page");
			// added this to avoid login issue in iAT(VM)
			if (!checkElementVisible(homenavigationMyADP)) {
				System.out.println("Home Page loaded");
				getDriver().navigate().refresh();
			}
			waitFor(homenavigationMyADP);
		} catch (Exception ex) {

		}
	}

	public void TempusWebClockingLogin(String p_userName, String p_password, String p_URL) {
		try {
			
			browserLaunchbyURL(p_URL);
			userIdTextbox.waitUntilVisible();
			userIdTextbox.clear();
			userIdTextbox.sendKeys(p_userName);
			empPasswordTextBox.clear();
			empPasswordTextBox.sendKeys(p_password);
			if (!clickOnElementIfExists(empSignInButton)) {
				empLoginInButton.click();
			}
		/*	if (!checkElementVisible(homenavigationMyADP)) {
				System.out.println("Home Page loaded");
				getDriver().navigate().refresh();
			}
			waitFor(homenavigationMyADP);*/
		} catch (Exception ex) {

		}
	}
	
	public boolean dislayHomePage() {
		// assert home page
		return homenavigationItem.isVisible();
	}

	// close the what's new dialog
	public void closeWhatsNewDialog() {
		if (whatsNewPopup.isVisible()) {
			/*
			 * if (whatsNewDontShowCheckbox.getAttribute("aria-checked").equals("false")) {
			 * whatsNewDontShowCheckbox.click(); }
			 */
			whatsNewCloseButton.click();
		}
	}

	// close bridge dialog
	public void closeBridgeDialog() {
		if (bridgeLinkDropdown.isVisible()) {
			/*
			 * if (!bridgeDontshowCheckbox.isSelected()) { bridgeDontshowCheckbox.click(); }
			 */
			bridgeGotItButton.click();
		}

	}

	public void quitBrowser() {
		getDriver().quit();
	}

}
