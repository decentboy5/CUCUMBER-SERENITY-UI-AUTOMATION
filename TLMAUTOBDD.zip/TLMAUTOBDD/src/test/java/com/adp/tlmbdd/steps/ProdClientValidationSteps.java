package com.adp.tlmbdd.steps;

import java.io.IOException;

import com.adp.tlmbdd.pages.editors.EmploymentProfileTechRefresh;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class ProdClientValidationSteps extends ScenarioSteps  {
	
	EmploymentProfileTechRefresh employmentProfileTechRefresh;
	
	  
	  @Step
		public void ValidateTimeTilePages() throws IOException {
			employmentProfileTechRefresh.ProductionClientValidation();

		}

}
