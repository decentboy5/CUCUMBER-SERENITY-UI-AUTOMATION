package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.editors.TimecardAccumulators;

import net.thucydides.core.steps.ScenarioSteps;

public class TimecardAccumulatorSteps extends ScenarioSteps{

	TimecardAccumulators accumulators;
	
	public void verifyAcrossPrdTotVisible()
	{
		accumulators.verifyAcrossPrdTotInTimecardAccumulators();
	}
	
	public void verifyDescription()
	{
		accumulators.verifyDescription();
	}
}
