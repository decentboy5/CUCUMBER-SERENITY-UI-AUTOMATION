package com.adp.tlmbdd.steps;

import java.util.List;

import com.adp.tlmbdd.pages.editors.MonthlySchedule;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;


public class MonthlyScheduleSteps extends ScenarioSteps {
	
	MonthlySchedule monthlysched;
	
	@Step
	public void VerifyMonthlyScheduleMDF6() {
		
		monthlysched.ValidateMonthlySchedule();
		
	}
	
	@Step
	public void ValidateEmpDetails() {
		
		monthlysched.ValidateEmpDet();
		
	}

	@Step
	public void ValidateSchedules() {
		
		monthlysched.ValidateSched();
		
	}

	@Step
	public void AddSchedules() {
		
		monthlysched.AddSched();
		
	}
	
	@Step
	public void AddSchedulesWithJobDept() {
		
		monthlysched.AddSchedwjobdept();
		
	}
	
	@Step
	public void ValidateSchedDeviationsMessage() {
		
		monthlysched.RemoveDeviationsMessage();
		
	}
	
	
	@Step
	public void AddSchedulesAll() {
		
		monthlysched.AddSchedAll();
		
	}
	
	@Step
	public void EditSchedules() {
		
		monthlysched.EditSched();
		
	}
	
	@Step
	public void ChangeDepartment() {
		
		monthlysched.ChangeDept();
		
	}
	
	@Step
	public void ChangeMealPlan() {
		
		monthlysched.ChangeMeal();
		
	}
	
	@Step
	public void ChangeCalendar() {
		
		monthlysched.ChangeCalendar();
		
	}
	
	@Step
	public void RemoveDeviation() {
		
		monthlysched.RemoveSchedDeviation();
		
	}
	
	
	@Step
	public void DeleteSchedules() {
		
		monthlysched.DeleteSched();
		
	}
	
	@Step
	public void ValidateAnnualSummaryLink() {
		
		monthlysched.ValidateAnnualSummary();
		
	}
	
	@Step
	public void ValidateHoliday() {
		
		monthlysched.ValidateHoliday();
		
	}
	
	@Step
	public void SelectDate() {
		
		monthlysched.SelectDateinPast();
		
	}
	
	@Step
	public void ValidateCalendarControl() {
		
		monthlysched.ValidateAnnualSummary();
		
	}
	

	@Step
	public void ClickPreferences() {
		
		monthlysched.ValidateMonthlySchedule();

		monthlysched.ClickPref();
		
	}
	
	@Step
	public void ValidatePreferenceSlider() {
		
		monthlysched.ValidatePref();
		
	}
	
	@Step
	public void ValidateFirstWeekIntheMonth(String DefaultStartWeek) {
		
		monthlysched.ValidateFirstWeekintheMonth(DefaultStartWeek);
		
	}

	@Step
	public void ValidateCalendarMonth() {
		
		monthlysched.ValidateCalendarMonth();
		
	}

	
	@Step
	public void ValidateThisWeek() {
		
		monthlysched.ValidateThisWeek();
		
	}
	

	@Step
	public void MovetoMonth(String Month) {
		
		monthlysched.MovetoMonth(Month);
		
	}
	
	@Step
	public void MovetoMonthFromCalendar(String Month) {
		
		monthlysched.MovetoMonthCalendar(Month);
		
	}
			
	
	/*RemoveScheduleDeviation*/
	@Step
	public void clickActionItemsIntheFirstWeek() {
		monthlysched.clickActionItemsIntheFirstWeek();
	}
	
	@Step
	public void closeRemoveScheduleDeviationsPopup() {
		monthlysched.closeRemoveScheduleDeviationsPopup();
	}
	@Step
	public void validateRemoveScheduleDeviationsInfoTextInPopup() {
		monthlysched.validateRemoveScheduleDeviationsInfoTextInPopup();
	}
	@Step
	public void validateRemoveScheduleDeviationsOptionsInPopup() {
		monthlysched.validateRemoveScheduleDeviationsOptionsInPopup();
	}
	@Step
	public void submitRemoveScheduleDeviationsPopup() {
		monthlysched.submitRemoveScheduleDeviationsPopup();
	}
	@Step
	public void openRemoveScheduleDeviationsPopup() {
		monthlysched.openRemoveScheduleDeviationsPopup();
	}
	@Step
	public void validateRemoveScheduleDeviationsPopup() {
		monthlysched.validateRemoveScheduleDeviationsPopup();
	}
	@Step
	public void verifyRemoveScheduleDeviationsMessage(int noOfSChedules) {
		monthlysched.verifyRemoveScheduleDeviationsMessage(noOfSChedules);
	}
	/*End RemoveScheduleDeviation*/
	
	public void searchEmployee(String employeeName)
	{
		monthlysched.searchEmployee(employeeName);
	}

	public void addSingleOrMultipleScheduleOnSpecificDay(String date,List<String> schedulelist)
	{
		monthlysched.addSingleOrMultipleScheduleOnSpecificDay(date,schedulelist);
	}

	

}
