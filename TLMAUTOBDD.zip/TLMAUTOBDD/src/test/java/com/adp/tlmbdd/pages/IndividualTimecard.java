package com.adp.tlmbdd.pages;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
public class IndividualTimecard extends GenericPageObject {

	public static Logger log = Logger.getLogger(IndividualTimecard.class);

	// ************************** Emp Search  ********************************************************//
	@FindBy(xpath = "//span[@id='employeeIdBarEmpListTooltipBtn']")
	private WebElementFacade empSearchButton;

	@FindBy(id = "empIdBarFilterId")
	private WebElementFacade currentListTextBox;

	@FindBy(xpath = "//div[@id='employeeIdBarEmpListTooltipDialog']")
	private WebElementFacade employeeSearchDailog;

	@FindBy(xpath = "//input[@id='idBarSscrollGrid_search']")
	private WebElementFacade searchTextBox;

	@FindBy(id = "empIdBarEmpData_Name")
	private WebElementFacade empNamelabel;

	@FindBy(xpath = "//*[@id='Preferences']//i")
	private WebElementFacade preferencesDropDown;

	@FindBy(xpath = "//*[text()='Show Date Out']")
	private WebElementFacade showDateOutText;

	@FindBy(xpath = "//*[text()='Show Date Out']/..")
	private WebElementFacade showDateOutCheckBox;

	@FindBy(xpath = "//a[@id='idBarSscrollGridIdCol_Id_1']")
	private WebElementFacade searchEmployee;

	@FindBy(xpath = "(//table[@id='TcGrid']//*[text()='DATE OUT'])[1]")
	private WebElementFacade dateOut;

	@FindBy(xpath = "//*[@id='aMnu']/img")
	private WebElementFacade PrintTimecardMenu;

	@FindBy(xpath = "//td[text()='Print Timecard']")
	public List<WebElementFacade> PrintTimecard;

	@FindBy(xpath = "//span[@id='btnDone']")
	public WebElementFacade ClosePrintTimecard;

	@FindBy(id= "PrintTimecardIFrame")
	public WebElementFacade PrintTimecardIFrame;

	@FindBy(xpath= "//*[@id='r_1_m_1_0']")
	public WebElementFacade RowGrabberMenu;

	@FindBy(xpath= "//td[text()='View Transaction Details']")
	public List<WebElementFacade> RowGrabber;

	@FindBy(xpath= "//*[@id='widget_dateRangeselect']/div[1]/input")
	public WebElementFacade payperiodselect;

	@FindBy(xpath= "//*[@id='dateRangeselect_popup0']")
	public WebElementFacade currentpayperiod;

	@FindBy(xpath= "//*[@id='dateRangeselect_popup1']")
	public WebElementFacade nextpayperiod;

	@FindBy(xpath= "//*[@id='dateRangeselect_popup2']")
	public WebElementFacade previouspayperiod;

	@FindBy(xpath= "//*[@id='dateRangeselect_popup3']")
	public WebElementFacade rangeofdates;

	@FindBy(xpath= "//*[@id='r_1_e_1_Value']")
	public WebElementFacade clickHours;

	@FindBy(xpath= "//*[@id='r_1_e_1_PayCodeID']/../..//input[contains(@id,'TLMWidgets_TimeEntry_DurationTextBox')]")
	public WebElementFacade enterHours;

	@FindBy(xpath= "//*[@id='btnSubmit']/span[1]")
	public WebElementFacade submitButton;

	@FindBy(xpath= "//p[text()='There is nothing to save.']")
	public WebElementFacade nothingToSave;

	@FindBy(xpath= "//p[text()='There is nothing to save.']/../div/span")
	public WebElementFacade nothingToSaveOK;

	@FindBy(xpath= "//*[@id='r_1_e_1_InDate']")
	public WebElementFacade dateIn;

	@FindBy(xpath= "//*[@id='r_1_e_1_OutDate']")
	public WebElementFacade dateOut1;

	@FindBy(xpath= "//*[@id='r_2_e_2_InDate']")
	public WebElementFacade dateIn2;

	@FindBy(xpath= "//*[@id='r_2_e_2_OutDate']")
	public WebElementFacade dateOut2;

	@FindBy(xpath= "//*[@id='tr_1']/td[4]")
	public WebElementFacade viewTransactionDetailsdateIn;

	@FindBy(xpath= "//*[@id='tr_1']/td[7]")
	public WebElementFacade viewTransactionDetailsdateOut;

	@FindBy(xpath= "//*[@id='grdEditAuditDetails']/tbody/tr[1]/td[3]")
	public WebElementFacade viewEditAuditDetailsdateIn;

	@FindBy(xpath= "//*[@id='grdEditAuditDetails']/tbody/tr[2]/td[3]")
	public WebElementFacade viewEditAuditDetailsdateOut;

	@FindBy(xpath= "//*[@id='tcTranAudit']")
	public WebElementFacade viewEditAudit;

	@FindBy(xpath= "//*[@id='btnClose']")
	public WebElementFacade viewEditAuditClose;

	@FindBy(xpath= "//*[@id='TransactionDetailsDialog']//*[@title='Cancel']")
	public WebElementFacade viewTransactionDetailsClose;

	@FindBy(xpath= "//*[@id='r_1_e_1_Value']")
	public WebElementFacade empHours;

	@FindBy(xpath= "//*[@id='r_2_e_2_Value']")
	public WebElementFacade empHours1;

	@FindBy(xpath= "//*[@id='btnChangeDate']")
	public WebElementFacade dateOfChange;

	@FindBy(xpath= "//*[@id='r_1_e_1_PayCodeID']")
	public WebElementFacade paycodeclick;

	@FindBy(xpath= "//*[@id='revit_form_ValidationTextBox_0']")
	public WebElementFacade paycodeenter;

	@FindBy(xpath= "//*[contains(text(),'The value entered is not valid')]")
	public WebElementFacade maxHourErrorMessage;

	@FindBy(xpath= "//*[@id='dateRangestart']/..//span")
	public WebElementFacade dateFormat;

	@FindBy(xpath= "//input[@id='dateRangestart']")
	public WebElementFacade startDate;

	@FindBy(xpath= "//input[@id='dateRangeend']")
	public WebElementFacade endDate;

	@FindBy(xpath= "//span[@id='dateRangefind']")
	public WebElementFacade findButton;

	@FindBy(xpath= "//*[@id='r_1_c_1_OutDate']/..//input[contains(@id,'DateTextBox')]")
	public WebElementFacade dateoutInput;

	@FindBy(xpath= "//*[@id='r_2_m_2_0']")
	public WebElementFacade RowGrabberMenu2;

	@FindBy(xpath= "//*[@id='r_1_e_1_InTime']")
	public WebElementFacade InTime;

	@FindBy(xpath= "//*[@id='r_1_e_1_OutTime']")
	public WebElementFacade OutTime;

	@FindBy(xpath= "//table[@id='TcGrid']/tbody/tr[3]//div[contains(@id,'OutTime')]")
	public WebElementFacade transferedTime;

	@FindBy(xpath= "//*[@id='tlmPortletForm']//*[text()='Employee Configuration']")
	public WebElementFacade employeeConfiguration;

	@FindBy(xpath= "//span[@aria-labelledby='btnNotesOk_label']")
	public WebElementFacade notesokbutton;

	@FindBy(xpath= "//span[@aria-labelledby='btnNotesCancel_label']")
	public WebElementFacade notescancelbutton;

	@FindBy(xpath= "//textarea[@id='txtNotes']")
	public WebElementFacade notestext;

	@FindBy(xpath= "//div[@aria-labelledby='lblAttributeName']")
	public WebElementFacade applynoteto;

	@FindBy(xpath= "//input[@id='txtAttributeName']")
	public WebElementFacade applynotetoinput;
	
	@FindBy(xpath="//span[contains(@id,'ComboButton')][text()='Approved']")
	public WebElementFacade approvedBtn;
	@FindBy(xpath="//td[contains(@class,'dijitMenuItemLabel')][text()='Remove Approval']")
	public WebElementFacade removeApprovallink;	
	@FindBy(xpath="//span[text()='Approve Timecard']/ancestor::span[@role='button']")
	public WebElementFacade approveTimecardBtn;	
	@FindBy(xpath="//span[contains(@class,'dijitDownArrowButton')][contains(@id,'revit_form_ComboButton')]")
	public WebElementFacade approvedBtnArrow;
	
	@FindBy(xpath= "//*[@id='editIcon'][not(contains(@src,'disabled'))]")
	public WebElementFacade notesediticon;

	//Search for Employee
	public void employeeSearch(String empName) {
		try {
			empSearchButton.waitUntilPresent();
			empSearchButton.click();
			System.out.println(currentListTextBox.getTextValue());
			employeeSearchDailog.waitUntilVisible();
			if(!currentListTextBox.getTextValue().contains("status is active"))	{
				currentListTextBox.click();
				currentListTextBox.clear();
				currentListTextBox.typeAndEnter("<status is active>");
				waitABit(1000);		
			}
			selectEmployeeFromSearcLookup(empName);	
		}catch (Exception ex) {
			ex.printStackTrace();
		}
	}


	public void selectEmployeeFromSearcLookup(String empName) {
		String[] empNameText = empName.split(",");
		String empLastName = empNameText[0];
		String empFirstName = empNameText[1];
		String empFullName = empLastName + "," + " " + empFirstName;
		searchTextBox.click();
		searchTextBox.sendKeys(empFullName);
		WebElementFacade employeeLink = getElementByDynamicValues("xpath", "empNameLink", empFullName);
		if(clickOnElementIfExists(employeeLink) == true)				
			waitABit(1000);
		searchEmployee.click();
		waitABit(5000);
		//assert empNamelabel.getText() == empFullName;
	}

	public void checkDateOutCheckbox()
	{
		WaitForAjax();
		preferencesDropDown.waitUntilClickable();
		if(!checkElementVisible(showDateOutText))
			preferencesDropDown.click();
		waitABit(1000);
		String dateouttext = showDateOutText.getText();
		assert dateouttext.equals("Show Date Out");
		String checkboxvalue = showDateOutCheckBox.getAttribute("aria-checked");
		if(checkboxvalue.equals("false")){
			showDateOutCheckBox.waitUntilClickable();
			showDateOutCheckBox.click();
		}
		else
			System.out.println("Checkbox is already checked");
		WaitForAjax();
	}

	public void uncheckDateOutCheckbox()
	{
		WaitForAjax();
		preferencesDropDown.waitUntilClickable();
		if(!checkElementVisible(showDateOutText))
			preferencesDropDown.click();
		waitABit(1000);
		String dateouttext = showDateOutText.getText();
		assert dateouttext.equals("Show Date Out");
		String checkboxvalue = showDateOutCheckBox.getAttribute("aria-checked");
		if(checkboxvalue.equals("true")){
			showDateOutCheckBox.waitUntilClickable();
			showDateOutCheckBox.click();
		}
		else
			System.out.println("Checkbox is already unchecked");
		WaitForAjax();
	}

	public void verifyDateOutVisible()
	{
		boolean flag = checkElementVisible(dateOut);
		Assert.assertEquals(true, flag);
	}

	public void verifyDateOutNotVisible()
	{
		boolean flag = checkElementVisible(dateOut);
		Assert.assertEquals(false, flag);
	}
	public void PrintTimecard()
	{
		PrintTimecardMenu.click();
		int itemCount = PrintTimecard.size();
		for (int i = 1; i <= itemCount;i++)
		{			
			if(getDriver().findElement(By.xpath("(//td[text()='Print Timecard'])["+i+"]")).isDisplayed())
			{
				getDriver().findElement(By.xpath("(//td[text()='Print Timecard'])")).click();
				break;
			}
		}

		getDriver().switchTo().frame(PrintTimecardIFrame);		
		ClosePrintTimecard.click();
		getDriver().switchTo().defaultContent();
	}

	public void ViewTransactionDetails()
	{
		RowGrabberMenu.click();
		int count = getObjectCount("(//td[text()='View Transaction Details'])");

		for (int i = 1; i<=count; i++)
		{
			if (getDriver().findElement(By.xpath("(//td[text()='View Transaction Details'])[" + i + "]")).isDisplayed())
			{
				getDriver().findElement(By.xpath("(//td[text()='View Transaction Details'])[" + i + "]")).click();
				break;
			}
		}
	}

	public void enterTimePair(String hours,String payperiod,String paycode)
	{

		payperiodselect.click();
		waitABit(1000);
		if(payperiod.equals("current"))
			currentpayperiod.click();
		else if(payperiod.equals("next"))
			nextpayperiod.click();
		else if(payperiod.equals("daterange"))
		{
			rangeofdates.click();
			enterDateRangeAndSearch("3");
		}
		else if(payperiod.equals("today"))
		{
			rangeofdates.click();
			enterDateRangeAndSearch("0");
		}
		String emphours = empHours.getText();
		//String emphours1 = empHours1.getText();

		if (emphours.equals("0.00") || emphours.equals("0:00") || emphours.equals("0.0000"))
		{

		}
		else
		{
			RowGrabberMenu.click();
			int count = getObjectCount("(//td[text()='Delete Row'])");
			for (int a = 1; a <= count; a++)
			{
				if (checkElementVisible("(//td[text()='Delete Row'])[" + a + "]"))
				{
					WebElement element =  getDriver().findElement(By.xpath("(//td[text()='Delete Row'])[" + a + "]"));
					element.click();
					break;
				}
			}

			/*  RowGrabberMenu2.click();
        	 int count1 = getObjectCount("(//td[text()='Delete Row'])");
             for (int a = 1; a <= count1; a++)
             {
                 if (checkElementVisible("(//td[text()='Delete Row'])[" + a + "]"))
                 {
                	 WebElement element =  getDriver().findElement(By.xpath("(//td[text()='Delete Row'])[" + a + "]"));
                     element.click();
                     break;
                 }
             }*/

			submitButton.click();
			WaitForAjax();
			if(checkElementVisible(nothingToSave))
				nothingToSaveOK.click();
			payperiodselect.click();
			waitABit(1000);
			if(payperiod.equals("current"))
				currentpayperiod.click();
			else if(payperiod.equals("next"))
				nextpayperiod.click();
			else if(payperiod.equals("daterange"))
			{
				rangeofdates.click();
				enterDateRangeAndSearch("3");
			}
			else if(payperiod.equals("today"))
			{
				rangeofdates.click();
				enterDateRangeAndSearch("0");
			}
			WaitForAjax();
		}

		paycodeclick.click();
		paycodeenter.sendKeys(paycode);
		waitABit(1000);
		clickHours.click();
		enterHours.sendKeys(hours);

		waitABit(3000);
		submitButton.click();
		WaitForAjax();
		if(checkElementVisible(nothingToSave))
			nothingToSaveOK.click();

	}

	public void enterHoursInCurrentPayPeriod(String hours)
	{

		payperiodselect.click();
		waitABit(1000);
		currentpayperiod.click();
		String emphours = empHours.getText();
		if (emphours.equals("0.00") || emphours.equals("0:00") || emphours.equals("0.0000"))
		{

		}
		else
		{
			RowGrabberMenu.click();
			int count = getObjectCount("(//td[text()='Delete Row'])");
			for (int a = 1; a <= count; a++)
			{
				if (checkElementVisible("(//td[text()='Delete Row'])[" + a + "]"))
				{
					WebElement element =  getDriver().findElement(By.xpath("(//td[text()='Delete Row'])[" + a + "]"));
					element.click();
					break;
				}
			}

			submitButton.click();
			WaitForAjax();
			if(checkElementVisible(nothingToSave))
				nothingToSaveOK.click();
			payperiodselect.click();
			waitABit(1000);
			currentpayperiod.click();
			WaitForAjax();
		}

		clickHours.click();
		enterHours.sendKeys(hours);
		waitABit(3000);

	}

	public void verifyTimePairSuccesfullyProcessed()
	{
		String processingstate = RowGrabberMenu.getAttribute("class");
		if(processingstate.equals("menuIconUnprocessed"))
		{
			System.out.println("Time pairs are not getting processed");
			assert false;

		}
		else
		{
			System.out.println("Timepair successfully processed");
		}

	}

	public void verifyDateOutInIndividualTimecard(String datedifference)
	{
		String inDateMonth = dateIn.getText();
		String outDateMonth = dateOut1.getText();
		String inDate  = inDateMonth.split("/")[1];
		String outDate =  outDateMonth.split("/")[1];
		if(datedifference.equals("one"))
		{
			int difference = Integer.valueOf(outDate) - Integer.valueOf(inDate);
			Assert.assertEquals(1, difference);
		}
		else if(datedifference.equals("two"))
		{
			int difference = Integer.valueOf(outDate) - Integer.valueOf(inDate);
			Assert.assertEquals(2, difference);
		}


	}

	public void verifyDateOutInViewTransactionDetails()
	{
		ViewTransactionDetails();
		String inDateMonth = viewTransactionDetailsdateIn.getText();
		String outDateMonth = viewTransactionDetailsdateOut.getText();
		String inDate  = inDateMonth.split("/")[1];
		String outDate =  outDateMonth.split("/")[1];
		int difference = Integer.valueOf(outDate) - Integer.valueOf(inDate);
		Assert.assertEquals(1, difference);
		viewTransactionDetailsClose.click();

	}

	public void viewEditAudit()
	{
		ViewTransactionDetails();
		viewEditAudit.click();
		switchToSpecificWindowUsingIndex(2);


	}

	public void verifyDateOutInViewEditAudit()
	{
		viewEditAudit();
		waitABit(3000);;
		dateOfChange.click();
		WaitForAjax();
		String inDateMonth = viewEditAuditDetailsdateIn.getText();
		String outDateMonth = viewEditAuditDetailsdateOut.getText();
		String inDate  = inDateMonth.split(" ")[0].split("/")[1];
		String outDate =  outDateMonth.split(" ")[0].split("/")[1];
		int difference = Integer.valueOf(outDate) - Integer.valueOf(inDate);
		Assert.assertEquals(1, difference);
		viewEditAuditClose.click();
		switchToSpecificWindowUsingIndex(1);
		viewTransactionDetailsClose.click();


	}

	public void verifyDateOutInPrintTimecard()
	{
		PrintTimecardMenu.click();
		int itemCount = PrintTimecard.size();
		for (int i = 1; i <= itemCount;i++)
		{			
			if(getDriver().findElement(By.xpath("(//td[text()='Print Timecard'])["+i+"]")).isDisplayed())
			{
				getDriver().findElement(By.xpath("(//td[text()='Print Timecard'])")).click();
				break;
			}
		}

		getDriver().switchTo().frame(PrintTimecardIFrame);		
		String inDateMonth = dateIn.getText();
		String outDateMonth = dateOut1.getText();
		String inDate  = inDateMonth.split("/")[1];
		String outDate =  outDateMonth.split("/")[1];
		int difference = Integer.valueOf(outDate) - Integer.valueOf(inDate);
		Assert.assertEquals(1, difference);
		ClosePrintTimecard.click();
		getDriver().switchTo().defaultContent();
	}

	public void verifyMaxHoursErrorMessage()
	{
		boolean flag = checkElementVisible(maxHourErrorMessage);
		Assert.assertTrue(flag);
	}

	public void enterDateRangeAndSearch(String addDays)
	{
		startDate.click();
		startDate.clear();
		String dateformat = dateFormat.getText().replace("mm", "M");
		int days = Integer.valueOf(addDays);
		LocalDateTime sdate = LocalDateTime.now();
		LocalDateTime edate = sdate.plusDays(days);
		String startdate = sdate.format(DateTimeFormatter.ofPattern(dateformat));
		String enddate = edate.format(DateTimeFormatter.ofPattern(dateformat));
		startDate.sendKeys(startdate);
		waitABit(2000);
		endDate.click();
		endDate.clear();
		endDate.sendKeys(enddate);
		waitABit(2000);
		findButton.click();
		WaitForAjax();

	}

	public void verifyDateOutEditable()
	{
		dateOut1.click();
		waitABit(2000);
		dateoutInput.sendKeys(LocalDate.now().toString());

	}

	public void verifyDateOutNotEditable()
	{
		boolean flag = true;
		try{
			dateOut1.click();
			flag = checkElementVisible(dateoutInput);

		}catch(Exception e){
			flag = false;
		}

		Assert.assertFalse(flag);
	}

	public void CopyRow()
	{
		RowGrabberMenu.click();
		int count = getObjectCount("(//td[text()='Copy Row'])");

		for (int i = 1; i<=count; i++)
		{
			if (getDriver().findElement(By.xpath("(//td[text()='Copy Row'])[" + i + "]")).isDisplayed())
			{
				getDriver().findElement(By.xpath("(//td[text()='Copy Row'])[" + i + "]")).click();
				break;
			}
		}

		submitButton.click();
		WaitForAjax();
	}

	public void CopyRowToNextDay()
	{
		RowGrabberMenu.click();
		int count = getObjectCount("(//td[text()='Copy Row to Next Day'])");

		for (int i = 1; i<=count; i++)
		{
			if (getDriver().findElement(By.xpath("(//td[text()='Copy Row to Next Day'])[" + i + "]")).isDisplayed())
			{
				getDriver().findElement(By.xpath("(//td[text()='Copy Row to Next Day'])[" + i + "]")).click();
				break;
			}
		}

		submitButton.click();
		WaitForAjax();
	}

	public void verifyDetailsAfterRowCopied(String copytype)
	{
		String indate1 = dateIn.getText();
		String indate2 = dateIn2.getText();
		String outdate1 = dateOut1.getText();
		String outdate2 = dateOut2.getText();
		String hours1 = empHours.getText();
		String hours2 = empHours1.getText();

		if(copytype.equals("copyrow"))
		{
			Assert.assertTrue(indate1.equals(indate2));
			Assert.assertTrue(outdate1.equals(outdate2));
			Assert.assertTrue(hours1.equals(hours2));
		}
		else if(copytype.equals("copyrowtonextday"))
		{
			Assert.assertEquals(1, Integer.valueOf(indate2.split("/")[1])-Integer.valueOf(indate1.split("/")[1]));
			Assert.assertEquals(1, Integer.valueOf(outdate2.split("/")[1])-Integer.valueOf(outdate1.split("/")[1]));
			Assert.assertTrue(hours1.equals(hours2));
		}
	}

	public void transferAndVerifyOutTime()
	{
		String outtime1 = OutTime.getText();
		rightClickOnElement(OutTime);
		int count = getObjectCount("(//td[text()='Transfer'])");

		for (int i = 1; i<=count; i++)
		{
			if (checkElementVisible("(//td[text()='Transfer'])[" + i + "]"))
			{
				getDriver().findElement(By.xpath("(//td[text()='Transfer'])[" + i + "]")).click();
				break;
			}
		}

		String outtime2 = transferedTime.getText();
		Assert.assertTrue(outtime1.equals(outtime2));


	}

	public void verifyWorkDayRuleInEmployeeConfiguration()
	{
		employeeConfiguration.click();
		WaitForAjax();
	}

	public void selectPayPeriod(String payperiod)
	{
		payperiodselect.click();
		waitABit(1000);
		if(payperiod.equals("current"))
			currentpayperiod.click();
		else if(payperiod.equals("next"))
			nextpayperiod.click();
		else if(payperiod.equals("previous"))
			previouspayperiod.click();	
		else if(payperiod.equals("daterange"))
		{
			rangeofdates.click();
			enterDateRangeAndSearch("3");
		}
		else if(payperiod.equals("today"))
		{
			rangeofdates.click();
			enterDateRangeAndSearch("0");
		}
	}
	
	public void verifyStatusOfTimecard(String status)
	{
		WaitForPageLoad();		
		if(status.equalsIgnoreCase("APPROVED")) {
			if(approvedBtn.isVisible()&&!approveTimecardBtn.isVisible()) {
				Assert.assertTrue("Timecard Status is Approved", true);
			}else {
				Assert.assertTrue("Timecard is not Approved", false);
			}
		} else if(status.equalsIgnoreCase("NOT APPROVED")) {
			if(!approvedBtn.isVisible()&&approveTimecardBtn.isVisible()) {
				Assert.assertTrue("Timecard Status is Not Approved", true);
			}else {
				Assert.assertTrue("Timecard is Approved", false);
			}
		}
		
	}
	
	public void removeEmpApprovalOfTimecard()
	{
		WaitForPageLoad();
		WaitForAjax();
		System.out.println(approvedBtn.isVisible());
		System.out.println(approveTimecardBtn.isVisible());
		if(!approvedBtn.isVisible()&&approveTimecardBtn.isVisible()) {
				Assert.assertTrue("Timecard Status is Not Approved", false);
			}else {
				approvedBtnArrow.click();
				removeApprovallink.click();
				WaitForPageLoad();
				if(approveTimecardBtn.isVisible()&&!approvedBtn.isVisible()) {
					Assert.assertTrue("Timecard Approval is Removed", true);
				}else {
					Assert.assertTrue("Timecard Status is still Approved", false);
				}
			}
	}
	
	public void addNoteForEmployeeOnDate(String operation,String applynoteto,String intendeddate,String note)
	{
		WaitForPageLoad();
		waitForElementToLoad(payperiodselect);
		getDriver().findElement(By.xpath("//div[contains(text(),'"+intendeddate+"')]/ancestor::tr/td[1]")).click();
		if(operation.equals("add"))
		{
			int count = getObjectCount("(//td[text()='Add Note'])");

			for (int i = 1; i<=count; i++)
			{
				if (getDriver().findElement(By.xpath("(//td[text()='Add Note'])[" + i + "]")).isDisplayed())
				{
					getDriver().findElement(By.xpath("(//td[text()='Add Note'])[" + i + "]")).click();
					break;
				}
			}
		}
		else if(operation.equals("edit"))
		{
			int count = getObjectCount("(//td[text()='Add/Edit Note'])");

			for (int i = 1; i<=count; i++)
			{
				if (getDriver().findElement(By.xpath("(//td[text()='Add/Edit Note'])[" + i + "]")).isDisplayed())
				{
					getDriver().findElement(By.xpath("(//td[text()='Add/Edit Note'])[" + i + "]")).click();
					break;
				}
			}
			
			notesediticon.click();
			waitABit(1000);
		}
		waitForElementToLoad(notestext);
		notestext.click();
		notestext.clear();
		notestext.sendKeys(note);
		waitABit(2000);
		notestext.sendKeys(Keys.TAB);
		this.applynoteto.click();
		waitABit(1000);
		applynotetoinput.clear();
		applynotetoinput.sendKeys(applynoteto);
		waitABit(1000);
		notesokbutton.click();
		waitABit(1000);

	}

	public void clickOnSubmitButton()
	{
		submitButton.click();
		WaitForPageLoad();
		
	}

	public void verifyNote(String note,String date)
	{	
		WaitForPageLoad();
		waitForElementToLoad(payperiodselect);
		WebElement element = getDriver().findElement(By.xpath("(//div[contains(text(),'"+date+"')]/ancestor::tr//*[contains(@class,'Note')])[1]"));
		Actions actions = new Actions(getDriver());
		actions.moveToElement(element).build().perform();
		waitABit(2000);
		Assert.assertTrue(checkElementVisible("//*[contains(text(),'"+note+"')]"));
	}
	
	public void enterTimePairOnSpecificDate(String punchType,String employeename,String punch,String date)
	{
		payperiodselect.click();
		waitABit(1000);
		currentpayperiod.click();
		waitABit(2000);
		if(punchType.equals("IN"))
		{
			getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//div[contains(@id,'InTime')]")).click();
			getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//input[contains(@id,'TcTimeTextBox')]")).sendKeys(punch);
		}
		else if(punchType.equals("OUT"))
		{
			getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//div[contains(@id,'OutTime')]")).click();
			getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//input[contains(@id,'TcTimeTextBox')]")).sendKeys(punch);
		}
	}
		

	public void addRowsOnIndividualTimecard(String rowcount,String date)
	{
		waitABit(10000);
		for(int j=0;j<Integer.parseInt(rowcount);j++)
		{	waitABit(2000);
			getDriver().findElement(By.xpath("(//div[contains(text(),'"+date+"')]/ancestor::tr/td[1])[1]")).click();
			waitABit(2000);
			int count = getObjectCount("(//td[text()='Add Blank Row'])");

			for (int i = 1; i<=count; i++)
			{
				if (getDriver().findElement(By.xpath("(//td[text()='Add Blank Row'])[" + i + "]")).isDisplayed())
				{
					getDriver().findElement(By.xpath("(//td[text()='Add Blank Row'])[" + i + "]")).click();
					break;
				}
			}
		}
	}
	
	public void enterMultipleTimePairOnSpecificDate(String punchType,String date,List<String> punches)
	{
		for(int i=1;i<=punches.size();i++)
		{
			if(punchType.equals("IN"))
			{
				waitABit(2000);
				getDriver().findElement(By.xpath("(//div[contains(text(),'"+date+"')]/ancestor::tr//div[contains(@id,'InTime')])["+i+"]")).click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//input[contains(@id,'TcTimeTextBox')]")).sendKeys(punches.get(i-1));
				waitABit(2000);
				getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//input[contains(@id,'TcTimeTextBox')]")).sendKeys(Keys.TAB);
			}
			else if(punchType.equals("OUT"))
			{
				waitABit(2000);
				getDriver().findElement(By.xpath("(//div[contains(text(),'"+date+"')]/ancestor::tr//div[contains(@id,'OutTime')])["+i+"]")).click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//input[contains(@id,'TcTimeTextBox')]")).sendKeys(punches.get(i-1));
				waitABit(2000);
				getDriver().findElement(By.xpath("//div[contains(text(),'"+date+"')]/ancestor::tr//input[contains(@id,'TcTimeTextBox')]")).sendKeys(Keys.TAB);
			}
		}
	}


	

}
