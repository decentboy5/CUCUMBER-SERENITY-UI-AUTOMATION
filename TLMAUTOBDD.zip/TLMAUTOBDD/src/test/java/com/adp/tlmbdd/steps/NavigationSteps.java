package com.adp.tlmbdd.steps;
import java.util.Dictionary;
import java.util.Hashtable;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.reports.adaptors.specflow.ScenarioStep;
import net.thucydides.core.steps.ScenarioSteps;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.GeckoDriverService;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.adp.tlmbdd.pages.*;

public class NavigationSteps extends ScenarioSteps {
	
 Navigation nav;
 
 //MainTab Navigation
 @Step
    public void wfnMainPageNavigationStep(String megaMenu,String subMenu,String mainTab)
    {
    	nav.wfnmainPageNavigation(megaMenu, subMenu, mainTab);    	
    }
 
 //MainTab Navigation for Shell enabled clients
 @Step
 public void wfnMainPageNavigationStepShell(String megaMenu,String subMenu,String mainTab)
 {
 	nav.wfnmainShellPageNavigation(megaMenu, subMenu, mainTab);    	
 }
   
 //Additional Configuration Editors Navigation
   @Step
   public void wfnEditorsLeftPaneNavigationStep(String leftPaneMainOption, String leftPaneSubOption) {
	   nav.wfnEditorsleftPaneNavigation(leftPaneMainOption,leftPaneSubOption);
   }
   
    
    
}