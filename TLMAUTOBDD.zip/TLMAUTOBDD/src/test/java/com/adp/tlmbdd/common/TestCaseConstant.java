package com.adp.tlmbdd.common;

public class TestCaseConstant {
	public static final String STARTDAYOFTHEWEEK = "STARTDAYOFTHEWEEK";
	public static final String FROMDATE = "FROMDATE";
	public static final String TODATE = "TODATE";
	public static final String TODAY = "TODAY";
	public static final String FIRSTDAYOFMONTH = "FIRSTDAYOFMONTH";
}
