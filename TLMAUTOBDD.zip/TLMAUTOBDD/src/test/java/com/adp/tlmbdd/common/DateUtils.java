package com.adp.tlmbdd.common;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalField;
import java.time.temporal.WeekFields;
import java.util.HashMap;
import java.util.Map;

public class DateUtils {
	public static Map<Integer,String> weekDays = new HashMap<>();
	static{
		weekDays.put(0,"SUNDAY");
		weekDays.put(1,"MONDAY");
		weekDays.put(2,"TUESDAY");
		weekDays.put(3,"WEDNESDAY");
		weekDays.put(4,"THURSDAY");
		weekDays.put(5,"FRIDAY");
		weekDays.put(6,"SATURDAY");
	}
	
	public static String getWeekStartEndDateFromDate(DayOfWeek day, LocalDate localDate,int i) {
		TemporalField myWeek = WeekFields.of(day, 1).dayOfWeek();
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("MMddyyyy");
		String str = formatter2.format(localDate.with(myWeek, i));
		return str;
	}
	public static String getCurrentDate() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String currentLocalDate = LocalDate.now().format(formatter);
		return currentLocalDate;
	}
	public static String getFormattedDate(LocalDate date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String currentLocalDate = date.format(formatter);
		return currentLocalDate;
	}
	public static String getCurrentTimeStamp() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
        String currentLocalTimeStamp = LocalDateTime.now().format(formatter);
        return currentLocalTimeStamp;
}

public static LocalDate getRequiredDate(String dateformat)
{
        int intendeddate;
        LocalDate dateUsed;

        LocalDate localDate = LocalDate.now();
        System.out.println(localDate);

        //set date and in punch values
        if(dateformat.contains("MINUS"))
        {
                        intendeddate = Integer.valueOf(dateformat.split("MINUS")[1].trim());
                        dateUsed = localDate.minusDays(intendeddate);
        }
        else if(dateformat.contains("PLUS"))
        {
                        intendeddate = Integer.valueOf(dateformat.split("PLUS")[1].trim());
                        dateUsed = localDate.plusDays(intendeddate);
        }
        else
        {
                        dateUsed = localDate;
        }

        return dateUsed;
}

}
