package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.editors.EmployeeBar;

import net.thucydides.core.steps.ScenarioSteps;

public class EmployeeBarSteps  extends ScenarioSteps {
	EmployeeBar employeeBar;

	public void selectEmployee(String employeeName) {
		employeeBar.openSearchPopup();
		employeeBar.enterTextAndSeach(employeeName);
		employeeBar.selectFirstEmployee();
	}
}
