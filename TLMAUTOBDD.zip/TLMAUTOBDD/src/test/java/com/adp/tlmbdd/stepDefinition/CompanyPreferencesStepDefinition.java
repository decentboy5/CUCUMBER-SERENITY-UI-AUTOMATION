package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.CompanyPreferencesSteps;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class CompanyPreferencesStepDefinition {

	
	@Steps
	CompanyPreferencesSteps companyPreferencesSteps;
	
	@Then("^I verify multiple day shifts button available in company preferences and is unchecked to default$")
	public void i_verify_multiple_day_shifts_button_available_in_company_preferences() throws Throwable {
	
		companyPreferencesSteps.verifyMultidayShiftCheckbox();
	}
	
	@Then("^I enable multi day shift feature$")
	public void i_enable_multi_day_shift_feature() throws Throwable {
	
		companyPreferencesSteps.enableMultiDayShiftCheckbox();
	}
	
	@Then("^I verify Help link and help text and steps to disble link are available$")
	public void i_verify_help_link_and_help_text_and_steps_to_disable_are_available() throws Throwable {
	
		companyPreferencesSteps.enableMultiDayShiftCheckbox();
	}
	
	
}
