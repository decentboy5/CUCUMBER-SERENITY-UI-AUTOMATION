package com.adp.tlmbdd.stepDefinition;
import java.time.format.DateTimeFormatter;

import com.adp.tlmbdd.steps.MyScheduleSteps;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;
public class MyScheduleStepDefinition  {	

	@Steps
	MyScheduleSteps myschedulesteps;

	@When("^I create a shift swap request on \"([^\"]*)\" with comment \"([^\"]*)\" and recipient as \"([^\"]*)\"$")
	public void i_create_a_shift_swap_request_on_with_comment_and_recipient_as(String date, String comment, String recipientname) throws Throwable {
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/d");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
	    myschedulesteps.createShiftSwapRequestOnSpecificDate(requireddate, comment, recipientname);
	}
	
	@Then("^I accept the shift swap request on \"([^\"]*)\" with comment \"([^\"]*)\"$")
	public void i_accept_the_shift_swap_request_on_with_comment(String date, String comment) throws Throwable {
	    
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/d");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
		myschedulesteps.acceptShiftSwapRequest(requireddate, comment);
	}
    
	
}
