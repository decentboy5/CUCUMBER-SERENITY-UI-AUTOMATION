package com.adp.tlmbdd.stepDefinition;
import java.util.HashMap;
import java.util.Map;

import com.adp.tlmbdd.common.SQLQueryConstant;
import com.adp.tlmbdd.common.SQLScriptRunner;
import com.adp.tlmbdd.common.TestCaseConstant;
import com.adp.tlmbdd.common.TestCaseContext;
import com.adp.tlmbdd.steps.*;

import net.thucydides.core.annotations.Steps;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class TimePositionInfoStepDefinition  {
	/*
	@Steps
	DailyCalculationProgramSteps dailyCalculationProgramSteps;
	
	@Then("^I Create New daily calculation program with \"([^\"]*)\" ,\"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_Create_New_daily_calculation_program_with_and(String dailyCalcId, String dailyDescription, String graceRoundRule, String lunchPlan) throws Throwable {
	   
		dailyCalculationProgramSteps.createDCPWithGraceAndLunch(dailyCalcId,dailyDescription,graceRoundRule,lunchPlan);
	}
	
	@When("^I Modify daily calculation program and Verify Updated \"([^\"]*)\" ,\"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\"$")
	public void modify_daily_calculation_program_and_Verify_Updated(String dailyCalcId,String updateDailyDescription,String updateGraceRoundRule,String updateLunchPlan) throws Throwable {
		dailyCalculationProgramSteps.modifyDailyCalc(dailyCalcId, updateDailyDescription, updateGraceRoundRule,updateLunchPlan);
	    
	}
	@Then("^I copy existing Daily calc Program and Verify Daily Calc Program Created successfully \"([^\"]*)\",\"([^\"]*)\"$")
	public void copy_existing_daily_calc_program_and_Verify(String dailyCalcId,String copyCalcID) throws Throwable {
		dailyCalculationProgramSteps.copyDailyCalc(dailyCalcId, copyCalcID);
	}
	@Then("^I Delete Daily Calc program from Search List page \"([^\"]*)\"$")
	public void delete_daily_cal_Program_from_Search_List_Page(String dailyCalcId) throws Throwable {
		dailyCalculationProgramSteps.deletefromSearchListPage(dailyCalcId);
	}
	
	@When("^User create duplicate \"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\" Daily calc Program and verify error message in Daily Calc program page$")
	public void user_create_duplicate_Daily_calc_Program_and_verify_error_message_in_Daily_Calc_program_page(String dailyCalcID, String dailyDescription, String graceRoundRule) throws Throwable {
		dailyCalculationProgramSteps.duplicateErrorMessage(dailyCalcID, dailyDescription, graceRoundRule);
	    
	}

	@When("^Verify error message when User create \"([^\"]*)\", \"([^\"]*)\" Daily calc Program without any rule$")
	public void verify_error_message_when_User_create_Daily_calc_Program_without_any_rule(String dailyCalcID, String dailyDescription) throws Throwable {
		dailyCalculationProgramSteps.withoutRulesErrorMessage(dailyCalcID, dailyDescription);
	}


	@Then("^Verify error message when User create \"([^\"]*)\" ,\"([^\"]*)\" Daily calc Program with Invalid data$")
	public void verify_error_message_when_User_create_Daily_calc_Program_with_Invalid_data(String dailyCalcID, String dailyDescription) throws Throwable {
		dailyCalculationProgramSteps.invalidDataErrorMessage(dailyCalcID, dailyDescription);
	}
	@Then("^Verify error message when User deselect mapped Include In checkbox for \"([^\"]*)\" Daily calc Program$")
	public void verify_error_message_when_User_deselect_mapped_Include_In_checkbox_for_Daily_calc_Program(String dailyCalcID) throws Throwable {
		dailyCalculationProgramSteps.includeInDeselectErrorMessage(dailyCalcID);
	}

	@Then("^Verify error message when User delete \"([^\"]*)\" in Daily calc Program page$")
	public void verify_error_message_when_User_delete_in_Daily_calc_Program_page(String dailyCalcID) throws Throwable {
		dailyCalculationProgramSteps.deleteMappedErrorMessage(dailyCalcID);
	}

	@Then("^Verify error message when User delete \"([^\"]*)\" in Daily calc Program Search page$")
	public void verify_error_message_when_User_delete_in_Daily_calc_Program_Search_page(String dailyCalcID) throws Throwable {
		dailyCalculationProgramSteps.deleteMapSearchPageErrorMessage(dailyCalcID);
	}

	*/
	
	@Given("^I Assign a payclass and first week paycycle to employee \"([^\"]*)\" through DB$")
	public void i_assign_a_payclass_and_paycycle_to_employee_through_DB(String positionId) throws Throwable {
		Map<String, Object> params = new HashMap<>();
		params.put("POSITIONID", positionId);
		params.put("FROMDATE",(String)TestCaseContext.getValue(TestCaseConstant.FROMDATE));
		params.put("TODATE",(String)TestCaseContext.getValue(TestCaseConstant.TODATE));
		params.put("PAYCYCLEID\\_PATTERN", "PC_AUT_%");
		params.put("PAYGROUPID\\_PATTERN", "PG_AUT_%");
		params.put("PAYCYCLEID", "PC_AUT_"+System.currentTimeMillis());
		params.put("PAYGROUPID", "PG_AUT_"+System.currentTimeMillis());
		

		//delete existing
		SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPOSITIONINFO_DELETE_PAYGROUP, params);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPOSITIONINFO_DELETE_PAYCYCLE, params);
		//create paycycle
		SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPOSITIONINFO_CREATE_PAYCYCLE_FROM_BIWKLY, params);
		//crete paygroup
		SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPOSITIONINFO_CREATE_PAYGROUP_FROM_HOURLY, params);
		//assign to employee
		SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPOSITIONINFO_ASSIGN_PAYGROUP_TO_POSITION, params);
	}
}
