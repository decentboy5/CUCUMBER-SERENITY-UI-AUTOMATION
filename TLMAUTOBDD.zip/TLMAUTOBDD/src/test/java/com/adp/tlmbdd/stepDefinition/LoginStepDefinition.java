package com.adp.tlmbdd.stepDefinition;
import com.adp.tlmbdd.steps.UserLoginsSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;
public class LoginStepDefinition  {	

	@Steps
	UserLoginsSteps userLoginsSteps;

	@Given("^I login as WFN parctitioner with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_to_WFN_as_a_parctitioner_with_and(String p_userName, String p_password) throws Throwable {
		
		userLoginsSteps.wfnPracUerLogin(p_userName, p_password);
	}
	
	@Given("^I login as WFN employee user with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_to_WFN_as_a_employee_user_with_and(String p_userName, String p_password) throws Throwable {
	    userLoginsSteps.wfnEmpUserLogin(p_userName, p_password);
	}
	
	@Given("^I login as WFN Uauser with \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_to_WFN_as_a_Uauser_with_and(String uaUserId, String uaPassword,String clientID) throws Throwable {		
		userLoginsSteps.wfUaUserLogin(uaUserId,uaPassword,clientID); 	
	}
	
	@Given("^I login as WFN Uauser$")
	public void i_login_to_WFN_as_a_Uauser() throws Throwable {		
		userLoginsSteps.wfUaUserLogin(GlobalPropertiesStepDefinition.uaUserId,GlobalPropertiesStepDefinition.uaUserPassword,GlobalPropertiesStepDefinition.clientName); 	
	}
	
	@Then("^display the HomePage$")
	public void display_the_HomePage() throws Throwable {
		userLoginsSteps.displayHomePage();
	}   
	
	@And("^I close browser$")
	public void i_close_browser() throws Throwable {
	  userLoginsSteps.closeBrowser();
	}

	@Given("^I login as RUN NEP user with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iLoginAsRUNNEPUserWithAnd(String p_userName, String p_password) throws Throwable {
		userLoginsSteps.RUNNepLogin(p_userName, p_password);
	}

	@Given("^I login as MyADP employee user with \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iLoginAsMyADPEmployeeUserWithAndAnd(String p_userName, String p_password, String p_URL) throws Throwable {
		userLoginsSteps.MyADPLogin(p_userName, p_password, p_URL);
	}
    
	@Given("^I login as AWS user with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_as_aws_user_with_and(String username, String password) throws Throwable {
		userLoginsSteps.awsUserLogin(username, password);
	}
	@Given("^I login as AWS practitioner with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_to_AWS_as_a_practitioner_with_and(String aws_p_userName, String aws_p_password) throws Throwable {
		
		userLoginsSteps.awsPracUserLogin(aws_p_userName, aws_p_password);
	}

	@Given("^I login as Non-TLM user with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iLoginAsNonTLMUserWithAnd(String p_userName, String p_password) throws Throwable {
		userLoginsSteps.NonTLMLogin(p_userName, p_password);
	} 
}
