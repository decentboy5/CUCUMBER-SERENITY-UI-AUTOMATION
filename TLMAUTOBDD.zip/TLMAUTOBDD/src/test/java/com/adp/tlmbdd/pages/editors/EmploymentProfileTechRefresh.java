package com.adp.tlmbdd.pages.editors;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;

import com.adp.tlmbdd.common.ReadDataFromExcel;
import com.adp.tlmbdd.pages.GenericPageObject;
import org.junit.Assert;


import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.AssertTrue;

import com.adp.tlmbdd.pages.Navigation;
import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.gargoylesoftware.htmlunit.javascript.host.Console;

public class EmploymentProfileTechRefresh extends GenericPageObject {
	Navigation nav;

	public static String PassEmployeeName;
	public static String SelectAdditionalLinkText;
	public static String date = getCurrentDate();
	public static String[] firstlastdate = GetFirstLastDatesOfMonth();
	public static String[] nonEffectivDates = GetNonEffectiveDates();
	// public static String date=today;
	/******** Employee Search on Employment Profile Page **************/

	@FindBy(xpath = "//button[@id='empidbar-empsearch-link']")
	private WebElementFacade EmployeeSearch;

	@FindBy(xpath = "//input[@placeholder='Search Within List...']")
	private WebElementFacade InputEmployeeName;

	@FindBy(xpath = "//div[@class='vdl-dropdown-list__input']")
	private WebElementFacade WfnFilterDropDown;

	@FindBy(xpath = "//div[@class='vdl-popup__content']//ul//li[.='<status is active>']")
	private WebElementFacade SelectActiveEmployees;

	@FindBy(xpath = "//div[@class='vdl-popup__content']//ul//li[.='<all employees>']")
	private WebElementFacade SelectAllEmployees;

	@FindBy(xpath = "//div[@class='portletCard-wrapper portletCard-wrapper-position ']")
	private WebElementFacade PositionTile;

	@FindBy(xpath = "//div[@class='portletCard-header portletCard-header-status']")
	private WebElementFacade StatusTile;

	@FindBy(xpath = "//div[@class='vdl-row empProfile-allMargin0']")
	private List<WebElementFacade> TileCount;

	/************ Non Time Position message *********/
	@FindBy(xpath = "//div[@class='vdl-alert__content'][.='Position is not using Time & Attendance']")
	private WebElementFacade NonTimePositionMessage;

	/************** Time Tile Page Objects **************/
	@FindBy(xpath = "//span[text()='Time & Attendance']")
	private WebElementFacade EmploymentProfileTimeAndAttendanceLink;

	@FindBy(xpath = "//div[@class='timeInfoGeneral-container']")
	private WebElementFacade SupervisorTimeTileContent;

	@FindBy(xpath = "//div[@class='lcf-container']")
	private WebElementFacade EmpLcfContainer;

	@FindBy(xpath = "//button[@name='cancelButton']//span[1]")
	private WebElementFacade employeeSlideInCancelButton;

	@FindBy(xpath = "//label[contains(text(),'Pay Class')]")
	private WebElementFacade EmploymentProfileTimeAndAttendancePayClassLabel;

	@FindBy(xpath = "//label[contains(text(),'Pay Class')]/..//span")
	private WebElementFacade EmploymentProfileTimeAndAttendancePayClassValue;
	@FindBy(xpath = "//label[contains(text(),'Badge')]")
	private WebElementFacade EmploymentProfileTimeAndAttendanceBadgeLabel;
	@FindBy(xpath = "//label[contains(text(),'Badge')]/../span")
	private WebElementFacade EmploymentProfileTimeAndAttendanceBadgeValue;
	@FindBy(xpath = "//label[.='Supervisor']")
	private WebElementFacade EmploymentProfileTimeAndAttendanceSupervisorLabel;
	@FindBy(xpath = "//label[.='Supervisor']/../span")
	private WebElementFacade EmploymentProfileTimeAndAttendanceSupervisorValue;
	@FindBy(xpath = "//label[.='Supervisor Position']")
	private WebElementFacade EmploymentProfileTimeAndAttendanceSupervisorPositionLabel;
	@FindBy(xpath = "//label[.='Supervisor Position']/../span")
	private WebElementFacade EmploymentProfileTimeAndAttendanceSupervisorPositionBoolean;
	@FindBy(xpath = "//label[contains(text(),'Include in Time Summary/Payroll?')]")
	private WebElementFacade EmploymentProfileTimeAndAttendanceIncludeInTimeSummaryLabel;
	@FindBy(xpath = "//label[contains(text(),'Include in Time Summary/Payroll?')]/../span")
	private WebElementFacade EmploymentProfileTimeAndAttendanceIncludeInTimeSummaryValue;

	/*************** Time & Attendance Slide in Page Objects *************/

	@FindBy(xpath = "//span[@class='employee-inline-name']")
	private WebElementFacade EmployeeNameOnSlideIn;

	@FindBy(xpath = "//div[@class='employee-banner-midsection-fields']//div[2]")
	private WebElementFacade EmployeePositionOnSlideIn;

	@FindBy(xpath = "//div[@class='timeframe-effdate']/span[2]")
	private WebElementFacade EmploymentPositionGetDateSelected;

	@FindBy(xpath = "//div[@class='mdf-time-frame__effDate--container update']//span[@class='vdl-button__icon fa fa-plus-circle']")
	private WebElementFacade TimeAttendanceSlideInAddButton;
	@FindBy(xpath = "//div[@class='mdf-time-frame__effDate--container update']//span[@class='vdl-button__icon fa fa-pencil']")
	private WebElementFacade TimeAttendanceSlideInEditRecordButton;
	@FindBy(xpath = "//button[@type='button']//span[@class='vdl-button__icon fa fa-pencil']")
	private WebElementFacade TimeAttendanceSlideDeleteRecordButton;
	@FindBy(xpath = "//button[@type='button']//span[@class='vdl-button__icon fa fa-trash']")
	private WebElementFacade ReadOnlyUsingTimeAndAttendanceToggle;
	@FindBy(xpath = "//div[@class='mdf-time-frame__dates-container mdf-time-frame__dates-container--slide-in-left']")
	private WebElementFacade GetTheCountOfRecordDisplayed;

	@FindBy(xpath = "//input[@id='effectiveDate']")
	private WebElementFacade DateTextBox;

	@FindBy(xpath = "//div[@class='vdl-alert vdl-alert--default-style vdl-alert--animate vdl-alert--sm vdl-alert--info']//div[@class='vdl-alert__content-container']")
	private WebElementFacade EffectiveDateMessage;
	@FindBy(xpath = "//div[contains(text(),\"You cannot change the employee's Pay Class on this\")]")
	private WebElementFacade PayClassMessage;

	@FindBy(xpath = "//div[contains(text(),\"You cannot change the employee's Pay Class on this\")]")
	private WebElementFacade ErrorMessageText;

	// Using Time Toggle & Pay class look up xpaths
	@FindBy(xpath = "//div[@class='mdf-validated-field tlm-label toggle-align toggle-switch']//div//div[@class='vdl-toggle-switch__label vdl-toggle-switch__label--unchecked']")
	private WebElementFacade NonTimeToggleOff;

	@FindBy(xpath = "//div[@class='mdf-validated-field tlm-label toggle-align toggle-switch']//div//div[@class='vdl-toggle-switch__label vdl-toggle-switch__label--checked']")
	private WebElementFacade TimeToggleOn;

	@FindBy(xpath = "//div[@class='mdf-validated-field tlm-label toggle-align toggle-switch']//div//div[@class='vdl-toggle-switch__knob']")

	private WebElementFacade SwitchTimeToggleOnOff;

	@FindBy(xpath = "//div[@class='mdf-validated-field' and contains (.,'Pay Class')]/..//span[@class='fa fa-search-plus']")
	private WebElementFacade PayclassTextBoxSearchIcon;

	@FindBy(xpath = "//div[@class='mdf-validated-field' and contains (.,'Pay Class')]/../..//div[@role='combobox']//input[@type='text']")
	private WebElementFacade InputPayClassValue;

	@FindBy(xpath = "//div[@id='PayclassSummaryView.PayclassCycle.wrapper']")
	private WebElementFacade getPayClassValueFromPayClassSummary;

	@FindBy(xpath = "//div[@class='mdf-validated-field'][contains(.,'Pay Class')]/..//i[@class='fa fa-close']")

	private WebElementFacade ClearExistingPayClass;

	// Using Supervisor Position Toggle & Supervisor look up xpaths

	@FindBy(xpath = "//div[@class='vdl-toggle-switch__container'][contains(.,'Supervisor Position')]//div[@class='vdl-toggle-switch__knob']")

	private WebElementFacade SupervisorToggle;

	@FindBy(xpath = "//div[@class='mdf-validated-field' and contains (.,'Supervisor')]/..//span[@class='fa fa-search-plus']")
	private WebElementFacade SupervisorSearchIcon;

	@FindBy(xpath = "//div[@class='search-textbox']//input[@type='text']")
	private WebElementFacade SupervisorlookupSearchTextbox;

	@FindBy(xpath = "//div[@data-index='0']//a")
	private WebElementFacade SelectSupervisorFromLookUp;

	@FindBy(xpath = "//div[@class='mdf-validated-field' and contains (.,'Supervisor')]/../..//div[@role='combobox']//input[@type='text']")
	private WebElementFacade InputSupervisorValue;

	@FindBy(xpath = "//div[@class='mdf-validated-field' and contains (.,'Supervisor')]/../..//div[@class='lookupbar-line']//i[@class='fa fa-close']")
	private WebElementFacade ClearExistingSupervisor;

	@FindBy(xpath = "//label[.='Shift Rule']/../..//ul/li[2]")
	private WebElementFacade SelectShiftRule;

	@FindBy(xpath = "//div[@name='selectedShiftRule']//span[@class='vdl-dropdown-list__picker']")
	private WebElementFacade ClickShiftRule;

	@FindBy(xpath = "//div[@name='selectedWageRates']//span[@class='vdl-dropdown-list__picker']")
	private WebElementFacade ClickWageRate;

	@FindBy(xpath = "//div[@class='mdf-validated-field toggle-switch']//div//label[@class='vdl-toggle-switch']//div[@class='vdl-toggle-switch__knob']")
	private WebElementFacade TurnSupervisorToggleOnOff;

	@FindBy(xpath = "//label[@for='selectedShiftRule']")
	private WebElementFacade ShiftRuleLabel;

	@FindBy(xpath = "//div[@name='selectedOutPunchProgram']//div[@class='vdl-dropdown-list__input-container']")
	private WebElementFacade OutPunchGenerationProgramInput;

	@FindBy(xpath = "//label[@for='selectedOutPunchProgram']")
	private WebElementFacade OutPunchGenerationProgramLabel;

	@FindBy(xpath = "//label[.='Wage Rate Program']/.././/ul/li[2]")
	private WebElementFacade SelectWageRateProgram;

	@FindBy(xpath = "//div[@class='conflict-popup-dialog']")
	private WebElementFacade FutureDatedAlertPopUp;

	@FindBy(xpath = "//button[@id='viewButton'][.='View']")
	private WebElementFacade FutureAlertViewButton;

	@FindBy(xpath = "//button[@id='closeButton']")
	private WebElementFacade FutureAlertCloseButton;

	@FindBy(xpath = "//span[.='Wage Rate Program']")
	private WebElementFacade FutureAlertWageRateProgramLabel;

	@FindBy(xpath = "//div[@class='vdl-row mdf-grid-row']//div[2]")
	private WebElementFacade FutureAlertCurrentPreviousRecord;
	@FindBy(xpath = "//div[@class='vdl-row mdf-grid-row']//div[3]")
	private WebElementFacade FutureAlertCurrentchangedRecord;

	@FindBy(xpath = "//div[@class='vdl-row mdf-grid-row']//div[4]//div[2]")
	private WebElementFacade FutureAlertFuturePreviousRecord;
	@FindBy(xpath = "//div[@class='vdl-row mdf-grid-row']//div[4]//div[3]")
	private WebElementFacade FutureAlertFuturechangedRecord;

	@FindBy(xpath = "//label[@for='selectedWageRates']")
	private WebElementFacade WageRateProgramLabel;

	@FindBy(xpath = "")
	private WebElementFacade OverridePayclassToggleClick;

	@FindBy(xpath = "")
	private WebElementFacade OverridePayclassToggleOn;

	@FindBy(xpath = "")
	private WebElementFacade OverridePayclassToggleOff;

	@FindBy(xpath = "//div[@name='selectedPayPremium']//div[@class='vdl-dropdown-list__input-container']")
	private WebElementFacade PayPremiumInput;

	@FindBy(xpath = "//label[@for='selectedPayPremium']")
	private WebElementFacade PayPremiumLabel;

	@FindBy(xpath = "//input[@id='badgeNumber']")
	private WebElementFacade BadgeNumberTextbox;

	@FindBy(xpath = "//li[contains(text(),'PST - Pacific Standard Time')]")
	private WebElementFacade TimeZoneInput;
	
	@FindBy(xpath = "//label[contains(.,'Time Zone')]/..//span[@class='vdl-dropdown-list__picker']")
	private WebElementFacade TimeZoneDropDown;
	
	

	@FindBy(xpath = "")
	private WebElementFacade TimeZoneLabel;

	@FindBy(xpath = "//button[@name='cancelButton']")
	private WebElementFacade CancelButton;

	@FindBy(xpath = "//button[@id='doneButton']")
	private WebElementFacade DoneButton;

	@FindBy(xpath = "")
	private WebElementFacade IncludeInTimeSummaryToggleOfF;

	@FindBy(xpath = "")
	private WebElementFacade IncludeInTimeSummaryToggleOn;

	@FindBy(xpath = "")
	private WebElementFacade IncludeInTimeSummaryToggleSelect;

	@FindBy(xpath = "//label[contains(text(),'To edit these fields, select an existing record or')]")
	private WebElementFacade ToEditFieldText;

	// Additional Links
	@FindBy(xpath = "//div[@class='tpilinks-headertext tlm-uppercase']")
	private WebElementFacade AdditionalLinkMoreFieldsLabel;

	@FindBy(xpath = "//span[contains(text(),'Additional Dates')]")
	private WebElementFacade AdditionalLinkAdditionalDate;

	@FindBy(xpath = "//span[contains(text(),'Other Rates')]")
	private WebElementFacade AdditionalLinkOtherRates;

	@FindBy(xpath = "//span[contains(text(),'Department - Job Rates')]")
	private WebElementFacade AdditionalLinkDeptJobRate;

	@FindBy(xpath = "//span[contains(text(),'Timeclocks')]")
	private WebElementFacade AdditionalLinkTimeClocks;

	@FindBy(xpath = "//span[contains(text(),'Mobile')]")
	private WebElementFacade AdditionalLinkMobile;

	@FindBy(xpath = "//span[contains(text(),'Notifications')]")
	private WebElementFacade AdditionalLinkNotifications;

	@FindBy(xpath = "//span[contains(text(),'Phone Access')]")
	private WebElementFacade AdditionalLinkPhoneAccess;

	@FindBy(xpath = "//span[contains(text(),'Time Cycle Access')]")
	private WebElementFacade AdditionalLinkTimeCycleAccess;

	@FindBy(xpath = "//a[@class='edit-audit-link']")
	private WebElementFacade ViewEditAuditLink;
	@FindBy(xpath = "//button[@class='vdl-slide-in-close vdl-button vdl-button--secondary']")
	private WebElementFacade EditAuditBackButton;
	

	@FindBy(xpath = "//div[@class='vdl-accordion-panel__body']")
	private WebElementFacade EditAuditBody;
	//body/div[@id='tlmConfigEditors_root']/div[@name='DailyCalculationPrograms']/div[@class='showcase']/div[@class='vdl-row responsiveByClases-border']/div[@class='router__page-container']/div[@class='router__content']/div/div[@name='employeeEditAudit']/div/div[1]

	@FindBy(xpath = "//span[text()='View Pay Class Summary']")
	private WebElementFacade ViewPayClassSummaryLink;
	
	@FindBy(xpath = "//div[@id='effDatingHistory_root']")
	private WebElementFacade EffectiveDatingHistoryBody;
	
	
	
	
	
	

	@FindBy(xpath = "//div[@class='react-autosuggest__container']//input")
	private WebElementFacade ClickSupervisorTextbox;

	@FindBy(xpath = "//div[@id='PayclassSummaryView.PayclassCycleDateRange.wrapper']")
	private WebElementFacade PayClassSummaryDateRange;
	@FindBy(xpath = "//a[@id='HolidayListLink']")
	private WebElementFacade HolidayLink;

	@FindBy(xpath = "//div[@id='HolidayTooltip']")
	private WebElementFacade HolidayToolTip;

	@FindBy(xpath = "//span[@class='vdl-button__container'][contains(text(),'Back')]")
	private WebElementFacade PayClassSummaryBackButton;

	/********** Additional Date link Slide in ***********/

	@FindBy(xpath = "//div[@class='tlm-action-row']//button[1]")
	private WebElementFacade AdditionalLinkSlideinAddButton;

	@FindBy(xpath = "//span[@class='fa fa-search-plus']")
	private WebElementFacade AdditionalDatesSearchIcon;

	@FindBy(xpath = "//div[@class='search-textbox']//input[@type='text']")
	private WebElementFacade AdditionalDatesSearchPopupTextBox;

	@FindBy(xpath = "//div[@class='vdl-row mdf-grid-row']//span[.='Test']")
	private WebElementFacade SelectAdditionalDate;

	@FindBy(xpath = "//div[@class='vdl-row mdf-grid-row']//span[.='001000']")
	private WebElementFacade SelectDept;

	@FindBy(xpath = "//div[@class='vdl-row mdf-grid-row']//span[.='Developer']")
	private WebElementFacade SelectJob;

	@FindBy(xpath = "//input[contains(@value,'Test')]")
	private WebElementFacade AdditionalDateSelectTextBox;

	@FindBy(xpath = "//input[@placeholder='mm/dd/yyyy']")
	private WebElementFacade AdditionalDateEnterDate;

	@FindBy(xpath = "//button[@class='vdl-button vdl-button--primary'][.='Done']")
	private WebElementFacade AdditionalDateDoneButton;

	@FindBy(xpath = "//div[@class='model-container  addedit-section']//button[.='Cancel']")
	private WebElementFacade AdditionalDateCancelButton;

	@FindBy(xpath = "//div[@class='vdl-col-xs mdf-grid-scroll-pane mdf-grid-window-scroll']//button//span[contains(.,'Test')]")
	private WebElementFacade AdditionalDateSelectOptionForEdit;

	@FindBy(xpath = "//div[@class='vdl-col-xs mdf-grid-scroll-pane mdf-grid-window-scroll']//button//span[contains(.,'Test')]/../../..//div[@class='vdl-col-xs mdf-grid-cell  column-2']")
	private WebElementFacade AdditionalDateGetEditedDate;

	@FindBy(xpath = "//div[@class='vdl-col-xs mdf-grid-cell  column-1'][contains(.,'Test')]/parent::div//div[@class='vdl-checkbox']/label")
	private WebElementFacade AdditionalDateCheckBox;

	@FindBy(xpath = "//div[contains(@class,'vdl-alert__content-container')]//div[contains(.,'Saved')]")
	private WebElementFacade SaveMessageAdditionalDate;

	@FindBy(xpath = "//div[@class='vdl-slide-in-mount']//button[2]")
	private WebElementFacade AdditionalLinkSlideinDeleteButton;

	@FindBy(xpath = "//div[@class='mdf-slide-in-body']//span[@class='vdl-button__container'][contains(text(),'Cancel')]")
	private WebElementFacade AdditionalLinkSlideinCancelButton;

	@FindBy(xpath = "//div[contains(@class,'tlmlookup-action-row')]//button[1]")
	private WebElementFacade AdditionalLinkPopUpCancelButton;

	// div[@class='model-container addedit-section']//button[.='Cancel']

	@FindBy(xpath = "//div[@class='vdl-slide-in-mount']//div[@role='combobox']/input[@type='text']")
	private WebElementFacade AdditionalDateSlideInAddAdditionalDates;

	@FindBy(xpath = "//input[@id='datepicker']")
	private WebElementFacade AdditionalDateSlideInAddingDate;

	@FindBy(xpath = "//div[@class='vdl-slide-in-body']//span[@class='fa fa-search-plus']")
	private WebElementFacade AdditionalDateSlideInlookup;

	@FindBy(xpath = "//div[@class='vdl-col-lg-12 action-row']//button[1]")
	private WebElementFacade AdditionalLinkDialogCancelButton;

	@FindBy(xpath = "//span[contains(text(),'Done')]")
	private WebElementFacade AdditionalLinkDialogDoneButton;

	/*********** Other Rates *******************/
	@FindBy(xpath = "//div[@class='vdl-slide-in-body']//div[@role='combobox']/input[@type='text']")
	private WebElementFacade OtherRatesDialogueTextBox;

	@FindBy(xpath = "//input[@id='rate-Amount-id']")
	private WebElementFacade OtherRateRateAmountTextBox;

	@FindBy(xpath = "//input[@id='datepicker']")
	private WebElementFacade OtherRateDialogueDatePicker;

	/************ Phone access ***************/

	@FindBy(xpath = "//input[@placeholder='Enter Phone ID']")
	private WebElementFacade PhoneIdTextBox;

	@FindBy(xpath = "//input[@placeholder='Enter Pin']")
	private WebElementFacade PhonePin1;

	@FindBy(xpath = "//input[@placeholder='Confirm Pin']")
	private WebElementFacade PhonePin2;

	@FindBy(xpath = "//div[@class='empphoneaccess-group-buttons']//span[@class='vdl-button__container'][contains(text(),'Cancel')]")
	private WebElementFacade PhoneAccessCancelButton;

	@FindBy(xpath = "//div[@class='vdl-slide-in-mount']//button[2]")
	private WebElementFacade PhoneAccessSaveButton;

	@FindBy(xpath = "//div[contains(text(),'Saved successfully')]")
	private WebElementFacade SideLinkSuccessMessage;

	/************ Dept-Job Look up *************/
	@FindBy(xpath = "//input[@placeholder='Enter Rate Amount']")
	private WebElementFacade DeptJobLinkDialogRateAmountTextBox;

	@FindBy(xpath = "//div[@class='tlmlookupbox-container model-container addedit-section']//span[@class='fa fa-search-plus']")
	private WebElementFacade DeptJobLinkDialogDepartmentLookup;

	@FindBy(xpath = "//div[@class='tlmlookupbox-container']//span[@class='fa fa-search-plus']")
	private WebElementFacade DeptJobLinkDialogJobLookup;

	@FindBy(xpath = "//div[@class='vdl-date-time-picker vdl-date-time-picker--lg dateTimePicker jobrate-date-effectiveDate ']//input")
	private WebElementFacade DeptJobLinkDialogDateTextBox;

	@FindBy(xpath = "//div[@class='empprofile-addedit-slidein fade in vdl-slide-in']//button[2]")

	private WebElementFacade DeptSearchIcon;
	@FindBy(xpath = "//div[@role='combobox']//input[@xpath='1']")

	private WebElementFacade JobSearchIcon;
	@FindBy(xpath = "//div[@role='combobox']//input[@xpath='2']")

	private WebElementFacade DeptJobLinkDialogSaveButton;

	/*********** Phone Id ***********************/

	@FindBy(xpath = "//input[@placeholder='Enter Phone ID']")
	private WebElementFacade PhoneAccessLinkEnterPhoneIdTextBox;

	@FindBy(xpath = "//input[@placeholder='Enter Pin']")
	private WebElementFacade PhoneAccessLinkEnterPinTextBox;

	@FindBy(xpath = "//input[@placeholder='Confirm Pin']")
	private WebElementFacade PhoneAccessLinkReEnterPinTextBox;

	@FindBy(xpath = "//div[@id='phoneAccessSlider']//button[1]")
	private WebElementFacade PhoneAccessSlideInCancelButton;

	@FindBy(xpath = "//div[@class='vdl-slide-in-mount']//button[2]")
	private WebElementFacade PhoneAccessSlideInSaveButton;

	// Temp
	@FindBy(xpath = "//button[contains(text(),'People')]")
	private WebElementFacade ClickPeople;

	@FindBy(xpath = "//div[@id='wfnnav_sub_People']//div[@class='wfnnav-sub-items']//button[.='Employment']")
	private WebElementFacade ClickEmployment;

	@FindBy(xpath = "//div[@class='wfnnav-ter-items']//button[.='Employment Profile']")
	private WebElementFacade ClickEmploymentProfileLink;

	/**************** History Page Xpaths ******************/

	@FindBy(xpath = "//a[contains(text(),'History')]")
	private WebElementFacade HistoryLink;

	@FindBy(xpath = "//button[@id='empProfileTimeAttendanceHistoryBtn']")
	private WebElementFacade EmploymentProfileTimeAndAttendanceHistoryButton;
	@FindBy(xpath = "//div[@class='vdl-slide-in-header']//button[@type='button']")
	private WebElementFacade HistoryPageBackButton;
	@FindBy(xpath = "//div[@class='vdl-modal-footer']//button[1]")
	private WebElementFacade HistoryDeletePopUpNoButton;
	@FindBy(xpath = "//div[@role='dialog']//button[2]")
	private WebElementFacade HistoryDeletePopUpYesButton;
	@FindBy(xpath = "//button[@class='vdl-button vdl-button--primary']/span[contains(.,'Yes')]")
	private WebElementFacade SlideInDeleteYesButton;

	@FindBy(xpath = "//div[contains(text(),'The record was deleted successfully.')]")
	private WebElementFacade HistoryRecordDeletionSuccessMessage;
	String DateSelectionOnSlideIn = "//div[@class='mdf-time-frame__dates']//div[@class='mdf-time-frame__point-label'][contains(.,'"
			+ date + "')]/..//div[@class='mdf-time-frame__timeline-point']";

	String DateSelectionOnSlideInDelete1 = "//div[@class='mdf-time-frame__dates']//div[@class='mdf-time-frame__point-label'][contains(.,'"
			+ date + "')]/..//div[@class='mdf-time-frame__timeline-point']";

	String DateSelectionOnSlideInDelete2 = "//div[@class='mdf-time-frame__point-label'][contains(.,'" + firstlastdate[4]
			+ "')]/../div";

	String DateAlreadySelected = "//div[@class='mdf-time-frame__date mdf-time-frame__date--point mdf-time-frame__date--selected']//div[contains(.,'"
			+ date + "')]";

	

	String HistoryusingTimeValue = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header column-1']";
	String HistorypayclassName = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header column-2']";
	String Historysupervisor = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header column-3']";
	String HistorysupervisorPosition = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header column-4']";
	String HistoryshiftRule = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header column-5']";
	String HistorywageRateProgram = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header column-6']";
	String HistoryoverRidePayClass = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header column-7']";
	String HistoryCalendarIcon = "//button[contains(.,'" + date
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header  column-8']/a[@class='action-calendar']";

	String HistoryDeleteIcon = "//button[contains(.,'" + firstlastdate[1]
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header  column-8']/a/i[@class='fa fa-trash']";
	String datelink = "//button[@class='vdl-button vdl-button--link'][contains(.,'" + date + "')]";
	String datelinkMaxdate = "//button[@class='vdl-button vdl-button--link'][contains(.,'" + firstlastdate[1] + "')]";
	String datelinkMindate = "//button[@class='vdl-button vdl-button--link'][contains(.,'" + firstlastdate[0] + "')]";
	String datelinkHiredate = "//button[@class='vdl-button vdl-button--link'][contains(.,'01/01/2011')]";
	String DateTimeLineCurrent = "//span[text()='01/01/2011 - " + firstlastdate[2] + " (Current)']";
	String Futurerecorddelete = "//button[@class='vdl-button vdl-button--link'][contains(.,'" + firstlastdate[4]
			+ "')]";
	
	//a[contains(text(),'c1dit')]

	String currentrecorddelete = "//button[contains(.,'" + firstlastdate[3]
			+ "')]/../..//div[@class='vdl-col-xs mdf-grid-cell history-header  column-8']/a/i[@class='fa fa-trash']";

	@FindBy(xpath = "//span[text()='03/31/2019 - Onward (Future)']")
	private WebElementFacade DateTimeLineFuture;

	// Error/Info messages

	@FindBy(xpath = "//div[@class='vdl-alert__content'][contains(.,'This change')]")
	private WebElementFacade InfoMessageOnEnteringDate;
	@FindBy(xpath = "//div[@class='mdf-validated-field ']//input")
	private WebElementFacade HistoryPageAddNewEffectiveDate;

	@FindBy(xpath = "//div[@class='vdl-row cancel-done-slider']//button[@name='doneButton'][@type='submit']")
	private WebElementFacade HistoryPageAddNewEffectiveDateDoneButton;

	@FindBy(xpath = "//div[@class='vdl-row cancel-done-slider']//button[@name='doneButton'][@type='button']")
	private WebElementFacade HistoryPageAddNewEffectiveCancelButton;

	@FindBy(xpath = "//div[contains(text(),'The record was edited successfully.')]")
	private WebElementFacade HistoryPageEditSuccessMessage;

	@FindBy(xpath = "//div[@class='vdl-alert__content'][contains(.,'You cannot')]")
	private WebElementFacade InfoMessageForPayClass;

	@FindBy(xpath = "//div[@class='MDFContentPane'][contains(.,'You cannot')]")
	private WebElementFacade ErrorMessageForPayClass;
	
	
	/******Additional links***********/

	// Convert Time to Non-Time
	@FindBy(xpath = "//div[.='Timeclocks Assigned']/../..//span[@class='tlm-cursor-pointer timeclocks-plus fa fa-plus-circle fa-2x']")
	private WebElementFacade TimeClocksAssignedPlusButton;

	@FindBy(xpath = "//div[.='Timeclocks Assigned']/../..//span[@class='tlm-cursor-pointer timeclocks-minus fa fa-minus-circle fa-2x']")
	private WebElementFacade TimeClocksAssignedMinusButton;

	@FindBy(xpath = "//div[.='Timeclocks Assigned']/../..//ul[@class='timeclocks-lbox vdl-list']/li")
	private WebElementFacade TimeClocksAssigned;

	@FindBy(xpath = "//div[.='Timeclocks Assigned']/../..//li[contains(@id,'option__0')]//div[@class='vdl-list-box__option__checkbox']")
	private WebElementFacade TimeClocksselectCheckbox;

	@FindBy(xpath = "//div[.='Timeclocks Assigned']/../..//ul")
	private WebElementFacade GetCountOfTimeClocks;

	@FindBy(xpath = "//div[.='Timeclock Groups Assigned']/../..//ul")
	private WebElementFacade GetCountOfTimeClocksAssigned;

	@FindBy(xpath = "//div[.='Timeclock Groups Assigned']/../..//span[@class='tlm-cursor-pointer timeclocks-plus fa fa-plus-circle fa-2x']")
	private WebElementFacade TimeClocksGroupAssignedPlusButton;

	@FindBy(xpath = "//div[.='Timeclock Groups Assigned']/../..//span[@class='tlm-cursor-pointer timeclocks-minus fa fa-minus-circle fa-2x']")
	private WebElementFacade TimeClocksGroupAssignedMinusButton;

	@FindBy(xpath = "//div[.='Timeclock Groups Assigned']/../..//ul[@class='timeclocks-lbox vdl-list']/li")
	private WebElementFacade TimeClocksGroupAssigned;

	@FindBy(xpath = "//div[.='Timeclock Groups Assigned']/../..//li[contains(@id,'option__0')]//div[@class='vdl-list-box__option__checkbox']")
	private WebElementFacade TimeClocksGroupCheckbox;

	@FindBy(xpath = "//div[@id='timeClocksSlider']//button[1]")
	private WebElementFacade TimeClocksCancelButton;

	@FindBy(xpath = "//div[@class='vdl-slide-in-mount']//button[2]")
	private WebElementFacade TimeClocksSaveButton;

	@FindBy(xpath = "//div[@class='tlmlookup-container']//div[@class='vdl-row mdf-grid-row'][@data-index='0']//div[@class='vdl-checkbox']/label")
	private WebElementFacade selectCheckbox;

	@FindBy(xpath = "//button[@class='tlm-show vdl-button vdl-button--primary']")
	private WebElementFacade selectbutton;

	// Mobile
	@FindBy(xpath = "//span[contains(@class,'plus fa fa-plus-circle fa-2x')]")
	
	private WebElementFacade SideLinkPlusButton;

	@FindBy(xpath = "//div[@class='vdl-checkbox']/label")
	private WebElementFacade SelectCheckboxFromPopUpOnSideLink;

	@FindBy(xpath = "//div[@class='tlmlookup-action-row']//button[2]")
	private WebElementFacade ClickSelectButton;

	@FindBy(xpath = "//span[contains(text(),'Save')]")
	private WebElementFacade SideLinkSaveButton;

	@FindBy(xpath = "//div[@class='vdl-list-box__option__checkbox']//*")
	private WebElementFacade MobileSelectLocation;

	@FindBy(xpath = "//span[@class='tlm-cursor-pointer mobile-minus fa fa-minus-circle fa-2x']")
	private WebElementFacade MobileSelectMinusButton;

	@FindBy(xpath = "//div[@id='mobileSlider']//button[1]")
	private WebElementFacade SideLinkCancelButton;

	@FindBy(xpath = "//span[@class='tlm-cursor-pointer empnotification-plus fa fa-plus-circle fa-2x']")
	private WebElementFacade NotificationsPlusButton;
	@FindBy(xpath = "//span[contains(@class,'minus fa fa-minus-circle fa-2x')]")
	private WebElementFacade SideLinkMinusButton;
	


	@FindBy(xpath = "//span[@class='tlm-cursor-pointer emptimecycle-plus fa fa-plus-circle fa-2x']")
	private WebElementFacade TimeCycleAccessPlusButton;
	@FindBy(xpath = "//span[@class='tlm-cursor-pointer emptimecycle-minus fa fa-minus-circle fa-2x']")
	private WebElementFacade TimeCycleAccessMinusButton;
	/*************Xpaths for changing client*****************/
	@FindBy(xpath = "//div[@id='adpUserInfo']//button[@id='adpUserGoBackToSupport']")
	private WebElementFacade GoBackToClientSetUpWizard;
	@FindBy(xpath = "//input[@id='searchBox']")
	private WebElementFacade EnterClientName;
	@FindBy(xpath = "//div[contains(@id, 'popup_')]/div[contains(@id, 'revit_TooltipDialog_')]//tr[1]/td/a/span")
	private WebElementFacade clientsearch;
	@FindBy(xpath = "//a[text()='Practitioner Access']")
	private WebElementFacade accessTypeLink;
	
	
	

	/****************
	 * Validate Info & Error messages on Main page
	 ************************/
	// Step 1
	public void ValidateInfoAndErrorMessageAndUpdatePayclass(String employeeName, String supervisorName) {
		String monthFirstDate = firstlastdate[0];
		String monthLastDate = firstlastdate[1];
		System.out.println(monthFirstDate);

		WaitForAjax();
		waitABit(3000);
		ClickTimeTileLinkAndValdiateSlideIn();

		ViewPayClassSummaryLink.click();
		WaitForAjax();
		waitABit(3000);
		String PayClassName = getPayClassValueFromPayClassSummary.getText();
		PayClassSummaryBackButton.click();
		System.out.println(PayClassName);
		WaitForAjax();
		waitABit(3000);
		//TimeAttendanceSlideInAddButton.click();
		WaitForAjax();
		//waitABit(5000);
		DateTextBox.sendKeys(date);
		System.out.println(date);
		waitABit(3000);
		ClearExistingPayClass.click();
		waitABit(3000);
		String datemessage = "This change takes effect in thecurrent Time pay period:" + monthFirstDate + " - "
				+ monthLastDate;
		System.out.println(datemessage);
		assert (InfoMessageOnEnteringDate.getText().contains(datemessage));

		WaitForAjax();
		PayclassTextBoxSearchIcon.click();
		waitABit(5000);
		SupervisorlookupSearchTextbox.sendKeys("SALARY");
		waitABit(3000);
		SelectSupervisorFromLookUp.click();
		waitABit(3000);
		ViewPayClassSummaryLink.click();
		WaitForAjax();
		waitABit(3000);

		String daterange = PayClassSummaryDateRange.getText();
		System.out.println(daterange);
		String currentPayCycleDate = daterange.substring(0, 10);
		String currentPayCycleEndDate = daterange.substring(13, 23);
		PayClassSummaryBackButton.click();
		WaitForAjax();

		String payclassMessage1 = "You cannot change the employee's Pay Class on this record. The employee is currently assigned to Pay Class "
				+ PayClassName + " with Current Pay Period Start Date of " + monthFirstDate + ".";
		String payclassMessage2 = "You must add a new record with the new Pay Class SALARY with an effective date equal to the Current Pay Period Start of "
				+ currentPayCycleDate + ".";
		String PayClassMessage = InfoMessageForPayClass.getText();
		assert (PayClassMessage.contains(payclassMessage1));
		assert (PayClassMessage.contains(payclassMessage2));
		DoneButton.click();
		waitABit(3000);
		assert (ErrorMessageForPayClass.getText().contains(payclassMessage1));
		assert (InfoMessageForPayClass.getText().contains(payclassMessage2));
		CancelButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(3000);
	//	TimeAttendanceSlideInAddButton.click();
		WaitForAjax();
		waitABit(5000);
		DateTextBox.click();
		DateTextBox.sendKeys(firstlastdate[4]);
		waitABit(1500);
		System.out.println(firstlastdate[4]);
		ClearExistingPayClass.click();
		waitABit(3000);
		ClickShiftRule.click();
		waitABit(1000);
		SelectShiftRule.click();
		DoneButton.click();
		WaitForAjax();
		waitABit(3000);

	}

	// Step2
	public void ValidateFuturePropogation() {

		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(3000);
		//TimeAttendanceSlideInAddButton.click();
		WaitForAjax();
		waitABit(5000);
		DateTextBox.click();
		DateTextBox.sendKeys(firstlastdate[3]);
		waitABit(1500);
		ClearExistingPayClass.click();
		waitABit(3000);
		ClickWageRate.click();
		waitABit(1000);
		SelectWageRateProgram.click();
		DoneButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (FutureDatedAlertPopUp.isDisplayed());
		FutureAlertViewButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (FutureAlertWageRateProgramLabel.isDisplayed());
		/******There is a defect for below code*****************/
		/*
		 * String currentprevious = FutureAlertCurrentPreviousRecord.getText(); String
		 * currentchanged = FutureAlertCurrentchangedRecord.getText(); String
		 * futureprevious = FutureAlertFuturePreviousRecord.getText(); String
		 * futurechanged = FutureAlertFuturechangedRecord.getText(); // assert
		 * (!currentprevious.contains(currentchanged)); // assert
		 * (!futureprevious.contains(futurechanged));
		 */
		FutureAlertCloseButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
	}

	// Step 3
	public void DeleteRecordOnSlideIn() {
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(3000);
		getDriver().findElement(By.xpath(DateSelectionOnSlideInDelete2)).click();
		DeleteRecordFromSlideIn();
		WaitForAjax();

	}

	public void DeleteRecordFromHistoryPage() {
		HistoryLink.click();
		WaitForAjax();
		waitABit(3000);
		getDriver().findElement(By.xpath(currentrecorddelete)).click();
		WaitForAjax();
		waitABit(3000);
		HistoryDeletePopUpYesButton.click();
		WaitForAjax();
		waitABit(10000);
		assert (HistoryRecordDeletionSuccessMessage.isDisplayed());
		HistoryPageBackButton.click();
		WaitForAjax();
		waitABit(3000);
		CancelButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
	}

	public void NavigateToEmploymentProfile(String employeeName) {
		NavigateToEmploymentProfilePage("prac");
		selectEmployee(employeeName);
	}

	/********** Validate Pay Class Summary ************/
	public void validatePayClassSummary() {
		ClickTimeTileLinkAndValdiateSlideIn();
		ViewPayClassSummaryLink.click();
		WaitForAjax();
		waitABit(3000);
		assert (PayClassSummaryDateRange.isDisplayed());
		String daterange = PayClassSummaryDateRange.getText();
		System.out.println(daterange);
		String currentPayCycleDate = daterange.substring(0, 10);
		System.out.println(currentPayCycleDate);
		if (HolidayLink.isDisplayed()) {
			HolidayLink.click();
			assert (HolidayToolTip.isDisplayed());
		}
		PayClassSummaryBackButton.click();
		WaitForAjax();
		waitABit(3000);
		CancelButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());

		// a[@id='HolidayListLink']
	}

	/********** Update date from History page **********/

	/**********************************/

	/********** This will navigate to Employment Profile Page *********/
	public void NavigateToEmploymentProfilePage(String userType) {

		String currentUrl = getDriver().getCurrentUrl();
		String url = null;
		switch (userType) {
		case "prac":
			String appendPracUrl = "#/People_ttd_PeopleTabEmploymentCategoryJobProfiles/PeopleTabEmploymentCategoryJobProfiles";
			url = currentUrl + appendPracUrl;
			break;

		case "sup":
			String appendSupUrl = "#/MyTeam_ttd_MyTeamTabEmploymentCategoryJobProfiles/MyTeamTabEmploymentCategoryJobProfiles";
			url = currentUrl + appendSupUrl;
			break;
		case "emp":
			String appendEmpUrl = "#/Myself_ttd_Profile/Profile";
			url = currentUrl + appendEmpUrl;
			break;
		}

		getDriver().get(url);
		getDriver().navigate().refresh();
	}

	/********** Select Employee from Employment Profile Page ****************/
	public void selectEmployee(String employeeName) {
		String selectEmployee = "//div[contains(text(),'" + employeeName + "')]";
		WaitForAjax();
		waitABit(10000);
		EmploymentProfileTimeAndAttendanceLink.waitUntilVisible();
		EmployeeSearch.click();
		WaitForAjax();
		WfnFilterDropDown.click();
		waitABit(3000);
		SelectActiveEmployees.click();
		waitABit(3000);
		InputEmployeeName.sendKeys(employeeName);
		WaitForAjax();
		getDriver().findElement(By.xpath(selectEmployee)).click();

	}

	/********** Click on Time tile and Validate Slide in **************/
	public void ClickTimeTileLinkAndValdiateSlideIn() {
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(5000);
		DateTextBox.waitUntilVisible();
		assert (DateTextBox.isVisible());
	}
	
	public void NonEffectiveDatingSelectTimeTile() {
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(5000);
	}

	public void ProdClientValidation() {
		NavigateToEmploymentProfilePage("prac");
	}
	
	
	/*********** Validate Time tile labels *******************/
	public void ValidateTimeTileForTimeEmployee(String employeeName) {
		NavigateToEmploymentProfilePage("prac");
		selectEmployee(employeeName);
		WaitForAjax();

		try {
			if (!EmploymentProfileTimeAndAttendanceLink.isVisible()) {
				String payclassvalue = EmploymentProfileTimeAndAttendancePayClassValue.getTextValue();
				String badgevalue = EmploymentProfileTimeAndAttendanceBadgeValue.getTextValue();
				String SupervisorPosition = EmploymentProfileTimeAndAttendanceSupervisorPositionBoolean.getTextValue();
				String PayrollSummary = EmploymentProfileTimeAndAttendanceIncludeInTimeSummaryValue.getTextValue();

				String[] timeTileLabels = { payclassvalue, badgevalue, SupervisorPosition, PayrollSummary };
				System.out.println(timeTileLabels[0]);

				String[] timeTilevalues = { "September 001", "000000026", "No", "Yes" };
				for (int i = 0; i < timeTileLabels.length; i++) {
					assert (timeTileLabels[i].equals(timeTilevalues[i]));
				}

				assert (EmploymentProfileTimeAndAttendanceHistoryButton.isCurrentlyVisible());

				ClickTimeTileLinkAndValdiateSlideIn();
				CancelButton.click();
				WaitForAjax();
				assert (EmploymentProfileTimeAndAttendanceLink.isCurrentlyVisible());
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void ValidateTimeTileForNonTime(String employeeName) {
		NavigateToEmploymentProfilePage("prac");
		selectEmployee(employeeName);
		/*if(NonTimePositionMessage.isVisible()) {
			assert(!EmploymentProfileTimeAndAttendancePayClassValue.isVisible());
			assert(!EmploymentProfileTimeAndAttendanceBadgeValue.isVisible());
			assert(!EmploymentProfileTimeAndAttendanceSupervisorPositionBoolean.isVisible());
			assert(!EmploymentProfileTimeAndAttendanceIncludeInTimeSummaryValue.isVisible());
		}*/
		WaitForAjax();
		waitABit(5000);
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(5000);
		
	}

	/******** Get current Date ***************/

	public void NavigateToTimeTileSlideIn() {

		EmploymentProfileTimeAndAttendanceLink.click();
		System.out.println(DateSelectionOnSlideIn);
		WaitForAjax();
		waitABit(5000);

	}

	public static String getCurrentDate() {

		String pattern = "MM/dd/YYYY";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		

		return date;
	}

	

	public static String[] GetFirstLastDatesOfMonth() {
		LocalDate now = LocalDate.now(); // 2015-11-23
		LocalDate maximum = now.with(TemporalAdjusters.lastDayOfMonth());
		LocalDate NextMonthFirstDate = now.with(TemporalAdjusters.firstDayOfNextMonth());
             	
		String mx = maximum.minusDays(0).toString();
		String nm = NextMonthFirstDate.minusDays(0).toString();
		String[] mx1 = mx.split("-");
		String[] nm1 = nm.split("-");
		String maxiumumDate = mx1[2];
		String nextMonth = nm1[2];
		String mxminusone = maximum.minusDays(1).toString();
		String mxminustwo = maximum.minusDays(2).toString();
		// String[] maxdate2 = maximum.split("-");
		String[] minmaxdates = date.split("/");
		String[] minmaxdates1 = mxminusone.split("-");
		String[] minmaxdates2 = mxminustwo.split("-");
		String[] nxmon = nm.split("-");
		String minimumMaximumDate[] = new String[5];

		String minimumdate = minmaxdates[0] + "/" + "01" + "/" + minmaxdates[2];
		String maximumdate = minmaxdates[0] + "/" + maxiumumDate + "/" + minmaxdates[2];
		String maxminusone = minmaxdates1[1] + "/" + minmaxdates1[2] + "/" + minmaxdates1[0];
		String maxminusTwo = minmaxdates2[1] + "/" + minmaxdates2[2] + "/" + minmaxdates2[0];
		String NextMonthDate = nxmon[1] + "/" + nxmon[2] + "/" + nxmon[0];
		minimumMaximumDate[0] = minimumdate;
		minimumMaximumDate[1] = maximumdate;
		minimumMaximumDate[2] = maxminusone;
		minimumMaximumDate[3] = maxminusTwo;
		minimumMaximumDate[4] = NextMonthDate;

		return minimumMaximumDate;
	}
	
	public static String[] GetNonEffectiveDates() {
		LocalDate now = LocalDate.now(); // 2015-11-23
		LocalDate maximum = now.with(TemporalAdjusters.lastDayOfMonth());
		LocalDate NextMonthFirstDate = now.with(TemporalAdjusters.firstDayOfNextMonth());
		String nm = NextMonthFirstDate.minusDays(0).toString();
		String[] nxmon = nm.split("-");
		String NonEdMinMaxDate[] = new String[2];
		String mxminusone = maximum.minusMonths(2).toString();
		String currentMinusOne = maximum.minusDays(1).toString();
		NonEdMinMaxDate[0]=mxminusone;
		NonEdMinMaxDate[1]=currentMinusOne;

		
		return NonEdMinMaxDate;
		
	}
	
	

	/************ Convert Non Time to Time ****************/
	public void NonTimeToTimeusingAddButton(String supervisorName) throws Exception {
			if (NonTimePositionMessage.isVisible()) {
				ClickTimeTileLinkAndValdiateSlideIn();
				waitABit(5000);
				//TimeAttendanceSlideInAddButton.click();
				waitABit(5000);
				DateTextBox.sendKeys(date);
				waitABit(3000);
				ClearExistingPayClass.click();
				waitABit(3000);
				PayclassTextBoxSearchIcon.click();
				waitABit(5000);
				SupervisorlookupSearchTextbox.sendKeys("SALARY");
				waitABit(3000);
				WaitForAjax();
				SelectSupervisorFromLookUp.click();
				waitABit(3000);

				InputSupervisorValue.clear();

				TurnSupervisorToggleOnOff.click();
				waitABit(2000);
				SupervisorSearchIcon.click();
				waitABit(2000);
				SupervisorlookupSearchTextbox.sendKeys(supervisorName);
				waitABit(3000);
				SelectSupervisorFromLookUp.click();
				waitABit(3000);

				BadgeNumberTextbox.clear();
				BadgeNumberTextbox.sendKeys("R2001");
				waitABit(2000);
				TimeZoneDropDown.click();
				waitABit(2000);
				TimeZoneInput.click();
				
					if (NonTimeToggleOff.isVisible()) {
						SwitchTimeToggleOnOff.click();
					}
				
				}
				// TimeZoneInput.sendKeys("PST");
			
			
				DoneButton.click();
				WaitForAjax();
				waitABit(10000);

				String badgevalue = EmploymentProfileTimeAndAttendanceBadgeValue.getTextValue();
				// String supervisorvalue =
				// EmploymentProfileTimeAndAttendanceSupervisorValue.getTextValue();
				String SupervisorPosition = EmploymentProfileTimeAndAttendanceSupervisorPositionBoolean.getTextValue();
				String PayrollSummary = EmploymentProfileTimeAndAttendanceIncludeInTimeSummaryValue.getTextValue();
				String payclassvalue = EmploymentProfileTimeAndAttendancePayClassValue.getTextValue();
				System.out.println(payclassvalue);
				String[] timeTileLabels = {badgevalue, SupervisorPosition, PayrollSummary };
				String[] timeTilevalues = {"R2001", "Yes", "Yes" };
				waitABit(3000);
				for (int i = 0; i < timeTileLabels.length; i++) {
					assert (timeTileLabels[i].equals(timeTilevalues[i]));
					// System.out.println(timeTileLabels[i]);
					System.out.println(timeTileLabels[i]);
					waitABit(1000);

				}
			

		
		
		/*
		 * ValidateOnHistoryPage(); TimeToNonTimeusingAddButton();
		 * EditDateOnHistoryPage(); ValidateTimeLineAndDeleteRecordFromHistoryPage(); //
		 * NavigateToEmploymentProfilePage("sup"); //
		 * NavigateToEmploymentProfilePage("emp"); // validateAdditionalDates();
		 * TimeClocks(); phoneaccess(); validateOtherRates();
		 */

	}

	/********* Validate on History Page **********/

	public void ValidateOnHistoryPage() throws Exception {
		waitABit(5000);

		EmploymentProfileTimeAndAttendanceHistoryButton.click();
		WaitForAjax();
		waitABit(5000);
		
			if (getDriver().findElement(By.xpath(datelink)).isDisplayed()) {
				String IsUsingTimeText = getDriver().findElement(By.xpath(HistoryusingTimeValue)).getText();
				String payclassnameHistoryPage = getDriver().findElement(By.xpath(HistorypayclassName)).getText();
				String supervisorPositionHistoryPage = getDriver().findElement(By.xpath(HistorysupervisorPosition))
						.getText();
				String overRidePayClassHistoryPage = getDriver().findElement(By.xpath(HistoryoverRidePayClass))
						.getText();
				String[] HistoryLabels = { IsUsingTimeText, supervisorPositionHistoryPage,
						overRidePayClassHistoryPage };
				String[] HistoryValues = { "YES", "YES", "NO" };
				waitABit(3000);
				for (int i = 0; i < HistoryLabels.length; i++) {
					assert (HistoryLabels[i].equals(HistoryValues[i]));
				}

				HistoryPageBackButton.click();
				WaitForAjax();
				waitABit(5000);
				assert (EmploymentProfileTimeAndAttendanceLink.isVisible());
				EmploymentProfileTimeAndAttendanceLink.click();
				WaitForAjax();
				waitABit(5000);
				HistoryLink.click();
				WaitForAjax();
				waitABit(5000);
				getDriver().findElement(By.xpath(datelink)).isDisplayed();
				getDriver().findElement(By.xpath(datelink)).click();
				WaitForAjax();
				waitABit(5000);
				CancelButton.click();
				WaitForAjax();
				waitABit(5000);
				assert (EmploymentProfileTimeAndAttendanceLink.isVisible());

			}
	}

	/************* Deleting record from History page *************/
	public void ValidateTimeLineAndDeleteRecordFromHistoryPage() {
		getDriver().findElement(By.xpath(datelinkMaxdate)).click();
		WaitForAjax();
		waitABit(1500);
		assert (DateTimeLineFuture.isDisplayed());
		HistoryLink.click();
		WaitForAjax();
		waitABit(1500);
		getDriver().findElement(By.xpath(datelinkHiredate)).click();
		WaitForAjax();
		waitABit(1500);
		assert (getDriver().findElement(By.xpath(DateTimeLineCurrent)).isDisplayed());
		HistoryLink.click();
		WaitForAjax();
		waitABit(3000);
		getDriver().findElement(By.xpath(HistoryDeleteIcon)).click();
		waitABit(3000);
		HistoryDeletePopUpNoButton.click();
		waitABit(3000);
		getDriver().findElement(By.xpath(HistoryDeleteIcon)).click();
		waitABit(3000);
		HistoryDeletePopUpYesButton.click();
		WaitForAjax();
		waitABit(10000);
		assert (HistoryRecordDeletionSuccessMessage.isDisplayed());
		HistoryPageBackButton.click();
		WaitForAjax();
		waitABit(3000);
		CancelButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
		EmploymentProfileTimeAndAttendanceHistoryButton.click();

	}

	public void deleteRecord() {

		String[] paths = { Futurerecorddelete, currentrecorddelete };

		for (int i = 0; i < paths.length; i++) {
			EmploymentProfileTimeAndAttendanceHistoryButton.click();
			WaitForAjax();
			waitABit(3000);
			getDriver().findElement(By.xpath(paths[i])).click();
			waitABit(3000);
			HistoryDeletePopUpYesButton.click();
			WaitForAjax();
			waitABit(10000);
			assert (HistoryRecordDeletionSuccessMessage.isDisplayed());
		}

		HistoryPageBackButton.click();
		WaitForAjax();
		waitABit(10000);

	}

	/**************
	 * Edit Record from History Page
	 * 
	 * @throws Exception
	 ************/

	public void NavigateToHistoryPageFromTimeTile() {
		EmploymentProfileTimeAndAttendanceHistoryButton.click();
		WaitForAjax();
		waitABit(3000);
	}

	public void EditDateOnHistoryPage() throws Exception {
		getDriver().findElement(By.xpath(HistoryCalendarIcon)).click();
		HistoryPageAddNewEffectiveDate.clear();
		WaitForAjax();
		waitABit(5000);
		HistoryPageAddNewEffectiveDate.click();
		HistoryPageAddNewEffectiveDate.sendKeys(firstlastdate[1]);
		HistoryPageAddNewEffectiveDateDoneButton.click();
		WaitForAjax();
		waitABit(3000);
		try {
			assert (HistoryPageEditSuccessMessage.isDisplayed());
		} catch (Exception ex) {
			HistoryPageAddNewEffectiveCancelButton.click();
			WaitForAjax();
			HistoryPageBackButton.click();
			WaitForAjax();
			throw new Exception("History page edit effective date failed", ex);
		}

	}

	public void DeleteRecord() {

	}

	/************ Delete Record from Practitioner Main Page *************/
	public void DeleteRecordFromSlideIn() {
		// Code for record selection
		TimeAttendanceSlideDeleteRecordButton.click();
		WaitForAjax();
		// HistoryDeletePopUpNoButton.click();
		waitABit(3000);
		SlideInDeleteYesButton.click();
		WaitForAjax();
		waitABit(7000);

	}

	/************* Practitioner read only **************/

	public void PractitionerReadOnlyModeValidations() {
		NavigateToEmploymentProfilePage("prac");
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(10000);
		assert (!DateTextBox.isDisplayed());
		assert (!TimeAttendanceSlideDeleteRecordButton.isDisplayed());
		/******* Code for side links ************/

	}

	/********************** End Practitioner read only mode *************/

	/********* Manager only Validations ***************/
	public void ManagerOnlyValidation(String employeeName) {
		NavigateToEmploymentProfilePage("sup");
		selectEmployee(employeeName);
		int NumberOfTiles = TileCount.size();
		assert (NumberOfTiles > 1);
		assert (!EmploymentProfileTimeAndAttendanceLink.isDisplayed());

	}

	/********* End Manager only Validations ***************/

	/********* Supervisor only Validations ***************/
	public void SupervisorOnlyValidation() {
		NavigateToEmploymentProfilePage("sup");
		int NumberOfTiles = TileCount.size();
		assert (NumberOfTiles == 1);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(10000);
		assert (SupervisorTimeTileContent.isDisplayed());
		assert (EmpLcfContainer.isDisplayed());
		employeeSlideInCancelButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
	}

	/********* End Supervisor only Validations **************/

	/********* Superman only Validations ***************/
	public void SupermanValidation(String employeeName, String employeeName2) {
		NavigateToEmploymentProfilePage("sup");
		selectEmployee(employeeName);
		int NumberOfTiles = TileCount.size();
		assert (NumberOfTiles > 1);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(10000);
		assert (SupervisorTimeTileContent.isDisplayed());
		assert (EmpLcfContainer.isDisplayed());
		// Employee 2 only reports to supervisor but with different supervisor so
		// supervisor shouldn't see time tile for him
		selectEmployee(employeeName2);
		int NumberOfTiles2 = TileCount.size();
		assert (NumberOfTiles2 == 1);
		assert (!EmploymentProfileTimeAndAttendanceLink.isDisplayed());
	}

	public void SupermanAsSupervisor(String employee) {
		selectEmployee(employee);
		int NumberOfTiles = TileCount.size();
		assert (NumberOfTiles > 1);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(10000);
		assert (SupervisorTimeTileContent.isDisplayed());
		assert (EmpLcfContainer.isDisplayed());
		assert (!EmploymentProfileTimeAndAttendanceLink.isDisplayed());
	}

	/********* End Superman only Validations **************/

	/********* Employee only Validations ***************/
	public void EmployeeValidation() {
		NavigateToEmploymentProfilePage("emp");
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(10000);
		assert (SupervisorTimeTileContent.isDisplayed());
		assert (EmpLcfContainer.isDisplayed());
		employeeSlideInCancelButton.click();
		WaitForAjax();
		waitABit(3000);
		assert (EmploymentProfileTimeAndAttendanceLink.isDisplayed());
	}

	/*********
	 * End Employee only Validations
	 * 
	 * @throws Exception
	 **************/


	// Additional Links

	public void validateDeptJobRates() throws Exception {
		try {
			if (AdditionalLinkDeptJobRate.isEnabled()) {
		AdditionalLinkDeptJobRate.click();
		WaitForAjax();
		waitABit(1000);
		AdditionalLinkSlideinAddButton.click();
		DeptSearchIcon.click();
		WaitForAjax();
		waitABit(1000);

		AdditionalDatesSearchPopupTextBox.sendKeys("001000");
		SelectDept.click();
		JobSearchIcon.click();
		WaitForAjax();
		waitABit(1000);

		AdditionalDatesSearchPopupTextBox.sendKeys("Developer");
		SelectJob.click();
		DeptJobLinkDialogRateAmountTextBox.sendKeys("100");
		DeptJobLinkDialogDateTextBox.sendKeys(date);
		AdditionalDateDoneButton.click();
		WaitForAjax();
		waitABit(1000);
			}}catch (Exception ex) {
				throw new Exception(
						"Dept Job Rates Option with xpath : "+AdditionalLinkDeptJobRate + " is not present please check data and try again ",
						ex);
			}
			

	}

	public void validateAdditionalDates() throws Exception {
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(1000);
		AdditionalLinkAdditionalDate.click();
		WaitForAjax();
		waitABit(1000);
		try {
			if (AdditionalLinkSlideinAddButton.isEnabled()) {

				AdditionalLinkSlideinAddButton.click();
				WaitForAjax();

				AdditionalDatesSearchIcon.click();
				waitABit(1500);
				AdditionalDatesSearchPopupTextBox.sendKeys("Test");
				try {
					if (SelectAdditionalDate.isVisible()) {
						SelectAdditionalDate.click();
						waitABit(1500);
						AdditionalDateEnterDate.sendKeys("21/21/2019");
						AdditionalDateSelectTextBox.click();
						assert (!AdditionalDateDoneButton.isEnabled());
						AdditionalDateEnterDate.clear();
						waitABit(1500);
						AdditionalDateEnterDate.sendKeys(date);
						AdditionalDateSelectTextBox.click();
						waitABit(1000);
						AdditionalDateDoneButton.click();
						waitABit(1000);
						AdditionalDateSelectOptionForEdit.click();

						waitABit(1000);

						AdditionalDateEnterDate.clear();
						AdditionalDateEnterDate.sendKeys(firstlastdate[1]);
						waitABit(1000);
						AdditionalDateDoneButton.click();
						WaitForAjax();
						waitABit(2000);
						String editedDate = AdditionalDateGetEditedDate.getText();
						assert (editedDate.contains(firstlastdate[1]));
						WaitForAjax();
						waitABit(2000);
						AdditionalDateCheckBox.click();
						AdditionalLinkSlideinDeleteButton.click();
						assert (SaveMessageAdditionalDate.isDisplayed());
						AdditionalLinkSlideinCancelButton.click();
					}
				} catch (Exception ex) {
					AdditionalLinkPopUpCancelButton.click();
					waitABit(1000);
					AdditionalDateCancelButton.click();
					waitABit(1000);
					AdditionalLinkSlideinCancelButton.click();
					waitABit(1000);
					CancelButton.click();
					waitABit(1000);
					throw new Exception(
							SelectAdditionalDate + "Selected Option is not present please check data and try again ",
							ex);
				}
			}
		} catch (Exception e) {
			AdditionalLinkSlideinCancelButton.click();
			waitABit(1000);
			CancelButton.click();
			waitABit(1000);
			throw new Exception(AdditionalLinkSlideinAddButton + "Additional link slide in add button is not enabled ",
					e);
		}

	}

	public void validateOtherRates() throws Exception {

		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(1000);
		AdditionalLinkOtherRates.click();
		WaitForAjax();
		waitABit(1000);
		try {
			if (AdditionalLinkSlideinAddButton.isEnabled()) {

				AdditionalLinkSlideinAddButton.click();
				WaitForAjax();
				waitABit(1000);
				AdditionalDatesSearchIcon.click();
				waitABit(1500);
				AdditionalDatesSearchPopupTextBox.sendKeys("Test");
				waitABit(1000);
				try {
					if (SelectAdditionalDate.isVisible()) {
						SelectAdditionalDate.click();
						waitABit(1500);
						OtherRateRateAmountTextBox.sendKeys(":LJDHFDOSUFSDLJF");

						AdditionalDateEnterDate.sendKeys(date);
						OtherRateRateAmountTextBox.click();
						waitABit(1500);
						assert (!AdditionalDateDoneButton.isEnabled());
						OtherRateRateAmountTextBox.clear();
						OtherRateRateAmountTextBox.sendKeys("5+5+45+5");
						assert (!AdditionalDateDoneButton.isEnabled());
						OtherRateRateAmountTextBox.clear();
						OtherRateRateAmountTextBox.sendKeys("100");
						waitABit(1500);
						AdditionalDateEnterDate.click();
						waitABit(1000);
						AdditionalDateDoneButton.click();
						WaitForAjax();
						waitABit(1000);
						AdditionalDateSelectOptionForEdit.click();
						waitABit(1000);
						assert (!AdditionalDateEnterDate.isEnabled());
						OtherRateRateAmountTextBox.clear();
						OtherRateRateAmountTextBox.sendKeys("200");

						AdditionalDateDoneButton.click();
						WaitForAjax();
						waitABit(1000);
						String editedDate = AdditionalDateGetEditedDate.getText();
						assert (editedDate.contains("200"));
						AdditionalDateCheckBox.click();
						AdditionalLinkSlideinDeleteButton.click();
						WaitForAjax();
						waitABit(1000);
						assert (SaveMessageAdditionalDate.isDisplayed());
						AdditionalLinkSlideinCancelButton.click();
					}
				} catch (Exception ex) {
					AdditionalLinkPopUpCancelButton.click();
					waitABit(1000);
					AdditionalDateCancelButton.click();
					waitABit(1000);
					AdditionalLinkSlideinCancelButton.click();
					waitABit(1000);
					CancelButton.click();
					waitABit(1000);

					throw new Exception(
							SelectAdditionalDate + "Selected Option is not present please check data and try again ",
							ex);
				}
			}
		} catch (Exception e) {
			AdditionalLinkSlideinCancelButton.click();
			waitABit(1000);
			CancelButton.click();
			waitABit(1000);
			throw new Exception(AdditionalLinkSlideinAddButton + "Additional link slide in add button is not enabled ",
					e);
		}

	}

	public void phoneaccess() throws Exception {
		WaitForAjax();
		try {
			if(EmploymentProfileTimeAndAttendanceLink.isDisplayed())
		
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(1000);
		AdditionalLinkPhoneAccess.click();
		WaitForAjax();
		waitABit(1000);
		PhoneIdTextBox.sendKeys("5432");
		PhonePin1.sendKeys("1234");
		PhonePin2.sendKeys("1234");
		PhoneAccessSaveButton.click();
		assert (SideLinkSuccessMessage.isDisplayed());
		PhoneIdTextBox.clear();
		PhoneAccessSaveButton.click();
		assert (SideLinkSuccessMessage.isDisplayed());
		PhoneAccessCancelButton.click();
		}
		catch (Exception e) {
			throw new Exception("Phone Access Link with xpath : " + EmploymentProfileTimeAndAttendanceLink + "is not displayed  ",
					e);
		}
	}


	public void ValidateMobile(String locationName) throws Exception {
		try {
			if(AdditionalLinkMobile.isDisplayed()) {
		
		AdditionalLinkMobile.click();
		WaitForAjax();
		waitABit(1000);
		SideLinkPlusButton.click();
		waitABit(2000);
		SupervisorlookupSearchTextbox.sendKeys(locationName);
		waitABit(2000);
		SelectCheckboxFromPopUpOnSideLink.click();
		waitABit(2000);
		ClickSelectButton.click();
		waitABit(2000);
		SideLinkSaveButton.click();
		WaitForAjax();
		waitABit(1000);
		assert (SideLinkSuccessMessage.isDisplayed());
		MobileSelectLocation.click();
		SideLinkMinusButton.click();
		SideLinkSaveButton.click();
		WaitForAjax();
		waitABit(1000);
		assert (SideLinkSuccessMessage.isDisplayed());
		SideLinkCancelButton.click();
		WaitForAjax();
		waitABit(1000);
			}}catch (Exception e) {
				throw new Exception("Mobile Access Link with xpath : " + AdditionalLinkMobile + "is not displayed  ",
						e);
			}
				
			

	}

	public void Notifications(String SupervisorName) throws Exception {
		try {
			if(AdditionalLinkNotifications.isDisplayed())
		
		AdditionalLinkNotifications.click();
		WaitForAjax();
		waitABit(1000);
		SideLinkPlusButton.click();
		waitABit(1000);
		SupervisorlookupSearchTextbox.sendKeys(SupervisorName);
		waitABit(1000);
		SelectCheckboxFromPopUpOnSideLink.click();
		waitABit(2000);
		ClickSelectButton.click();
		waitABit(2000);
		SideLinkSaveButton.click();
		WaitForAjax();
		waitABit(1000);
		assert (SideLinkSuccessMessage.isDisplayed());
		MobileSelectLocation.click();
		waitABit(2000);
		SideLinkMinusButton.click();
		waitABit(2000);
		SideLinkSaveButton.click();
		WaitForAjax();
		waitABit(1000);
		assert (SideLinkSuccessMessage.isDisplayed());
		waitABit(2000);
		SideLinkCancelButton.click();
		WaitForAjax();
		waitABit(1000);
		}catch (Exception e) {
			throw new Exception("Notification Access Link with xpath : " + AdditionalLinkNotifications + "is not displayed  ",
					e);
		}
	}

	public void TimeCycleAccess(String PayCycleName) throws Exception {
		try {
			if(AdditionalLinkTimeCycleAccess.isDisplayed()) {
		AdditionalLinkTimeCycleAccess.click();
		WaitForAjax();
		waitABit(1000);
		SideLinkPlusButton.click();
		SupervisorlookupSearchTextbox.sendKeys(PayCycleName);
		SelectCheckboxFromPopUpOnSideLink.click();
		waitABit(2000);
		ClickSelectButton.click();
		waitABit(2000);
		SideLinkSaveButton.click();
		WaitForAjax();
		waitABit(1000);
		assert (SideLinkSuccessMessage.isDisplayed());
		MobileSelectLocation.click();
		waitABit(1000);
		SideLinkMinusButton.click();
		SideLinkSaveButton.click();
		WaitForAjax();
		waitABit(1000);
		assert (SideLinkSuccessMessage.isDisplayed());
		SideLinkCancelButton.click();
		WaitForAjax();
		waitABit(1000);
			}}catch (Exception e) {
				throw new Exception("Time Cycle  Access Link with xpath : " + AdditionalLinkTimeCycleAccess + "is not displayed  ",
						e);
			}

	}

	public void TimeClocks() throws Exception {
		
		EmploymentProfileTimeAndAttendanceLink.click();
		WaitForAjax();
		waitABit(1000);
		AdditionalLinkTimeClocks.click();
		WaitForAjax();
		waitABit(1000);
		try {
			if(TimeClocksAssignedPlusButton.isDisplayed()) {
		TimeClocksAssignedPlusButton.click();
		selectCheckbox.click();
		selectbutton.click();
		TimeClocksGroupAssignedPlusButton.click();
		selectCheckbox.click();
		selectbutton.click();
		TimeClocksSaveButton.click();
		TimeClocksselectCheckbox.click();
		TimeClocksAssignedMinusButton.click();
		TimeClocksGroupCheckbox.click();
		TimeClocksGroupAssignedMinusButton.click();
		TimeClocksSaveButton.click();
			}}catch (Exception e) {
				throw new Exception("Time Clocks  Access Link with xpath : " + TimeClocksAssignedPlusButton + "is not displayed  ",
						e);
			}

	}

	/************** Convert Time to NonTime ***************/
	public void TimeToNonTimeusingAddButton() {

		System.out.println(DateSelectionOnSlideIn);
		if (!getDriver().findElement(By.xpath(DateAlreadySelected)).isDisplayed()) {
			getDriver().findElement(By.xpath(DateSelectionOnSlideIn)).click();
		}
		System.out.println(DateSelectionOnSlideIn);
		waitABit(3000);

		//TimeAttendanceSlideInAddButton.click();
		waitABit(5000);
		DateTextBox.sendKeys(date);
		waitABit(3000);
		ClearExistingPayClass.click();
		waitABit(3000);
		SwitchTimeToggleOnOff.click();
		waitABit(5000);
		SupervisorToggle.click();
		// TurnSupervisorToggleOnOff.click();
		waitABit(2000);
		DoneButton.click();
		WaitForAjax();
		waitABit(10000);
		// String IsUsingTimeText =
		// getDriver().findElement(By.xpath(HistoryusingTimeValue)).getText();
		assert (NonTimePositionMessage.isDisplayed());
	}

	/************** Add Effective Dated Record ***************/

	public void AddMultipleRecords(String effdt) throws Exception {
		WaitForAjax();
		waitABit(10000);
		EmploymentProfileTimeAndAttendanceLink.waitUntilVisible();

		try {
			if (EmploymentProfileTimeAndAttendanceLink.isVisible()) {

				EmploymentProfileTimeAndAttendanceLink.click();
				WaitForAjax();
				waitABit(5000);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		try {
			if (DateTextBox.isVisible()) {

				//TimeAttendanceSlideInAddButton.click();
				waitABit(5000);
				DateTextBox.sendKeys("1/1/2019");
				waitABit(5000);
				if (NonTimeToggleOff.isCurrentlyVisible()) {
					SwitchTimeToggleOnOff.click();
				}
				ClearExistingPayClass.click();
				InputPayClassValue.sendKeys("salary");
				waitABit(5000);
				ClearExistingSupervisor.click();
				waitABit(5000);
				InputSupervisorValue.sendKeys("Lynn, Shaun - ID1000998");
				BadgeNumberTextbox.sendKeys("2001");
				waitABit(2000);
				TimeZoneDropDown.click();
				waitABit(2000);
				TimeZoneInput.click();
				DoneButton.click();
				WaitForAjax();
				waitABit(5000);
				assert (EmploymentProfileTimeAndAttendanceLink.isVisible());

			}
		} catch (Exception e) {
			if (!EmploymentProfileTimeAndAttendanceLink.isVisible()) {
				String ErrorMessage = ErrorMessageText.getText();
				throw new Exception("Add operation failed: " + ErrorMessage, e);
			}
		}
	}
	
	/**************Non Effective Dating Cases*********************/
	@FindBy(xpath = "//input[@name='ezlmActiveDate']")
	private WebElementFacade NEDStartDateTextBox;
	
	@FindBy(xpath = "//input[@name='ezlmActiveDate']/..//button")
	private WebElementFacade NEDStartDateCalendar;
	
	@FindBy(xpath = "//input[@name='ezlmInactiveDate']/..//button")
	private WebElementFacade NEDStopDateCalendar;
	
	
	
	@FindBy(xpath = "//input[@name='ezlmInactiveDate']")
	private WebElementFacade NEDEndDateTextBox;
	
	//span[contains(.,'Include in Time Summary')]/parent::div//div[@class='vdl-toggle-switch__slide']

	@FindBy(xpath = "//span[contains(.,'Include in Time Summary')]/parent::div//div[@class='vdl-toggle-switch__slide']")
	private WebElementFacade IncludeInTimeSummaryToggleButton;
	
	public void NonEdConvertNonTimeToTime(String supervisorName) {
		NEDStartDateCalendar.click();
		waitABit(1500);
		NEDStartDateTextBox.sendKeys(date);
		waitABit(3000);
		NEDStopDateCalendar.click();
		waitABit(1500);
		NEDEndDateTextBox.sendKeys(firstlastdate[3]);
		waitABit(3000);
		ClearExistingPayClass.click();
		waitABit(3000);
		PayclassTextBoxSearchIcon.click();
		waitABit(5000);
		SupervisorlookupSearchTextbox.sendKeys("SALARY");
		waitABit(3000);
		WaitForAjax();
		SelectSupervisorFromLookUp.click();
		waitABit(3000);

		InputSupervisorValue.clear();

		TurnSupervisorToggleOnOff.click();
		waitABit(2000);
		SupervisorSearchIcon.click();
		waitABit(2000);
		SupervisorlookupSearchTextbox.sendKeys(supervisorName);
		waitABit(3000);
		SelectSupervisorFromLookUp.click();
		waitABit(3000);

		BadgeNumberTextbox.clear();
		BadgeNumberTextbox.sendKeys("R02001");
		TimeZoneInput.sendKeys("PST");
			if (NonTimeToggleOff.isVisible()) {
				SwitchTimeToggleOnOff.click();
			}	
		// TimeZoneInput.sendKeys("PST");
		DoneButton.click();
		WaitForAjax();
		waitABit(10000);

}
	
	public void convertTimeToNonTime() {
		
		waitABit(5000);
		DateTextBox.sendKeys(nonEffectivDates[1]);
		waitABit(3000);
		TurnSupervisorToggleOnOff.click();
		waitABit(2000);
		DoneButton.click();
		WaitForAjax();
		waitABit(10000);
		// String IsUsingTimeText =
		// getDriver().findElement(By.xpath(HistoryusingTimeValue)).getText();
		assert (NonTimePositionMessage.isDisplayed());
		
		DateTextBox.sendKeys("");
		waitABit(2000);
		DoneButton.click();
		WaitForAjax();
		waitABit(10000);
	
	}
	
	public void convertEmployeeToSupervisor() {
	NonEffectiveDatingSelectTimeTile();
	
	TurnSupervisorToggleOnOff.click();
	waitABit(2000);
	DoneButton.click();
	WaitForAjax();
	waitABit(10000);
	assert(EmploymentProfileTimeAndAttendanceLink.isVisible());
			
	}
	
    public void convertSupervisorToEmployee() {
    	
    	TurnSupervisorToggleOnOff.click();
    	waitABit(2000);
    	DoneButton.click();
    	WaitForAjax();
    	waitABit(10000);
    	assert(EmploymentProfileTimeAndAttendanceLink.isVisible());
	}
    
    
    public void EditSupervisor(String supervisorName) {
    	NonEffectiveDatingSelectTimeTile();
    	
    	SupervisorSearchIcon.click();
		waitABit(2000);
		SupervisorlookupSearchTextbox.sendKeys(supervisorName);
		waitABit(3000);
		SelectSupervisorFromLookUp.click();
		waitABit(3000);
    	DoneButton.click();
    	WaitForAjax();
    	waitABit(10000);
    	assert(EmploymentProfileTimeAndAttendanceLink.isVisible());
	}
    
    /***************Production Client Validation
     * @throws IOException *************************/
    
    /**
     * @throws IOException
     */
    
    
  
	public void ProductionClientValidation() throws IOException {
		String path = System.getProperty("user.dir");
		String empProfileResultOutput = path + "\\test-output\\empProfileResult.txt";
		PrintStream myconsole = new PrintStream(new File(empProfileResultOutput));
		myconsole.flush();
		System.setOut(myconsole);
		String[] clientList = ReadDataFromExcel.getClientsList();
		int count = clientList.length;
		for (int i = 0; i < count; i++) {
			myconsole.print("--------" + "Below result is for Client: " + clientList[i] + "--------"
					+ System.getProperty("line.separator"));
			GoBackToClientSetUpWizard.click();
			WaitForAjax();
			waitABit(10000);
			EnterClientName.type(clientList[i]);
			String clientIdLoweCase = clientList[i].toLowerCase();
			String ClickClient = "//a[contains(text(),'" + clientIdLoweCase + "')]";
			waitABit(5000);
			getDriver().findElement(By.xpath(ClickClient)).click();
			accessTypeLink.waitUntilVisible();
			accessTypeLink.click();
			WaitForAjax();
			waitABit(5000);
			getDriver().navigate().refresh();

			NavigateToEmploymentProfilePage("prac");
			WaitForAjax();
			waitABit(8000);

			try {
				if (EmploymentProfileTimeAndAttendanceLink.isVisible())
					try {
						Assert.assertTrue(EmploymentProfileTimeAndAttendanceHistoryButton.isVisible());

					} catch (AssertionError e) {
						myconsole.print("Assertion error for Client : " + clientList[i] + " Xpath="
								+ EmploymentProfileTimeAndAttendanceHistoryButton
								+ " Error: T&A History button on Time Tile is not displayed"
								+ System.getProperty("line.separator"));
					}
				EmploymentProfileTimeAndAttendanceLink.click();
				WaitForAjax();
				waitABit(8000);
				try {
					Assert.assertTrue(DateTextBox.isVisible());

				} catch (AssertionError e) {
					myconsole.print("Assertion error: " + clientList[i] + " Xpath=" + DateTextBox
							+ " Error: Date Textbox not is not displayed on Time tile slide in"
							+ System.getProperty("line.separator"));
				}
				try {
					Assert.assertTrue(ViewPayClassSummaryLink.isVisible());
					ViewPayClassSummaryLink.click();
					WaitForAjax();

					try {
						Assert.assertTrue(PayClassSummaryDateRange.isVisible());
					} catch (AssertionError e) {
						myconsole.print("Assertion error: " + clientList[i] + " xpath =" + PayClassSummaryDateRange
								+ " Error: View Pay Class Summary Page  is not displayed"
								+ System.getProperty("line.separator"));
					}
					try {
						Assert.assertTrue(PayClassSummaryBackButton.isVisible());
						PayClassSummaryBackButton.click();
						WaitForAjax();
						waitABit(8000);

					} catch (AssertionError e) {
						myconsole.print("Assertion error. " + clientList[i] + " xpath=" + PayClassSummaryBackButton
								+ " Error: Pay class Summary Back button is not displayed"
								+ System.getProperty("line.separator"));
					}
				} catch (AssertionError e) {

					myconsole.print("Assertion error: " + clientList[i] + " xpath=" + ViewPayClassSummaryLink
							+ " Error: Pay class Summary Link is not displayed" + System.getProperty("line.separator"));
				}
				try {
					Assert.assertTrue(ViewEditAuditLink.isVisible());
				} catch (AssertionError e) {
					myconsole.print("Assertion error: " + clientList[i] + " xpath=" + ViewEditAuditLink
							+ " Error: View Edit Audit Link  is not displayed" + System.getProperty("line.separator"));
				}
				try {
					Assert.assertTrue(HistoryLink.isVisible());
					HistoryLink.click();
					WaitForAjax();
					waitABit(8000);
					try {
						Assert.assertTrue(EffectiveDatingHistoryBody.isVisible());
						try {
							Assert.assertTrue(PayClassSummaryBackButton.isVisible());
							PayClassSummaryBackButton.click();
							WaitForAjax();
							waitABit(8000);

						} catch (AssertionError e) {
							myconsole.print("Assertion error. " + clientList[i] + " xpath=" + PayClassSummaryBackButton
									+ " Error:History page back button   is not displayed"
									+ System.getProperty("line.separator"));
						}

					} catch (AssertionError e) {
						myconsole.print("Assertion error: " + clientList[i] + " xpath=" + EffectiveDatingHistoryBody
								+ " Error: History page   is not displayed" + System.getProperty("line.separator"));
					}

				} catch (AssertionError e) {
					myconsole.print("Assertion error: " + clientList[i] + " xpath=" + HistoryLink
							+ " Error: History Link    is not displayed" + System.getProperty("line.separator"));
				}
				try {
					Assert.assertTrue(employeeSlideInCancelButton.isVisible());
					employeeSlideInCancelButton.click();
					WaitForAjax();
					waitABit(8000);

				} catch (AssertionError e) {
					myconsole.print("Assertion error. " + clientList[i] + " xpath=" + employeeSlideInCancelButton
							+ " Error: Employment Profile page cancel button is not displayed"
							+ System.getProperty("line.separator"));
				}

			} catch (AssertionError e) {
				myconsole.print("Assertion error: " + clientList[i] + " xpath=" + EmploymentProfileTimeAndAttendanceLink
						+ "Error: T&A Link is not displayed" + System.getProperty("line.separator"));
			}
			NavigateToEmploymentProfilePage("prac");
			WaitForAjax();
			waitABit(8000);
		}

	}

}
