package com.adp.tlmbdd.common;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.CreateRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.response.CreateResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RallyUpdateTests {
	
	static RallyRestApi restApi;
	public static void updateTestCaseResults(String autheKey, String testCaseName, String userName, String testCaseStatus, String buildId, String notes)
		    throws URISyntaxException, IOException
		  {
		    String[] testCaseNameArray = testCaseName.split("-");
		    String testCaseId = testCaseNameArray[0].toString().trim();
		    System.out.println(testCaseId);
		    String wsapiVersion = "v2.0";
		    restApi = new RallyRestApi(new URI("https://rally1.rallydev.com"), autheKey);
		    
		    restApi.setWsapiVersion(wsapiVersion);
		    QueryRequest userRequest = new QueryRequest("User");
		    userRequest.setFetch(new Fetch(new String[] { "UserName", "Subscription", "DisplayName", "SubscriptionAdmin" }));
		    userRequest.setQueryFilter(new QueryFilter("UserName", "=", userName));
		    QueryResponse userQueryResponse = restApi.query(userRequest);
		    JsonArray userQueryResults = userQueryResponse.getResults();
		    JsonElement userQueryElement = userQueryResults.get(0);
		    JsonObject userQueryObject = userQueryElement.getAsJsonObject();
		    String userRef = userQueryObject.get("_ref").getAsString();
		    
		    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		    Date date = new Date();
		    
		    QueryRequest testCaseRequest = new QueryRequest("TestCase");
		    testCaseRequest.setFetch(new Fetch(new String[] { "FormattedID", "Name" }));
		    
		    testCaseRequest.setQueryFilter(new QueryFilter("FormattedID", "=", testCaseId));
		    QueryResponse testCaseQueryResponse = restApi.query(testCaseRequest);
		    JsonObject testCaseJsonObject = testCaseQueryResponse.getResults().get(0).getAsJsonObject();
		    String testCaseRef = testCaseQueryResponse.getResults().get(0).getAsJsonObject().get("_ref").getAsString();
		    
		    JsonObject newTestCaseResult = new JsonObject();
		    newTestCaseResult.addProperty("Verdict", rallyTestCaseStatus(testCaseStatus));
		    newTestCaseResult.addProperty("Date", formatter.format(date));
		    newTestCaseResult.addProperty("Notes", notes);
		    newTestCaseResult.addProperty("Build", buildId);
		    newTestCaseResult.addProperty("Tester", userRef);
		    newTestCaseResult.addProperty("TestCase", testCaseRef);
		    CreateRequest createRequest = new CreateRequest("testcaseresult", newTestCaseResult);
		    CreateResponse createResponse = restApi.create(createRequest);
		  }
		  
		  public static void closeRallyConnection()
		    throws IOException
		  {
		    restApi.close();
		  }
		  
		  public static String rallyTestCaseStatus(String testCaseStatus)
		  {
		    String verdict = null;
		    if ("PASS".equals(testCaseStatus))
		    {
		      System.out.println(testCaseStatus);
		      verdict = "Pass";
		      System.out.println(verdict);
		    }
		    else if ("FAIL".equals(testCaseStatus))
		    {
		      verdict = "Fail";
		    }
		    else if ("CANCELED".equals(testCaseStatus))
		    {
		      verdict = " Inconclusive";
		    }
		    return verdict;
		  }
		  
		  public static String getTheEnvionmentBVT(String notes)
		  {
		    String envNotes = notes.toUpperCase();
		    String env = null;
		    
		    String pod = null;
		    if (envNotes.contains("_"))
		    {
		      String[] podNotes = envNotes.split("_");
		      pod = podNotes[1].toString().trim();
		    }
		    if (envNotes.contains("FIT1")) {
		      env = "FIT1_" + pod;
		    } else if (envNotes.contains("FIT2")) {
		      env = "FIT2_" + pod;
		    } else if (envNotes.contains("DIT2")) {
		      env = "DIT1_" + pod;
		    } else if (envNotes.contains("AUTO1")) {
		      env = "AUTO1_" + pod;
		    } else if (envNotes.contains("AUTO2")) {
		      env = "AUTO2_" + pod;
		    } else if (envNotes.contains("IAT")) {
		      env = "IAT_" + pod;
		    } else if (envNotes.contains("PROD")) {
		      env = "PROD";
		    }
		    return env == null ? envNotes : env;
		  }
		  
		  public static String getTheEnvionmentReg(String notes)
		  {
		    String envNotes = notes.toUpperCase();
		    String env = null;
		    System.out.println(envNotes);
		    if (envNotes.contains("FIT1")) {
		      env = "FIT1";
		    } else if (envNotes.contains("FIT2")) {
		      env = "FIT2";
		    } else if (envNotes.contains("DIT2")) {
		      env = "DIT1";
		    } else if (envNotes.contains("AUTO1")) {
		      env = "AUTO1";
		    } else if (envNotes.contains("AUTO2")) {
		      env = "AUTO2";
		    } else if (envNotes.contains("IAT")) {
		      env = "IAT";
		    } else if (envNotes.contains("PROD")) {
		      env = "PROD";
		    }
		    return env == null ? envNotes : env;
		  }
		

}
