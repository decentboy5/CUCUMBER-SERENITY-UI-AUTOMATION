package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.EmploymentProfileTechRefreshSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class EmploymentProfileTechRefreshStepDefinition {
	
	@Steps
	EmploymentProfileTechRefreshSteps employmentProfileTechRefreshSteps;
	/**********************/
	

	
	
	
	/*
	 * @When("^I navigate to url  Employment profile page is displayed$") public
	 * void i_navigate_to_url_Employment_profile_page_is_displayed() throws
	 * Throwable { employmentProfileTechRefreshSteps.wfnEditorsNavigationurls();
	 * throw new PendingException(); }
	 */
//Test1
	@Then("^Validate The Time Tile Fields using \"([^\"]*)\" and check history & Time tile link working$")
	public void validate_The_Time_Tile_Fields_using_and_check_history_Time_tile_link_working(String employeeName) throws Throwable {
		employmentProfileTechRefreshSteps.ValidateTimeTile(employeeName);

	    throw new PendingException();
	}
	
	//Test 2
	
	@Then("^Validate The Time Tile Fields using \"([^\"]*)\"$")
	public void validate_The_Time_Tile_Fields_using(String employeeName) throws Throwable {
		employmentProfileTechRefreshSteps.NavigateToTimeTile(employeeName);

	    throw new PendingException();
	}

	
	  @Then("^Add details on Time tile slide in including \"([^\"]*)\"  and convert it to Time Employee$"
	  ) public void
	  add_details_on_Time_tile_slide_in_including_and_convert_it_to_Time_Employee(
	  String supervisorName) throws Throwable { 
	  employmentProfileTechRefreshSteps.ConvertNonTimeToTime(supervisorName);  }
	 
	


	@Then("^Validate the Record on History Page and Edit Audit Page$")
	public void validate_the_Record_on_History_Page_and_Edit_Audit_Page() throws Throwable {
		
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	
	
	//Test3
	
	@Then("^Select Time & Attendance Link for  Time Employee$")
	public void select_Time_Attendance_Link_for_Time_Employee() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add details on Time tile slide in to convert it to Non-Time Employee$")
	public void add_details_on_Time_tile_slide_in_to_convert_it_to_Non_Time_Employee() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test4
	
	@Then("^edit the details by providing incorrect details such as incorrect supervisor$")
	public void edit_the_details_by_providing_incorrect_details_such_as_incorrect_supervisor() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate the Error Message displayed$")
	public void validate_the_Error_Message_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	//Test 5
	@Then("^Delete current record for employee$")
	public void delete_current_record_for_employee() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test6
	
	@Then("^Add a new Effective dated record by updating PayClass$")
	public void add_a_new_Effective_dated_record_by_updating_PayClass(String effdt) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate the changes on History page and Edit Audit Page$")
	public void validate_the_changes_on_History_page_and_Edit_Audit_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test7
	@Then("^Edit  Effective dated record by updating Date$")
	public void edit_Effective_dated_record_by_updating_Date() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test 8
	@Then("^Edit  Effective dated record by updating Supervisor$")
	public void edit_Effective_dated_record_by_updating_Supervisor() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	//Test9
	@Then("^Select Time & Attendance Link for  Time Employee who is not a supervisor$")
	public void select_Time_Attendance_Link_for_Time_Employee_who_is_not_a_supervisor() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Edit  Effective dated record by converting Employee To Supervisor$")
	public void edit_Effective_dated_record_by_converting_Employee_To_Supervisor() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test10
	@Then("^Select Time & Attendance Link for  Time Employee who is  a supervisor$")
	public void select_Time_Attendance_Link_for_Time_Employee_who_is_a_supervisor() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Edit  Effective dated record by converting Supervisor To Employee$")
	public void edit_Effective_dated_record_by_converting_Supervisor_To_Employee() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test11
	@Then("^Select Time & Attendance Link for  Time Employee and select History Link$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_History_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Edit  Effective date and save$")
	public void edit_Effective_date_and_save() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^validate the changes on Time tile slide in$")
	public void validate_the_changes_on_Time_tile_slide_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test12
	@Then("^Delete Future Record and save$")
	public void delete_Future_Record_and_save() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test 13
	
	@When("^Select History Link for  Time Employee a$")
	public void select_History_Link_for_Time_Employee_a() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate History Page Loads successfully$")
	public void validate_History_Page_Loads_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test 14
	//No Methods generated
	
	//Test 15
	@Then("^Click on Historical date$")
	public void click_on_Historical_date() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^validate Time Slide in loads with Historical Dated Record$")
	public void validate_Time_Slide_in_loads_with_Historical_Dated_Record() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test16
	//No Methods generated
	
	//Test 17
	@Then("^Validate Add, Edit, Delete buttons are not displayed$")
	public void validate_Add_Edit_Delete_buttons_are_not_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^validate Additional Links are read only too$")
	public void validate_Additional_Links_are_read_only_too() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test18
	@Given("^I login as WFN Manager with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_as_WFN_Manager_with_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Time Tile is not displayed$")
	public void validate_Time_Tile_is_not_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	//Test19
	@Given("^I login as WFN Supervisor with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_as_WFN_Supervisor_with_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Validate Time Tile is  displayed$")
	public void validate_Time_Tile_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Time tile is accessible and Read only$")
	public void validate_Time_tile_is_accessible_and_Read_only() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test 20
	
	@Given("^I login as WFN Superman with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_as_WFN_Superman_with_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Time Tile is  displayed for Employees for which he is supervisor$")
	public void validate_Time_Tile_is_displayed_for_Employees_for_which_he_is_supervisor() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Time tile is not  accessible for whom he/she is manager only$")
	public void validate_Time_tile_is_not_accessible_for_whom_he_she_is_manager_only() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Time Tile is displayed for whome he/she is supervisor as well as Manager$")
	public void validate_Time_Tile_is_displayed_for_whome_he_she_is_supervisor_as_well_as_Manager() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test21
	@Given("^I login as WFN Employee  with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_as_WFN_Employee_with_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Validate Time Tile is  displayed for Employee$")
	public void validate_Time_Tile_is_displayed_for_Employee() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Time Tile is read only$")
	public void validate_Time_Tile_is_read_only() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	
	//Test 22
	@When("^Select Time & Attendance Link for  Time Employee and select PayClass Summary Link$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_PayClass_Summary_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^validate PayClassSummary Page is loading fine$")
	public void validate_PayClassSummary_Page_is_loading_fine() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test 23
	@Then("^Select Time & Attendance Link for  Time Employee and select Additional Dates$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Additional_Dates() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add Additional Dates , Edit Additional Dates and Delete Date$")
	public void add_Additional_Dates_Edit_Additional_Dates_and_Delete_Date() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate Add, Edit, Delete worked fine$")
	public void validate_Add_Edit_Delete_worked_fine() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test 24
	@Then("^Select Time & Attendance Link for  Time Employee and select Other Dates$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Other_Dates() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add ,Edit, Delete Other Rates$")
	public void add_Edit_Delete_Other_Rates() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	//Test25
	
	@Then("^Select Time & Attendance Link for  Time Employee and select Dept-Job Rates$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Dept_Job_Rates() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add ,Edit, Delete Dept-Job Rates$")
	public void add_Edit_Delete_Dept_Job_Rates() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test26
	@Then("^Select Time & Attendance Link for  Time Employee and select Time Clocks Link$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Time_Clocks_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add ,Edit, Delete Time clocks$")
	public void add_Edit_Delete_Time_clocks() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test27
	
	@Then("^Select Time & Attendance Link for  Time Employee and select Mobile Link$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Mobile_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add ,Edit, Delete Mobile$")
	public void add_Edit_Delete_Mobile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test28
	@Then("^Select Time & Attendance Link for  Time Employee and select Notifications Link$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Notifications_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add ,Edit, Delete Notifications$")
	public void add_Edit_Delete_Notifications() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test29
	@Then("^Select Time & Attendance Link for  Time Employee and select Phone Access Link$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Phone_Access_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add ,Edit, Delete Phone Access$")
	public void add_Edit_Delete_Phone_Access() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	//Test30
	
	@Then("^Select Time & Attendance Link for  Time Employee and select Time Cycle  Access Link$")
	public void select_Time_Attendance_Link_for_Time_Employee_and_select_Time_Cycle_Access_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Add ,Edit, Delete Time Cycle  Access Link$")
	public void add_Edit_Delete_Time_Cycle_Access_Link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
