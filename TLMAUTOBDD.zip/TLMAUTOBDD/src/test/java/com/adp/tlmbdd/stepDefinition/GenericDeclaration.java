package com.adp.tlmbdd.stepDefinition;

import java.util.Properties;

import org.junit.rules.ErrorCollector;
//error handling , move it to framework component
public class GenericDeclaration {

	public static String Configpath=System.getProperty("user.dir")+"\\config.properties";
	public final ErrorCollector collector= new ErrorCollector();
	public static Properties prop;
}
