package com.adp.tlmbdd.pages.editors;

import java.util.List;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.pages.GenericPageObject;
import com.adp.tlmbdd.pages.Navigation;


public class ActualVsScheduled extends GenericPageObject {

	Navigation nav;
	
	
	
	@FindBy(xpath = "//div[contains(., 'Cannot display timecard') and @class='vdl-alert__content']")
	private WebElementFacade timeCardNotDisplayedMessage;
	
	@FindBy(xpath = "//div[contains(., 'The position for this employee') and @class='vdl-alert__content']")
	private WebElementFacade timeCardErrorMessage;
	
	@FindBy(xpath = "//div[@class='summary-details']")
	private WebElementFacade payrollSummaryDetailTable;
	
	@FindBy(xpath = "//textarea[@class='custom-textarea-style vdl-textarea']")
	private WebElementFacade edittextarea;
	
	@FindBy(xpath = "//th[@title='REDISTRIBUTED HOURS'  and text()='REDISTRIBUTED HOURS']")
	private WebElementFacade redistributedHoursColumnPayrollSummary;
	
	@FindBy(xpath = "//th[@title='FINAL HOURS'  and text()='FINAL HOURS']")
	private WebElementFacade finalHoursColumnPayrollSummary;
	
	@FindBy(xpath = "//th[@title='HOURS'  and text()='HOURS']")
	private WebElementFacade hoursColumnPayrollSummary;
	
	
	@FindBy(xpath = "//th[@title='PAY CODE'  and text()='PAY CODE']")
	private WebElementFacade payCodeColumnPayrollSummary;
	
	@FindBy(xpath = "//th[@title='DAYS'  and text()='DAYS']")
	private WebElementFacade daysColumnPayrollSummary;
	
	@FindBy(xpath = "//th[@title='DOLLARS'  and text()='DOLLARS']")
	private WebElementFacade dollarsColumnPayrollSummary;
	
	@FindBy(xpath = "//span[text()='Timecard Approval History']/parent::button[@class='control-header-right-button vdl-button vdl-button--link']")
	private WebElementFacade timeCardApprovalHistoryLink;
	
	@FindBy(xpath = "//span[@class='vdl-slide-in-title' and text()='Timecard Approval History']")
	private WebElementFacade timeCardApprovalHistoryLinkSliderTitle;
	
	@FindBy(xpath = "//*[@id='actualVsScheduledLanding_root']/div/div[2]/div/table/tr[2]/td[1]")
	private WebElementFacade startdate;
	
	@FindBy(xpath = "//div[text()='No timecard approval history for this employee for the selected date range.']")
	private WebElementFacade timeCardApprovalHistoryLinkSliderNoDataMessage;
	
	
	@FindBy(xpath = "//th[text()='EDIT REASON']")
	private WebElementFacade timeCardApprovalHistoryLinkSliderColumnEditReason;
	
	@FindBy(xpath = "//th[text()='CHANGE DATE']")
	private WebElementFacade timeCardApprovalHistoryLinkSliderColumnChangeDate;
	
	@FindBy(xpath = ".//*[text()='Edit Audit History']/parent::button[@class='control-header-right-button vdl-button vdl-button--link']")
	private WebElementFacade editAuditHistoryLink;
	
	@FindBy(xpath = ".//*[text()='Edit Audit']/parent::button[@class='control-header-right-button vdl-button vdl-button--link']")
	private WebElementFacade editAuditLink;
	
	@FindBy(xpath = "//div[contains(text(),'Edit Shift')]")
	private WebElementFacade EditShiftDialog;
	
	@FindBy(xpath = "//span[@class='vdl-slide-in-title' and text()='Time Pair Edit Audit']")
	private WebElementFacade editAuditHistoryLinkSliderTitle;
	
	@FindBy(xpath = "//*[@id='labelScheduledTaskTimeZone']")
	private WebElementFacade editAuditHistoryLinkSliderTimeZoneBox;
	
	@FindBy(xpath = "//*[@id='lblTpEditAudit' and text()='Time Pair Edit Audit']")
	private WebElementFacade editAuditHistoryLinkSliderTimePairEditAuditText;
	
	@FindBy(xpath = "//*[@id='lblExtraInfo' and text()='- All Dates']")
	private WebElementFacade editAuditHistoryLinkSliderAllDateText;
	
	@FindBy(xpath = "//th[text()='Action']")
	private WebElementFacade editAuditHistoryLinkSliderColumnAction;
	
	@FindBy(xpath = "//th[text()='Reason']")
	private WebElementFacade editAuditHistoryLinkSliderColumnReason;
	
	@FindBy(xpath = "//th[text()='Date of Change']")
	private WebElementFacade editAuditHistoryLinkSliderColumnDateofChange;
	
	@FindBy(xpath = "//th[text()='Changed By (Associate ID)']")
	private WebElementFacade editAuditHistoryLinkSliderColumnChangedBy;
	
	@FindBy(xpath = "//table/tr/td/button[1]")
	private WebElementFacade SaveButton;
	
	@FindBy(xpath = "//button[@class='vdl-slide-in-close vdl-button vdl-button--secondary']")
	private WebElementFacade backButtonSliderAVS;
	
	
	@FindBy(xpath = "//span[text()='Employee Approval Status: Required']/parent::button[@class='control-header-right-button vdl-button vdl-button--link']")
	private WebElementFacade approvalTimeCardLink;
	
	@FindBy(xpath = "//span[text()='Employee Approval Status: Not Possible']/parent::button[@class='control-header-right-button vdl-button vdl-button--link']")
	private WebElementFacade approvalTimeCardNotPossibleLink;
	
	
	@FindBy(xpath = "//span[text()='Employee Approval Status: Done']/parent::button[@class='control-header-right-button vdl-button vdl-button--link']")
	private WebElementFacade approvedTimeCardLink;
	
	//@FindBy(xpath = "//*[@class='dijitReset dijitButtonText' and text()='Approve Timecard']")
	//private WebElementFacade approveTimeCardButtonOnMyTimeCard;
	
	@FindBy(xpath = "//*[@class='dijitReset dijitButtonText' and text()='Approve Timecard']/parent::span")
	private WebElementFacade approveTimeCardButtonOnMyTimeCard;
	
	@FindBy(xpath = "//div[contains(text(),'Department')]/following-sibling::div/div/div/span")
	private WebElementFacade Departmentlookup;	
	
	@FindBy(xpath = "//div[contains(text(),'JOB')]/following-sibling::div/div/div/span")
	private WebElementFacade Joblookup;	
	
	@FindBy(xpath = "//*[@class='dijitButtonText' and text()='Approved']")
	private WebElementFacade approvedTimeCardButtonOnMyTimeCard;
	
	
	
	@FindBy(xpath = "//*[@class='dijitArrowButtonInner']")
	private WebElementFacade arrowForApproveUnapproveTimeCardOnMyTimeCard;
	
	@FindBy(xpath = "//*[@class='dijitReset dijitMenuItemLabel' and text()='Remove Approval']")
	private WebElementFacade removeApprovalTimeCardBoxOnMyTimeCard;
	
	@FindBy(xpath = "//*[@class='dijitReset dijitButtonText' and text()='Approve']/parent::span")
	private WebElementFacade approveTimeCardConfirmationButtonCardOnMyTimeCard;
	
	@FindBy(xpath = "//label[@class='vdl-toggle-switch']")
	private WebElementFacade defaultToggleShowHideDollarAmountButtonUnchecked;
	
	@FindBy(xpath = "//*[@class='vdl-toggle-switch vdl-toggle-switch--checked']")
	private WebElementFacade ToggleShowHideDollarAmountButtonChecked;
	
	//@FindBy(xpath = "//*[@class='vdl-toggle-switch__slide']")
	//private WebElementFacade ToggleButtonChangeValueDollarAmount;
	
	@FindBy(xpath = "//th[@title='PAY CODE']/parent::tr//th")
	private List<WebElementFacade> numberOfColumnInpayrollSummary;
	
	
	
	@FindBy(xpath = "//div[@class='vdl-toggle-switch__knob']")
	private WebElementFacade ToggleButtonChangeValueDollarAmount;
	
    //for pop-up details
	@FindBy(xpath = "//div[@class=\"vdl-col-lg-7 calender-page actual-vs-schedule-payroll-details\"]//tr[@paycode]")
	private List <WebElementFacade> payCodeListPayrollSummary ;
	
	
	@FindBy(xpath = "//div[@class=\"vdl-col-lg-5 calender-page actual-vs-schedule-payroll-details\"]//tr[@paycode]")
	private List <WebElementFacade> supplementalpayCodeListPayrollSummary ;
	
	
	@FindBy(xpath = "//div[@class='actual-vs-schedule-payroll-details']")
	private WebElementFacade payCodeInPayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='DATE']")
	private WebElementFacade dateColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='Department']")
	private WebElementFacade departmentColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='HOURS']")
	private WebElementFacade hoursColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='REDISTRIBUTED HOURS']")
	private WebElementFacade redistributedHoursColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='FINAL HOURS']")
	private WebElementFacade finalHoursColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='DAYS']")
	private WebElementFacade daysColumnInpayCodePayrollSummaryPopUp;
	
	
	@FindBy(xpath = "//th[@title='RATE']")
	private WebElementFacade rateColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='DOLLARS']")
	private WebElementFacade dollarColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='ENTERED AMOUNT']")
	private WebElementFacade EnteredAmountColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='FACTOR']")
	private WebElementFacade FactorColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//th[@title='FINAL AMOUNT']")
	private WebElementFacade FinalAmountColumnInpayCodePayrollSummaryPopUp;
	
	@FindBy(xpath = "//span[text()='OK']/parent::button[@type='button']")
	private WebElementFacade OkButtonInPayCodePayrollSummaryPopUp;
	
	/// Drop down list for selecting Pay Period
	
	//@FindBy(className = "vdl-dropdown-list__picker")
	//private WebElementFacade selectPayPeriodDropDownListPicker;
	
	@FindBy(xpath = "//div[contains(text(),'Add Shift')]")
	private WebElementFacade AddShiftDialog;
	
	@FindBy(xpath = "//div[@class='vdl-dropdown-list__input'  and text()='Today']")
	private WebElementFacade defaultPayPeriodToday;
	
	@FindBy(xpath = "//div[@class='vdl-dropdown-list__input']")
	private WebElementFacade payPeriodInputBoxDropDownList;
	
	@FindBy(xpath = "(//*[@class='shift-edit-action fa fa-edit'])[1]")
	private WebElementFacade scheduleEdit;
	
	@FindBy(xpath = "//*[@class='vdl-dropdown-list__picker']")
	private WebElementFacade selectPayPeriodDropDownListPicker;
	
	@FindBy(xpath = "//li[text()='Current Pay Period']")
	private WebElementFacade currentPayPeriodInDropDownList;
	
	@FindBy(xpath = "//li[text()='Previous Pay Period']")
	private WebElementFacade previousPayPeriodInDropDownList;
	
	@FindBy(xpath = "//li[text()='Next Pay Period']")
	private WebElementFacade nextPayPeriodInDropDownList;
	
	@FindBy(xpath = "//li[text()='Today']")
	private WebElementFacade TodayInDropDownList;
	
	@FindBy(xpath = "//li[text()='Other Pay Period (Enter Date)']")
	private WebElementFacade otherPayPeriodInDropDownList;
	
	@FindBy(xpath = "//li[text()='Historical Pay Period']")
	private WebElementFacade historicalPayPeriodInDropDownList;
	
	
	//Historical Pay Period Popup
	@FindBy(xpath = "//*[@class='vdl-modal-title' and text()='Historical Pay Period Lookup']")
	private WebElementFacade historicalPayPeriodPopUpInDropDownList;
	
	@FindBy(xpath = "//*[text()='No historical pay periods found for this employee']")
	private WebElementFacade hitoricalPayPeriodPopNoDataMessage;
	
	
	@FindBy(xpath = "//table[@class='historical-pay-period']/tr")
	private List< WebElementFacade> ListOfHistoricalPayPeriodInPopUp;  // number = size -1;
	
	@FindBy(xpath = "(//input[@class='vdl-date-time-picker__input'])[1]")
	private WebElementFacade StartTimeTextBox;
	
	@FindBy(xpath = "(//input[@class='vdl-date-time-picker__input'])[2]")
	private WebElementFacade EndTimeTextBox;
	
	@FindBy(xpath = ".//*[@id='vdl_11__listbox__option__1']")
	public WebElementFacade FirstDepartment;
	
	@FindBy(xpath = "//th[@title='Start Date' and text()='Start Date']")
	private WebElementFacade startDateColumnInhistoricalPayPeriodPopUpInDropDownList;
	
	@FindBy(xpath = "//th[@title='End Date' and text()='End Date']")
	private WebElementFacade endDateColumnInhistoricalPayPeriodPopUpInDropDownList;
	
	@FindBy(xpath = "//span[text()='Cancel']/parent::button[@type='button']")
	private WebElementFacade CancelButtonInhistoricalPayPeriodPopUpInDropDownList;
	
	@FindBy(xpath = "//span[text()='Actual Hours']/parent::button[@class='control-header-right-button label-tlm-totals vdl-button vdl-button--link']")
	private WebElementFacade actualHourLink;
	
	@FindBy(xpath = "//span[text()='Scheduled Hours']/parent::button[@class='control-header-right-button label-tlm-totals vdl-button vdl-button--link']")
	private WebElementFacade scheduleHourLink;
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode']")
	private WebElementFacade pageTitle;
	
	@FindBy(xpath = "(//div[@class='vdl-dropdown-list__filter'])[3]/following-sibling::ul/li[4]")
	private WebElementFacade Departmentfirst;
	
	@FindBy(xpath = "(//div[@class='vdl-dropdown-list__filter'])[3]/following-sibling::ul/li[2]")
	private WebElementFacade Jobfirst;
	
	@FindBy(xpath = "//div[contains(text(),'Department')]/following-sibling::div/div/div/span[@class='vdl-dropdown-list__picker']")
	public WebElementFacade DepartmentDropdown;		
	
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode' and (text()='My Schedule' or text()= 'Monthly Schedule')]")
	private WebElementFacade monthlyScheduleOrMySchedulePage;
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode' and text()='My Schedule']")
	private WebElementFacade mySchedulePage;
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode' and text()= 'Monthly Schedule']")
	private WebElementFacade monthlySchedulePage;
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode' and text()='My Timecard']")
	private WebElementFacade myTimecardPage;
	
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode' and text()='Individual Timecard']")
	private WebElementFacade individualTimecardPage;
	
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode' and (text()='My Timecard' or   text()='Individual Timecard')]")
	private WebElementFacade individualTimecardOrMyTimecardPage;
	
	
	@FindBy(xpath = "//*[@class='dijitTitlePaneTextNode']")
	private WebElementFacade currentPageNode;
	
	@FindBy(xpath = "//span[@class='vdl-date-time-picker__select']")
	private WebElementFacade calenderDatePicker;

	
	@FindBy(xpath = "(//a[@class='calendar-header-currentDate-selector'])[1]")
	private WebElementFacade monthSelecterInCalandar;
	
	@FindBy(xpath = "(//a[@class='calendar-header-currentDate-selector'])[2]")
	private WebElementFacade yearSelecterInCalandar;
	
	@FindBy(xpath = "//span[text()='More']")
	private WebElementFacade MoreLink;
	
	@FindBy(xpath = "//li[contains(text(),'Schedule')]")
	private WebElementFacade scheduleLinkInMoreLink;
	
	@FindBy(xpath = "//li[contains(text(),'Timecard')]")
	private WebElementFacade timecardLinkInMoreLink;
	
	@FindBy(xpath = "//li[contains(text(),'Legend')]")
	private WebElementFacade legendLinkInMoreLink;
	
	@FindBy(xpath = "//*[@class='vdl-slide-in-close vdl-button vdl-button--secondary']")
	private WebElementFacade backInLegend;
	
	@FindBy(xpath = "//input[@aria-describedby='popover-1']")
	private WebElementFacade ShiftDurationTextBox;
	
	//Search employee on myTeam AVS
	
	@FindBy(xpath = "//*[@id='employeeIdBarEmpListTooltipBtn']")
	private WebElementFacade searchButtonOnMyTeamAVS;
	
	
	@FindBy(xpath = "//*[@id='idBarSscrollGrid_search']")
	private WebElementFacade searchTextBoxOnMyTeamAVS;
	
	@FindBy(xpath = "//*[@id='revit_form_ValidationTextBox_0']")
	private WebElementFacade searchTextBoxOnMyTeamAVSTLM;
	
	// selecting pay period in TimeCard page
	
	@FindBy(xpath = "//input[@id='dateRangeselect']")
	private WebElementFacade inputBoxPayPeriodOnTimeCard;
	
	
	@FindBy(xpath = "//*[@class='dijitReset dijitInputField dijitArrowButtonInner']")
	private WebElementFacade payPeriodlistPickerOnTimeCard;
	
	
	///////////////for PayClass//////////
	
	@FindBy(xpath = "//td[text()='Pay Classes']")
	private WebElementFacade payClassInAddtionConfiguration;
	
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElementFacade AdditionalConfigurationMainPageFrame;
	
	@FindBy(xpath = "//iframe[@id='TLMiFrame']")
	private WebElementFacade AdditionalConfigurationMainPageTLMFrame;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame1_iframe']")
	private WebElementFacade AdditionalConfigurationPayClassFrame;
	
//	@FindBy(xpath = "//input[@id='chkShowRedistHrs']")
//	private WebElementFacade showRedistHourCheckBoxInPayrollSummary;
	
	@FindBy(xpath = ".//*[@id='lblShowRedistributeHours']/parent::td/following-sibling::td//*[@id='chkShowRedistHrs']")
	private WebElementFacade showRedistHourCheckBoxInPayrollSummary;
	
	
	
	@FindBy(xpath = "(//*[@class='dijitReset dijitInputField dijitInputContainer'])[15]")
	private WebElementFacade boxInPayrollSummary;
	
	
	@FindBy(xpath = "//*[@id='barButtons_btnSubmit']")
	private WebElementFacade submitButtonInPayClass;
	
	
	@FindBy(xpath = "//*[@id='manage-profiles']")
	private WebElementFacade manageProfileButtonAtAccessPermission ;
	
	
	@FindBy(xpath = "(//a[text()='Standard Time and Attendance Supervisor'])[1]")
	private WebElementFacade standardTimeAndAttendaceSupervisorForAccessPermission ;
	
	@FindBy(xpath = "(//a[text()='Standard Supervisor'])[1]")
	private WebElementFacade standardSupervisorForAccessPermission ;
	
	
	@FindBy(xpath = "(//*[@class='resource-tabs ng-binding ng-scope inactive'])[6]")
	private WebElementFacade sensitivePersonalInfo ;
	
	@FindBy(xpath = "(//*[@class='resource-tabs ng-binding ng-scope inactive'])[5]")
	private WebElementFacade sensitiveOption ;
	
	@FindBy(xpath = "//i[@class='fa fa-check-square fa-lg ng-hide']")
	private WebElementFacade maskingEnabledForSupervisorBoxUnchecked ;
	
	@FindBy(xpath = "//*[@class='fa fa-check-square fa-lg ng-hide']/following-sibling::input")
	private WebElementFacade disableMaskingForSupervisor ; 
	
	@FindBy(xpath = "//i[@class='fa fa-check-square fa-lg']")
	private WebElementFacade maskingDisabledForSupervisorBoxChecked ;
	
	@FindBy(xpath = "//*[@class='fa fa-check-square fa-lg']/following-sibling::input")
	private WebElementFacade  enableMaskingForSupervisor ;
	
	@FindBy(xpath = "//*[@id='saveProfile']")
	private WebElementFacade saveButtonProfileInSensitivePersonalInfo ;
	
	@FindBy(xpath = "//div[@class=\"dijitReset revitLeftNav\"]//span[text()='Time & Attendance']")
	private WebElementFacade timeAndAttendanceLink ;
	
	@FindBy(xpath = "//*[@id='lblConfirmMsg']")
	private WebElementFacade confirmMessage ;
	
	@FindBy(xpath = "//*[@id='btnSubmit']")
	private WebElementFacade submitButton ;
	
	@FindBy(xpath = "//div[@class='actual']")
	private WebElementFacade ActualHoursLink;
	
	@FindBy(xpath = "//div[@class='in-out']")
	private WebElementFacade ScheduleHoursLink;
	
	@FindBy(xpath = "//*[@id='mastheadGlobalOptions']")
	private WebElementFacade employeeId;
	
	@FindBy(xpath = "//*[@id='preferences_text']")
	private WebElementFacade preferencesLink;
	
	@FindBy(xpath = "//input[@id='radAmountTwoDecimals']")
	private WebElementFacade amountTwoDec;
	
	@FindBy(xpath = "//div[@class='in-out' and contains(text(),'02')]")
	private WebElementFacade preceedingZero;
	
	@FindBy(xpath = "//*[@id='prefTabContainer_tablist_prefcontent32_tab']")
	private WebElementFacade contentLink;
	
	@FindBy(id = "eZlmIFrameUserPrefTlm_iframe") 
	private WebElementFacade ezLMIFrameUserPref; 
	
	@FindBy(id = "//span[contains(., 'Actual vs Scheduled') and @class='dijitTitlePaneTextNode']") 
	private WebElementFacade ActualVsScheduledTitle;
	
	@FindBy(xpath = "(//div[@class='pto-box'])[1]") 
	private WebElementFacade approvedPTO;
	
public void verifyRedistributedHourColumnInPayrollSummary() {
	
	WaitForAjax();
	waitABit(10000);
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 5000);");
	WaitForAjax();
	System.out.println("Scrolled down");
	redistributedHoursColumnPayrollSummary.shouldBeVisible();
	//redistributedHoursColumnPayrollSummary.isDisplayed();
	System.out.println("Redistributed Hours Column is displayed in payroll summary");
	
	
	
}

public void verifyFinalHourColumnInPayrollSummary() {
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	WaitForAjax();
//	finalHoursColumnPayrollSummary.isDisplayed();
	finalHoursColumnPayrollSummary.shouldBeVisible();
	System.out.println("Final Hours Column is displayed in payroll summary");
	
	
}

public void verifyDayColumnInPayrollSummary() {
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	WaitForAjax();
	daysColumnPayrollSummary.shouldBeVisible();
	System.out.println("Days Column is displayed in payroll summary");
	
}

public void verifyPayCodeColumnInPayrollSummary() {
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	WaitForAjax();
	payCodeColumnPayrollSummary.shouldBeVisible();
	System.out.println("PayCode Column is displayed in payroll summary");
	
}

public void verifyAmountColumnInPayrollSummar() {
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	WaitForAjax();
	dollarsColumnPayrollSummary.shouldBeVisible();
	System.out.println("dollar/amount Column is displayed in payroll summary");
	
}

public void selectPayPeriod(String payPeriod){
	WaitForAjax();
	waitABit(20000);
	String setXpathForPayPeriod = "//li[text()='"+ payPeriod + "']";
	
	
	selectPayPeriodDropDownListPicker.waitUntilClickable().then().click();
	//selectPayPeriodDropDownListPicker.click();
	System.out.println("Selected list picker in Pay period List");
	
	WaitForAjax();
	getDriver().findElement(By.xpath(setXpathForPayPeriod)).click();
	System.out.println("Pay period is selected in Pay period list");
	WaitForAjax();
}

public void verifyTimeCardApprovalLink() {
	WaitForAjax();
	waitABit(10000);
	approvalTimeCardLink.shouldBePresent();
	System.out.println("Approved TimeCard link is present");
	
}



public void verifyTimeCardApprovedLink() {
	WaitForAjax();
	waitABit(10000);
	approvedTimeCardLink.shouldBePresent();
	System.out.println("Approved TimeCard link is present");
	
}

public void approveTimeCard(){
	WaitForAjax();
	waitABit(10000);
//	boolean isSchedule = false;
//	boolean isMyTeamAVS = pageTitle.containsText("Actual vs. Scheduled");
	//String seletedpayPeriod = payPeriodInputBoxDropDownList.getText().toString();
	approvalTimeCardLink.waitUntilVisible().then().click();
	System.out.println("Approval TimeCard Link is displayed");
	
	/*
	WaitForAjax();
	individualTimecardOrMyTimecardPage.shouldBeEnabled();
	System.out.println("Successfully Navigated.. Timecard Approval link is working");
	WaitForAjax();
	waitABit(5000);
	*/
	
//	navigationFromAVS(isSchedule, isMyTeamAVS);
	
	
	approveTimeCardButtonOnMyTimeCard.waitUntilClickable();
	approveTimeCardButtonOnMyTimeCard.click();
	WaitForAjax();
	approveTimeCardConfirmationButtonCardOnMyTimeCard.waitUntilClickable();
	approveTimeCardConfirmationButtonCardOnMyTimeCard.click();
	WaitForAjax();
	System.out.println("Time Card is approved");
	
	//navigationBackToAVS(isMyTeamAVS);
	/*
	nav.wfnmainPageNavigation("myself", "Time & Attendance", "Actual vs Scheduled"); 
	WaitForAjax();
	*/
	//selectPayPeriod(seletedpayPeriod);
	
}

public void unApproveTimeCard(){
	WaitForAjax();
	waitABit(10000);
	//boolean isSchedule = false;
	//boolean isMyTeamAVS = pageTitle.containsText("Actual vs. Scheduled");
	//String seletedpayPeriod = payPeriodInputBoxDropDownList.getText().toString();
	approvedTimeCardLink.waitUntilVisible().then().click();
	System.out.println("Approved TimeCard is displayed");
	
	//navigationFromAVS(isSchedule, isMyTeamAVS);
	
	/*
	WaitForAjax();
	individualTimecardOrMyTimecardPage.shouldBeEnabled();
	System.out.println("Successfully Navigated.. Timecard Approved link is working");
	*/
	
	approvedTimeCardButtonOnMyTimeCard.isEnabled();
	arrowForApproveUnapproveTimeCardOnMyTimeCard.waitUntilClickable().then().click();
	waitABit(1000);
	removeApprovalTimeCardBoxOnMyTimeCard.waitUntilClickable().then().click();
	WaitForAjax();
	WaitForAjax();
	System.out.println("Time Card is Unapproved");
	
	//navigationBackToAVS(isMyTeamAVS);
	/*
	nav.wfnmainPageNavigation("myself", "Time & Attendance", "Actual vs Scheduled"); 
	WaitForAjax();
	*/
	
	//selectPayPeriod(seletedpayPeriod);
}

public void verifyAmountHiddenByDefaultAndShowThenVerifyIt() {
	WaitForAjax();
	waitABit(10000);
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	verifyToggleButtonIsHiddenAndAmountColumnIsNotDisplayed();
	WaitForAjax();
	ChangeToggleCheckButtonAmount();
	WaitForAjax();
	verifyToggleButtonIsShownAndAmountColumnIsDisplayed();
	WaitForAjax();
	ChangeToggleCheckButtonAmount();
	System.out.println("Toggle button state again changed to Uncheck :");
	verifyToggleButtonIsHiddenAndAmountColumnIsNotDisplayed();
	WaitForAjax();
	
}

public void verifyAmountMaskingIsDisabled(){
	WaitForAjax();
	waitABit(5000);
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	if(pageTitle.containsText("Actual vs Scheduled"))
		ChangeToggleCheckButtonAmount();
	int numberofCoulmn = numberOfColumnInpayrollSummary.size();
	int payCodeCount = payCodeListPayrollSummary.size();
	String xpathAmountForDifferentPaycodes = null;
	
	
	int i=1;
	while(i!=payCodeCount){		
	    xpathAmountForDifferentPaycodes = "(//tr[@paycode])[" + i + "]//td[" + numberofCoulmn + "]";
	    String amountValue = getDriver().findElement(By.xpath(xpathAmountForDifferentPaycodes)).getText().toString();
	
	    if(amountValue.equals("XXXX")){
	    	 throw new AssertionError("Masking is Enabled!! Should not be!!! ERROR");
	    }
		
		i++;
	}
	System.out.println("Masking is Disabled");
	if(pageTitle.containsText("Actual vs Scheduled"))
		ChangeToggleCheckButtonAmount();
	WaitForAjax();
	
}

public void verifyAmountMaskingIsEnabled(){
	WaitForAjax();
	waitABit(5000);
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	if(pageTitle.containsText("Actual vs Scheduled"))
		ChangeToggleCheckButtonAmount();
	int numberofCoulmn = numberOfColumnInpayrollSummary.size();
	int payCodeCount = payCodeListPayrollSummary.size();
	String xpathAmountForDifferentPaycodes = null;
	
	
	int i=1;
	while(i!=payCodeCount){		
	    xpathAmountForDifferentPaycodes = "(//tr[@paycode])[" + i + "]//td[" + numberofCoulmn + "]";
	    String amountValue = getDriver().findElement(By.xpath(xpathAmountForDifferentPaycodes)).getText().toString();
	
	    if(!amountValue.equals("XXXX")){
	    	 throw new AssertionError("Masking is disabled!! Should not be!!! ERROR");
	    }
		
		i++;
	}
	System.out.println("Masking is Enabled");
	if(pageTitle.containsText("Actual vs Scheduled"))
		ChangeToggleCheckButtonAmount();
	WaitForAjax();
	
	
}



private void verifyToggleButtonIsShownAndAmountColumnIsDisplayed() {
	WaitForAjax();
	ToggleShowHideDollarAmountButtonChecked.isEnabled();
	System.out.println("Verified Toggle button to Show Amount is checked");
	WaitForAjax();
	dollarsColumnPayrollSummary.shouldBeVisible();
	System.out.println("dollar/amount Column is displayed in payroll summary");
		
}

private void verifyToggleButtonIsHiddenAndAmountColumnIsNotDisplayed() {
	
	defaultToggleShowHideDollarAmountButtonUnchecked.isEnabled();
	System.out.println("	Verified that Toggle button is unchecked");
	
	 dollarsColumnPayrollSummary.shouldNotBeVisible();
	 System.out.println("	Dollar/Amount column is not displayed");
	
}

private void ChangeToggleCheckButtonAmount() {
	WaitForAjax();
	//String xpathVal = "//*[@class='vdl-toggle-switch__slide']";
	//getDriver().findElement(By.xpath(xpathVal)).click();
	waitABit(5000);
	ToggleButtonChangeValueDollarAmount.waitUntilClickable();
	ToggleButtonChangeValueDollarAmount.click();
	System.out.println("Change the toggle button State");
}


private void verifyPaycodePopUp() {
		WaitForAjax();
		payCodeInPayrollSummaryPopUp.isEnabled();
		System.out.println("		PopUp is opened for paycode in payroll summary");
		dateColumnInpayCodePayrollSummaryPopUp.isEnabled();
		System.out.println("		date Column is present in popUp for paycode in payroll summary");
		departmentColumnInpayCodePayrollSummaryPopUp.isEnabled();
		System.out.println("		department Column is present in popUp for paycode in payroll summary");
		hoursColumnInpayCodePayrollSummaryPopUp.isEnabled();
		System.out.println("		Hours Column is present in popUp for paycode in payroll summary");
		if(redistributedHoursColumnPayrollSummary.isPresent()){
			redistributedHoursColumnInpayCodePayrollSummaryPopUp.isEnabled();
			System.out.println("		Redistributed Hours Column is present in popUp for paycode in payroll summary");	}
		else{
			redistributedHoursColumnInpayCodePayrollSummaryPopUp.shouldNotBePresent();
			System.out.println("		Redistributed Hours Column is Not present in popUp for paycode in payroll summary:correct");	}
		
		
		if(finalHoursColumnPayrollSummary.isPresent()){
			finalHoursColumnInpayCodePayrollSummaryPopUp.isEnabled();
			System.out.println("		Final Hours Column is present in popUp for paycode in payroll summary");}
		else{
			finalHoursColumnInpayCodePayrollSummaryPopUp.shouldNotBePresent();
			System.out.println("		Final Hours Column is Not present in popUp for paycode in payroll summary:correct");}
		
		
		if(daysColumnPayrollSummary.isPresent()){
			daysColumnInpayCodePayrollSummaryPopUp.isEnabled();
			System.out.println("		Days Column is present in popUp for paycode in payroll summary");	}
		else{
			daysColumnInpayCodePayrollSummaryPopUp.shouldNotBePresent();
			System.out.println("		Days Column is Not present in popUp for paycode in payroll summary:correct");}
	
		
		rateColumnInpayCodePayrollSummaryPopUp.isEnabled();
		System.out.println("		Rate Column is present in popUp for paycode in payroll summary");
		
		dollarColumnInpayCodePayrollSummaryPopUp.isEnabled();
		System.out.println("		Dollar Column is present in popUp for paycode in payroll summary");
		
		
		OkButtonInPayCodePayrollSummaryPopUp.waitUntilClickable();
		OkButtonInPayCodePayrollSummaryPopUp.click();
}


private void verifySupplementalPaycodePopUp() {
	WaitForAjax();
	payCodeInPayrollSummaryPopUp.isEnabled();
	System.out.println("		PopUp is opened for supplemental paycode in payroll summary");
	dateColumnInpayCodePayrollSummaryPopUp.isEnabled();
	System.out.println("		date Column is present in popUp for paycode in payroll summary");
	departmentColumnInpayCodePayrollSummaryPopUp.isEnabled();
	System.out.println("		department Column is present in popUp for paycode in payroll summary");
	EnteredAmountColumnInpayCodePayrollSummaryPopUp.isEnabled();
	System.out.println("		Hours Column is present in popUp for paycode in payroll summary");
	FactorColumnInpayCodePayrollSummaryPopUp.isEnabled();
	System.out.println("		Hours Column is present in popUp for paycode in payroll summary");
	FinalAmountColumnInpayCodePayrollSummaryPopUp.isEnabled();
	System.out.println("		Hours Column is present in popUp for paycode in payroll summary");
	
	OkButtonInPayCodePayrollSummaryPopUp.waitUntilClickable();
	OkButtonInPayCodePayrollSummaryPopUp.click();
}
public void verifyPayCodeLinksOpeningPopUpInPayrollSummary() {
	WaitForAjax();
	int payCodeCount = payCodeListPayrollSummary.size();
	System.out.println("number of different paycodes are = " + payCodeCount);
	int i = payCodeCount;
	while(i!=0){
		String xpathVal = "(//div[@class=\"summary-details\"]//tr[@paycode])[" + i + "]//td[1]//a";
		getDriver().findElement(By.xpath(xpathVal)).click();
		System.out.println("PayCode " + i +"link of opening pop-Up:");
		verifyPaycodePopUp();
		WaitForAjax();
		i--;
	}
	if(i==0)
		System.out.println(" All links for paycode in payroll Summary are working");
}


public void selectHistoricalPayPeriodFromPayPeriodListAndVerifyPopUp() {
	WaitForAjax();
	waitABit(20000);

	selectPayPeriodDropDownListPicker.waitUntilClickable();
	selectPayPeriodDropDownListPicker.click();
	System.out.println("Selected list picker in Pay period List");
	
	WaitForAjax();
	historicalPayPeriodInDropDownList.waitUntilClickable().then().click();
	System.out.println("Historical Pay period is selected in Pay period list");
	WaitForAjax();
	
	historicalPayPeriodPopUpInDropDownList.isEnabled();
	System.out.println("Historical pay period pop is opened");
	
	if(hitoricalPayPeriodPopNoDataMessage.isPresent()){
		System.out.println("Historical pay period Data is not available");
	}
	else{
		/*
		startDateColumnInhistoricalPayPeriodPopUpInDropDownList.isEnabled();
		System.out.println("Start date is peresent in Historical pay period popup");
		endDateColumnInhistoricalPayPeriodPopUpInDropDownList.isEnabled();
		System.out.println("End date is peresent in Historical pay period popup");
		*/
		
		int numberOfPeriod = ListOfHistoricalPayPeriodInPopUp.size() - 1;
		int i=1;
		String xpathForLink = null;
		while(i <= numberOfPeriod){
			
			xpathForLink = "//table[@class='historical-pay-period']/tr[" + (i+1) + "]/td[1]/a";
			getDriver().findElement(By.xpath(xpathForLink)).click();
			WaitForAjax();
			waitABit(5000);
			payPeriodInputBoxDropDownList.shouldContainText("Historical Pay Period");
			System.out.println("Historical Pay Period Number " + i + " is working");
			
			selectPayPeriodDropDownListPicker.waitUntilClickable().then().click();
			historicalPayPeriodInDropDownList.waitUntilClickable().then().click();
			WaitForAjax();
			i++;
		}
	
	}
	WaitForAjax();
	//selectPayPeriodDropDownListPicker.waitUntilClickable().then().click();
	//historicalPayPeriodInDropDownList.waitUntilClickable().then().click();
	
	CancelButtonInhistoricalPayPeriodPopUpInDropDownList.isEnabled();
	System.out.println("Cancel button is peresent in Historical pay period popup");
	
	CancelButtonInhistoricalPayPeriodPopUpInDropDownList.waitUntilClickable();
	CancelButtonInhistoricalPayPeriodPopUpInDropDownList.click();
	WaitForAjax();
	
	
}

public void verifyActualHoursLinkDisplayedAndWorking() {
	WaitForAjax();
	waitABit(10000);
	//boolean isSchedule = false;
	//boolean isMyTeamAVS = pageTitle.containsText("Actual vs. Scheduled");
	//String seletedpayPeriod = payPeriodInputBoxDropDownList.getText().toString();
	actualHourLink.shouldBeVisible();
	System.out.println("Actual Hour Link is visible");
	actualHourLink.waitUntilClickable().then().click();
	
	/*
	WaitForAjax();
	individualTimecardOrMyTimecardPage.shouldBeEnabled();
	System.out.println("Successfully Navigated.. Actual Hour link is working");
	
	nav.wfnmainPageNavigation("myself", "Time & Attendance", "Actual vs Scheduled") ;
	WaitForAjax();
	
	*/
	/*navigationFromAVS(isSchedule, isMyTeamAVS);
	navigationBackToAVS(isMyTeamAVS);
	*/
	//selectPayPeriod(seletedpayPeriod);
	
	
}

public void verifyScheduleHoursLinkDisplayedAndWorking() {
	WaitForAjax();
	waitABit(5000);
//	boolean isSchedule = true;
	//boolean isMyTeamAVS = pageTitle.containsText("Actual vs. Scheduled");
	//String seletedpayPeriod = payPeriodInputBoxDropDownList.getText().toString();
	scheduleHourLink.shouldBeVisible();
	System.out.println("Scheduled Hour Link is visible");
	scheduleHourLink.waitUntilClickable().then().click();
	
	/*
	WaitForAjax();
	monthlyScheduleOrMySchedulePage.shouldBeEnabled();
	System.out.println("Successfully Navigated.. Schedule Hour link is working" + "akki");
	nav.wfnmainPageNavigation("myself", "Time & Attendance", "Actual vs Scheduled"); 
	WaitForAjax();
	*/
	/*navigationFromAVS(isSchedule, isMyTeamAVS);
	navigationBackToAVS(isMyTeamAVS);
	selectPayPeriod(seletedpayPeriod);
	*/
}

public void verifyScheduleLinkInMoreLinkIsWorking() {
	WaitForAjax();
	waitABit(20000);
	//boolean isSchedule = true;
	//boolean isMyTeamAVS = pageTitle.containsText("Actual vs. Scheduled");
	//String seletedpayPeriod = payPeriodInputBoxDropDownList.getText().toString();
	MoreLink.isEnabled();
	System.out.println("More Link is enabled");
	MoreLink.waitUntilClickable().then().click();
	waitABit(2000);
	scheduleLinkInMoreLink.waitUntilClickable().then().click();
	WaitForAjax();
	waitABit(20000);
/*	boolean isSchedule = getDriver().findElement(By.xpath("//*[@id='SchedulingCalendarMonthlyView.History']")).isDisplayed();
	try {
	if(isSchedule) {
	mySchedulePage.shouldBeEnabled();
	System.out.println("Successfully navigated to My Schedule page");
	}
	}
	catch(Exception e)
	{
		monthlySchedulePage.shouldBeEnabled();
		System.out.println("Successfully navigated to Monthly Schedule page");
	}*/
	
	}
	//navigationFromAVS(isSchedule, isMyTeamAVS);
	//navigationBackToAVS(isMyTeamAVS);
	
	/*
	monthlyScheduleOrMySchedulePage.shouldBeEnabled();
	System.out.println("Successfully Navigated..");
	WaitForAjax();
	waitABit(6000);
	nav.wfnmainPageNavigation("myself", "Time & Attendance", "Actual vs Scheduled"); /
	WaitForAjax();
	*/
	
	//selectPayPeriod(seletedpayPeriod);
	


public void verifyTimecardLinkInMoreLinkIsWorking() {
	WaitForAjax();
	waitABit(20000);
	//boolean isSchedule = false;
	//boolean isMyTeamAVS = pageTitle.containsText("Actual vs. Scheduled");
	//String seletedpayPeriod = payPeriodInputBoxDropDownList.getText().toString();
	MoreLink.isEnabled();
	System.out.println("More Link is enabled");
	MoreLink.waitUntilClickable().then().click();
	waitABit(10000);
	timecardLinkInMoreLink.waitUntilClickable().then().click();
	WaitForAjax();
	waitABit(10000);
	/*boolean myTimecard = getDriver().findElement(By.xpath("//*[@id='anchrPayClassDetails']")).isDisplayed();
	if(myTimecard) {
		individualTimecardPage.shouldBeEnabled();
		System.out.println("Successfully navigated to Individual Timecard page");
		
	}
	else 
	{
		myTimecardPage.shouldBeEnabled();
		System.out.println("Successfully navigated to My Timecard page");

	}*/
	}
	
	//navigationFromAVS(isSchedule, isMyTeamAVS);
	//navigationBackToAVS(isMyTeamAVS);
	/*
	individualTimecardOrMyTimecardPage.shouldBeEnabled();
	System.out.println("Successfully Navigated..");
	WaitForAjax();
	waitABit(6000);
	nav.wfnmainPageNavigation("myself", "Time & Attendance", "Actual vs Scheduled"); /
	WaitForAjax();
	*/
	
	//selectPayPeriod(seletedpayPeriod);




public void selectOtherPayPeriodForDate(String pickDate) {
	WaitForAjax();
	waitABit(20000);
	selectDateInCalendar(pickDate);
	WaitForAjax();
}

public void selectOtherPayPeriod(String selectDate1, String selectDate2,String selectDate3) {
	WaitForAjax();
	waitABit(20000);
	selectDateInCalendar(selectDate1);
	WaitForAjax();
	waitABit(10000);
	payPeriodInputBoxDropDownList.shouldContainText("Other Pay Period (Enter Date)");
	System.out.println("Other Pay Period is Selected");
	timeCardNotDisplayedMessage.isEnabled();
	System.out.println("Cannot display timecard information because this employee's current and next pay cycle dates are prior to today.:correct");
	
	
	WaitForAjax();
	waitABit(5000);
	selectDateInCalendar(selectDate2);
	WaitForAjax();
	waitABit(10000);
	payPeriodInputBoxDropDownList.shouldContainText("Other Pay Period (Enter Date)");
	System.out.println("Other Pay Period is Selected");
	timeCardNotDisplayedMessage.isEnabled();
	System.out.println("Cannot display timecard information because this employee's current and next pay cycle dates are prior to today.:correct");
	
	WaitForAjax();
	waitABit(20000);
	selectDateInCalendar(selectDate3);
	WaitForAjax();
	waitABit(10000);
	payPeriodInputBoxDropDownList.shouldContainText("Other Pay Period (Enter Date)");
	System.out.println("Other Pay Period is Selected");
	/*verifyActualHoursLinkDisplayedAndWorking();
	verifyScheduleLinkInMoreLinkIsWorking();
	verifyPayCodeColumnInPayrollSummary();
	*/
	
}

public void selectDateInCalendar(String selectDate){
	String dateSplit[] = selectDate.split(" ");
	String dateOnly = dateSplit[0];
	String month = dateSplit[1];
	String year = dateSplit[2];
	
	calenderDatePicker.waitUntilClickable();
	calenderDatePicker.click();
	WaitForAjax();
	
	monthSelecterInCalandar.click();
	waitABit(1000);
	
	String monthXpath = "//div[contains(text(),'" + month + "')]";
	getDriver().findElement(By.xpath(monthXpath)).click();
	waitABit(1000);
	
	yearSelecterInCalandar.click();
	waitABit(1000);
	String yearXpath = "//div[contains(text(),'" + year + "')]";
	
	getDriver().findElement(By.xpath(yearXpath)).click();
	waitABit(1000);
	
	
	waitABit(1000);
	String dateOnlyXpath = "//div[@class='calendar-grid-item-day' and text() = '"+ dateOnly + "']";
	getDriver().findElement(By.xpath(dateOnlyXpath)).click();
	waitABit(1000);
	//div[@class='calendar-grid-item-day' and text() = '1']
	WaitForAjax();
	
}

public void verifyNavigationPage(String pageBeforeNavigation){
	String currentPage =  getCurrentPage();
}

public String getCurrentPage(){
	String currentPage=null;
	WaitForAjax();
	currentPage = currentPageNode.getText().toString().toUpperCase();
	return currentPage;
}

public void verfyTodayPayPeriodIsSelected() {
	WaitForAjax();
	waitABit(20000);
	defaultPayPeriodToday.isEnabled();
	System.out.println("By default Today pay period is selected in dropdown list");
}

public void verifyTimeCardInfoPayrollSummaryApprovalLinkShouldNotEnabled() {
	
	WaitForAjax();
	waitABit(20000);
	timeCardNotDisplayedMessage.isEnabled();
	System.out.println("Cannot display timecard information because this employee's current and next pay cycle dates are prior to today.:correct");
	
	approvalTimeCardLink.shouldNotBePresent();
	System.out.println("Approval TimeCard link is not present:correct");

	approvedTimeCardLink.shouldNotBePresent();
	System.out.println("Approved TimeCard link is not present:correct");
	
	payrollSummaryTableAndItsColumnShouldNotPresent();
	
}

public void payrollSummaryTableAndItsColumnShouldNotPresent(){
	
	redistributedHoursColumnPayrollSummary.shouldNotBePresent();
	System.out.println("Redistributed Hour column in payroll summary is not present:correct");
	finalHoursColumnPayrollSummary.shouldNotBePresent();
	System.out.println("Final Hour column in payroll summary is not present:correct");
	hoursColumnPayrollSummary.shouldNotBePresent();
	System.out.println("Hour column in payroll summary is not present:correct");
	payCodeColumnPayrollSummary.shouldNotBePresent();
	System.out.println("Paycode column in payroll summary is not present:correct");
	daysColumnPayrollSummary.shouldNotBePresent();
	System.out.println("Days column in payroll summary is not present:correct");	
}

public void selectCurrentPayPeriod() {
	WaitForAjax();
	waitABit(30000);

	selectPayPeriodDropDownListPicker.waitUntilVisible();
	selectPayPeriodDropDownListPicker.waitUntilClickable();
	selectPayPeriodDropDownListPicker.click();
	System.out.println("Selected list picker in Pay period List");
	
	WaitForAjax();
	currentPayPeriodInDropDownList.waitUntilClickable();
	currentPayPeriodInDropDownList.click();
	WaitForAjax();
	payPeriodInputBoxDropDownList.shouldContainText("Current Pay Period"); 
	System.out.println("Current Pay period is selected in Pay period list");
	
}

public void selectNextPayPeriod() {
	WaitForAjax();
	waitABit(20000);

	selectPayPeriodDropDownListPicker.waitUntilVisible();
	selectPayPeriodDropDownListPicker.waitUntilClickable();
	selectPayPeriodDropDownListPicker.click();
	System.out.println("Selected list picker in Pay period List");
	
	WaitForAjax();
	nextPayPeriodInDropDownList.waitUntilClickable();
	nextPayPeriodInDropDownList.click();
	WaitForAjax();
	payPeriodInputBoxDropDownList.shouldContainText("Next Pay Period");
	System.out.println("Next Pay period is selected in Pay period list");
	
}

public void selectPreviousPayPeriod() {
	WaitForAjax();
	waitABit(20000);

	selectPayPeriodDropDownListPicker.waitUntilVisible();
	selectPayPeriodDropDownListPicker.waitUntilClickable();
	selectPayPeriodDropDownListPicker.click();
	System.out.println("Selected list picker in Pay period List");
	
	WaitForAjax();
	previousPayPeriodInDropDownList.waitUntilClickable();
	previousPayPeriodInDropDownList.click();
	WaitForAjax();
	payPeriodInputBoxDropDownList.shouldContainText("Previous Pay Period");
	System.out.println("Previous Pay period is selected in Pay period list");
	
}

public void verifyMoreLink() {
	WaitForAjax();
	verifyScheduleLinkInMoreLinkIsWorking();
	System.out.println("	schedule link in more link is working");
	verifyTimecardLinkInMoreLinkIsWorking();
	System.out.println("	timecard link in more link is working");
}

public void searchEmployeeOnMyTeamAVSPage(String employee) {
	WaitForAjax();
	waitABit(10000);
	String nameWithFormat = shownEMployeeNameFormat(employee);
	//*[contains(@id,'idBarSscrollGridIdCol_Id')]//span[@title='emp2, auto' ]
	searchButtonOnMyTeamAVS.waitUntilClickable().then().click();
	WaitForAjax();
	waitABit(5000);
	searchTextBoxOnMyTeamAVS.sendKeys(nameWithFormat);
	waitABit(2000);
	String xpathForSelectingEmployee = "//*[contains(@id,'idBarSscrollGridIdCol_Id')]//span[@title='"+ nameWithFormat + "' ]";
	getDriver().findElement(By.xpath(xpathForSelectingEmployee)).click();
	WaitForAjax();
	waitABit(5000);
	
}

public String shownEMployeeNameFormat(String employeeName){
	String empName[] = employeeName.split(" ");
	String nameWithFormat = empName[1] +", " + empName[0];
	return nameWithFormat;
}

public void navigationFromAVS(boolean isSchedule, boolean isMyTeamAVS){
	WaitForAjax();
	waitABit(10000);
	if(isMyTeamAVS){
		if(isSchedule){
			monthlySchedulePage.shouldBeEnabled();
			System.out.println("Successfully navigated to Monthly Schedule page");
		}
		else{
			individualTimecardPage.shouldBeEnabled();
			System.out.println("Successfully navigated to Individual Timecard page");
		}
	/*	waitABit(2000);
		nav.wfnmainPageNavigation("MyTeam", "Time & Attendance", "Actual vs. Scheduled"); 
		WaitForAjax();
		waitABit(10000); */
	}
	else{
		if(isSchedule){
			mySchedulePage.shouldBeEnabled();
			System.out.println("Successfully navigated to My Schedule page");
		}
		else{
			myTimecardPage.shouldBeEnabled();
			System.out.println("Successfully navigated to My Timecard page");
		}
		
	}
	
}

public void navigationBackToAVS(boolean isMyTeamAVS){
	waitABit(2000);
	if(isMyTeamAVS)
		nav.wfnmainPageNavigation("MyTeam", "Time & Attendance", "Actual vs. Scheduled"); 
	else
		nav.wfnmainPageNavigation("Myself", "Time & Attendance", "Actual vs Scheduled");  
	WaitForAjax();
	waitABit(10000);
	System.out.println("Successfully navigated back to Actual vs Schedule Page");
	
}

public void selectPayPeriodInTimeCard(String payPeriod){

	WaitForAjax();
	String inputValue = inputBoxPayPeriodOnTimeCard.getValue();
	if(!inputValue.equals(payPeriod)){
		payPeriodlistPickerOnTimeCard.click();
		waitABit(1000);
		String xpathPayPeriod = "//*[contains(@id, 'dateRangeselect') and text()='"+ payPeriod +"']";
		getDriver().findElement(By.xpath(xpathPayPeriod)).click();
		System.out.println(payPeriod + "is selected in TimeCard");
		WaitForAjax();
		waitABit(3000);
	}
}

public void verifyTimeCardApprovalHistoryLinkWorking() {
	WaitForAjax();
	timeCardApprovalHistoryLink.isEnabled();
	System.out.println("TimeCard Approval History link is enabled");
	timeCardApprovalHistoryLink.waitUntilClickable().then().click();
	WaitForAjax();
	waitABit(10000);
	
	timeCardApprovalHistoryLinkSliderTitle.shouldBeVisible();
	if(timeCardApprovalHistoryLinkSliderNoDataMessage.isPresent()){
		System.out.println("There is no data for timecard approval history:correct");
	}
	else{
	waitABit(2000);
	timeCardApprovalHistoryLinkSliderColumnChangeDate.shouldBePresent();
	timeCardApprovalHistoryLinkSliderColumnEditReason.shouldBePresent();
	}
	backButtonSliderAVS.click();
	WaitForAjax();
}


public void verifyEditAuditHistoryLinkWorking() {
	WaitForAjax();
	editAuditHistoryLink.isEnabled();
	System.out.println("Edit Audit History link is enabled");
	editAuditHistoryLink.waitUntilClickable().then().click();
	
	WaitForAjax();
	waitABit(10000);
	
	editAuditHistoryLinkSliderTitle.isEnabled();
	System.out.println("Edit Audit History link Slider's Title is enabled");
	
	WebElement innerFrame = getDriver().findElement(By.xpath("//iframe[@class='inner-frame']"));
	getDriver().switchTo().frame(innerFrame);
	WaitForAjax();
	
	editAuditHistoryLinkSliderTimeZoneBox.isDisplayed();
	System.out.println("Edit Audit History link Slider's Time zone box is displayed");
	editAuditHistoryLinkSliderAllDateText.isDisplayed();
	System.out.println("Edit Audit History link Slider's All date text is displayed");
	editAuditHistoryLinkSliderTimePairEditAuditText.isDisplayed();
	System.out.println("Edit Audit History link Slider's All time Pair edit text is displayed");
	waitABit(2000);
	editAuditHistoryLinkSliderColumnAction.isDisplayed();
	System.out.println("Edit Audit History link Slider's Action Column is displayed");
	editAuditHistoryLinkSliderColumnChangedBy.isDisplayed();
	System.out.println("Edit Audit History link Slider's Change by Column is displayed");
	
	editAuditHistoryLinkSliderColumnDateofChange.isDisplayed();
	System.out.println("Edit Audit History link Slider's Date of change column is displayed");
	
	editAuditHistoryLinkSliderColumnReason.isDisplayed();
	System.out.println("Edit Audit History link Slider's Reason Column is displayed");
	
	getDriver().switchTo().defaultContent();
	
	backButtonSliderAVS.click();
	WaitForAjax();
}

public void verifyToggleButtonShouldNotBeEnabled() {
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	WaitForAjax();
	ToggleButtonChangeValueDollarAmount.shouldNotBePresent();
	System.out.println("Toggle button is not enabled: correct");
	
	
}

public void changeRedistributionHourFlagInPayClass(String flag, String payClass) {
	WaitForAjax();
	gotoPayclass(payClass);
	
	selectFrame(AdditionalConfigurationMainPageFrame);
	WaitForAjax();
	System.out.println("EZlm frame is selected");
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 500);");
	WaitForAjax();
	selectFrame(AdditionalConfigurationPayClassFrame); //to be removed
	System.out.println("EZlm inner frame1 is selected");
	WaitForAjax();  
	
	WebDriver driver2 = getDriver();
	JavascriptExecutor jse2 = (JavascriptExecutor) driver2;
	jse2.executeScript("scroll(0, 300);");
	System.out.println("Scrolled down");
	
	
	
	
	WebElement checkBox = getDriver().findElement(By.id("chkShowRedistHrs"));
	
	String currentCheckBoxValue = checkBox.getAttribute("aria-checked").toLowerCase();
	if(currentCheckBoxValue.equals(flag)) {
		System.out.println("Show Redistribution Hour Flag is already " + flag);
		
	}
	else
	{
		checkBox.click();
		System.out.println("Checked the box");
		getDriver().findElement(By.id("barButtons_btnSubmit")).click();
		WaitForAjax();
	}
	WaitForAjax();
	switchToDefaultContent();
	
}

public void changeRedistributionHourFlagInPayClassTLM(String flag, String payClass) {
	WaitForAjax();
	gotoPayclassTLM(payClass);
	
	selectFrame(AdditionalConfigurationMainPageTLMFrame);
	WaitForAjax();
	System.out.println("EZlm frame is selected");
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 500);");
	WaitForAjax();
	selectFrame(AdditionalConfigurationPayClassFrame); //to be removed
	System.out.println("EZlm inner frame1 is selected");
	WaitForAjax();  
	
	WebDriver driver2 = getDriver();
	JavascriptExecutor jse2 = (JavascriptExecutor) driver2;
	jse2.executeScript("scroll(0, 300);");
	System.out.println("Scrolled down");
	
	
	
	
	WebElement checkBox = getDriver().findElement(By.id("chkShowRedistHrs"));
	
	String currentCheckBoxValue = checkBox.getAttribute("aria-checked").toLowerCase();
	if(currentCheckBoxValue.equals(flag)) {
		System.out.println("Show Redistribution Hour Flag is already " + flag);
		
	}
	else
	{
		checkBox.click();
		System.out.println("Checked the box");
		getDriver().findElement(By.id("barButtons_btnSubmit")).click();
		WaitForAjax();
	}
	WaitForAjax();
	switchToDefaultContent();
	
}


public void gotoPayclass(String payClass){
	WaitForAjax();
	selectFrame(AdditionalConfigurationMainPageFrame);
	payClassInAddtionConfiguration.waitUntilClickable().then().click();
	WaitForAjax();
	
	selectFrame(AdditionalConfigurationPayClassFrame);
	WaitForAjax();
	
	
	String xpathPayClass = "//a[text()='" + payClass + "']";
	getDriver().findElement(By.xpath(xpathPayClass)).click();
	WaitForAjax();  
	System.out.println("PayClass" + payClass + " is selected");
		
	switchToDefaultContent();
	
	WaitForAjax();  
	
}

public void gotoPayclassTLM(String payClass){
	WaitForAjax();
	selectFrame(AdditionalConfigurationMainPageTLMFrame);
	payClassInAddtionConfiguration.waitUntilClickable().then().click();
	WaitForAjax();
	waitABit(2000);
	selectFrame(AdditionalConfigurationPayClassFrame);
	WaitForAjax();
	String xpathPayClass = "//*[@id='BDY_Content']//a[text()='" + payClass + "']";
	getDriver().findElement(By.xpath(xpathPayClass)).click();
	WaitForAjax();  
	System.out.println("PayClass" + payClass + " is selected");
		
	switchToDefaultContent();
	
	WaitForAjax();  
	
}
public void verifyRedistributedHourAndFinalHourColumnShouldNotBeDisplayed() {
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	
	redistributedHoursColumnPayrollSummary.shouldNotBePresent();
	System.out.println("redisribution hour column is not present in payroll summary : correct");
	
	finalHoursColumnPayrollSummary.shouldNotBePresent();
	System.out.println("final hour is not present in payroll summary: correct");
	
	
	
}

public void changeMaskingOfAmount(String enableOrDisableMasking) {
	WaitForAjax();
	manageProfileButtonAtAccessPermission.waitUntilClickable().then().click();
	WaitForAjax();
	
	standardTimeAndAttendaceSupervisorForAccessPermission.waitUntilClickable().then().click();
	WaitForAjax();
	
	sensitivePersonalInfo.waitUntilClickable().then().click();
	WaitForAjax();

		if (enableOrDisableMasking.equals("enableMasking")) {
			if (maskingDisabledForSupervisorBoxChecked.isPresent()) {
				System.out.println("masking is disabled.. going to change it");
				
				//enableMaskingForSupervisor.waitUntilClickable().then().click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//span[contains(text(),'Screens')]/../i[1]")).click();
				System.out.println("Masking Enabled");
			}
			else
				System.out.println("Masking is already Enabled");
		}
		else if(enableOrDisableMasking.equals("disableMasking")) {
			if(maskingDisabledForSupervisorBoxChecked.isPresent()){
				System.out.println("Masking is already disabled");
			}
			else{
				//disableMaskingForSupervisor.waitUntilClickable().then().click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//span[contains(text(),'Screens')]/../i[1]")).click();
			
				System.out.println("Masking Disabled");
			}
		}
		
		saveButtonProfileInSensitivePersonalInfo.click();

}

public void verifyOvertimeLink() {
	waitABit(2000);
	nav.wfnmainPageNavigation("MyTeam", "Time & Attendance", "Actual vs. Scheduled"); 
	WaitForAjax();
	waitABit(10000);
	
	
	
	
}

public void verifyRegularLink() {
	// TODO Auto-generated method stub
	
}

public void verifyLegendInMoreLinkIsWorking() {
	// TODO Auto-generated method stub
	WaitForAjax();
	waitABit(10000);
	MoreLink.isEnabled();
	System.out.println("More Link is enabled");
	MoreLink.waitUntilClickable().then().click();
	waitABit(2000);
	legendLinkInMoreLink.waitUntilClickable();
	legendLinkInMoreLink.click();
	waitABit(5000);
	backInLegend.waitUntilClickable();
	backInLegend.click();
	
	
}

public void searchEmployeeOnMyTeamAVSTLMPage(String employee) {
	WaitForAjax();
	waitABit(10000);
	//String nameWithFormat = shownEMployeeNameFormat(employee);
	searchTextBoxOnMyTeamAVSTLM.sendKeys(employee);
	waitABit(2000);
	String xpathForSelectingEmployee = "//table[@class='dgrid-row-table']//*[contains(text(),'"+ employee + "') ]";
	getDriver().findElement(By.xpath(xpathForSelectingEmployee)).click();
	WaitForAjax();
	waitABit(5000);
	
	}

public void verifyThatEditAuditLinkIsWorkingStep() {
	WaitForAjax();
	editAuditLink.isEnabled();
	System.out.println("Edit Audit History link is enabled");
	editAuditLink.waitUntilClickable().then().click();
	
	WaitForAjax();
	waitABit(10000);
	
	editAuditHistoryLinkSliderTitle.isEnabled();
	System.out.println("Edit Audit History link Slider's Title is enabled");
	
	WebElement innerFrame = getDriver().findElement(By.xpath("//iframe[@class='inner-frame']"));
	getDriver().switchTo().frame(innerFrame);
	WaitForAjax();
	
	editAuditHistoryLinkSliderTimeZoneBox.isDisplayed();
	System.out.println("Edit Audit History link Slider's Time zone box is displayed");
	editAuditHistoryLinkSliderAllDateText.isDisplayed();
	System.out.println("Edit Audit History link Slider's All date text is displayed");
	editAuditHistoryLinkSliderTimePairEditAuditText.isDisplayed();
	System.out.println("Edit Audit History link Slider's All time Pair edit text is displayed");
	waitABit(2000);
	editAuditHistoryLinkSliderColumnAction.isDisplayed();
	System.out.println("Edit Audit History link Slider's Action Column is displayed");
	editAuditHistoryLinkSliderColumnChangedBy.isDisplayed();
	System.out.println("Edit Audit History link Slider's Change by Column is displayed");
	
	editAuditHistoryLinkSliderColumnDateofChange.isDisplayed();
	System.out.println("Edit Audit History link Slider's Date of change column is displayed");
	
	editAuditHistoryLinkSliderColumnReason.isDisplayed();
	System.out.println("Edit Audit History link Slider's Reason Column is displayed");
	
	getDriver().switchTo().defaultContent();
	
	backButtonSliderAVS.click();
	WaitForAjax();
	
}

public void verifyTimeCardApprovedLinkNotPossible() {
	WaitForAjax();
	waitABit(10000);
	approvalTimeCardNotPossibleLink.shouldBePresent();
	System.out.println("Approval Not Possible TimeCard link is present");
	
}

public void changeMaskingTLMOfAmount(String enableOrDisableMasking) {
	WaitForAjax();
	manageProfileButtonAtAccessPermission.waitUntilClickable().then().click();
	WaitForAjax();
	
	standardSupervisorForAccessPermission.waitUntilClickable().then().click();
	WaitForAjax();
	
	sensitiveOption.waitUntilClickable().then().click();
	WaitForAjax();

		if (enableOrDisableMasking.equals("enableMasking")) {
			if (maskingDisabledForSupervisorBoxChecked.isPresent()) {
				System.out.println("masking is disabled.. going to change it");
				
				//enableMaskingForSupervisor.waitUntilClickable().then().click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//span[contains(text(),'Screens')]/../i[1]")).click();
				System.out.println("Masking Enabled");
			}
			else
				System.out.println("Masking is already Enabled");
		}
		else if(enableOrDisableMasking.equals("disableMasking")) {
			if(maskingDisabledForSupervisorBoxChecked.isPresent()){
				System.out.println("Masking is already disabled");
			}
			else{
				//disableMaskingForSupervisor.waitUntilClickable().then().click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//span[contains(text(),'Screens')]/../i[1]")).click();
			
				System.out.println("Masking Disabled");
			}
		}
		
		saveButtonProfileInSensitivePersonalInfo.click();

	
}

public void SelectTimeAttendanceAndEnableTimecardApprovalForEmployee() {
	WaitForAjax();
	timeAndAttendanceLink.waitUntilClickable().then().click();
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	if (confirmMessage.isPresent()) {
		System.out.println("Employee is already allowed to approve Timecard");
		
	}
	else
	{
		System.out.println("Employee is not allowed to approve Timecard going to change it");
		waitABit(2000);
		getDriver().findElement(By.xpath("//*[@id='chkAllowEmpTimeCard']")).click();
		System.out.println("Employee is already allowed to approve Timecard");
		submitButton.click();
	}
	
}


public void CheckActualHoursAndScheduleHoursTimePairs() {
	WaitForAjax();
	if (ActualHoursLink.isPresent()) {
		System.out.println("Actual hours time pairs are present");
		
	}
	else
	{
		System.out.println("Actual hours time pairs are not present");
	}
	if (ScheduleHoursLink.isPresent()) {
		System.out.println("Actual hours time pairs are present");
		
	}
	else
	{
		System.out.println("Schedule hours time pairs are not present");
	}
	
	
}

public void VerifySupplementalPaycodeLinksOpeningPopUpInPayrollSummary() {
	WaitForAjax();
	int payCodeCount = supplementalpayCodeListPayrollSummary.size();
	System.out.println("number of different paycodes are = " + payCodeCount);
	int i = payCodeCount;
	while(i!=0){
		String xpathVal = "(//tr[@paycode])[" + i + "]//td[1]//a";
		getDriver().findElement(By.xpath(xpathVal)).click();
		System.out.println("Supplemental PayCode " + i +"link of opening pop-Up:");
		verifyPaycodePopUp();
		WaitForAjax();
		i--;
	}
	if(i==0)
		System.out.println(" All links for Supplemental paycode in payroll Summary are working");
	
}

public void verifyAmountFormatAsAAAAInPreferences() {
	WaitForAjax();
	waitABit(20000);
	employeeId.waitUntilClickable().then().click();
	preferencesLink.waitUntilClickable().then().click();
	waitABit(10000);
    contentLink.click();
	waitABit(10000);
	System.out.println("Content is selected");
    WebElement innerFrame = getDriver().findElement(By.xpath("//iframe[@id='eZlmIFrameUserPrefTlm_iframe']"));
	getDriver().switchTo().frame(innerFrame);
//	selectFrame(ezLMIFrameUserPref);
	System.out.println("iframe is selected");
	WaitForAjax();
	waitABit(10000);
    WebElement twodec = getDriver().findElement(By.xpath("//input[@id='radAmountTwoDecimals']"));
    twodec.click();
	//amountTwoDec.isDisplayed();
	System.out.println("Element visible");
	//amountTwoDec.waitUntilClickable().then().click();
	System.out.println("Amount with 2 decimals is selected");
	waitABit(5000);
	//submitButton.click();
	   WebElement submitButton = getDriver().findElement(By.xpath("//span[@id='btnSubmit']"));
	   submitButton.click();
	waitABit(5000);
	getDriver().switchTo().defaultContent();
	 WebElement backIn = getDriver().findElement(By.xpath("//*[@id='revit_dialog_FocusSlideIn_0']/div/span"));
	System.out.println("Switched");
	backIn.click();
	WaitForAjax();
	waitABit(5000);
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	if(pageTitle.containsText("Actual vs Scheduled"))
		ChangeToggleCheckButtonAmount();
	int numberofCoulmn = numberOfColumnInpayrollSummary.size();
	int payCodeCount = payCodeListPayrollSummary.size();
	String xpathAmountForDifferentPaycodes = null;
	
	int i=1;
	while(i!=payCodeCount){		
	    xpathAmountForDifferentPaycodes = "(//tr[@paycode])[" + i + "]//td[" + numberofCoulmn + "]";
	    String amountValue = getDriver().findElement(By.xpath(xpathAmountForDifferentPaycodes)).getText().toString();
	
	    if(amountValue.equals("0.00")){
	    	 System.out.println("True");
	    }
		
		i++;
	}
	if(pageTitle.containsText("Actual vs Scheduled"))
		ChangeToggleCheckButtonAmount();
	WaitForAjax();
	
	
}

public void VerifySupplementalPaycodesAmountIsNotMasked() {
	WaitForAjax();
	WebDriver driver = getDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("scroll(0, 250);");
	WaitForAjax();
    ToggleButtonChangeValueDollarAmount.shouldNotBePresent();
	ChangeToggleCheckButtonAmount();
	verifyAmountMaskingIsDisabled();
	
	
}

public void UpdateNotesAndVerifyUponHover() {
	 waitABit(10000);
	    WaitForAjax();
  
        getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='emp-cell-action-container']/div/div[@class='shift-edit-action fa fa-edit'])[1]")).click();
        waitABit(1000);
        System.out.println("Hover completed");               
        scheduleEdit.click();
	    waitABit(1000);
		EditShiftDialog.waitUntilVisible();
		System.out.println("Dialog opened");
	    edittextarea.clear();
	    edittextarea.sendKeys("Test");
		SaveButton.click();
	      waitABit(2000);
	      getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='emp-cell-action-container']/div/div[@class='shift-edit-action fa fa-edit'])[1]")).click();
	      System.out.println("Verified Hover");   
}

public void VerifyPageIsNotLoadedForTerminatedEmployee() {
	 waitABit(10000);
	    WaitForAjax();
		timeCardErrorMessage.isEnabled(); 
		System.out.println("The position for this employee is not configured to use Time & Attendance.:correct");
}

public void VerifyActualVsSchedulePageIsLoading() {
	 waitABit(10000);
	    WaitForAjax();
	   ActualVsScheduledTitle.shouldBePresent(); 
	
}

public void DeleteScheduleNoteforAShift() {
	 waitABit(10000);
	    WaitForAjax();
     getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@class='emp-cell-action-container']/div/div[@class='shift-edit-action fa fa-edit'])[1]")).click();
     waitABit(1000);
     System.out.println("Hover completed");               
     scheduleEdit.click();
	    waitABit(1000);
		EditShiftDialog.waitUntilVisible();
		System.out.println("Dialog opened");
	    edittextarea.clear();
		SaveButton.click();

	
}

public void VerifyStartDateOfThePeriod() {
	 waitABit(10000);
	    WaitForAjax();
	    startdate.shouldBePresent();
	System.out.println("Start date is verified");
}

public void AddShiftWithParentLCFAndVerifyChildLCFValuesAreDisplayed() {
	 waitABit(10000);
	    WaitForAjax();
	    getDriver().findElement(org.openqa.selenium.By.xpath("(//div[@title='Add Shift'])[1]")).click();
	     waitABit(1000);
			AddShiftDialog.waitUntilVisible();
			System.out.println("Dialog opened");
     		StartTimeTextBox.sendKeys("1:30");
     		StartTimeTextBox.sendKeys(Keys.TAB);
     		EndTimeTextBox.sendKeys("2:30");
     		waitABit(2000);
     		ShiftDurationTextBox.sendKeys(Keys.TAB);
     		Departmentlookup.click();
    		waitABit(2000);
            System.out.println("Look up clicked");
    		Departmentfirst.click();		
            System.out.println("Department selected"); 
     		waitABit(1000);
     		Joblookup.click();
    		waitABit(2000);
            System.out.println("Look up clicked");
    		Jobfirst.click();		
            System.out.println("Job selected"); 
     		waitABit(1000);
     		SaveButton.click();
}

public void VerifyPreceedingZeroValue() {
	 waitABit(10000);
	    WaitForAjax();
	    preceedingZero.isPresent();
	   System.out.println("Preceeded by zero"); 
	
}

public void VerifyApprovedPTO() {
	 waitABit(10000);
	    WaitForAjax();
	   approvedPTO.isPresent();	
}

}