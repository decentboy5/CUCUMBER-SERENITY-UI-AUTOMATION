package com.adp.tlmbdd.pages.editors;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import com.adp.tlmbdd.pages.GenericPageObject;

public class PayCycle extends GenericPageObject {
	
	@FindBy(xpath = ".//*[@id='btnAddNew']")
	private WebElementFacade addNewPayCycleButton;
	
	@FindBy(xpath = ".//*[@id='txtPayCycleID']")
	private WebElementFacade PayCycleID;
	
	@FindBy(xpath = ".//*[@id='multiDesc']")
	private WebElementFacade PayCycleDesc;
	
	@FindBy(xpath = ".//*[@id='ddlCalcType']")
	private WebElementFacade PayFrequencyddl;
	
	@FindBy(xpath = ".//*[@id='ddlIntegratedSystem']")
	private WebElementFacade IntegratedSystemddl;
	
	@FindBy(xpath = ".//*[@id='calCurrPayCyStDate']")
	private WebElementFacade CurrentPayCycleStartDate;
	
	
	public void createPayCycle(String PayFrequency, String IntegratedSystem)
	{
		
		addNewPayCycleButton.click();
		PayCycleID.sendKeys("aa");
		PayCycleDesc.sendKeys("aa");
		PayFrequencyddl.selectByVisibleText(PayFrequency);
		IntegratedSystemddl.selectByVisibleText(IntegratedSystem);
		CurrentPayCycleStartDate.sendKeys("04/12/2017");
		addNewPayCycleButton.click();
		
	}

}
