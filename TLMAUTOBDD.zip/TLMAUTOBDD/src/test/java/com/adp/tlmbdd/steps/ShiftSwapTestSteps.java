package com.adp.tlmbdd.steps;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import com.adp.tlmbdd.pages.editors.ShiftSwapTest;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class ShiftSwapTestSteps extends ScenarioSteps {
	
	ShiftSwapTest  SftSwpTst;
	
	@Step
	public void deleteNotifications(){
		SftSwpTst.deleteAllNotifications();
	}
	
	@Step
	public void senderCancelAllSwapRequests() throws IOException {
		SftSwpTst.cancelAllSwapRequestsBySender( );

	}
	
	@Step
	public void senderCancelAllSwapRequestsPendingForApproval() throws IOException {
		SftSwpTst.cancelAllSwapRequestsBySenderPendingForApproval( );

	}
	
	@Step
	public void createShiftSwapRequest(String reciever) throws IOException {
		SftSwpTst.createSwapRequest(reciever);

	}

	@Step
	public void verifyShiftSwapRequestBySuccessPopUp( ) throws IOException{
		SftSwpTst.verifySwapRequestBySuccessPopUp( );
	}
	
	@Step
	public void verifySentSwapBox()  throws IOException{
		SftSwpTst.verifySentSwapRequest( );
	}
	/*
	@Step
	public void verifyNotificationSentToSuperVisorAndRecipient(String Supervisor, String Recipient){
		SftSwpTst.verifySentRequestNotification(Supervisor, Recipient);
		
	} */
	
/////Scenario2///////////////
	
	
	@Step
	public void verifyRequestInNotification(String sender, String reciever) throws IOException{
		SftSwpTst.verifyRequestInNotification(sender,reciever);
	}
	
	@Step
	public void verifyAcceptedRequestInNotification(String sender, String reciever)throws IOException{
		SftSwpTst.verifyAcceptRequestInNotification(sender,reciever);
	}
	
	
	
	
	public void observRecivedRequest()
	{
		SftSwpTst.observRecivedBox();
	}
	
	@Step
	public void searchActiveSwapRequest( ) throws IOException{
		SftSwpTst.activeRequest( );
	}
	
	@Step
	public void acceptSwapRequestFromSlider( ) throws IOException{
		SftSwpTst.acceptRequestFromSlider( );
	}
	
	@Step
	public void acceptSwapRequestThroughPopUp() throws IOException{
		SftSwpTst.acceptRequestThroughPopUp( );
	}
	
	@Step
	public void verifyAcceptanceBySuccessMessage( ) throws IOException{
		SftSwpTst.verifyAcceptanceBySuccessBar( );
	}
	
	@Step
	public void verifyPendingApprovalBox()  throws IOException{
		SftSwpTst.verifyPendingApproval( );
	}
	
	@Step
	public void verifyAcceptNotification() throws IOException{
		SftSwpTst.acceptNotification( );
	}
	
	@Step
	public void declineSwapRequestThroughPopup() throws IOException{
		SftSwpTst.declineSwapRequestPopup( );
	}
	
	
	@Step
	public void declineRequestThrughSlider(){
		SftSwpTst.declineSwapRequestSlider();
	}
	
	@Step
	public void verifyDeclinedRequest(){
		SftSwpTst.verifyDeclineBySuccessBar();
	}
	
	@Step
	public void verifyDeclinedRecievedRequestMyschedule(){
		SftSwpTst.verifyDeclinedRecieveRequestByMySchedule();
	}
	
	@Step
	public void verifyDeclineRequestNotification(String sender, String recipient){
		SftSwpTst.verifyDeclinedNotication(sender, recipient);
	}
	
	////////////Scenario 3////////////
	@Step
	public void viewApprovalRequest( ) throws IOException{
	SftSwpTst.ViewApprovalRequestAtSchedule();
	}
	
	@Step
	public void verifyApprovalRequestFromSlider(String requester, String reciever) throws IOException{
	SftSwpTst.verifyApprovalRequest(requester, reciever);
	}
	
	@Step
	public void ApproveRequestFromViewSlider() throws IOException{
		SftSwpTst.approveRequestThroughViewSlider();
	}
	
	@Step
	public void verifyApprovedNotification(String sender, String recipient){
		SftSwpTst.verifyApproveNotication(sender,recipient );
	}
	
	@Step
	public void verifyApprovedNotification(String sender, String recipient, String supervisor){
		SftSwpTst.verifyApproveNotication(sender,recipient, supervisor );
	}
	
	
	public void verifyRejectRequestNotification(String supervisor, String sender, String recipient ){
		SftSwpTst.verifyRejectNotification(supervisor, sender, recipient );
	}
	
	@Step
	public void  rejectRequestThroughBannner(){
		SftSwpTst.rejectRequestThroughViewSlider();
	}
	
	@Step
	public void verifyRejectRequestNotification(String sender, String recipient){
		SftSwpTst.verifyRejectedRequestNotication(sender, recipient);
	}
	
	@Step
	public void ApproveRequestThroughPopUp(String sender) throws InterruptedException
	{
		SftSwpTst.ApproveRequestThroughPopUp(sender);
	}
	
	@Step
	public void rejectRequestThroughPopUp(String sender)
	{
		SftSwpTst.rejectRequestThroughPopUp(sender);
		
	}
	
	@Step
	public void cancelAllSentRequestThroughSlider(){
		SftSwpTst.cancelSentRequestsThroughSlider();
	}
	
	/// mutiple Swap request///
	
	@Step
	public void createMultipleSwapRequest(String reciever1, String reciever2) throws IOException {
		SftSwpTst.createMultipleSwapRequest(reciever1, reciever2);

	}
	
	@Step
	public void verifyMultipleEmpRequestNotification(String sender, String recipient1, String recipient2){
		
		SftSwpTst.verifyMultipleRecipientRequestInNotification(sender, recipient1, recipient2);
	}
	
	@Step
	public void verfyNotificationForAutomaticallyCancelledRequest(String sender, String recipient){
		SftSwpTst.verifyAutomaticCanceledRequest(sender, recipient);
	}

	@Step
	public void createRequestLastDayForNextMonthStep(String recipient){
		SftSwpTst.createRequestLastDayForNextMonth(recipient);
	}
	
	
	
	@Step
	public void verifyHolidayShiftNotOnTargetSlider(String recipient){
		SftSwpTst.verifyHolidayShiftNotInTargetSlider(recipient);
	}
	
	@Step
	public void verifyPTONotOnTargetSlider(String recipient){
		SftSwpTst.verifyPTOShiftNotInTargetSlider(recipient);
	}
	
	@Step
	public void verifyMaxDaySwapAllowed(int maxDaySwapAllowed){
		SftSwpTst.verifyMaxSwapAllowedDays(maxDaySwapAllowed);
	}
	
	@Step
	public void createSwapRequestWithExpirationTime(String recipient, int expirationTime) throws ParseException{
		
		SftSwpTst.createSwapRequestWithExpiry(recipient,expirationTime);
		
	}
	
	public void waitAndRefresh (int expirationTime){
		SftSwpTst.waitAndRefreshMySchedule(expirationTime);
	}
	
	
	public void verifySentSwapRequestNotPresentAtMySchedule(){
		SftSwpTst.verifySentSwapRequestNotInMySchedule();
	}
	
	
	public void verifyPendingApprovalRequestNotPresentAtMySchedule(){
		SftSwpTst.verifyPendingApprovalRequestNotInMySchedule();
	}
	
	public void multipleEmpRequestWithExpiry(String recipient1, String recipient2, int expirationTime) throws ParseException{
		SftSwpTst.requestMultipleEmployeeWithExpiry(recipient1, recipient2, expirationTime);
	}
	
	public void verifyRecievedRequestNotPresentAtMySchedule(){
		SftSwpTst.verifyRecievedRequestNotInMySchedule();
	}
	
	public void changeLunchPlanOfPendingApprovalRequest(String sender){
		SftSwpTst.changeLunchPlanOfPendingApproval(sender);
	}
	
	public void changeLunchPlanOfSentSwapRequest(String sender){
		SftSwpTst.changeLunchPlanOfSentSwapRequest(sender);
	}
	public void	verifyShiftSwapRequestExpiryNotification(String sender, String recipient){
		SftSwpTst.expireShiftSwapRequestNotification(sender, recipient);
	}
	
	public void noSentSwapRequestInSchedule(String sender){
		SftSwpTst.ObservNoSentSwapRequestInSchedule(sender);
	}
	
	public void verifyNoPendingRequestAtSchedule(String sender){
		SftSwpTst.verifyNoPendingRequestAtSchedulePage(sender);
	}
	
	
	public void verifyAutoCancelNotificationOnShiftEdit(String sender, String recipient){
		SftSwpTst.verifyNotificationForAutoCancelOnshiftEdit(sender, recipient);
	}

	public void reviewTLMNotification() {
		SftSwpTst.reviewAllTLMNotification();
		
	}

	public void observTargetShiftsForLockPeriod(String lockPeriod) {
		//SftSwpTst.observNoTargetShiftForLockPeriod(lockPeriod);
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
