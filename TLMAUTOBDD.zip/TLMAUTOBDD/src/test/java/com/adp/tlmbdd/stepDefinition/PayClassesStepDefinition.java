package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.PayClassSteps;

import cucumber.api.java.en.And;
import net.thucydides.core.annotations.Steps;

public class PayClassesStepDefinition {

	@Steps
	PayClassSteps classesSteps;
	
	@And("^I change time entry plan as \"([^\"]*)\" for Pay class \"([^\"]*)\"$")
	public void i_change_time_entry_plan_as_for_Pay_class(String payclass, String timeentryplan) throws Throwable {
	 
		classesSteps.changeTimeEntryPlan(payclass, timeentryplan);
	}
}
