package com.adp.tlmbdd.steps;

//import com.adp.tlmbdd.pages.editors.CompanyPreferences;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class CompanyPreferencesSteps extends ScenarioSteps{

//	CompanyPreferences companyPreferences;
	
	@Step
	public void verifyMultidayShiftCheckbox()
	{
//		companyPreferences.verifyMultiDayShiftCheckboxVisible();
	}
	
	@Step
	public void enableMultiDayShiftCheckbox()
	{
//		companyPreferences.enableMultiDayShift();
	}
	
	@Step
	public void verifyHelpAndHelpTextAndStepsToDisable()
	{
//		companyPreferences.verifyHelpAndHelpTextandStepsToDisablelink();
	}
	
	
}
