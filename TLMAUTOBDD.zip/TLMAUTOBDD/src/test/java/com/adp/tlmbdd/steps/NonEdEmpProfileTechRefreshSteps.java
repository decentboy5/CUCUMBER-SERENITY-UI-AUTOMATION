package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.editors.EmploymentProfileTechRefresh;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class NonEdEmpProfileTechRefreshSteps  extends ScenarioSteps {
	
	EmploymentProfileTechRefresh employmentProfileTechRefresh;


	  @Step 
	 public void ValidateTimeTile(String employeeName) throws Exception {
	  employmentProfileTechRefresh.ValidateTimeTileForNonTime(employeeName); }
	 
	  @Step 
		 public void ValidateTimeTileForTime(String employeeName) throws Exception {
		  employmentProfileTechRefresh.ValidateTimeTileForTimeEmployee(employeeName); }
		
	 
	 @Step 
	 public  void convertNonTimeToTime(String supervisor) throws Exception {
		  employmentProfileTechRefresh.NonEdConvertNonTimeToTime(supervisor);
		  }

	 @Step 
	 public  void selectTimeTile() throws Exception {
		  employmentProfileTechRefresh.NonEffectiveDatingSelectTimeTile();
		  }
	 
	 @Step 
	 public  void ConveertTimeToNonTime() throws Exception {
		  employmentProfileTechRefresh.convertTimeToNonTime();
		  }
	///change from here test 4: 
	 @Step 
	 public void SelectEmployee(String employeeName) throws Exception {
	  employmentProfileTechRefresh.selectEmployee(employeeName); }

	 @Step 
	 public void ConvertEmployeeToSupervisor() throws Exception {
	  employmentProfileTechRefresh.convertEmployeeToSupervisor(); }
	 
	 @Step 
	 public void ConvertSupervisorToEmployee() throws Exception {
	  employmentProfileTechRefresh.convertSupervisorToEmployee(); }
	 
	 
	 @Step 
	 public void NonTimeEditSupervisor(String supervisorName) throws Exception {
	  employmentProfileTechRefresh.EditSupervisor(supervisorName); }
	 

	 @Step
		public void PracReadOnly() throws Exception {		
		  employmentProfileTechRefresh.PractitionerReadOnlyModeValidations(); 
		}
	 

	 @Step
		public void ValidatePayClassSummary() throws Exception {		
		  employmentProfileTechRefresh.validatePayClassSummary(); 
		}
	 
	 
@Step
public void ValidateManager(String EmployeeName) throws Exception {		
	  employmentProfileTechRefresh.ManagerOnlyValidation(EmployeeName); 
	}
	  	
@Step
public void ValidateSupervisor() throws Exception {		
	  employmentProfileTechRefresh.SupervisorOnlyValidation(); 
	}
@Step
public void ValdiateSupermanAsManagerAndSupervisor(String EmployeeOne, String EmployeeTwo) throws Exception {		
	  employmentProfileTechRefresh.SupermanValidation(EmployeeOne,EmployeeTwo); 
	}
@Step
public void ValdiateSuperman(String EmployeeThree) throws Exception {		
	  employmentProfileTechRefresh.SupermanAsSupervisor(EmployeeThree); 
	}
@Step
public void ValidateEmployee() throws Exception {		
	  employmentProfileTechRefresh.EmployeeValidation(); 
	}
}

