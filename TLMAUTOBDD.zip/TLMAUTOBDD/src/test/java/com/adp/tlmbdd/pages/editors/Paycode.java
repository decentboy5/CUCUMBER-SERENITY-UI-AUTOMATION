package com.adp.tlmbdd.pages.editors;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.pages.GenericPageObject;

import org.junit.Assert;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class Paycode extends GenericPageObject {

	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElement mainiframe;

	@FindBy(xpath = "//iframe[@id='eZlmIFrame1_iframe']")
	private WebElement subframe;

	@FindBy(xpath = "//*[@id='PayCodeListAddNew']")
	private WebElementFacade  addNewPayCode;

	@FindBy(xpath = "//*[@id='PayCodeListDelete']/span")
	private WebElementFacade  deletePaycode;

	@FindBy(xpath = "//span[text()='English (US)']")
	private WebElementFacade  cultureEnglish;

	@FindBy(xpath = "//*[@id='payCodeIdValue']")
	private WebElementFacade  payCodename;

	@FindBy(xpath = "//*[@id='payCodeDescriptionValue']")
	private WebElementFacade  description;

	@FindBy(xpath = "//*[@id='payCodeTypeDropDown']")
	private WebElementFacade  paycodetypedropdown;

	@FindBy(xpath = "//ul[@id='payCodeTypeDropDown__listbox']/li[1]")
	private WebElementFacade  paycodetype1;

	@FindBy(xpath = "//*[@id='columnsInTCDropDown']")
	private WebElementFacade  includeTotalColoumns;

	@FindBy(xpath = "//ul[@id='columnsInTCDropDown__listbox']/li[1]")
	private WebElementFacade  includeTotalColoumns1;

	@FindBy(xpath = "//*[@id='payEmployeeUseTAChecked']/span[1]")
	private WebElementFacade  useTimeAndAttendance;

	@FindBy(xpath = "//*[@id='payrollTransfCode']")
	private WebElementFacade  payrollTransferCodes;

	@FindBy(xpath = "//*[text()='Rate Calculation Type']")
	private WebElementFacade  rateCalcType;

	@FindBy(xpath = "//*[@id='rateCalcFlagNone']/span[1]")
	private WebElementFacade  noneratecalctype;

	@FindBy(xpath = "//*[@id='rateCalcFlagEmpRate']/span[1]")
	private WebElementFacade  employeeratecalctype;

	@FindBy(xpath = "//*[@id='applyWageRateProgramCheck']/span[1]")
	private WebElementFacade  applyWageRateProgram;

	@FindBy(xpath = "//*[@id='empRateIdDropDown']")
	private WebElementFacade  emprateiddropdown;

	@FindBy(xpath = "//ul[@id='empRateIdDropDown__listbox']/li[1]")
	private WebElementFacade  emprateiddropdownvalue;

	@FindBy(xpath = "//*[@id='employeeRateFactor']")
	private WebElementFacade  empratefactor;

	@FindBy(xpath = "//*[@id='rateCalcFlagJobRate']/span[1]")
	private WebElementFacade  jobratecalctype;

	@FindBy(xpath = "//*[@id='jobHierarchyDropDown']")
	private WebElementFacade  jobHierarchyDropDown;

	@FindBy(xpath = "//ul[@id='jobHierarchyDropDown__listbox']/li[2]")
	private WebElementFacade  jobHierarchyDropDownValue;

	@FindBy(xpath = "//*[@id='jobRateIdDropDown']")
	private WebElementFacade  jobrateiddropdown;

	@FindBy(xpath = "//ul[@id='jobRateIdDropDown__listbox']/li[1]")
	private WebElementFacade  jobrateiddropdownvalue;

	@FindBy(xpath = "//*[@id='jobRateFactor']")
	private WebElementFacade  jobratefactor;

	@FindBy(xpath = "//*[@id='rateCalcFlagPayCodeRate']/span[1]")
	private WebElementFacade  paycoderatecalctype;

	@FindBy(xpath = "//*[@id='payCodeRateAmountTextBox']")
	private WebElementFacade  paycoderatefactor;

	@FindBy(xpath = "//input[@name='eZlmIFrame_iframe']")
	private WebElementFacade  effectiveDate;

	@FindBy(xpath = "//*[@id='rateCalcFlagPayCodeRate']/..//*[contains(@class,'plus-circle')]")
	private WebElementFacade  rateCalcEffectiveDateAdd;

	@FindBy(xpath = "//*[@id='payCodeRateAmountTextBox']")
	private WebElementFacade  rateAmount;

	@FindBy(xpath = "//*[text()='Timecard Options']")
	private WebElementFacade  timecardOptions;

	@FindBy(xpath = "//*[@id='entryTypeDropDown']")
	private WebElementFacade  entryType;

	@FindBy(xpath = "//ul[@id='entryTypeDropDown__listbox']/li[1]")
	private WebElementFacade  entryTypeOptionTimePair;

	@FindBy(xpath = "//*[@id='defaultAmountTextBox']")
	private WebElementFacade  defaultAmount;

	@FindBy(xpath = "//*[@id='workedTypeTextBox']")
	private WebElementFacade  workedType;

	@FindBy(xpath = "//ul[@id='workedTypeTextBox__listbox']/li[1]")
	private WebElementFacade  workedTypeWorked;

	@FindBy(xpath = "//*[@id='guaranteedHoursTextBox']")
	private WebElementFacade  guarenteedHours;

	@FindBy(xpath = "//*[text()='Timecard Options']")
	private WebElementFacade  holidayOptions;

	@FindBy(xpath = "//*[@id='payCodeSubmit']")
	private WebElementFacade  submitButton;

	@FindBy(xpath = "//*[text()='Save']")
	private WebElementFacade  saveButton;

	@FindBy(xpath = "//*[@id='payCodeManagePayclass']/span")
	private WebElementFacade  managePayClasses;

	@FindBy(xpath = "//*[@id='selectAssign']//span[contains(@class,'circle')]")
	private WebElementFacade  assignPayClass;

	@FindBy(xpath = "//*[@id='selectUnassign']//span[contains(@class,'circle')]")
	private WebElementFacade  unassignPayClass;

	@FindBy(xpath = "//*[@id='selectUpdate']//span[contains(@class,'circle')]")
	private WebElementFacade  updatePayClass;

	@FindBy(xpath = "//*[@id='managePayClassSave']/span")
	private WebElementFacade  managePayClassSave;

	@FindBy(xpath = "//*[text()='The Pay Code was successfully added']")
	private WebElementFacade  paycodeSuccessMessage;
	
	@FindBy(xpath = "//*[text()='Action successful']")
	private WebElementFacade  actionSuccessMessage;
	
	@FindBy(xpath = "//span[text()='Yes']")
	private WebElementFacade  actionYes;
	
	@FindBy(xpath = "//*[text()='The Pay Code was successfully deleted']")
	private WebElementFacade  deleteSuccessMessage;
	
	@FindBy(xpath = "//button[@id='managePayClassCancel']")
	private WebElementFacade  managePayClassCancel;
	
	@FindBy(xpath = "(//*[@title='Copy'])[1]")
	private WebElementFacade copyFirstPaycode;
	
	@FindBy(xpath = "(//*[@title='Copy'])[1]")
	private WebElementFacade clickFirstPaycode;

	public static String paycodename; 



	public void clickOnAddNewPayCode()
	{
		WaitForAjax();
		WaitForPageLoad();
		waitForWebElementToLoad(mainiframe);
		selectFrame(mainiframe);
		selectFrame(subframe);
		selectFrame(mainiframe);
		waitForElementToLoad(addNewPayCode);
		addNewPayCode.click();
		WaitForAjax();
	}

	public void addPayCodeDetails(String culture)
	{
		waitForElementToLoad(payCodename);
		if(culture.equals("en-US"))
			cultureEnglish.click();
		paycodename = "PayCodeUI_"+RandomStringUtils.randomNumeric(5);
		String paycodedescription = "Description_"+RandomStringUtils.randomNumeric(5); 
		if(checkElementVisible(payCodename))
		{
		payCodename.clear();
		payCodename.sendKeys(paycodename);
		}
		description.clear();
		description.sendKeys(paycodedescription);

	}

	public void addPayCodeTypeAndIncludeColoumns(String paycodetype,String inculdecoloumns)
	{
		//Selecting paycode type
		paycodetypedropdown.click();
		if(paycodetype.equals("normal"))
			paycodetype1.click();
		if(paycodetype.equals("prepaid"))
			paycodetype1.click();
		if(paycodetype.equals("alreadypaid"))
			paycodetype1.click();


		//include total columns
		includeTotalColoumns.click();
		if(inculdecoloumns.equals("regular"))
			includeTotalColoumns1.click();
		if(inculdecoloumns.equals("overtime"))
			includeTotalColoumns1.click();
	}

	public void selectRateCalcType(String ratecalculationtype,String ratefactor,String rateamount)
	{
		//Selecting rate calculation type
		rateCalcType.click();
		if(ratecalculationtype.equals("none"))
			noneratecalctype.click();
		else if(ratecalculationtype.equals("employeeRate"))
		{
			employeeratecalctype.click();
			applyWageRateProgram.click();
			emprateiddropdown.click();
			emprateiddropdownvalue.click();
			empratefactor.clear();
			empratefactor.sendKeys(ratefactor);

		}

		else if(ratecalculationtype.equals("jobRate"))
		{
			jobratecalctype.click();
			jobHierarchyDropDown.click();
			jobHierarchyDropDownValue.click();
			jobrateiddropdown.click();
			jobrateiddropdownvalue.click();
			jobratefactor.clear();
			jobratefactor.sendKeys(ratefactor);
		}

		else if(ratecalculationtype.equals("paycodeRate"))
		{
			paycoderatecalctype.click();

			//Effective Date 
			LocalDateTime sdate = LocalDateTime.now();
			effectiveDate.sendKeys(sdate.toString());
			rateAmount.sendKeys(rateamount);
			rateCalcEffectiveDateAdd.click();

		}
	}

	public void enrtyTypeAndWorkedType(String entrytype,String workedtype)
	{
		//Timecard Options
		timecardOptions.click();
		waitABit(2000);
		entryType.click();
		waitABit(2000);
		if(entrytype.equals("timepair"))
		{
			entryTypeOptionTimePair.click();
		}
		else if(entrytype.equals("hours"))
		{
			entryTypeOptionTimePair.click();
		}

		//Worked Type
		waitABit(2000);
		workedType.click();
		waitABit(2000);
		if(workedtype.equals("worked"))
		{
			workedTypeWorked.click();
		}
		else if(workedtype.equals("nonworked"))
		{
			workedTypeWorked.click();
		}
		defaultAmount.clear();
		defaultAmount.sendKeys("100");
		guarenteedHours.clear();
		guarenteedHours.sendKeys("100");
	}

	public void selectPayClasses(List<String> classlist)
	{
		if(classlist.isEmpty())
		{
			for( int i=1;i<=2;i++)
			{	
				System.out.println("(//*[@id='itemsCheckPayclass'])["+i+"]");
				getDriver().findElement(By.xpath("(//*[@id='itemsCheckPayclass'])["+i+"]")).click();

			}
		}
		else{
			for( int i=0;i<classlist.size();i++)
			{	
				System.out.println("//*[text()='"+classlist.get(i)+"']/..//*[@id='itemsCheckPayclass']");
				getDriver().findElement(By.xpath("//*[text()='"+classlist.get(i)+"']/..//*[@id='itemsCheckPayclass']")).click();

			}
		}
		saveButton.click();
		WaitForAjax();
	}

	public void verifyPayCodeAddedSuccesfully()
	{
		WaitForPageLoad();
		Assert.assertEquals(true, checkElementVisible(paycodeSuccessMessage));
		Assert.assertEquals(true, checkElementVisible("//a[text()='"+paycodename+"']"));
		switchToDefaultContent();
	}

	public void clickSubmitPaycode()
	{
		submitButton.click();
		WaitForPageLoad();
	}

	public void assignOrUnassignPayClasses(String operation,String payclassname)
	{
		managePayClasses.click();
		waitABit(2000);
		if(operation.equals("assign"))
		{
			assignPayClass.click();
			waitABit(2000);
			getDriver().findElement(By.xpath("//*[text()='"+payclassname+"']/..//*[@id='payclassSelect']")).click();
			waitABit(2000);
			managePayClassSave.click();
			waitABit(2000);
			managePayClasses.click();
			waitABit(2000);
			assignPayClass.click();
			Assert.assertEquals(false, checkElementVisible("//*[text()='"+payclassname+"']"));
			managePayClassCancel.click();
			
			
		}
		else if(operation.equals("unassign"))
		{
			unassignPayClass.click();
			waitABit(2000);
			getDriver().findElement(By.xpath("//*[text()='"+payclassname+"']/..//*[@id='payclassSelect']")).click();
			waitABit(2000);
			managePayClassSave.click();
			waitABit(2000);
			Assert.assertEquals(true, checkElementVisible(actionSuccessMessage));
			managePayClasses.click();
			waitABit(1000);
			unassignPayClass.click();
			Assert.assertEquals(false, checkElementVisible("//*[text()='"+payclassname+"']"));
			managePayClassCancel.click();
			
		}
		else if(operation.equals("update"))
		{
			updatePayClass.click();
			waitABit(2000);
			getDriver().findElement(By.xpath("//*[text()='"+payclassname+"']/..//*[@class='vdl-toggle-switch__slide']")).click();
			waitABit(2000);
			managePayClassSave.click();
			Assert.assertEquals(true, checkElementVisible(actionSuccessMessage));
			
		}
		
		
	}
	
	public void clickOnCreatedpayCode()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		selectFrame(mainiframe);
		getDriver().findElement(By.xpath("//a[text()='"+paycodename+"']")).click();
		WaitForPageLoad();
		waitForElementToLoad(description);
	}
	
	public void deletePayCodeAndVerify()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		selectFrame(mainiframe);
		getDriver().findElement(By.xpath("//*[text()='"+paycodename+"']/../..//input/..")).click();
		deletePaycode.click();
		actionYes.click();
		WaitForPageLoad();
		waitABit(3000);
		Assert.assertEquals(true, checkElementVisible(deleteSuccessMessage));
		Assert.assertEquals(false, checkElementVisible("//a[text()='"+paycodename+"']"));
		switchToDefaultContent();
		
	}
	
	public void copyFirstPayCode()
	{
		WaitForAjax();
		WaitForPageLoad();
		waitForWebElementToLoad(mainiframe);
		selectFrame(mainiframe);
		selectFrame(subframe);
		selectFrame(mainiframe);
		copyFirstPaycode.click();
		WaitForPageLoad();
	}
	
	public void clickFirstPayCode()
	{
		WaitForAjax();
		WaitForPageLoad();
		waitForWebElementToLoad(mainiframe);
		selectFrame(mainiframe);
		selectFrame(subframe);
		selectFrame(mainiframe);
		clickFirstPaycode.click();
		WaitForPageLoad();
	}
	

}
