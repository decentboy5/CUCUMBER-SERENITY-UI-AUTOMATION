package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.editors.HourDistributionRule;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class HourDistributionRuleSteps extends ScenarioSteps{

	HourDistributionRule hourDistributionRule;
	
	@Step
	public void clickHourDistributionRule(String rule)
	{
		hourDistributionRule.clickHourDistributionRule(rule);
	}
	
	@Step
	public void verifyACROSSPRDTOTNotAvailable()
	{
		hourDistributionRule.verifyACROSSPRDTOTNotAvailable();
	}
	
	@Step
	public void addNewHourDistributionRule()
	{
		hourDistributionRule.addNewHourDistributionRule();
	}
	
	@Step
	public void copyHourDistributionRule()
	{
		hourDistributionRule.copyHourDistributionRule();
	}
	
}
