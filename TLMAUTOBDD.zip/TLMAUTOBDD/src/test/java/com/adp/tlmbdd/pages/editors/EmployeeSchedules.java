package com.adp.tlmbdd.pages.editors;

import java.lang.reflect.Field;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.WordUtils;
import org.openqa.selenium.Keys;
import org.springframework.util.Assert;

import com.adp.tlmbdd.pages.objects.ScheduleObjectsGen;
import com.google.common.collect.Ordering;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class EmployeeSchedules extends ScheduleObjectsGen {

	private static String loggedInUser;

	public void getLoggedInUser() {
		waitABit(3000);
		String name = loggedUserName.getText();
		String[] fullname = name.split(" ");
		loggedInUser = fullname[1] + ", " + fullname[0];
	}

	public void cleanup() {
		selectViewSchedulePreference(preferenceViewShiftByStartTime);
		/*
		 * while(timepairs.isCurrentlyVisible()) { timepairs.click();
		 * timepairsDeleteIcon.click(); confirmDeleteDialogYesButton.click();
		 * scheduleFindButton.click(); waitABit(2000); }
		 */

	}

	public void searchForLocation(String location) {
		locationSearchInput.waitUntilClickable();
		locationSearchInput.type(location);
		selectLookupDropDownOption(getElementByDynamicValues("xpath", "locationSearchOption", location));
		waitABit(5000);
		// Validate
	}

	// Employee Search and Employee Count
	public void searchEmployeeByName(String name) {
		cleanup();
		String empCount = "Employee (1)";
		employeeSearchTextBox.waitUntilClickable();
		employeeSearchTextBox.type(name);
		WaitForAjax();
		waitABit(15000);
		Assert.isTrue(getElementByDynamicValues("xpath", "scheduleEmployeeName", name).isCurrentlyVisible(),
				"Schedule Employee Search Failed! The Employee Was NOT Found!!!");
		Assert.isTrue(employeeCount.getText().equals(empCount),
				"Schedule Employee Search Failed! Search Fail to Return Correct Emp Count!!!");
		employeeSearchTextBox.type("");
		employeeSearchIcon.click();
		WaitForAjax();
		waitABit(15000);
		Assert.isTrue(!employeeCount.getText().equals(empCount),
				"Schedule Employee Search Failed! Search Result Returns Wrong Employee Count!!!");
	}

	// Date Selection Validations
	public void dateRangeShortcuts() {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate startOfWeek = LocalDate.now().with(DayOfWeek.MONDAY).plusDays(-1);
		String today = LocalDate.now().format(format);
		// Verify drop down options
		dateShortCutDropDown.click();
		Assert.isTrue(getElementByDynamicValues("xpath", "dateDropDownOptions", "0").getText().equals("Date Range"),
				"Date Range is NOT display in drop-down option");
		Assert.isTrue(getElementByDynamicValues("xpath", "dateDropDownOptions", "1").getText().equals("Today"),
				"Today is NOT display in drop-down option");
		Assert.isTrue(getElementByDynamicValues("xpath", "dateDropDownOptions", "2").getText().equals("This Week"),
				"This Week is NOT display in drop-down option");
		// verify Today option
		getElementByDynamicValues("xpath", "dateDropDownOptions", "1").click();
		WaitForAjax();
		boolean isToday = today.equals(scheduleStartDateInput.getValue())
				&& today.equals(scheduleEndDateInput.getValue());
		Assert.isTrue(isToday, "Selecting Today Date Shortcut Return Wrong Date Range!!!");
		waitABit(5000);
		// verify This Week option
		dateShortCutDropDown.click();
		getElementByDynamicValues("xpath", "dateDropDownOptions", "2").click();
		WaitForAjax();
		Assert.isTrue(scheduleStartDateInput.getValue().equals(startOfWeek.format(format)),
				"Wrong Start Date Value When This Week Date Range is Selected!!!");
		Assert.isTrue(scheduleEndDateInput.getValue().equals(startOfWeek.plusDays(6).format(format)),
				"Wrong End Date Value When This Week Date Range is Selected!!!");
		waitABit(4000);
		// validate next and previous date range selection icon
		nextDateRowArrowIcon.click();
		WaitForAjax();
		Assert.isTrue(scheduleStartDateInput.getValue().equals(LocalDate.now().with(DayOfWeek.SUNDAY).format(format)),
				"Wrong Start Date Value When Next Date Range is Selected by Clicking on the Next Icon!!!");
		Assert.isTrue(
				scheduleEndDateInput.getValue()
						.equals(LocalDate.now().with(DayOfWeek.SUNDAY).plusDays(6).format(format)),
				"Wrong Start End Value When Next Date Range is Selected by Clicking on the Next Icon!!!");
		waitABit(4000);
		// previous
		previousDateRowArrowIcon.click();
		Assert.isTrue(scheduleStartDateInput.getValue().equals(startOfWeek.format(format)),
				"Wrong Start Date Value When This Week Date Range is Selected!!!");
		Assert.isTrue(scheduleEndDateInput.getValue().equals(startOfWeek.plusDays(6).format(format)),
				"Wrong End Date Value When This Week Date Range is Selected!!!");
	}

	public void dateInputValidation() {
		LocalDate startOfWeek = LocalDate.now();
		String startDate = startOfWeek.format(DateTimeFormatter.ofPattern("M/d/yyyy"));
		scheduleStartDateInput.waitUntilClickable();
		scheduleStartDateInput.type("");
		waitABit(500);
		scheduleStartDateInput.typeAndTab(startDate);
		scheduleEndDateInput.type(startOfWeek.plusDays(14).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		waitABit(500);
		scheduleFindButton.click();
		waitABit(5000);
		Assert.isTrue(
				firstDayCellHeader.getText()
						.equalsIgnoreCase(startOfWeek.format(DateTimeFormatter.ofPattern("EEE MM/dd"))),
				"Wrong End Date Value When This Week Date Range is Selected!!!");
		horizontalScrollBar.click();
		WaitForAjax();
		Assert.isTrue(
				lastDayCellHeader.getText()
						.equalsIgnoreCase(startOfWeek.plusDays(13).format(DateTimeFormatter.ofPattern("EEE MM/dd"))),
				"Wrong End Date Value When This Week Date Range is Selected!!!");
	}

	public void dateInputErrorValidation() {
		LocalDate startOfWeek = LocalDate.now();

		// invalid date input
		scheduleStartDateInput.type("15455gh");
		Assert.isTrue(dateErrorMsgDialog.getText().equals("The value entered is not valid."),
				"Wrong Error Message for Invalid Date Input!!!");
		scheduleEndDateInput.type("27/10/12");
		Assert.isTrue(dateErrorMsgDialog.getText().equals("The value entered is not valid."),
				"Wrong Error Message for Invalid Date Input!!!");
		// greater start date
		scheduleStartDateInput.type(startOfWeek.plusDays(5).format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
		scheduleEndDateInput.typeAndTab(startOfWeek.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

		Assert.isTrue(dateErrorMsgDialog.getText().equals("Start date cannot be greater than End Date."),
				"Wrong Error Message for Greater Start Date!!!");
		// greater end date
		scheduleEndDateInput.type(startOfWeek.plusDays(6).format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
		scheduleStartDateInput.type(startOfWeek.plusDays(10).format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
		scheduleFindButton.click();
		WaitForAjax();
		waitABit(500);
		System.out.println(scheduleErrorMsgDiv.getText());
		Assert.isTrue(scheduleErrorMsgDiv.getText().trim().equals("Start date cannot be greater than End Date."),
				"Wrong Error Message for Invalid Date Input!!!");
		calendarDateSelection("2019");
	}

	public void calendarDateSelection(String year) {
		startDateCalendarIcon.waitUntilClickable();
		startDateCalendarIcon.click();
		calendarStartDatMonth.click();
		getElementByDynamicValues("xpath", "calendarMonthOption", "February").click();
		calendarStartDateYear.click();
		getElementByDynamicValues("xpath", "calendarYearOption", year).click();
		getElementByDynamicValues("xpath", "calendarDayOption", "1").click();
		endDateCalendarIcon.click();
		calendarEndDateMonth.click();
		getElementByDynamicValues("xpath", "calendarEndDateMonthOption", "March").click();
		calendarEndDateYear.click();
		getElementByDynamicValues("xpath", "calendarEndDateYearOption", year).click();
		getElementByDynamicValues("xpath", "calendarEndDateDayOption", "20").click();
		waitABit(1000);
		scheduleFindButton.click();
		waitABit(5000);
		Assert.isTrue(scheduleStartDateInput.getValue().equals("2/1/" + year),
				"Selecting Start Date From Calendar Failed!!!");
		Assert.isTrue(scheduleEndDateInput.getValue().equals("3/20/" + year),
				"Selecting Start Date From Calendar Failed!!!");
		// date range greater than 90 days
		startDateCalendarIcon.click();
		calendarStartDatePreviousMonthArrow.click();
		getElementByDynamicValues("xpath", "calendarDayOption", "1").click();
		endDateCalendarIcon.click();
		calendarEndDateNextMonthArrow.click();
		calendarEndDateNextMonthArrow.click();
		getElementByDynamicValues("xpath", "calendarEndDateDayOption", "28").click();
		scheduleFindButton.click();
		Assert.isTrue(scheduleErrorMsgDiv.getText().equals("Schedule date range cannot be more than 100 days."),
				"Wrong Error Message for Date Range Greater than 100 Days!!!");
		dateShortCutDropDown.click();
		getElementByDynamicValues("xpath", "dateDropDownOptions", "2").click();
		WaitForAjax();
	}

	// ######################SCHEDULE CRUD OPERATIONS###############################
	public void addSingleShift(String dept, String paycode) {
		getLoggedInUser();
		shiftcell.waitUntilClickable();
		shiftcell.click();
		addShiftIcon.click();
		addShiftIntime.waitUntilClickable();
		addShiftIntime.typeAndTab("8");
		addShiftOutTime.type("4p");
		addShiftLunchPlan.click();
		addShiftDepartment.type(dept);
		waitABit(1000);
		shiftAddLookupOption.click();
		addShiftNote.type("Add shift note");
		addShiftPayCode.type(paycode);
		waitABit(1000);
		addShiftLunchPlan.type("30ACTL - 30-Min Always Punch - Actual");
		addShiftSave.click();
		waitABit(2000);
		addedShift.shouldContainText("08:00 AM - 04:00 PM");
	}

	public void verifyTotalHourAndLunchPlanDeduction() {

	}

	public void editSingleShift(String dept, String paycode) {
		waitABit(2000);
		addedShift.click();
		editIcon.click();
		addShiftIntime.typeAndTab("823");
		addShiftOutTime.type("436p");
		addShiftLunchPlan.click();
		addShiftDepartment.type(dept);
		waitABit(1000);
		shiftAddLookupOption.click();
		addShiftNote.type("Edit shift note");
		addShiftPayCode.type(paycode);
		addShiftPayCode.click();
		addShiftLunchPlan.type("60AUTO - 60-Min Never Punch - Autodeduct");
		addShiftSave.click();
		waitABit(2000);
		addedShift.shouldContainText("08:23 AM - 04:36 PM");
	}

	public void shiftOverlapForMultipleDays() {

	}

	public void deleteSingleShift() {
		waitABit(2000);
		addedShift.click();
		deleteIcon.click();
		confirmDeleteDialogYesButton.click();
		waitABit(2000);
		addedShift.shouldNotBePresent();
	}

	public void enterShiftInDialog(String startTime, String endTime, String paycode, String lunchPlan, String dept,
			String job, String location, String note) {
		waitABit(2000);
		addShiftIntime.typeAndTab(startTime);
		addShiftOutTime.type(endTime);
		addShiftLunchPlan.click();
		addShiftLunchPlan.click();
		addShiftDepartment.click();
		addShiftDepartment.type(dept);
		selectLookupDropDownOption(shiftAddLookupOption);
		addShiftJob.click();
		addShiftJob.typeAndTab(job);
		selectLookupDropDownOption(shiftAddJobOption);
		addShiftLocation.typeAndTab(location);
		selectLookupDropDownOption(shiftAddLocationOption);
		addShiftNote.type(note);
		addShiftPayCode.type(paycode);
		waitABit(500);
		selectLookupDropDownOption(payCodeLookupOption);
		addShiftLunchPlan.type(lunchPlan);
		addShiftSave.click();
		waitABit(2000);
	}

	public void addMultipleShiftsAcrossMultipleEmployees(String paycode, String dept, String job, String location) {
		int j = 4;
		for (int i = 1; i < 4; i++) {
			waitABit(3000);
			getElementByDynamicValues("xpath", "scheduleShiftCell", Integer.toString(i), Integer.toString(j)).click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", Integer.toString(i), Integer.toString(j)).click();
			j++;
		}
		actionBarAddShiftLink.click();
		enterShiftInDialog("8", "4p", paycode, "30ACTL - 30-Min Always Punch - Actual", dept, job, location,
				"Add shift note");
		waitABit(3100);
	}

	public void editMultipleShiftsAcrossMultipleEmployees(String paycode, String dept, String job, String location) {
		waitABit(2000);
		int j = 4;
		for (int i = 1; i < 4; i++) {
			getElementByDynamicValues("xpath", "scheduleShiftCell", Integer.toString(i), Integer.toString(j)).click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", Integer.toString(i), Integer.toString(j)).click();
			j++;
		}
		actionBarEditShiftLink.click();
		waitABit(1000);
		getElementByDynamicValues("xpath", "shiftEditToggle", "InTime").click();
		addShiftIntime.typeAndTab("823");
		getElementByDynamicValues("xpath", "shiftEditToggle", "OutTime").click();
		addShiftOutTime.type("436p");
		getElementByDynamicValues("xpath", "shiftEditToggle", "PayCode").click();
		getElementByDynamicValues("xpath", "shiftEditToggle", "LunchPlan").click();
		addShiftLunchPlan.click();
		addShiftLunchPlan.type("60AUTO - 60-Min Never Punch - Autodeduct");
		getElementByDynamicValues("xpath", "shiftEditToggle", "Department").click();
		addShiftDepartment.type(dept);
		selectLookupDropDownOption(shiftAddLookupOption);
		getElementByDynamicValues("xpath", "shiftEditToggle", "Location").click();
		addShiftLocation.typeAndTab(location);
		selectLookupDropDownOption(shiftAddLocationOption);
		getElementByDynamicValues("xpath", "shiftEditToggle", "Job").click();
		addShiftJob.typeAndTab(job);
		selectLookupDropDownOption(shiftAddJobOption);
		getElementByDynamicValues("xpath", "shiftEditToggle", "Notes").click();
		addShiftNote.type("Edit shift note");
		addShiftPayCode.type(paycode);
		waitABit(500);
		selectLookupDropDownOption(payCodeLookupOption);
		addShiftSave.click();
		waitABit(2000);
	}

	public void validateMultipleShifts(String time, String paycode, String department, String job, String location) {
		int j = 4;
		for (int i = 1; i < 4; i++) {
			getElementByDynamicValues("xpath", "noteIcon", Integer.toString(i), Integer.toString(j)).shouldBeVisible();
			;
			getElementByDynamicValues("xpath", "shiftTime", Integer.toString(i), Integer.toString(j))
					.shouldContainText(time);
			getElementByDynamicValues("xpath", "shiftPaycode", Integer.toString(i), Integer.toString(j))
					.shouldContainText(paycode);
			// validate shift lcfs
			getElementByDynamicValues("xpath", "shiftJob", Integer.toString(i), Integer.toString(j))
					.shouldContainText(job);
			getElementByDynamicValues("xpath", "shiftLocation", Integer.toString(i), Integer.toString(j))
					.shouldContainText(location);
			getElementByDynamicValues("xpath", "shiftDepartment", Integer.toString(i), Integer.toString(j))
					.shouldContainText(department);
			j++;
		}
	}

	public void multipleShiftAddValidation(String paycode, String dept, String job, String location) {
		validateMultipleShifts("08:00 AM - 04:00 PM", paycode, dept, job, location);
	}

	public void multipleShiftEditValidation(String paycode, String dept, String job, String location) {
		validateMultipleShifts("08:23 AM - 04:36 PM", paycode, dept, job, location);
	}

	public void deleteMultipleShifts() {
		int j = 4;
		waitABit(2000);
		for (int i = 1; i < 4; i++) {
			getElementByDynamicValues("xpath", "scheduleShiftCell", Integer.toString(i), Integer.toString(j)).click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", Integer.toString(i), Integer.toString(j)).click();
			j++;
		}
		actionBarDeleteShiftLink.click();
		confirmDeleteDialogYesButton.click();
		WaitForAjax();
	}

	public void validateMultipleShiftDelete() {
		int j = 4;
		for (int i = 1; i < 4; i++) {
			getElementByDynamicValues("xpath", "scheduleShift", Integer.toString(i), Integer.toString(j), "0")
					.shouldNotBePresent();
			j++;
		}
	}

	// ######################In-Line Editing###########################
	public void inLineEditAutoAutoAdvancedShiftAdd() {
		// in-line shift add with auto advance, tab and shift key
		getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "5").waitUntilClickable();
		doubleClick(getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "5"));
		typeInActiveElement("5am");
		waitABit(500);
		typeInActiveElement("1300");
		waitABit(500);
		typeInActiveElement("8");
		typeInActiveElement(Keys.TAB);
		waitABit(500);
		typeInActiveElement("10");
		typeInActiveElement(Keys.ENTER);
		waitABit(500);
		// validate add shifts
		getElementByDynamicValues("xpath", "scheduleShift", "0", "5", "0").shouldContainText("05:00 AM - 01:00 PM");
		getElementByDynamicValues("xpath", "scheduleShift", "0", "6", "0").shouldContainText("08:00 AM - 10:00 AM");
		scheduleFindButton.click();
		WaitForAjax();
	}

	public void inLineEditEnterKeyShiftEdit() {
		// in-line edit with enter key
		waitABit(2500);
		getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "5").waitUntilClickable();
		getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "5").click();
		typeInActiveElement(Keys.ENTER);
		waitABit(500);
		typeInActiveElement("2pm");
		waitABit(500);
		typeInActiveElement("7p");
		typeInActiveElement(Keys.ENTER);
		waitABit(500);
		getElementByDynamicValues("xpath", "scheduleShift", "0", "5", "0").shouldContainText("02:00 PM - 07:00 PM");
	}

	public void inLineEditInsertKeyShiftAdd() {
		// in-line insert with insert key
		getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "6").click();
		typeInActiveElement(Keys.INSERT);
		waitABit(500);
		typeInActiveElement("12");
		typeInActiveElement(Keys.TAB);
		waitABit(500);
		typeInActiveElement("13");
		typeInActiveElement(Keys.ENTER);
		waitABit(1000);
		getElementByDynamicValues("xpath", "scheduleShift", "0", "6", "0").shouldContainText("08:00 AM - 10:00 AM");
		getElementByDynamicValues("xpath", "scheduleShift", "0", "6", "1").shouldContainText("12:00 PM - 01:00 PM");
		waitABit(2000);
	}

	public void inLineEditShifOverlapValidation() {
		// validate hanging shift overlap during in-line editing
		getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "5").click();
		typeInActiveElement(Keys.ENTER);
		waitABit(500);
		typeInActiveElement("11pm");
		waitABit(500);
		typeInActiveElement("9");
		typeInActiveElement(Keys.ENTER);
		waitABit(500);
		Assert.isTrue(overLapErrorDialog.getText().contains("Shift overlaps with an existing shift"),
				"Shift overlaps are allowed in inline editing!!!");
		scheduleFindButton.click();
		waitABit(1500);
	}

	public void inLineEditCleanUpDeleteShifts() {
		// clean up: delete all shifts
		for (int i = 5; i < 7; i++) {
			getElementByDynamicValues("xpath", "scheduleShiftCell", "0", Integer.toString(i)).click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", "0", Integer.toString(i)).click();
		}
		actionBarDeleteShiftLink.click();
		confirmDeleteDialogYesButton.click();
		WaitForAjax();
	}

	// ######################Quick Shifts###############################
	public void addQuickShift(String paycode, String name, String dept, String job, String location) {
		try {
			if (!addQuickShift.isCurrentlyVisible()) {
				scheduleMoreLink.click();
				waitABit(500);
				quickShiftLink.click();
				waitABit(1000);
				deleteQuickShift();
			}
			addQuickShift.click();
			quickShiftName.type(name);
			quickShiftInTime.type("2");
			quickShiftOutTime.type("10");
			quickShiftPayCode.click();
			quickShiftMealPlan.type("45AUTO - 45-Min Never Punch - Autodeduct");
			quickShiftDepartment.type(dept);
			selectLookupDropDownOption(quickShiftDeptDropDownOption);
			quickShiftJob.type(job);
			selectLookupDropDownOption(quickShiftJobDropDownOption);
			quickShiftLocation.type(location);
			selectLookupDropDownOption(quickShiftLocationDropDownOption);
			quickShiftPayCode.type(paycode + " - " + paycode);
			selectLookupDropDownOption(quickShiftPaycodeDropDownOption);
			quickShiftPayCode.click();
			quickShiftDoneButton.click();
			waitABit(1500);
			Assert.isTrue(getElementByDynamicValues("xpath", "quickShift", name).isCurrentlyVisible(),
					"Quick Shift Creation Failed!!!");
		} catch (Exception e) {
			quickShiftCancel.click();
			System.out.println(e.getMessage());
		}
	}

	public void editQuickShift(String paycode, String name, String dept, String job, String location) {
		try {
			if (!addQuickShift.isCurrentlyVisible()) {
				scheduleMoreLink.click();
				quickShiftLink.click();
			}
			getElementByDynamicValues("xpath", "quickShift", name).click();
			getElementByDynamicValues("xpath", "quickShiftEditIcon", name).click();
			quickShiftName.waitUntilClickable();
			quickShiftName.type(name + "Edited");
			quickShiftInTime.type("3p");
			quickShiftOutTime.type("18");
			quickShiftPayCode.type(paycode);
			quickShiftMealPlan.type("45AUTO - 45-Min Never Punch - Autodeduct");
			quickShiftDepartment.type("");
			selectLookupDropDownOption(quickShiftDeptDropDownOption);
			quickShiftJob.type("");
			selectLookupDropDownOption(quickShiftJobDropDownOption);
			quickShiftLocation.type("");
			selectLookupDropDownOption(quickShiftLocationDropDownOption);
			quickShiftDoneButton.click();
			WaitForAjax();
			getElementByDynamicValues("xpath", "quickShift", name + "Edited").shouldBeVisible();
		} catch (Exception e) {
			quickShiftCancel.click();
			System.out.println(e.getMessage());
		}
	}

	public void assignQuickShift(String qs1, String qs2) {
		/*
		 * int j = 4; for(int i = 1; i < 4; i++) { getElementByDynamicValues("xpath",
		 * "scheduleShiftCell", Integer.toString(i), Integer.toString(j)).click();
		 * getElementByDynamicValues("xpath", "cellSelectionIcon", Integer.toString(i),
		 * Integer.toString(j)).click(); j++; }
		 */
		WebElementFacade cell1 = getElementByDynamicValues("xpath", "scheduleShiftCell", "2", "3");
		WebElementFacade cell2 = getElementByDynamicValues("xpath", "scheduleShiftCell", "3", "3");
		dragAndDropQuickShift(qs1, cell1);
		dragAndDropQuickShift(qs2, cell2);
	}

	public void deleteQuickShift() {
		while (quickShiftQS00.isCurrentlyVisible()) {
			quickShiftQS00.click();
			quickShiftQS00Delete.click();
			WaitForAjax();
			quickShiftConfirmDelete.click();
			waitABit(1500);
		}
		quickShiftQS00.shouldNotBeVisible();
	}

	// ######################Copy Paste###############################
	public void copyAndPasteUsingMenuLink(String paycode, String dept, String job, String location) {
		waitABit(3000);
		addMultipleShiftsAcrossMultipleEmployees(paycode, dept, job, location);
		int j = 4;
		for (int i = 1; i < 4; i++) {
			getElementByDynamicValues("xpath", "scheduleShiftCell", Integer.toString(i), Integer.toString(j)).click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", Integer.toString(i), Integer.toString(j)).click();
			j++;
		}
		waitABit(500);
		actionBarCopyShiftLink.click();
		getElementByDynamicValues("xpath", "scheduleShiftCell", "1", "5").click();
		actionBarPasteShiftLink.click();
		waitABit(3000);
		// verify copy paste
		int k = 5;
		for (int i = 1; i < 4; i++) {
			getElementByDynamicValues("xpath", "shiftTime", Integer.toString(i), Integer.toString(k))
					.shouldContainText("08:00 AM - 04:00 PM");
			getElementByDynamicValues("xpath", "scheduleShiftCell", Integer.toString(i), Integer.toString(k)).click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", Integer.toString(i), Integer.toString(k)).click();
			getElementByDynamicValues("xpath", "scheduleShiftCell", Integer.toString(i), Integer.toString(k - 1))
					.click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", Integer.toString(i), Integer.toString(k - 1))
					.click();
			k++;
		}
		waitABit(500);
		// delete all shifts
		actionBarDeleteShiftLink.click();
		confirmDeleteDialogYesButton.click();
		waitABit(3000);
	}

	public void copyPasteWithKeyboardShortcut() {
		waitABit(1500);
		selectViewSchedulePreference(preferenceViewShiftByHours);
		try {
			for (int i = 4; i < 7; i++) {
				getElementByDynamicValues("xpath", "scheduleShiftCell", "2", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "cellSelectionIcon", "2", Integer.toString(i)).click();

			}
			actionBarAddShiftLink.click();
			addShiftIntime.waitUntilClickable();
			addShiftIntime.typeAndTab("8");
			addShiftOutTime.type("4p");
			addShiftLunchPlan.type("60AUTO - 60-Min Never Punch - Autodeduct");
			addShiftSave.click();
			waitABit(3000);
			for (int i = 4; i < 7; i++) {
				getElementByDynamicValues("xpath", "scheduleShiftCell", "2", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "cellSelectionIcon", "2", Integer.toString(i)).click();

			}
			waitABit(500);
			// copy and paste using keyboard shortcuts
			typeInActiveElement(Keys.CONTROL + "c");
			waitABit(500);
			getElementByDynamicValues("xpath", "scheduleShiftCell", "3", "4").click();
			waitABit(500);
			typeInActiveElement(Keys.CONTROL + "v");
			waitABit(3000);
			// validate pasted shifts
			for (int i = 4; i < 7; i++) {
				getElementByDynamicValues("xpath", "shiftTime", "3", Integer.toString(i)).shouldContainText("8");
			}
		} finally {
			// clean up: delete added shifts
			actionBarClearAll.click();
			waitABit(500);
			scheduleMoreLink.click();
			waitABit(500);
			morePreferenceLink.click();
			preferenceViewShiftByStartTime.click();
			preferenceApplyButton.click();
			waitABit(3000);
			for (int i = 4; i < 7; i++) {
				getElementByDynamicValues("xpath", "scheduleShiftCell", "2", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "cellSelectionIcon", "2", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "scheduleShiftCell", "3", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "cellSelectionIcon", "3", Integer.toString(i)).click();
			}
			actionBarDeleteShiftLink.click();
			confirmDeleteDialogYesButton.click();
			WaitForAjax();
		}
	}

	// ##############Remove Like the Change Link on Schedule Pages: US1197474 and
	// US1197473#########
	public void validateRemoveLikeTheChangeLink() {
		likeTheChangeLink.shouldNotBePresent();
	}

	/* #############SCHEDULE AUDIT FEATURE AUTOMATION############## */
	/*
	 * This method navigates to row grabber slide in pages Params: row - employee
	 * row and link - link for page to navigate to
	 */
	public void navigateToRowGrabberPage(String row, String link) {
		waitABit(2000);
		getElementByDynamicValues("xpath", "scheduleRowGrabberMenu", row).click();
		waitABit(500);
		if (getElementByDynamicValues("xpath", "scheduleRowGrabberOption", "Accrual Balances").isCurrentlyVisible()
				&& link == "Time Off Balances") {
			link = "Accrual Balances";
		}
		getElementByDynamicValues("xpath", "scheduleRowGrabberOption", link).waitUntilClickable();
		getElementByDynamicValues("xpath", "scheduleRowGrabberOption", link).click();
		waitABit(2000);
		// Verify page title
		getElementByDynamicValues("xpath", "scheduleRowGrabberOption", link).isCurrentlyVisible();
	}

	public void validateShiftInsertAudit(String newDept, String newPayCode) {
		validateScheduleAudit("Insert", "", "8:00 AM", "", "4:00 PM", "", newDept, "", newPayCode, "", "Add shift note",
				"", "30ACTL");
	}

	public void validateShiftUpdateAudit(String dept, String newDept, String paycode, String newPayCode) {
		validateScheduleAudit("Update", "8:00 AM", "8:23 AM", "4:00 PM", "4:36 PM", dept, newDept, paycode, newPayCode,
				"Add shift note", "Edit shift note", "30ACTL", "60AUTO");
	}

	public void validateShiftDeleteAudit(String dept, String paycode) {
		validateScheduleAudit("Delete", "8:23 AM", "", "4:36 PM", "", dept, "", paycode, "", "Edit shift note", "",
				"60AUTO", "");
	}

	/**
	 * Validates changes to the following shift attributes: start time, end time,
	 * department, pay code, shift note and meal plan
	 **/
	public void validateScheduleAudit(String editType, String oldStartTime, String newStartTime, String oldEndTime,
			String newEndTime, String oldDept, String newDept, String oldPayCode, String newPayCode, String oldNote,
			String newNote, String oldMealPlan, String newMealPlan) {
		String changedBy = WordUtils.capitalizeFully(loggedInUser);
		try {
			if (!(oldPayCode == "")) {
				WebElementFacade oldPayCodeColumn = getElementByDynamicValues("xpath", "editedFieldColumn", oldPayCode);
				WebElementFacade oldMealPlanColumn = getElementByDynamicValues("xpath", "editedFieldColumn",
						oldMealPlan);
				oldPayCodeColumn.click();
				oldMealPlanColumn.click();
			}
			if (!(newPayCode == "")) {
				WebElementFacade newPayCodeColumn = getElementByDynamicValues("xpath", "editedFieldColumn", newPayCode);
				WebElementFacade newMealPlanColumn = getElementByDynamicValues("xpath", "editedFieldColumn",
						newMealPlan);
				newPayCodeColumn.click();
				newMealPlanColumn.click();
			}
			WebElementFacade changedByColumn = getElementByDynamicValues("xpath", "editedFieldColumn", changedBy);
			changedByColumn.click();
			System.out.println(scheduleEditTypeColumn.getValue());
			scheduleEditTypeColumn.shouldContainText(editType);
			scheduleOldStartTimeColumn.shouldContainText(oldStartTime);
			scheduleNewStartTimeColumn.shouldContainText(newStartTime);
			scheduleOldEndTimeColumn.shouldContainText(oldEndTime);
			scheduleNewEndTimeColumn.shouldContainText(newEndTime);
			scheduleOldDepartmentColumn.shouldContainText(oldDept);
			scheduleNewDepartmentColumn.shouldContainText(newDept);
		} finally {
			scheduleAuditSliderBackButton.click();
			waitABit(1000);
		}
	}

	/* #############SCHEDULE AUDIT - IMPLEMENT COLUMN SORTING ############## */
	public void columnSortingValidation() {
		try {
			oldDepartmentColumnSortIcon.click();
			waitABit(1000);
			verifyScheduleAuditColumnSorting("scheduleOldDepartmentColumn");
			editColumnSortIcon.click();
			waitABit(1000);
			verifyScheduleAuditColumnSorting("scheduleEditTypeColumn");
		} finally {
			scheduleAuditSliderBackButton.click();
			waitABit(1000);
		}
	}

	/*
	 * #############SCHEDULE TEMPLATE DELETE AUDIT FEATURE AUTOMATION##############
	 */
	public void enterShiftOnTemplateAddShiftDialog(String startTime, String endTime, String payCode, String dept,
			String mealPlan, String job, String location) {
		templateAddShiftStartTimeInput.waitUntilClickable();
		templateAddShiftStartTimeInput.type(startTime);
		templateAddShiftEndTimeInput.type(endTime);
		templateAddShiftPayCodeInput.click();
		templateAddShiftDepartmentInput.type(dept);
		selectLookupDropDownOption(templateAddDepartmentLookUpOption);
		templateAddShiftJobInput.type(job);
		selectLookupDropDownOption(templateAddJobLookUpOption);
		templateAddShiftLocationInput.type(location);
		selectLookupDropDownOption(templateAddLocationLookUpOption);
		templateAddShiftMealPlanInput.type(mealPlan);
		templateAddShiftPayCodeInput.type(payCode);
		selectLookupDropDownOption(templateAddPaycodeLookUpOption);
		templateAddShiftSaveButton.click();
		WaitForAjax();
	}

	public void createSingleWeekTemplate(String templateName, String paycode, String dept, String job,
			String location) {
		getLoggedInUser();
		waitABit(7000);
		scheduleTemplateLink.waitUntilClickable();
		scheduleTemplateLink.click();
		createNewTemplateButton.waitUntilClickable();
		createNewTemplateButton.click();
		templateNameInput.waitUntilClickable();
		templateNameInput.type(templateName);
		templateDescriptionInput.type(templateName);
		templateStartDateInput.type("01/01/2018");
		waitABit(1000);
		for (Integer i = 0; i < 5; i++) {
			WebElementFacade shiftCell = getElementByDynamicValues("xpath", "templateShiftCell", "0", i.toString());
			shiftCell.click();
		}
		templateAddShiftIcon.click();
		waitABit(1000);
		enterShiftOnTemplateAddShiftDialog("6a", "12p", paycode, dept, "45AUTO - 45-Min Never Punch - Autodeduct", job,
				location);
		waitABit(1000);
		SaveTemplateButton.click();
		WaitForAjax();
		WebElementFacade newTemplate = getElementByDynamicValues("xpath", "createdTemplate", templateName);
		newTemplate.shouldBeVisible();
	}

	public void editTemplate(String templateName, String paycode, String newPaycode, String dept, String newDept,
			String job, String newJob, String location, String newLocation) {
		waitABit(2000);
		WebElementFacade template = getElementByDynamicValues("xpath", "createdTemplate", templateName);
		template.click();
		WaitForAjax();
		// Delete first shift of the template
		templateDescriptionInput.type(templateName + "Edited");
		WebElementFacade firstShift = getElementByDynamicValues("xpath", "editTemplateTimePair", "2");
		firstShift.click();
		WebElementFacade firstShiftGearIcon = getElementByDynamicValues("xpath", "editTemplateTimePairGearIcon", "2");
		firstShiftGearIcon.click();
		editTemplateDeleteShiftLink.click();
		editTemplateConfirmShiftDelete.click();
		WaitForAjax();
		// Edit Second Shift of the template
		WebElementFacade secondShift = getElementByDynamicValues("xpath", "editTemplateTimePair", "3");
		secondShift.click();
		WebElementFacade secondShiftGearIcon = getElementByDynamicValues("xpath", "editTemplateTimePairGearIcon", "3");
		secondShiftGearIcon.click();
		editTemplateEditShiftLink.click();
		enterShiftOnTemplateAddShiftDialog("4p", "8p", newPaycode, newDept, "30ACTL - 30-Min Always Punch - Actual",
				newJob, newLocation);
		// Add two new shifts
		for (Integer i = 5; i < 7; i++) {
			WebElementFacade shiftCell = getElementByDynamicValues("xpath", "templateShiftCell", "0", i.toString());
			shiftCell.click();
		}
		WebElementFacade addShiftIcon = getElementByDynamicValues("xpath", "templateAddShiftIcon", "5");
		addShiftIcon.click();
		enterShiftOnTemplateAddShiftDialog("6a", "12p", paycode, dept, "45AUTO - 45-Min Never Punch - Autodeduct", job,
				location);
		SaveTemplateButton.click();
		WaitForAjax();
		templateEditEffectiveDateInput.type("02/02/2019");
		templateEnterEffectiveDateDialogDoneButton.click();
	}

	public void deleteScheduleTemplate(String templateName) {
		WebElementFacade template = getElementByDynamicValues("xpath", "createdTemplate", templateName);
		template.click();
		waitABit(3000);
		while (templateDeleteRecord.isCurrentlyVisible()) {
			templateDeleteRecord.waitUntilClickable();
			templateDeleteRecord.click();
			waitABit(1000);
			confirmTemplateDeleteButton.click();
			waitABit(1500);
		}
		template.shouldNotBeCurrentlyVisible();
	}

	public void verifyTemplateDeleteAudit(String templateName) {
		// Validate data on Template Delete Audit page
		viewDeleteAuditLink.waitUntilClickable();
		viewDeleteAuditLink.click();
		String date = LocalDate.now().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		viewDeleteAuditTemplateNameColumn.waitUntilVisible();
		Assert.isTrue(viewDeleteAuditTemplateNameColumn.getText().equals(templateName),
				"Deleted template not displayed on Template Delete Audit page!!!");
		Assert.isTrue(viewDeleteAuditDeletedDateColumn.getText().contains(date),
				"Value of Date Deleted does not match the actual date the template was deleted!!!");
		Assert.isTrue(viewDeleteAuditDeletedByColumn.getText().equalsIgnoreCase(loggedInUser),
				"Deleted By Name does not match the name of actual user that deleted the template!!!");
		// Validate Schedule Template Audit page for the deleted template is displayed
		// upon clicking View Audit link
		viewDeleteAuditDetailLink.click();
		WaitForAjax();
		Assert.isTrue(scheduleTemplateAuditTitle.getText().equals("Schedule Template Audit for " + templateName),
				"Deleted template not displayed on Schedule Template Audit page!!!");
	}

	public void verifyTemplateDeleteAuditDetails(String templateName, String paycode, String newPaycode, String dept,
			String newDept, String job, String newJob, String location, String newLocation) {
		viewDeleteAuditLink.waitUntilClickable();
		viewDeleteAuditLink.click();
		WaitForAjax();
		WebElementFacade viewAuditLink = getElementByDynamicValues("xpath", "deletedTemplateViewAuditLink",
				templateName);
		viewAuditLink.click();
		templateAuditDetailsValidation(templateName, paycode, newPaycode, dept, newDept, job, newJob, location,
				newLocation);
	}

	/* #############SCHEDULE TEMPLATE AUDIT FEATURE AUTOMATION############## */
	public void navigateToTemplateAuditPage(String templateName) {
		waitABit(2000);
		WebElementFacade rowGrabber = getElementByDynamicValues("xpath", "templateRowGrabberMenu", templateName);
		rowGrabber.click();
		templateRowGrabberAuditOptionLink.click();
		templateAuditSlideInTitle.waitUntilClickable();
		Assert.isTrue(templateAuditSlideInTitle.getText().equals("Schedule Template Audit for " + templateName),
				"Template Audit Title is not Correctly Displayed on Template Audit Page!!!");
	}

	public void verifyTemplateChangeAudit(String templateName, String desc, String effectiveDate) {
		navigateToTemplateAuditPage(templateName);
		String date = LocalDate.now().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		WebElementFacade changedBy = getElementByDynamicValues("xpath", "templateAuditColumns", "0");
		Assert.isTrue(changedBy.getText().equalsIgnoreCase(loggedInUser),
				"Change by name does not match name of actual user that edited the template!!!");
		WebElementFacade dateEdited = getElementByDynamicValues("xpath", "templateAuditColumns", "1");
		Assert.isTrue(dateEdited.getText().contains(date),
				"Edit date does not reflect the date the template was edited!!!");
		WebElementFacade effDate = getElementByDynamicValues("xpath", "templateAuditColumns", "4");
		Assert.isTrue(effDate.getText().equals(effectiveDate),
				"Expected Effective Date does not match actual Effective Date!!!");
		WebElementFacade description = getElementByDynamicValues("xpath", "templateAuditColumns", "5");
		Assert.isTrue(description.getText().equals(desc), "Expected description is not equal to actual description!!!");
		templateAuditPageBackButton.click();
		WaitForAjax();
	}

	public void validateTemplateAuditDetails(String templateName, String paycode, String newPaycode, String dept,
			String newDept, String job, String newJob, String location, String newLocation) {
		WaitForAjax();
		navigateToTemplateAuditPage(templateName);
		templateAuditDetailsValidation(templateName, paycode, newPaycode, dept, newDept, job, newJob, location,
				newLocation);
	}

	public void templateAuditDetailsValidation(String templateName, String paycode, String newPaycode, String dept,
			String newDept, String job, String newJob, String location, String newLocation) {
		scheduleTemplateAuditViewDetailsLink.click();
		WaitForAjax();
		Assert.isTrue(scheduleTemplateAuditDetailsTemplateName.getText().equals(templateName),
				"Edited template not displayed on Schedule Template Audit page!!!");
		validateScheduleTempSettingChanges(templateName);
		// Validate Schedule Template Shift Changes
		for (Integer j = 0; j < 3; j++) {
			List<String> rowValues = getAuditDetailsRowValues(j);
			String[] expectedValues;

			String editType = rowValues.get(0);
			String expectedAuditDetailInsert[] = { "Insert", "", "6:00 AM", "", "12:00 PM", "", dept, "", job, "",
					location, "", paycode, "", "45AUTO" };
			String expectedAuditDetailUpdate[] = { "Update", "6:00 AM", "4:00 PM", "12:00 PM", "8:00 PM", dept, newDept,
					job, newJob, location, newLocation, paycode, newPaycode, "45AUTO", "30ACTL" };
			String expectedAuditDetailDelete[] = { "Delete", "6:00 AM", "", "12:00 PM", "", dept, "", job, "", location,
					"", paycode, "", "45AUTO", "" };

			switch (editType) {
			case "Insert":
				expectedValues = expectedAuditDetailInsert;
				break;
			case "Update":
				expectedValues = expectedAuditDetailUpdate;
				break;
			default:
				expectedValues = expectedAuditDetailDelete;
				break;
			}

			Assert.isTrue(Arrays.asList(expectedValues).equals(rowValues),
					"Actual Audit Detail values not equal to expected values!!!");
			rowValues.clear();
		}
		// validate pay code and lunch plan
		if ((scheduleTemplateAuditDetailsEditType.getText().equals("Insert"))) {
			closeSlideInButton.click();
			WaitForAjax();
			templateAuditPageBackButton.click();
			WaitForAjax();
		}
	}

	/*
	 * ##########US1100956 - SCHEDULE TEMPLATE AUDIT TEMPLATE - IMPLEMENT COLUMN
	 * SORTING #############
	 */
	public void validateScheduleTemplateAuditSorting() {
		navigateToTemplateAuditPage("TemplateEditAuditTest");
		// Validate changed date column sorting
		scheduleTemplateAuditChangedDateSortIcon.click();
		waitABit(1000);
		verifyScheduleAuditColumnSorting("viewDeleteAuditDeletedDateColumn");
		// Validate effective date column sorting
		scheduleTemplateAuditEffDateSortIcon.click();
		waitABit(1000);
		verifyScheduleAuditColumnSorting("scheduleTemplateAuditEffDateColumn");
		// Validate description column sorting
		scheduleTemplateAuditDescriptionSortIcon.click();
		waitABit(1000);
		verifyScheduleAuditColumnSorting("scheduleTemplateAuditDescColumn");
		templateAuditPageBackButton.click();
		WaitForAjax();
	}

	// ########### ROW GRABBER #################
	/*
	 * ##########US1100956 - SCHEDULE TEMPLATE AUDIT TEMPLATE DETAILS - IMPLEMENT
	 * COLUMN SORTING #############
	 */
	public void validatedTemplateAuditDetailsSorting() {
		try {
			viewDeleteAuditDetailsEditTypeSortIcon.click();
			waitABit(1000);
			List<String> editTypeAscending = getTemplateAuditDetailsColumnValues(2);
			Assert.isTrue(Ordering.natural().isOrdered(editTypeAscending),
					"Template audit details Edit Type column is not sorted!");
			// Reverse Sort
			viewDeleteAuditDetailsEditTypeSortIcon.click();
			waitABit(1000);
			List<String> editTypeDescending = getTemplateAuditDetailsColumnValues(2);
			Assert.isTrue(Ordering.natural().reverse().isOrdered(editTypeDescending),
					"Template audit details Edit Type column is not sorted!");

			// TODO: Add link name sorting validation after fix

			WaitForAjax();
		} finally {
			if (closeSlideInButton.isCurrentlyVisible()) {
				closeSlideInButton.click();
			}
			waitABit(2000);
			templateAuditPageBackButton.click();
			WaitForAjax();
		}
	}

	public void viewAllNotesPage() {
		try {
			DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			LocalDate startOfWeek = LocalDate.now().with(DayOfWeek.MONDAY).plusDays(-1);
			String fullname = getElementByDynamicValues("xpath", "employeeNameShell", "2").getText();
			String note = "Schedule note";
			waitABit(3000);
			for (int i = 2; i < 6; i++) {
				getElementByDynamicValues("xpath", "scheduleShiftCell", "2", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "AddShiftIcon", "2", Integer.toString(i)).click();
				addShiftIntime.waitUntilClickable();
				addShiftIntime.typeAndTab("8");
				addShiftOutTime.type("4p");
				addShiftNote.type(note + i);
				addShiftSave.click();
				waitABit(3000);
			}
			String[] actualValues = { "08:00 AM", "04:00 PM", "", "Schedule note" };
			navigateToRowGrabberPage("2", "View All Notes");
			// validate view all notes display
			Assert.isTrue(viewAllNotesEmpName.getText().equals(fullname),
					"Wrong Employee Name Displayed on View All Notes Slide in");
			Assert.isTrue(
					viewAllNotesDateRange.getText()
							.equals(startOfWeek.format(format) + " TO " + startOfWeek.plusDays(6).format(format)),
					"Wrong Employee Name Displayed on View All Notes Slide in");
			for (int j = 0; j < 4; j++) {
				Assert.isTrue(
						getElementByDynamicValues("xpath", "viewNotesColumn", Integer.toString(j), "0").getText()
								.equals(startOfWeek.plusDays(j).format(format)),
						"Wrong Date Displayed in View All Notes Slide in");
				Assert.isTrue(getElementByDynamicValues("xpath", "viewNotesColumn", Integer.toString(j), "1").getText()
						.equals(actualValues[0]), "Wrong Start Time Displayed in View All Notes Slide in");
				Assert.isTrue(getElementByDynamicValues("xpath", "viewNotesColumn", Integer.toString(j), "2").getText()
						.equals(actualValues[1]), "Wrong End Time Displayed in View All Notes Slide in");
				Assert.isTrue(getElementByDynamicValues("xpath", "viewNotesColumn", Integer.toString(j), "3").getText()
						.equals(actualValues[2]), "Wrong Reason Code Displayed in View All Notes Slide in");
				Assert.isTrue(
						getElementByDynamicValues("xpath", "viewAllNotesNoteColumn", Integer.toString(j), "4").getText()
								.equals(actualValues[3] + (j + 2)),
						"Wrong Reason Code Displayed in View All Notes Slide in");
			}
		} finally {
			// clean up: delete added shifts
			viewAllBackButton.click();
			WaitForAjax();
			for (int i = 2; i < 6; i++) {
				getElementByDynamicValues("xpath", "scheduleShiftCell", "2", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "cellSelectionIcon", "2", Integer.toString(i)).click();
			}
			actionBarDeleteShiftLink.click();
			confirmDeleteDialogYesButton.click();
			WaitForAjax();
		}
	}

	public void monthlySchedulePage(String dept, String job, String location) {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("MMMM YYYY");
		LocalDate startOfWeek = LocalDate.now().with(DayOfWeek.MONDAY).plusDays(-1);
		String fullname = getElementByDynamicValues("xpath", "employeeNameShell", "2").getText();
		for (int i = 4; i < 7; i++) {
			getElementByDynamicValues("xpath", "scheduleShiftCell", "2", Integer.toString(i)).click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", "2", Integer.toString(i)).click();
		}
		actionBarAddShiftLink.click();
		enterShiftInDialog("8", "4p", "PERSONAL - Personal Hours", "30ACTL - 30-Min Always Punch - Actual", dept, job,
				location, "schedule note");
		navigateToRowGrabberPage("2", "Monthly Schedule");
		Assert.isTrue(monthlyScheduleEmpName.getText().equals(fullname),
				"Wrong Employee Name Displayed on Monthly Schedule Slide in");
		Assert.isTrue(monthlyScheduleCurrentDate.getText().equals(startOfWeek.format(format)),
				"Monthly Schedule - Expected month not equal to actual month!!!");
		String cellHeader = null;
		startOfWeek = startOfWeek.plusDays(1);
		int i = 0;
		while (i++ < 3) {
			// verify added shifts on monthly schedule slide-in
			startOfWeek = startOfWeek.plusDays(1);
			cellHeader = Integer.toString(startOfWeek.getDayOfMonth());
			// cellHeader =
			// WordUtils.capitalizeFully(startOfWeek.getDayOfWeek().toString()+"
			// "+startOfWeek.getDayOfMonth());
			// verify shift data
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftValues", cellHeader, "1").getText()
							.equals("08:00 AM - 04:00 PM"),
					"Actual shift time on Monthly Schedule Slide in not equal to Expected shift time!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftValues", cellHeader, "2").getText()
							.equals("PERSONAL"),
					"Actual shift PAYCODE on Monthly Schedule Slide in not equal to Expected shift PAYCODE!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftValues", cellHeader, "3").getText()
							.contains(dept),
					"Actual shift DEPARTMENT on Monthly Schedule Slide in not equal to Expected shift DEPARTMENT!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftValues", cellHeader, "4").getText()
							.contains(job),
					"Actual shift JOB on Monthly Schedule Slide in not equal to Expected shift JOB!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftValues", cellHeader, "5").getText()
							.contains(location),
					"Actual shift LOCATION on Monthly Schedule Slide in not equal to Expected shift LOCATION!!!");
		}
	}

	public void verifyMonthlyScheduleShiftDetailsDialog(String dept, String job, String location) {
		LocalDate startOfWeek = LocalDate.now().with(DayOfWeek.MONDAY).plusDays(3);
		String cellHeader = Integer.toString(startOfWeek.getDayOfMonth());
		// String cellHeader =
		// WordUtils.capitalizeFully(startOfWeek.getDayOfWeek().toString()+"
		// "+startOfWeek.getDayOfMonth());
		// validate month schedule shift detail dialog
		try {
			getElementByDynamicValues("xpath", "monthlyScheduleShift", cellHeader).click();
			waitABit(1000);
			monthlyScheduleShiftDetailsClose.shouldBeCurrentlyVisible();
			Assert.isTrue(monthlyScheduleShiftDetailsTime.getText().equals("08:00 AM - 04:00 PM"),
					"Actual shift TIME on Monthly Schedule Shift Details Dialog in not equal to Expected shift TIME!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftDialogValues", "0").getText()
							.equals("PERSONAL - Personal Hours"),
					"Actual shift PAYCODE on Monthly Schedule Shift Details Dialog in not equal to Expected shift PAYCODE!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftDialogValues", "1").getText()
							.contains(dept),
					"Actual shift DEPARTMENT on Monthly Schedule Shift Details Dialog in not equal to Expected shift DEPARTMENT!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftDialogValues", "2").getText().contains(job),
					"Actual shift JOB on Monthly Schedule Shift Details Dialog in not equal to Expected shift JOB!!!");
			Assert.isTrue(
					getElementByDynamicValues("xpath", "monthlyScheduleShiftDialogValues", "3").getText()
							.contains(location),
					"Actual shift LOCATION on Monthly Schedule Shift Details Dialog in not equal to Expected shift LOCATION!!!");
		} finally {
			monthlyScheduleShiftDetailsClose.click();
			WaitForAjax();
		}
	}

	public void monthlyScheduleDateSelectionAndViewToggle() {
		try {
			DateTimeFormatter format = DateTimeFormatter.ofPattern("MMMM YYYY");
			LocalDate startOfWeek = LocalDate.now().with(DayOfWeek.MONDAY).plusDays(-1);
			// validate month/week view toggle
			monthlyScheduleWeekMonthSchedule.click();
			waitABit(1000);
			Assert.isTrue(monthlyScheduleWeekView.isCurrentlyVisible(),
					"Monthly Schedule Slide In week view NOT displayed when Week View Toggle button is clicked!!!");
			monthlyScheduleWeekMonthSchedule.click();
			waitABit(2000);
			// verify next month and previous month date selection
			monthlySchedulePreviousMonth.click();
			waitABit(2000);
			startOfWeek = startOfWeek.minusDays(31);
			Assert.isTrue(monthlyScheduleCurrentDate.getText().equals(startOfWeek.format(format)),
					"Monthly Schedule - Expected month not equal to actual month when previous month is selected!!!");
			monthlyScheduleNextMonth.click();
			waitABit(2000);
			startOfWeek = startOfWeek.plusDays(31);
			Assert.isTrue(monthlyScheduleCurrentDate.getText().equals(startOfWeek.format(format)),
					"Monthly Schedule - Expected month not equal to actual month when next month is selected!!!");
		} finally {
			monthlyScheduleCloseButton.click();
			waitABit(2000);
			// Clean up: Delete all shifts
			for (int i = 4; i < 7; i++) {
				getElementByDynamicValues("xpath", "scheduleShiftCell", "2", Integer.toString(i)).click();
				getElementByDynamicValues("xpath", "cellSelectionIcon", "2", Integer.toString(i)).click();
			}
			actionBarDeleteShiftLink.click();
			confirmDeleteDialogYesButton.click();
			WaitForAjax();
		}
	}

	public void employeeInformationValidation(String payclass, String supervisor) {
		try {
			navigateToRowGrabberPage("1", "Employee Information");
			waitABit(3000);
			selectFrame(empInfoIframe);

			Assert.isTrue(empInfoSupervisor.getText().equalsIgnoreCase(supervisor),
					"Expected Supervisor NOT Equal to Actual Supervisor on Employee Info Page");
			Assert.isTrue(empInfoPayClass.getText().equals(payclass),
					"Expected Pay Class NOT Equal to Actual Pay Class on Employee Info Page");
			Assert.isTrue(empInfoPayCycle.getText().contains(payclass),
					"Expected Pay Cycle NOT Equal to Actual Pay Cycle on Employee Info Page");
			empInfoPrintIcon.shouldBeCurrentlyVisible();
		} finally {
			switchToDefaultContent();
			if (empInfoBackButton.isCurrentlyVisible()) {
				empInfoBackButton.click();
			}
		}
	}

	public void timecardSlideInIndividaulTimecardTab(String dept, String job, String location) {
		// DateTimeFormatter format = DateTimeFormatter.ofPattern("M/d/yyyy");
		// LocalDate startOfWeek = LocalDate.now().with(DayOfWeek.MONDAY).plusDays(-1);
		String fullname = getElementByDynamicValues("xpath", "employeeNameShell", "0").getText();
		getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "2").click();
		getElementByDynamicValues("xpath", "cellSelectionIcon", "0", "2").click();
		waitABit(500);
		actionBarAddShiftLink.click();
		enterShiftInDialog("8", "4p", "DBLTME - Doubletime", "45AUTO - 45-Min Never Punch - Autodeduct", dept, job,
				location, "Add shift note");
		waitABit(1500);
		navigateToRowGrabberPage("0", "Individual Timecard");
		waitABit(4000);
		// verify employee name
		Assert.isTrue(individualTimecardHeader.getText().contains(fullname),
				"Actual Employee Name NOT 	equal to Expected Employee Name on Individaul Timecard Slide-in");
		// verify date range
		/*
		 * Assert.isTrue(individualTimecardStartDate.getValue().equals(startOfWeek.
		 * format(format)),
		 * "Wrong Start Date Value When This Week Date Range is Selected!!!");
		 * Assert.isTrue(individualTimecardEndDate.getValue().equals(startOfWeek.
		 * plusDays(6).format(format)),
		 * "Wrong End Date Value When This Week Date Range is Selected!!!");
		 */
		// verify date range drop down option
		individualTimecardDropDown.click();
		waitABit(500);
		Assert.isTrue(getElementByDynamicValues("xpath", "individualTimecardDateOptions", "0").getText()
				.equals("Current Pay Period"), "Current Pay Period is NOT display in drop-down option");
		Assert.isTrue(getElementByDynamicValues("xpath", "individualTimecardDateOptions", "1").getText()
				.equals("Next Pay Period"), "Next Pay Period is NOT display in drop-down option");
		Assert.isTrue(getElementByDynamicValues("xpath", "individualTimecardDateOptions", "2").getText()
				.equals("Previous Pay Period"), "Previous Pay Period is NOT display in drop-down option");
		Assert.isTrue(getElementByDynamicValues("xpath", "individualTimecardDateOptions", "3").getText()
				.equals("Range of Dates"), "Range of Dates is NOT display in drop-down option");
		Assert.isTrue(getElementByDynamicValues("xpath", "individualTimecardDateOptions", "4").getText()
				.equals("Historical Pay Periods..."), "Historical Pay Periods... is NOT display in drop-down option");

		// verify adding time pairs
		doubleClick(individualTimecardHour);
		typeInActiveElement("8");
		individualTimecardSaveButton.click();
		WaitForAjax();
		waitABit(3000);
		individualTimecardOperationSuccessful.shouldBeVisible();
		doubleClick(individualTimecardHour);
		typeInActiveElement("2");
		individualTimecardSaveButton.click();
		WaitForAjax();
		waitABit(3000);
	}

	public void timecardSlideInScheduleTab(String dept, String job, String location) {
		individualTimecardScheduleTab.click();
		WaitForAjax();
		if (individualTimecardHour.getText().equals("2.00")) {
			Assert.isTrue(individualTimecardScheduleHourValue.getText().equals("7.25"),
					"Actual schedule HOUR value not equal to expected schedule HOUR value on Schedule tab on Individual Timecard Slide in");
		} else {
			Assert.isTrue(individualTimecardHour.getText().equals("2:00"),
					"Actual Timecard HOURS value not equal to expected Timecard HOURS value on Schedule tab on Individual Timecard Slide in");
			Assert.isTrue(individualTimecardScheduleHourValue.getText().equals("7:15"),
					"Actual schedule HOUR value not equal to expected schedule HOUR value on Schedule tab on Individual Timecard Slide in");
		}
		Assert.isTrue(
				getElementByDynamicValues("xpath", "indTimecardScheduleShiftAttribute", "PayCodeID").getText()
						.equals("DBLTME"),
				"Actual PAYCODE value not equal to expected PAYCODE value on Schedule tab on Individual Timecard Slide in");
		Assert.isTrue(
				getElementByDynamicValues("xpath", "indTimecardScheduleShiftAttribute", "DepartmentID").getText()
						.equals(dept),
				"Actual DEPARTMENT value not equal to expected DEPARTMENT value on Schedule tab on Individual Timecard Slide in");
		Assert.isTrue(
				getElementByDynamicValues("xpath", "indTimecardScheduleShiftAttribute", "WorkedJobID").getText()
						.equals(job),
				"Actual JOB value not equal to expected JOB value on Schedule tab on Individual Timecard Slide in");
		// TODO: enable location for timecard
		Assert.isTrue(
				getElementByDynamicValues("xpath", "indTimecardScheduleShiftAttribute", "Lcf").getText()
						.equals(location),
				"Actual LOCATION value not equal to expected LOCATION value on Schedule tab on Individual Timecard Slide in");
	}

	public void timecardSlideInTotalAndTimeOffTab() {
		waitABit(3000);
		try {
			individualTimecardTotalsTab.click();
			WaitForAjax();
			// verify shift total
			Assert.isTrue(individualTimecardTotalsTabTotalValue.getText().equals("2:00"),
					"Actual regular shift TOTAL value not equal to expected regular shift TOTAL value on Schedule tab on Individual Timecard Slide in");
			individualTimecardTOR.click();
			WaitForAjax();
			waitABit(3000);
			individualTimecardTimeOffBalanceTable.shouldBeCurrentlyVisible();
		} finally {
			individualTimecardBackButton.click();
			waitABit(3000);
			// clean up: Delete shift
			getElementByDynamicValues("xpath", "scheduleShiftCell", "0", "2").click();
			getElementByDynamicValues("xpath", "cellSelectionIcon", "0", "2").click();
			actionBarDeleteShiftLink.click();
			confirmDeleteDialogYesButton.click();
			waitABit(2000);
			addedShift.shouldNotBePresent();
		}
	}

	public void timeoffBalancesSlidein() {
		try {
			String fullname = getElementByDynamicValues("xpath", "employeeNameShell", "0").getText();
			navigateToRowGrabberPage("0", "Time Off Balances");
			DateTimeFormatter format = DateTimeFormatter.ofPattern("M/d/yyyy");
			String today = LocalDate.now().format(format);
			waitABit(2000);
			Assert.isTrue(timeOffBalancesTitle.getText().equals("Time Off Balances for " + fullname),
					"Actual Employee Name NOT equal to Expected Employee Name on Time Off Balances Slide-in!!!");
			selectFrame(timeOffBalancesIframe);
			Assert.isTrue(timeOffBalancesAsOfDate.getValue().equals(today),
					"Actual As of Date NOT equal to Expected As of Date on Time Off Balances Slide-in!!!");
			Assert.isTrue(timeOffBalancesTable.isCurrentlyVisible(),
					"Time off Balances table is NOT displayed on Time off Balances Slide in!!!");
			switchToDefaultContent();
			waitABit(1500);
		} finally {
			timeOffBalancesBackButton.click();
		}
	}

	private void verifyScheduleAuditColumnSorting(String webElementName) {
		List<WebElementFacade> columns = findAll(extractWebElementXpath(webElementName));
		List<String> columnValues = new ArrayList<String>();
		for (int i = 0; (i < columns.size() && (i < 4)); i++) {
			columnValues.add(columns.get(i).getText());
		}
		Assert.isTrue(Ordering.natural().isOrdered(columnValues), webElementName + " Fields are not sorted!");
	}

	/** Takes a WebElmenent as argument and return it's XPath string value */
	private static String extractWebElementXpath(String element) {
		Field field = null;
		try {
			field = ScheduleObjectsGen.class.getField(element);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}
		Object objectXPath = field.getAnnotation(FindBy.class).xpath();
		return objectXPath.toString();
	}

	// Validate Schedule Template Settings Changes
	private void validateScheduleTempSettingChanges(String templateName) {
		String oldDesc = "";
		String newDesc = "";
		if (scheduleTemplateAuditDetailsEditType.getText().equals("Insert")) {
			oldDesc = "";
			newDesc = templateName;
		}
		if (scheduleTemplateAuditDetailsEditType.getText().equals("Update")) {
			oldDesc = templateName;
			newDesc = templateName + "Edited";
		}
		if (scheduleTemplateAuditDetailsEditType.getText().equals("Delete")) {
			oldDesc = templateName;
			newDesc = "";
		}
		Assert.isTrue(scheduleTemplateAuditDetailsChangedBy.getText().equalsIgnoreCase(loggedInUser),
				"Actual changedBy name is not equal to expected value!!!");
		Assert.isTrue(scheduleTemplateAuditDetailsOldDesc.getText().equals(oldDesc),
				"Actual old description is not equal to expected value!!!");
		Assert.isTrue(scheduleTemplateAuditDetailsNewDesc.getText().equals(newDesc),
				"Actual new description is not equal to expected value!!!");
	}

	private List<String> getAuditDetailsRowValues(Integer j) {
		List<String> values = new ArrayList<String>();
		for (Integer i = 2; i < 17; i++) {
			WebElementFacade auditDetailsColumn = getElementByDynamicValues("xpath", "templateAuditDetailsColumns",
					j.toString(), i.toString());
			if (auditDetailsColumn.isCurrentlyVisible()) {
				values.add(auditDetailsColumn.getText());
			}
		}
		return values;
	}

	private List<String> getTemplateAuditDetailsColumnValues(Integer j) {
		List<String> values = new ArrayList<String>();
		for (Integer i = 0; i < 4; i++) {
			WebElementFacade auditDetailsColumn = getElementByDynamicValues("xpath", "templateAuditDetailsColumns",
					i.toString(), j.toString());
			if (auditDetailsColumn.isCurrentlyVisible()) {
				values.add(auditDetailsColumn.getText());
			}
		}
		return values;
	}

	private void selectLookupDropDownOption(WebElementFacade option) {
		waitABit(500);
		if (option.isCurrentlyVisible()) {
			option.click();
		}
	}

	private void dragAndDropQuickShift(String quickShiftName, WebElementFacade cell) {
		WebElementFacade quickShift = getElementByDynamicValues("xpath", "quickShift", quickShiftName);
		dragAndDropElement(quickShift, cell);
	}

	private void selectViewSchedulePreference(WebElementFacade viewBy) {
		scheduleMoreLink.click();
		waitABit(500);
		morePreferenceLink.click();
		waitABit(500);
		viewBy.click();
		preferenceApplyButton.click();
		waitABit(1000);
	}

	public void clickManageAssignments(String templateName) {
		for (Integer i = 0; i < 15; i++) {
			WebElementFacade template = getElementByDynamicValues("xpath", "templateName", i.toString());
			if (template.getText().equals(templateName)) {
				WebElementFacade manageAssignments = getElementByDynamicValues("xpath", "manageAssignments",
						i.toString());
				manageAssignments.click();
				waitABit(5000);
				break;
			}

		}

	}

	public void selectemployees() {

		for (Integer i = 0; i < 3; i++) {
			WebElementFacade employeeIcon = getElementByDynamicValues("xpath", "employeeNameIcon", i.toString());
			employeeIcon.click();
		}
	}

	public void enterMultipleDateRanges() {
		LocalDate startOfWeek = LocalDate.now();
		for (Integer i = 0; i < 3; i++) {
			WebElementFacade startDate = getElementByDynamicValues("xpath", "templateStartDate", i.toString());
			startDate.type(startOfWeek.plusDays(i + 6).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
			WebElementFacade endDate = getElementByDynamicValues("xpath", "templateEndDate", i.toString());
			endDate.type(startOfWeek.plusDays(i + 14).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		}

		submitSchedulingAssignmentDates.click();
		waitABit(5000);

	}

	public void goBack() {
		waitABit(2000);
		closeManageAssignments.waitUntilClickable();
		closeManageAssignments.click();
		waitABit(1000);
	}

	public void assignedEmployees(String templateName) {
		for (Integer i = 0; i < 15; i++) {
			WebElementFacade template = getElementByDynamicValues("xpath", "templateName", i.toString());
			if (template.getText().equals(templateName)) {
				WebElementFacade assignedEmployees = getElementByDynamicValues("xpath", "assignedEmployees",
						i.toString());
				assignedEmployees.click();
				waitABit(5000);
				break;

			}
		}
	}

	public void verifyTemplateShiftOnEmployee(String inTime, String outTime, String empName) {
		LocalDate startOfWeek = LocalDate.now();
		int j = 0;
		waitABit(2000);
		String startDate = startOfWeek.plusDays(6).format(DateTimeFormatter.ofPattern("M/d/yyyy"));
		String endDate = startOfWeek.plusDays(14).format(DateTimeFormatter.ofPattern("M/d/yyyy"));
		scheduleStartDateInput.typeAndTab(startDate);
		scheduleEndDateInput.type(endDate);
		waitABit(1000);
		scheduleFindButton.click();
		waitABit(1000);
		searchByName.typeAndEnter(empName);
		waitABit(5000);

		System.out.println(inTime + " - " + outTime);

		for (int i = 2; i < 3; i++) {
			WebElementFacade timePair = getElementByDynamicValues("xpath", "shiftTime", Integer.toString(j),
					Integer.toString(i));
			System.out.println(timePair.getText());
			Assert.isTrue(timePair.containsText(inTime + " - " + outTime),
					"Template Shift Validation failed on employee schedule");

		}
	}

	public void selectSingleEmployee() {
		WebElementFacade employeeIcon = getElementByDynamicValues("xpath", "employeeNameIcon", "0");
		employeeIcon.click();
	}

	public void navigateToTemplates() {
		templateBtn.waitUntilClickable();
		templateBtn.click();
	}

	public void removeTemplateAssignment() {
		removeAssignments.click();
		removeCurrentShifts.waitUntilVisible();
		removeCurrentShifts.click();
		schedulingShiftsDelete.click();
		waitABit(2000);
		schedulingAssignmentClose.click();
		waitABit(3000);
	}

	public void veriftTemplateRemovalOnEmployee(String empName) {
		waitABit(5000);
		int j = 0;
		LocalDate startOfWeek = LocalDate.now();
		String startDate = startOfWeek.plusDays(6).format(DateTimeFormatter.ofPattern("M/d/yyyy"));
		String endDate = startOfWeek.plusDays(14).format(DateTimeFormatter.ofPattern("M/d/yyyy"));
		scheduleStartDateInput.typeAndTab(startDate);
		scheduleEndDateInput.type(endDate);
		waitABit(1000);
		scheduleFindButton.click();
		waitABit(1000);
		searchByName.typeAndEnter(empName);
		int count = getObjectCount("//div[contains(@id, 'timepair')]");
		if (count == 0) {
			Assert.isTrue(count == 0, "Employee schedule not deleted");
		} else if (count != 0) {
			firstShiftCellTimePair.shouldNotBeVisible();
//			for (int i = 2; i < 3; i++) {
//				WebElementFacade timePair = getElementByDynamicValues("xpath", "shiftTime", Integer.toString(j),
//						Integer.toString(i));
//				System.out.println(timePair.getText());
//				Assert.isTrue(!timePair.containsText("06:00AM - 12:00 PM"), "Employee schedule not deleted");
//
//			}
		}
		waitABit(2000);

	}

	public void selectAllEmployees() {
		waitABit(3000);
		selectAllEmployees.click();
	}

	public void selectSameDateRange() {
		LocalDate startOfWeek = LocalDate.now();
		setDateRangeForEmployees.click();
		String startDatetoggleSwitch = startDateToggleSwitch.getAttribute("class");
		if (startDatetoggleSwitch.contains("floatLeft")) {
			startDateToggle.click();
		}

		startDateSchedulingAssignment.type(startOfWeek.plusDays(6).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		String endDatetoggleSwitch = endDateToggleSwitch.getAttribute("class");
		if (endDatetoggleSwitch.contains("floatLeft")) {
			endDateToggle.click();
		}

		endDateSchedulingAssignment.type(startOfWeek.plusDays(14).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		applyAllSchedulingAssignment.click();
		submitSchedulingAssignmentDates.click();
		waitABit(6000);
	}

//	public void validateAssignmentsForSameDateRange() {
//		LocalDate startOfWeek = LocalDate.now();
//		String Date = startOfWeek.plusDays(6).format(DateTimeFormatter.ofPattern("M/d/yyyy"));
//		int j = 4;
//
//		for (int i = 0; i < 3; i++) {
//			waitABit(1000);
//			WebElementFacade Startdate = getElementByDynamicValues("xpath", "employeeTemplateDate", Integer.toString(i),
//					Integer.toString(j));
//			// System.out.println("test "+date.getText());
//			Assert.isTrue(Startdate.containsText(Date), "Dates donot match");
//		}
//		waitABit(10000);
//	}

	public void validateAssignmentsForSameDateRange(String inTime, String outTime, String empName) {
		LocalDate startOfWeek = LocalDate.now();
		System.out.println("StartOfTheWeek"+startOfWeek);
		int j = 0;
		waitABit(2000);
		String startDate = startOfWeek.plusDays(6).format(DateTimeFormatter.ofPattern("M/d/yyyy"));
		String endDate = startOfWeek.plusDays(14).format(DateTimeFormatter.ofPattern("M/d/yyyy"));
		scheduleStartDateInput.typeAndTab(startDate);
		scheduleEndDateInput.type(endDate);
		waitABit(1000);
		scheduleFindButton.click();
		waitABit(1000);
		searchByName.typeAndEnter(empName);
		waitABit(5000);

		System.out.println(inTime + " - " + outTime);

		for (int i = 2; i < 3; i++) {
			WebElementFacade timePair = getElementByDynamicValues("xpath", "shiftTime", Integer.toString(j),
					Integer.toString(i));
			System.out.println(timePair.getText());
			Assert.isTrue(timePair.containsText(inTime + " - " + outTime),
					"Template Shift Validation failed on employee schedule");

		}
	}

	public void navigateToSchedulesPage() {
		waitABit(3000);
		closeBtn.waitUntilClickable();
		closeBtn.click();
		waitABit(6000);

	}

	public void validateOverlapErrorMessage() {
		Assert.isTrue(overlapErrorMessage.getText().contains(
				"Cannot save the changes because overlapping shifts would be caused for one or more assignments if the changes are saved."),
				"Error Message for Overlapping shifts!!!");
		schedulingAssignmentClose.click();
		waitABit(3000);
	}

	public void selectEmployee(String employeeName) {
		for (Integer i = 0; i < 15; i++) {
			WebElementFacade empName = getElementByDynamicValues("xpath", "employeeNames", i.toString());
			if (empName.getText().equals(employeeName)) {
				WebElementFacade employeeIcon = getElementByDynamicValues("xpath", "employeeNameIcon", i.toString());
				employeeIcon.click();
				break;
			}
		}
		nextScheduleAssignment.click();
		waitABit(2000);

	}

	public void multipleTimesTemplate(String templateName, String startTime, String endTime) {
		getLoggedInUser();
		scheduleTemplateLink.waitUntilClickable();
		scheduleTemplateLink.click();
		createNewTemplateButton.waitUntilClickable();
		createNewTemplateButton.click();
		templateNameInput.waitUntilClickable();
		templateNameInput.type(templateName);
		templateDescriptionInput.type(templateName);
		templateStartDateInput.type("01/01/2018");
		for (Integer i = 0; i < 5; i++) {
			WebElementFacade shiftCell = getElementByDynamicValues("xpath", "templateShiftCell", "0", i.toString());
			shiftCell.click();
		}
		templateAddShiftIcon.click();
		enterTimeOnTemplateAddShiftDialog(startTime, endTime);
		SaveTemplateButton.click();
		WaitForAjax();
		WebElementFacade newTemplate = getElementByDynamicValues("xpath", "createdTemplate", templateName);
		newTemplate.shouldBeVisible();
	}

	public void multipleShiftsTemplate(String templateName, String startTime, String endTime) {
		WebElementFacade template = getElementByDynamicValues("xpath", "createdTemplate", templateName);
		template.click();
		WaitForAjax();
		for (Integer i = 0; i < 5; i++) {
			WebElementFacade shiftCell = getElementByDynamicValues("xpath", "templateShiftCell", "0", i.toString());
			shiftCell.click();
		}
		WebElementFacade thirdShiftGearIcon = getElementByDynamicValues("xpath", "editTemplateTimePairGearIcon", "4");
		thirdShiftGearIcon.click();
		editTemplateAddShiftLink.waitUntilClickable();
		editTemplateAddShiftLink.click();
		enterTimeOnTemplateAddShiftDialog(startTime, endTime);
		SaveTemplateButton.click();
		WaitForAjax();
		templateEditEffectiveDateInput.type("02/02/2019");
		templateEnterEffectiveDateDialogDoneButton.click();
		waitABit(3000);
	}

	public void enterTimeOnTemplateAddShiftDialog(String startTime, String endTime) {
		templateAddShiftStartTimeInput.waitUntilClickable();
		templateAddShiftStartTimeInput.type(startTime);
		templateAddShiftEndTimeInput.type(endTime);
		templateAddShiftSaveButton.click();
		WaitForAjax();
	}

	public void validateTemplateDetails(String templateName) {

		WebElementFacade template = getElementByDynamicValues("xpath", "createdTemplate", templateName);
		template.click();
		WaitForAjax();
		Assert.isTrue(templateNameInput.getAttribute("value").equals(templateName), "Wrong Template Name!!!");
		Assert.isTrue(templateDescriptionInput.getAttribute("value").equals(templateName),
				"Wrong Template Description!!!");
		Assert.isTrue(SaveTemplateButton.isCurrentlyVisible(), "Save Template Button NOT displayed!!!");
		Assert.isTrue(cancelButton.isCurrentlyVisible(), "Cancel Button NOT displayed!!!");
		Assert.isTrue(manageAssignments.isCurrentlyVisible(), "Manage Assignments Button NOT displayed!!!");
		Assert.isTrue(templateStatus.getAttribute("value").equals("Active"), "Template Status is NOT Active!!!");
		Assert.isTrue(templateAccess.getAttribute("value").equals("Private"), "Template Access is NOT Private!!!");

	}

	public void navigateToTemplatesList() {
		templateCreatorBackButton.click();
		waitABit(3000);
	}

	public void deleteShiftsforTemplate(String templateName) {
		WebElementFacade template = getElementByDynamicValues("xpath", "createdTemplate", templateName);
		template.click();
		WaitForAjax();

		for (Integer i = 0; i < 4; i++) {
			WebElementFacade shiftCell = getElementByDynamicValues("xpath", "templateShiftCell", "0", i.toString());
			shiftCell.click();
		}

		WebElementFacade secondShiftGearIcon = getElementByDynamicValues("xpath", "editTemplateTimePairGearIcon", "3");
		secondShiftGearIcon.click();
		editTemplateDeleteShiftLink.click();
		editTemplateConfirmShiftDelete.click();
		WaitForAjax();
		SaveTemplateButton.click();
		WaitForAjax();
		LocalDate startOfWeek = LocalDate.now();
		templateEditEffectiveDateInput.type(startOfWeek.plusDays(7).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		templateEnterEffectiveDateDialogDoneButton.click();
		waitABit(3000);
	}

	public void setWrongDateRange() {

		LocalDate startOfWeek = LocalDate.now();
		setDateRangeForEmployees.click();
		String startDatetoggleSwitch = startDateToggleSwitch.getAttribute("class");
		if (startDatetoggleSwitch.contains("floatLeft")) {
			startDateToggle.click();
		}

		startDateSchedulingAssignment.type(startOfWeek.plusDays(5).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		String endDatetoggleSwitch = endDateToggleSwitch.getAttribute("class");
		if (endDatetoggleSwitch.contains("floatLeft")) {
			endDateToggle.click();
		}

		endDateSchedulingAssignment.type(startOfWeek.format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		applyAllSchedulingAssignment.click();
		waitABit(6000);
	}

	public void validateGreaterStartDate() {
		Assert.isTrue(
				schedulingAssignmentsDateErrorMsg.getText().contains("Start date cannot be greater than End Date."),
				"Wrong Error Message for Greater Start Date!!!");

	}

	public void setWrongDateRangeForMultipleEmployees() {
		LocalDate startOfWeek = LocalDate.now();
		for (Integer i = 0; i < 3; i++) {
			WebElementFacade startDate = getElementByDynamicValues("xpath", "templateStartDate", i.toString());
			startDate.type(startOfWeek.plusDays(5).format(DateTimeFormatter.ofPattern("M/d/yyyy")));
			WebElementFacade endDate = getElementByDynamicValues("xpath", "templateEndDate", i.toString());
			endDate.type(startOfWeek.format(DateTimeFormatter.ofPattern("M/d/yyyy")));
		}

		submitSchedulingAssignmentDates.click();
		waitABit(5000);

	}

	public void assignedToggleOn() {
		String assignedOnlyToggleSwitchText = assignedOnlyToggleSwitch.getAttribute("class");
		if (assignedOnlyToggleSwitchText.contains("floatLeft")) {
			assignedOnlyToggleSwitch.click();
		}

	}

	public void clickAssignmentCancel() {
//		schedulingAssignmentCancel.waitUntilClickable();
		schedulingAssignmentCancel.click();
		waitABit(3000);
	}

	public void navigateFromAssignmentsToTemplateList() {
		schedulingAssignmentClose.waitUntilClickable();
		schedulingAssignmentClose.click();
		waitABit(3000);
	}

	public void scheduleAssignmentsClickNext() {
		nextScheduleAssignment.click();
		waitABit(2000);
	}

	public void findUsername() {
		waitABit(2000);
		String name = username.getTextValue();
		String realName = name.split(" ")[1] + "," + name.split(" ")[0];
		searchByName.typeAndEnter(realName);
		waitABit(6000);
	}

	public void validateUser(String flag) {
		if (flag.equalsIgnoreCase("enabled")) {
			waitABit(2000);
			selfShiftCell.isVisible();
			waitABit(5000);
		} else if (flag.equalsIgnoreCase("disabled")) {
			waitABit(2000);
			System.out.println("test");
			try {
				selfShiftCell.shouldNotBeVisible();
			} catch (Exception e) {
				System.out.println("Error message: " + e.getMessage());
			}
		}

	}

	public void addShiftToSchedule(int paycode) {
		waitABit(5000);
		shiftcell.waitUntilClickable();
		shiftcell.click();
		addShiftIcon.click();
		addShiftIntime.waitUntilClickable();
		addShiftIntime.typeAndTab("1p");
		addShiftOutTime.type("3p");
		if (paycode == 1) {
			addShiftSave.click();
			waitABit(5000);
			findButton.waitUntilClickable();
			findButton.click();
			waitABit(2000);
		} else if (paycode == 0) {
			waitABit(2000);
			payCode.typeAndTab("ABSENT");
			paySelect.click();
			waitABit(2000);
			addShiftSave.click();
			waitABit(2000);
			findButton.waitUntilClickable();
			findButton.click();
			waitABit(2000);
		}
	}

	public void validateShift() {
		waitABit(5000);
		addedShift.containsText("01.00PM-03.00PM");
	}

	public void deleteShift() {
		waitABit(2000);
		addedShift.waitUntilClickable();
		addedShift.click();
		deleteIcon.waitUntilClickable();
		deleteIcon.click();

		confirmDeleteDialogYesButton.click();
		waitABit(4000);
		addedShift.shouldNotBePresent();
	}

	public void validateHours(String paycode) {
		waitABit(5000);
		if (paycode.equalsIgnoreCase("worked")) {
			moreIcon.waitUntilClickable();
			moreIcon.click();
			Assert.isTrue(totlHours.getTextValue().contains("2"), "Total Hours Don't Match!");
			Assert.isTrue(totalWorkedHours.getTextValue().contains("2"), "Total Worked Hours Don't Match!");
			Assert.isTrue(employeeWorkedHours.getTextValue().contains("2"), "Hours Don't Match!");
		} else if (paycode.equalsIgnoreCase("non-worked")) {
			Assert.isTrue(totlHours.getTextValue().contains("2"), "Total Hours Don't Match!");
			Assert.isTrue(employeeNonWorkedHours.getTextValue().contains("2"),
					"Employee Non- worked Hours Don't Match!");
			Assert.isTrue(totalNonWorkedHours.getTextValue().contains("2"), " Hours Don't Match!");
		}
	}

	public void validateShifts(String paycode) {
		waitABit(2000);
		if (paycode.equalsIgnoreCase("worked")) {
			moreIcon.waitUntilClickable();
			moreIcon.click();
			Assert.isTrue(totalWorkedShifts.getTextValue().contains("1"), "Shifts Don't match");
			Assert.isTrue(totalShifts.getTextValue().contains("1"), "Shifts Don't match");
			Assert.isTrue(employeeWorkedShift.getTextValue().contains("1"), "Shifts Don't Match!");
		} else if (paycode.equalsIgnoreCase("non-worked")) {
			Assert.isTrue(totalShifts.getTextValue().contains("1"), "Number of Shifts Don't Match!");
			Assert.isTrue(totalNonWorkedShifts.getTextValue().contains("1"), "Number of Shifts Don't Match!");
			Assert.isTrue(employeeNonWorkedShifts.getTextValue().contains("1"), "Number of Shifts Don't Match!");
		}
	}

	public void scheduledFilter() {
		employeeFilter.typeAndTab("Show employees with schedules");
		waitABit(2000);

	}

	public void validateScheduleExists() {
		waitABit(1000);
		int count = getObjectCount("//div[contains(@id, 'timepair')]");
		Assert.isTrue(count != 0, "No employees with shcedules exists.");
		waitABit(2000);
	}

	public void unscheduledFilter() {
		employeeFilter.typeAndTab("Show unscheduled employees");

		waitABit(4000);

	}

	public void checkEmployeeCount(String flag) {
		String value = employeeCount.getTextValue();
		String count = value.split(" ")[1];
		waitABit(1000);
		if (flag.equalsIgnoreCase("before")) {
			System.out.println("count" + count);
			Assert.isTrue(count.contains("5"), "Employee count does not match  before");

		} else if (flag.equalsIgnoreCase("after")) {
			waitABit(1000);
			Assert.isTrue(count.contains("4"), "Employee count does not match after!");
		}
	}

	public void validateNoScheduleExists() {
		waitABit(2000);
		int count = getObjectCount("//div[contains(@id, 'timepair')]");
		Assert.isTrue(count == 0, "Employees with schedules were found!");
		System.out.println("count is this : " + count);
		waitABit(2000);
	}

	public void access() {
		waitABit(1000);
		menuAccessTab.waitUntilClickable();
		menuAccessTab.click();
		waitABit(1000);
		supervisor.waitUntilClickable();
		supervisor.click();
		waitABit(1000);

	}

	public void editSchedulePrivileges(int flag) {
		 // flag to enable/disable
		myTeamTab.waitUntilClickable();
		myTeamTab.click();
		waitABit(5000);
		try {
			if (flag == 0) {
				String classString = editPrivilegesChecked.getAttribute("class");
				waitABit(1000);
				System.out.println("here" + classString);
				// 0 indicates to disable
				if (classString.equalsIgnoreCase("fa fa-check-square fa-lg")) {
					editPrivileges.waitUntilClickable();
					editPrivileges.click();
					waitABit(2000);
					savePrivileges.click();

				} else {
					savePrivileges.click();
				}
			} else if (flag == 1) {
				editPrivileges.waitUntilClickable();
				editPrivileges.click();
				savePrivileges.click();
			}
		} catch (Exception e) {
		}

		waitABit(5000);

	}

	public void editSelfPrivileges() {
		myTeamTab.waitUntilClickable();
		myTeamTab.click();
		waitABit(5000);
		editPrivilegesMoreIcon.click();
		System.out.println("Class String");
		waitABit(5000);
		try {

			// String classString = selfEditingCheckBoxChecked.getAttribute("class"); //For
			// disabling also change the equals ignore case
			String classString = selfEditingCheckBoxUnChecked.getAttribute("class"); // For enabling
			waitABit(1000);
			System.out.println("Class String" + classString);
			if (classString.equalsIgnoreCase("fa fa-square-o fa-lg")) {
				selfEditing.waitUntilClickable();
				selfEditing.click();
				waitABit(5000);

				savePrivileges.click();
			} else {

				savePrivileges.click();
			}
		} catch (Exception ex) {
		}

	}

	public void validateScheduleDisable() {
		waitABit(1000);
		shiftcell.waitUntilClickable();
		String classString = shiftcell.getAttribute("class");
		System.out.println("Class String" + classString);
		waitABit(1000);
		shiftcell.click();
		addShiftIcon.shouldNotBeVisible();
		waitABit(5000);
	}
}
