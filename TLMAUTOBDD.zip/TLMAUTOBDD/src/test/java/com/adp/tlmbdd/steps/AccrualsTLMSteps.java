package com.adp.tlmbdd.steps;
import com.adp.tlmbdd.pages.*;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class AccrualsTLMSteps {

	AccrualsTLM accrualsTLMbase;
	
	@Step
	public Boolean verifyAccuralsfeatureEnabledStep() 
	{		
		Boolean flag;
		flag=accrualsTLMbase.verifyAccuralsfeatureEnabled();
		return flag;
	}
	
	@Step
	public void addAccrualProgressionStep()
	{
		accrualsTLMbase.addAccrualProgression();
	}
	@Step
	public void addAccrualDefinitionStep()
	{
		accrualsTLMbase.addAccrualDefinition();
	}
}
