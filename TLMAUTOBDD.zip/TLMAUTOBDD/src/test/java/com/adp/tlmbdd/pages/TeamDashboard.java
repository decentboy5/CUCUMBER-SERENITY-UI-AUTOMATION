package com.adp.tlmbdd.pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;


import com.google.common.collect.Ordering;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;


public class TeamDashboard extends GenericPageObject{

	public static Logger log = Logger.getLogger(TeamDashboard.class);
	SoftAssertions sftAssert=new SoftAssertions();

	@FindBy(xpath = "//div[text()='Missed Punches']")
	private WebElementFacade missedPunches;

	@FindBy(xpath = "//div[text()='Shifts To Review']")
	private WebElementFacade shiftsToReview;

	@FindBy(xpath = "//div[text()='Timecard Approvals']")
	private WebElementFacade timecardApprovals;

	@FindBy(xpath = "//*[@class='shiftsToReview-snackbar']//button[2]")
	private WebElementFacade saveButton;

	@FindBy(xpath = "//*[@class='shiftsToReview-snackbar']//button[1]")
	private WebElementFacade cancelButton;

	@FindBy(xpath = "//*[@id='notes-slider']//*[@class='mdf-snackbar']//button[2]")
	private WebElementFacade notesSliderSaveButton;

	@FindBy(xpath = "//*[@id='notes-slider']//*[@class='mdf-snackbar']//button[1]")
	private WebElementFacade notesSliderCancelButton;

	@FindBy(xpath = "//*[@aria-label='Back']")
	private WebElementFacade timecardBackButton;

	@FindBy(xpath = "//*[@class='vdl-slide-in-close']/button")
	private WebElementFacade backButton;

	@FindBy(xpath = "//*[@id='notes-slider']//*[@class='vdl-slide-in-close']/button")
	private WebElementFacade noteSliderbackButton;

	@FindBy(xpath = "//*[contains(@class,'thingsTodo-title-filter')]")
	private WebElementFacade displayPreferences;
	
	@FindBy(xpath = "//*[contains(@class,'thingsTodo-tile-todoListViewName')]")
	private WebElementFacade ShifttoReview;
	
	@FindBy(xpath = "//div[contains(@class,'fa fa-filter')]")
	private WebElementFacade Thingstofiltericon;
	
	@FindBy(xpath = "//div[@class='vdl-slide-in-content']//button[.='Back']")
	private WebElementFacade clickbackbuttonshifttoreview;
	
	@FindBy(xpath = "//*[contains(@class,'vdl-row vdl-col-xs')]")
	private WebElementFacade verifyshifttoreviewtile;
	
	@FindBy(xpath = "//*[text()='Shifts To Review']/following-sibling::div[contains(@class,'vdl-col-xs-12')]")
	private WebElementFacade verifyshifttoreviewtileemployee;
	
	@FindBy(xpath = "//*[contains(@class,'vdl-col-xs-12 dashBoard-thingsTodo-tile-todoListViewName')]")
	private WebElementFacade verifyshifttoreviewtitle;
	
	@FindBy(xpath = "//h4[text()='Display Shifts to Review']/preceding-sibling::div/descendant::label[@id='ToggleSwitch']")
	private WebElementFacade DisplayShiftstoReviewtogglebutton;
	
	@FindBy(xpath ="(//button[contains(@class,'preferencesButtonClass')])[2]")
	private WebElementFacade PrefenceSavebutton;
	
	@FindBy(xpath = "//h5[text()='Worked Longer Than Expected']/preceding-sibling::div/descendant::label[@id='ToggleSwitch']")
	private WebElementFacade WorkedLongerThanExpectedtogglebutton;
	
	@FindBy(xpath = "//input[@name= 'workedLongerTextbox']")
	private WebElementFacade WorkedLongerThanExpectedtext;
	
	@FindBy(xpath = "//h5[text()='Worked Earlier Than Expected']/preceding-sibling::div/descendant::label[@id='ToggleSwitch']")
	private WebElementFacade WorkedearlierThanExpected;
	
	@FindBy(xpath = "//h5[text()='Worked Later Than Expected']/preceding-sibling::div/descendant::label[@id='ToggleSwitch']")
	private WebElementFacade WorkedlaterThanExpected;
	
	@FindBy(xpath = "//div[text()='Missed Punches']/../div[2]")
	private WebElementFacade missedPunchesAndEmployeeCount;
	
	@FindBy(xpath = "//input[@name= 'workedLaterTextbox']")
	private WebElementFacade WorkedlaterThanExpectedtext;
	
	@FindBy(xpath = "//h5[text()='Worked Longer Than Expected Outside of Shift']/preceding-sibling::div/descendant::label[@id='ToggleSwitch']")
	private WebElementFacade WorkedlongerThanExpectedoutsideofshift;
	
	@FindBy(xpath = "//input[@name= 'workedLongerOutsideTextbox']")
	private WebElementFacade WorkedlongerThanExpectedoutsideofshifttext;
	
	@FindBy(xpath = "//*[@class='missedPunches-notification-header']/../text")
	private WebElementFacade missedPunchesAndEmployeeCountOnMissedPunchesPage;

	@FindBy(xpath = "//div[text()='Timecard Approvals']")
	private WebElementFacade dashBoardTimeCardApprovalsLink;

	@FindBy(xpath = "//div[text()='Timecard Approvals']/following-sibling::div")
	private WebElementFacade dashBoardTimeCardsforApprovalCount;

	@FindBy(xpath = "//div[contains(@class,'dashBoard-thingsTodo-tile-todoClassName')][contains(@class,'fa fa-check-circle-o')]")
	private WebElementFacade dashBoardTimeCardApprovalsIcon;


	@FindBy(xpath = "//div[@class='vdl-slide-in-content']//span[text()='Back']/parent::button")
	private WebElementFacade timecardApprovalsBack;	

	@FindBy(xpath = "//div[@class='vdl-slide-in-title']")
	private WebElementFacade timecardApprovalsHeader;

	@FindBy(xpath = "//div[@class='vdl-row timecard-page-heading']/descendant::h3")
	private WebElementFacade timecardApprovalsWhichTimeCardLabel;

	@FindBy(xpath = "//div[@class='timeCard-Approval-Grid-Parent-Class']")
	private WebElementFacade timecardApprovalsGrid;

	@FindBy(xpath = "//div[contains(@class,'timecard-Approvals-ClassName fa fa-check-circle-o')]")
	private WebElementFacade timecardApprovalsLabelIcon;

	@FindBy(xpath = "//div[contains(@class,'timecard-Approvals-ListViewName')]")
	private WebElementFacade timecardApprovalsLabel;	

	@FindBy(xpath = "//div[contains(@class,'timecard-Approvals-ListViewName')]/following-sibling::div")
	private WebElementFacade timecardApprovalsCount;	

	@FindBy(xpath = "//div[@class='vdl-slide-in-content']//button[.='REMIND EMPLOYEE TO APPROVE']")
	private WebElementFacade timecardApprovalsRemindEmployeetoApprove;	

	@FindBy(xpath = "//div[@class='vdl-slide-in-content']//button[.='APPROVE']")
	private WebElementFacade timecardApprovalsApprove;	

	@FindBy(xpath = "//span[text()='Missed Punches']/parent::button")
	private WebElementFacade timecardApprovalsMissedPunches;	

	@FindBy(xpath = "//span[text()='Other Exceptions']/parent::button")
	private WebElementFacade timecardApprovalsOtherExceptions;	

	@FindBy(xpath = "//span[contains(@class,'icon-missing-punch')]")
	private WebElementFacade timecardApprovalsMissedPunchesIcon;	

	@FindBy(xpath = "//span[contains(@class,'icon-part-time-employee')]")
	private WebElementFacade timecardApprovalsOtherExceptionsIcon;

	@FindBy(xpath = "//div[text()='These actions need to be taken to reach 100% timecard approval for your team!']")
	private WebElementFacade timecardApprovalsActionNeedtoTakeLabel;

	@FindBy(xpath = "//div[contains(@class,'timecard-Approvals-ListViewName')]")
	private WebElementFacade timecardApprovalsCardHeader;

	@FindBy(xpath = "//div[@class='MDFContentPane']//b")
	private WebElementFacade timecardApprovalsSubCardTACount;	
	@FindBy(xpath = "//div[@class='preferences-container ']")
	private WebElementFacade VerifyWorkerLongerThanExpectedexistence;

	@FindBy(xpath = "(//*[contains(@class,'view-timecard-link')])[1]/text")
	private WebElementFacade viewTimecard;

	@FindBy(xpath = "//div[@id='gridDiv']")
	private WebElementFacade timecardTable;	

	@FindBy(xpath = "//*[@id='TlmRevit']")
	private WebElementFacade timecardRevit;

	@FindBy(xpath = "//div[contains(@class,'empidbar-name-pic')]//div[@class='empidbar-name-text']")
	private WebElementFacade timecardEmpName;	

	@FindBy(xpath = "//div[@class='empidbar-midsection vdl-hidden-lg-down']/descendant::button[@id='empidbar-empsearch-link']")
	private WebElementFacade timecardEmpSearch;

	@FindBy(xpath = "//a[contains(@id,'idBarSscrollGridIdCol')]")
	private WebElementFacade selectEmpNameLink;

	@FindBy(xpath = "//div[@id='searchbox']/input")
	private WebElementFacade selectEmpPopupSearch;

	@FindBy(xpath = "//*[@name='dashBoardPage']")
	private WebElementFacade teamDashboardRoot;

	@FindBy(xpath = "//*[contains(@class,'dashBoard-thingsTodo-tile vdl-tile')]")
	private WebElementFacade thingsToDoTile;

	@FindBy(xpath = "//*[@id='totalHoursOfMyTeamId']")
	private WebElementFacade totalhoursformyteamgraph;

	@FindBy(xpath="//div[@class='ReactVirtualized__Grid__innerScrollContainer']")
	private WebElementFacade empSearchResultsGrid;

	@FindBy(xpath="//span[.='Approve Timecard']")
	private WebElementFacade individualTimecardApproveTimecard;

	@FindBy(xpath="//span[.='Find']")
	private WebElementFacade individualTimecardFind;	

	@FindBy(xpath="//span[.='Save']")
	private WebElementFacade individualTimecardSave;

	@FindBy(xpath="//span[.='Refresh']")
	private WebElementFacade individualTimecardRefresh;

	@FindBy(xpath="//span[.='Preferences']")
	private WebElementFacade individualTimecardPreferences;

	@FindBy(xpath="//input[@type='text'][contains(@id,'TcTimeTextBox')]")
	private WebElementFacade timePunchTextBox;

	@FindBy(xpath="//div[text()='Operation Successful.']")
	private WebElementFacade individualTimecardPreferencesOperationSuccessful;

	@FindBy(xpath="//textarea[contains(@class,'textarea')]")
	private WebElementFacade supervisornotes;

	@FindBy(xpath="//label[@id='ToggleSwitch']")
	private WebElementFacade employeeviewabletogglestatus;

	@FindBy(xpath="//*[@class='vdl-toggle-switch__toggle']")
	private WebElementFacade employeeviewabletoggle;

	@FindBy(xpath="//*[@class='notes-noteType']")
	private WebElementFacade notesType;

	@FindBy(xpath="//*[@class='notes-padding-username']")
	private WebElementFacade notesUsername;

	@FindBy(xpath="//*[@class='shiftsToReview-snackbar']/button")
	private WebElementFacade shiftsToReviewDismiss;

	@FindBy(xpath = "//div[text()='Shifts To Review']/../div[2]")
	private WebElementFacade ShiftsAndEmployeeCount;

	@FindBy(xpath = "//h4[text()='Shifts To Review']/../text")
	private WebElementFacade ShiftsAndEmployeeCountOnSlider;

    @FindBy(xpath="//div[@id='approveAllBtn']")
    public WebElementFacade lorApproveAll;

    @FindBy(xpath="//div[@class='vdl-slide-in-body']/following-sibling::div//button[@id='torSubmitReqBtn']")
    public WebElementFacade lorSubmit;
    
    @FindBy(xpath="//div[@class='vdl-slide-in-body']/following-sibling::div//button[@id='torCancelReqBtn']")
    public WebElementFacade lorCancel;
    
    @FindBy(xpath="//div[@id='denyAllBtn']")
    public WebElementFacade lorDenyAll;

    @FindBy(xpath = "//div[text()='Shift Swap Requests']")
	private WebElementFacade shiftSwapRequests;

    @FindBy(xpath = "//div[@id='Shift-Swap-Slidein-Page']//*[@class='count']")
	private WebElementFacade shiftSwapRequestSliderCount;
    
	@FindBy(xpath = "//div[text()='Shift Swap Requests']/../div[2]")
	private WebElementFacade shiftSwapRequestCountTTDTile;
	
	@FindBy(xpath = "(//textarea)[1]")
	private WebElementFacade shiftSwapComment;
	
	@FindBy(xpath = "(//span[text()='APPROVE'])[1]")
	private WebElementFacade approveShiftSwapRequest;
	
	@FindBy(xpath = "(//span[text()='REJECT'])[1]")
	private WebElementFacade rejectShiftSwapRequest;
	
	@FindBy(xpath = "//button[@aria-label='Back']")
	private WebElementFacade ShiftSwapBack;

	@FindBy(xpath = "(//a[text()='View the impact of approving this swap request'])[1]")
	private WebElementFacade impactOfApprovingLink;
	
	@FindBy(xpath = "//*[class='mdf-slide-in-body']//button[@value='APPROVE']")
	private WebElementFacade approveShiftSwapRequestSlider;
	
	@FindBy(xpath = "//*[class='mdf-slide-in-body']//button[@value='APPROVE']")
	private WebElementFacade rejectShiftSwapRequestSlider;
	
	@FindBy(xpath = "(//*[@class='vdl-row swapActionApprovalDialog']//textarea)[1]")
	private WebElementFacade commentinsubslider;
	
	@FindBy(xpath = "(//*[@class='vdl-row swapActionApprovalDialog']/../../..//span[text()='Yes'])[1]")
	private WebElementFacade yesButtonInSubSlider;

	@FindBy(xpath="//div[@class='revitButtonBox']//span[.='OK']")
	public WebElementFacade alertOK;

	//Time Off Tile
	@FindBy(xpath="//*[.='Time Off Requests']/ancestor::div[@class='vdl-list-view vdl-error']")
	public WebElementFacade torTTDTile;

	@FindBy(xpath="//div[@title='NAME'][contains(@class,'column-0')]")
	public WebElementFacade timeOffTileName;
	
	@FindBy(xpath="//div[@class='vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 column-1']")
	public WebElementFacade timeOffTileStartWeek;
	
	@FindBy(xpath="//div[@class='vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 column-7']")
	public WebElementFacade timeOffTileEndWeek;
	
	@FindBy(xpath = "//div[contains(@class,'dashBoard-thingsTodo-tile-todoListViewName')][.='Time Off Requests']")
	private WebElementFacade torTTDChevron;	

	@FindBy(xpath="//div[contains(@class,'dashBoard-thingsTodo-tile-todoListViewName')][.='Time Off Requests']/following-sibling::div")
	public WebElementFacade torEmployeeRequestCount;
	
	@FindBy(xpath="//div[contains(@class,'dashBoard-thingsTodo-tile-todoListViewName')][.='Time Off Requests']/parent::div")
	public WebElementFacade timeOffRequest;
	
	@FindBy(xpath="//span[contains(@class,'vdl-slide-in-title')][.='List Of Requests']/preceding-sibling::button")
	public WebElementFacade lorBack;
	
	@FindBy(xpath="//div[@class='vdl-col-xs mdf-grid-scroll-pane mdf-grid-unlocked-infinite-scroll']")
	public WebElementFacade lorRequestsGrid;

	@FindBy(xpath="//div[@class='fa fa-chevron-circle-right timeoff-request-chevron-class']")
	private WebElementFacade nextWeekView;

	@FindBy(xpath="//div[@class='fa fa-chevron-circle-left timeoff-request-chevron-class']")
	private WebElementFacade previousWeekView;
	
	@FindBy(xpath="//div[@class='timeOffRequestEmployeesStatusTextClass'][@title='PENDING']")
	private WebElementFacade pending;
	
	@FindBy(xpath="//div[@class='timeOffRequestEmployeesStatusTextClass'][@title='APPROVED']")
	private WebElementFacade approved;
	
	@FindBy(xpath="//div[@class=' timeOffRequestPendingBoxClass']")
	private WebElementFacade pendingCount;
	
	@FindBy(xpath="//div[@class='timeOffRequestApprovedClass']")
	private WebElementFacade approvedCount;
	
	@FindBy(xpath="//div[contains(@class,'timeOffRequestEmployeesStatusClass')][text()='EMPLOYEES:']")
	private WebElementFacade employeesLabel;
	
	@FindBy(xpath="//div[contains(@class,'dashboardTileTitleClass')]/div[text()='Time Off This Week']")
	private WebElementFacade timeOffThisWeekTitle;
	
	@FindBy(xpath="//div[contains(@class,'dashboardTileTitleClass')]/div[text()='Time Off Next Week']")
	private WebElementFacade timeOffNextWeekTitle;		
	
	@FindBy(xpath="//div[@id='PTOMainDivClassID']/descendant::span[@class='vdl-tile__title__icon']")
	private WebElementFacade titleIcon;		
	
	@FindBy(xpath="//div[@id='lor-request-tab-pending'][@class='lor-count-tab-selected']")
	private WebElementFacade lorPendingBucket;

	@FindBy(xpath="//span[@id='requestTimeOffButton']")
	private WebElementFacade requestTimeOffButton;
	
	@FindBy(xpath="//input[@id='torStartDatePicker']")
	private WebElementFacade torStartDay;
	
	@FindBy(xpath="//input[@id='torEndDatePicker']")
	private WebElementFacade torEndDay;	
	
	@FindBy(xpath="//textarea[@id='torCommentsTextaArea']")
	private WebElementFacade torComments;
	
	@FindBy(xpath="//input[@id='torRespondByDatePicker']")
	private WebElementFacade torRespondBy;
	
	@FindBy(xpath="//*[contains(@id,'torGridRow-torPolicySelectBox')][@role='combobox']")
	private WebElementFacade torTimeOffPolicy;
	
	@FindBy(xpath="//input[@name='AMOUNT']")
	private WebElementFacade torAmount;
	
	@FindBy(xpath="//div[contains(@id,'torGridRow-torStartTimePicker')]")
	private WebElementFacade torStartTime;
	
	@FindBy(xpath="//button[@id='torSubmitReqBtn']")
	private WebElementFacade torSubmit;
	
	@FindBy(xpath="//button[@type='button'][.='Process Request']")
	private WebElementFacade lorProcessRequest;
	
	@FindBy(xpath="//td[contains(@class,'OUTPUT_TEXT')][.='Mon, Jan 07, 2019']")
	private WebElementFacade requestDate;
	
	By policy = By.xpath("//*[contains(@id,'torGridRow-torPolicySelectBox')][@role='combobox']");
	
	By startTime = By.xpath("//div[contains(@id,'torGridRow-torStartTimePicker')]");	
	
	@FindBy(xpath="//iframe[@id='ptoIframe']")
	public WebElementFacade ptoFrame;
	
	@FindBy(xpath="//div[contains(@id,'torGridRow-Date')]")
	public WebElementFacade ptoSelectedDate;

	public void clickMissedPunchesOnTTDTile()
	{
		WaitForPageLoad();
		waitForElementToLoad(missedPunches);
		missedPunches.click();
		WaitForPageLoad();
		waitForElementToLoad(missedPunchesAndEmployeeCountOnMissedPunchesPage);
	}

	public void clickShiftsToReviewOnTTDTile()
	{
		WaitForPageLoad();
		waitForElementToLoad(shiftsToReview);
		shiftsToReview.click();
		WaitForPageLoad();
		waitForElementToLoad(ShiftsAndEmployeeCountOnSlider);
	}

	public void clickTimecardApprovalsOnTTDTile()
	{
		WaitForPageLoad();
		waitForElementToLoad(timecardApprovals);
		timecardApprovals.click();
		WaitForPageLoad();
	}

	public void clickTimeOffRequestsOnTTDTile() {
		try {
			WaitForPageLoad();
			waitForElementToLoad(torTTDTile);
			waitForElementToLoad(torTTDChevron);
			torTTDChevron.click();
			WaitForPageLoad();
			waitForElementToLoad(lorRequestsGrid);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void verifyDefaultSaveAndCancel()
	{
		Assert.assertEquals("true",saveButton.getAttribute("aria-disabled"));
		Assert.assertEquals("true",cancelButton.getAttribute("aria-disabled"));
		Assert.assertEquals("You have not made any changes", saveButton.getAttribute("title"));
		Assert.assertEquals("You have not made any changes", cancelButton.getAttribute("title"));
	}

	public void clickBackButton()
	{
		backButton.click();
		WaitForPageLoad();
		waitForElementToLoad(displayPreferences);
	}

	public void verifyEmployeeAlphabeticalOrder()
	{
		ArrayList<String> employeeNames = new ArrayList<String>();
		List<WebElement> allEmployees = getDriver().findElements(By.xpath("//*[@class='missedPunches-grid-subheader-text'][not(contains(text(),'Supervised by'))]"));
		for (WebElement webElement : allEmployees) {
			employeeNames.add(webElement.getText().split(",")[0]);
		}
		System.out.println(employeeNames);

		Assert.assertTrue(Ordering.natural().isOrdered(employeeNames));

	}

	public void clickSaveButtonOnMissedPunchesScreen()
	{
		saveButton.click();
		WaitForPageLoad();
	}

	public void verifyDataOnMissedPunchesTTDTile(String employeecount,String missedpunchescount)
	{
		String employeecountandmissedpunches = missedPunchesAndEmployeeCount.getText();
		String employees = employeecountandmissedpunches.split(",")[0].trim();
		String missedpunches = employeecountandmissedpunches.split(",")[1].trim();
		Assert.assertEquals(employees.split(" ")[0].trim(), employeecount);
		Assert.assertEquals(missedpunches.split(" ")[0].trim(), missedpunchescount);
	}

	public void verifyTimeOffRequestsTTDtile(String status) {
		try {
			WaitForPageLoad();
			if (status.equalsIgnoreCase("EXISTS")) {
				Assert.assertEquals(checkElementVisible(torTTDChevron), true);
			} else if (status.equalsIgnoreCase("DOESNOTEXIST")) {
				Assert.assertEquals(checkElementVisible(torTTDChevron), false); 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void verifyDataOnTimeOffRequestTTDTile(String employeeCount,String requestCount)
	{
		String count = torEmployeeRequestCount.getText();
		String employees = count.split(",")[0].trim();
		String requests = count.split(",")[1].trim();
		Assert.assertEquals(employees.split(" ")[0].trim(), employeeCount);
		Assert.assertEquals(requests.split(" ")[0].trim(), requestCount);
	}
	
	public void verifySaveAndCancelEnabledOrNot()
	{
		Assert.assertEquals("false",saveButton.getAttribute("aria-disabled"));
		Assert.assertEquals("false",cancelButton.getAttribute("aria-disabled"));
		Assert.assertEquals("true",backButton.getAttribute("aria-disabled"));

	}



	public void clickonshifttoreviewbutton() {
		// TODO Auto-generated method stub
		ShifttoReview.click();
	}

	public void clickonpreference() {
		// TODO Auto-generated method stub
		WaitForPageLoad();
		waitABit(5000);
		clickUsingJavaScript(Thingstofiltericon);
		WaitForPageLoad();
		waitABit(5000); 
	}

	public void clickbackbuttonshifttoreview() {
		// TODO Auto-generated method stub
		clickbackbuttonshifttoreview.click();

	}

	public void verifyShiftToReviewtogglebutton(String arg1) {
		// TODO Auto-generated method stub
		verifyToggleButton(DisplayShiftstoReviewtogglebutton,arg1);

	}

	public void shifttoreview(String arg1) {
		// TODO Auto-generated method stub
		selectToggleButton(DisplayShiftstoReviewtogglebutton,arg1);
	}

	public void preferencesavebutton() {
		// TODO Auto-generated method stub
		PrefenceSavebutton.click();
	}

	public void WorkedLongerThanExpected(String arg1) {
		// TODO Auto-generated method stub
		WorkedLongerThanExpectedtext.clear(); 
		selectToggleButton(WorkedLongerThanExpectedtogglebutton,arg1);
	}

	public void WorkedLongerThanExpectedtext(String arg1) {
		// TODO Auto-generated method stub
		WorkedLongerThanExpectedtext.sendKeys(arg1);
	}

	public void WorkedEarlierThanExpected(String arg1) {
		// TODO Auto-generated method stub
		selectToggleButton(WorkedearlierThanExpected,arg1);
	}


	public void resolveAMissedPunchOfEmployee(String employeename,String punchtime,String date)
	{
		waitABit(3000);
		getDriver().findElement(By.xpath("//*[text()='"+employeename+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[contains(@class,'missedPunches-image-missing-punch')]")).click();
		waitABit(1000);
		getDriver().findElement(By.xpath("//*[text()='"+employeename+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[contains(@class,'missedPunches-time-textbox')]")).sendKeys(punchtime);
		waitABit(1000);
		getDriver().findElement(By.xpath("//*[text()='"+employeename+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[contains(@class,'missedPunches-time-textbox')]")).sendKeys(Keys.TAB);
	}

	public void verifyDataOnMissedPunchesPage(String employeecount,String missedpunchescount)
	{
		String employeecountandmissedpunches = missedPunchesAndEmployeeCountOnMissedPunchesPage.getText();
		String employees = employeecountandmissedpunches.split(",")[0].trim();
		String missedpunches = employeecountandmissedpunches.split(",")[1].trim();
		Assert.assertEquals(employees.split(" ")[0].trim(), employeecount);
		Assert.assertEquals(missedpunches.split(" ")[0].trim(), missedpunchescount);
	}

	public void verifyTimecardApprovalandcountinThingsToDoTile(String approvalLink, String approvalCount) {
		WaitForPageLoad();
		try {
			if(approvalLink.equalsIgnoreCase("exists"))
			{Assert.assertTrue("Verification Passed: Timecard Approvals link is displayed in Things To Do Tile", dashBoardTimeCardApprovalsLink.isDisplayed());}
			else if((approvalLink.equalsIgnoreCase("doesexists"))) {
				Assert.assertTrue("Verification Passed:Timecard Approvals link is not displayed in Things To Do Tile", !dashBoardTimeCardApprovalsLink.isDisplayed());
			}
			String[] actualTimecards=(dashBoardTimeCardsforApprovalCount.getText().trim()).split(" ");
			String actualCount=actualTimecards[0];
			String expectedCount=approvalCount;
			Assert.assertTrue("Verification of Timecards ready for Approval: Actual - '"+actualCount+"'; Expected - '"+expectedCount+"'", actualCount.contentEquals(expectedCount));
		} 		
		catch (Exception ex) {
			ex.printStackTrace();
		}	

	}
	
	public void clickTimeOffRequestOnTTDTile()
	{
		WaitForPageLoad();
		waitForElementToLoad(timeOffRequest);
		missedPunches.click();
		WaitForPageLoad();
		waitForElementToLoad(lorBack);
	}
	
	public void verifyStatusofButton(String button, String buttonStatus) {
		try {
			String actualStatus = "";
			if (!button.equalsIgnoreCase("") && !buttonStatus.equalsIgnoreCase("")) {
				switch (button.toUpperCase()) {

				case "APPROVE":
					actualStatus = verifyObjectStatus(timecardApprovalsApprove);
					if (buttonStatus.equalsIgnoreCase(actualStatus))
						Assert.assertTrue("Verification Passed: '" + button + "' is '" + actualStatus + "'", true);
					else
						Assert.assertTrue("Verification Failed: '" + button + "' is '" + actualStatus + "'", false);
					break;
				case "REMIND EMPLOYEE TO APPROVE":
					actualStatus = verifyObjectStatus(timecardApprovalsRemindEmployeetoApprove);
					if (buttonStatus.equalsIgnoreCase(actualStatus))
						Assert.assertTrue("Verification Passed: '" + button + "' is '" + actualStatus + "'", true);
					else
						Assert.assertTrue("Verification Failed: '" + button + "' is '" + actualStatus + "'", false);
					break;
				case "BACK":
					actualStatus = verifyObjectStatus(timecardApprovalsBack);
					if (buttonStatus.equalsIgnoreCase(actualStatus))
						Assert.assertTrue("Verification Passed: '" + button + "' is '" + actualStatus + "'", true);
					else
						Assert.assertTrue("Verification Failed: '" + button + "' is '" + actualStatus + "'", false);
					break;
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void verifyMessageOnScreen(String message) {
		if(message.contentEquals("")) return;	
		try {
			waitABit(3000);
			WaitForPageLoad();
			String messageLocator = ".vdl-tile__content,.vdl-alert__title,.vdl-alert__content,.timeCard-Grid-Exceptions-Name-Class.vdl-col-xs,h3,.success-banner,.tc-banner-message ,.tc-banner-title.manager-approve,.tc-banner-title.employee-approve,.tc-banner-message.employee-approve,.tc-banner-title ,.tc-banner-message ,.tc-banner-message.employee-approve,.tc-banner-title.exception,.tc-banner-message.exception,.tc-banner-title.manager-modified";
			int iWaitTime = 0;
			String expectedValue = message;
			List<String> actualMessages = new ArrayList<String>();
			String msg="";
			do {
				boolean msgFound = false;
				List<WebElement> messageObjs = getDriver().findElements(By.cssSelector(messageLocator));
				for (WebElement messageObj : messageObjs) {
					if (messageObj.isDisplayed()) {
						msgFound = true;
						msg=(messageObj.getText().trim()).replace("\r\n", " ").replace("\n", " ");
						actualMessages.add(msg.replace("  ", " "));
					}
				}
				if (!msgFound) {
					iWaitTime = iWaitTime + 2;
					Thread.sleep(2000);
				} else {
					break;
				}
			} while (iWaitTime <= 60);
			if (!actualMessages.isEmpty()) {
				boolean msgFound = false;
				for (String actualMessage : actualMessages) {
					if (actualMessage.contentEquals(expectedValue)) {
						msgFound = true;
						Assert.assertTrue("'" + expectedValue + "' message is displayed", true);
						break; }
				}
				if (!msgFound) {
					//sftAssert.fail("'" + expectedValue + "' message not displayed");
					Assert.assertFalse("'" + expectedValue + "' message not displayed", true);
				}
			}
			sftAssert.assertAll();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void verifyDataAndObjectsOnTASlider(String cardTACount, String MissedPunches, String OtherExceptions,String RemindEmployees) {

		if (timecardApprovalsHeader.isDisplayed())
			Assert.assertTrue("'Timecard Approvals' Top header is displayed on Timecard Approval Slider", true);
		else
			Assert.assertTrue("'Timecard Approvals' Top header is not displayed on Timecard Approval Slider", false);
		if (timecardApprovalsBack.isDisplayed())
			Assert.assertTrue("Back Button is displayed on Timecard Approval Slider", true);
		else
			Assert.assertTrue("Back Button is not displayed on Timecard Approval Slider", false);
		if (timecardApprovalsCardHeader.isDisplayed())
			Assert.assertTrue("'Timecard Approvals' card header is displayed on Timecard Approval Slider", true);
		else
			Assert.assertTrue("'Timecard Approvals' card header is not displayed on Timecard Approval Slider", false);

		if (!cardTACount.contentEquals("")) {
			if (timecardApprovalsSubCardTACount.isDisplayed()) {
				if (timecardApprovalsSubCardTACount.getText().contentEquals(cardTACount)) {
					Assert.assertTrue("Verification Passed: Timecards for Approval count on card - '"+ timecardApprovalsSubCardTACount.getText() + "'", true);
				} else
					Assert.assertTrue("Verification Failed: Timecards for Approval count on card is '"+ timecardApprovalsSubCardTACount.getText() + "' instaed of '" + cardTACount + "'",false);
			} else
				Assert.assertTrue("Timecards for Approval count is displayed on card  on Timecard Approval Slider",false);
		} else
			Assert.assertTrue("'Timecard Approvals' card header is not displayed on Timecard Approval Slider", false);
		if (!MissedPunches.contains("")) {
			if (MissedPunches.equalsIgnoreCase("EXISTS")) {
				Assert.assertTrue("Verification of 'Missed Punches' on Timecard Approval Slider",timecardApprovalsMissedPunches.isDisplayed());
			}
			if (MissedPunches.equalsIgnoreCase("DOESNOTEXISTS")) {
				Assert.assertTrue("Verification of 'Missed Punches' on Timecard Approval Slider",!timecardApprovalsMissedPunches.isDisplayed());
			}
		}
		if (!OtherExceptions.contains("")) {
			if (OtherExceptions.equalsIgnoreCase("EXISTS")) {
				Assert.assertTrue("Verification of 'Missed Punches' on Timecard Approval Slider",timecardApprovalsOtherExceptions.isDisplayed());
			}
			if (OtherExceptions.equalsIgnoreCase("DOESNOTEXISTS")) {
				Assert.assertTrue("Verification of 'Missed Punches' on Timecard Approval Slider",!timecardApprovalsOtherExceptions.isDisplayed());
			}
		}

		if (timecardApprovalsApprove.isDisplayed())
			Assert.assertTrue("Approve Button is displayed on Timecard Approval Slider", true);
		else
			Assert.assertTrue("Approve Button is not displayed on Timecard Approval Slider", false);

		if (!RemindEmployees.contains("")) {
			if (RemindEmployees.equalsIgnoreCase("EXISTS")) {
				Assert.assertTrue("Verification of 'Remind Employees To Approve' on Timecard Approval Slider",timecardApprovalsRemindEmployeetoApprove.isDisplayed());
			}
			if (RemindEmployees.equalsIgnoreCase("DOESNOTEXISTS")) {
				Assert.assertTrue("Verification of 'Remind Employees To Approve' on Timecard Approval Slider",!timecardApprovalsRemindEmployeetoApprove.isDisplayed());
			}
		}
	}

	public void selectTimeCardinTASlider(String timecardCheckbox,String empName,String timePeriod) {
		try {
			WaitForPageLoad();
			String[] fullTimePeriod=timePeriod.split(":");
			String actualName="";
			List<WebElement> empTimecards=getDriver().findElements(By.xpath("//div[contains(@class,'timecard-Approvals-Subheader-Class')][contains(.,'"+fullTimePeriod[0].trim()+"')][contains(.,'"+fullTimePeriod[1].trim()+"')]/ancestor::div[contains(@class,'mdf-grid-subheader')]/following-sibling::div[contains(@class,'mdf-grid-row')]"));
			//identify the timecard
			WebElement objEmpName=null;
			WebElement objSelect=null;
			boolean flag=false;
			if(!empTimecards.isEmpty()) {
				for(WebElement empTimecard: empTimecards) {
					objEmpName=empTimecard.findElement(By.xpath(".//div[@class='timeCard-Grid-Name-Class']"));
					actualName=objEmpName.getText().toString().trim();
					if(empName.contentEquals(actualName)) {
						flag=true;
						if(timecardCheckbox.equalsIgnoreCase("ON")) {
							objSelect=empTimecard.findElement(By.xpath(".//label"));
							JavascriptExecutor jsExecutor = (JavascriptExecutor) getDriver();
							jsExecutor.executeScript("arguments[0].click();",objSelect );
						}
						break;
					}	


				}if(!flag) {Assert.assertTrue("No Timecards available for Employee '"+empName+"' Timeperiod '"+timePeriod+"'", false);}
			} else {Assert.assertTrue("No Timecards available for Timeperiod '"+timePeriod+"'", false);}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnViewTimeCardinTASlider(String timePeriod, String empName, String viewTimecard) {
		// Get Timecards List
		WaitForPageLoad();
		String[] fullTimePeriod=timePeriod.split(":");
		List<WebElement> empTimecards=getDriver().findElements(By.xpath("//div[contains(@class,'timecard-Approvals-Subheader-Class')][contains(.,'"+fullTimePeriod[0].trim()+"')][contains(.,'"+fullTimePeriod[1].trim()+"')]/ancestor::div[contains(@class,'mdf-grid-subheader')]/following-sibling::div[contains(@class,'mdf-grid-row')]"));
		// identify the timecard
		WebElement objEmpName = null;
		WebElement objViewTimecard = null;
		boolean flag = false;
		if (!empTimecards.isEmpty()) {
			for (WebElement empTimecard : empTimecards) {
				objEmpName = empTimecard.findElement(By.xpath(".//div[@class='timeCard-Grid-Name-Class']"));
				if (empName.contentEquals(objEmpName.getText().trim())) {
					flag = true;
					if (viewTimecard.equalsIgnoreCase("YES")) {
						objViewTimecard = empTimecard.findElement(By.xpath(".//div[contains(@class,'fa fa-chevron-right teamdasboard-busy-indicator')]"));
						objViewTimecard.click();
					}
					break;
				}
			}
			if (!flag) { Assert.assertTrue("No Timecards available for Employee '" + empName + "' Timeperiod '" + timePeriod + "'", false);	}
		} else {Assert.assertTrue("No Timecards available for Timeperiod '" + timePeriod + "'", false); }
	}

	public void verifyTimeCardDatainTASlider(String timecardCheckbox,String timePeriod,String empName,String empApproval,String totals,String regular,String OT,String totalsColor) {
		// Get Timecards List
		WaitForPageLoad();
		try{
			String[] fullTimePeriod=timePeriod.split(":");
			List<WebElement> empTimecards=getDriver().findElements(By.xpath("//div[contains(@class,'timecard-Approvals-Subheader-Class')][contains(.,'"+fullTimePeriod[0].trim()+"')][contains(.,'"+fullTimePeriod[1].trim()+"')]/ancestor::div[contains(@class,'mdf-grid-subheader')]/following-sibling::div[contains(@class,'mdf-grid-row')]"));
			//identify the timecard
			WebElement objEmpName=null;
			boolean flag=false;
			if(!empTimecards.isEmpty()) {
				for(WebElement empTimecard: empTimecards) {
					objEmpName=empTimecard.findElement(By.xpath(".//div[@class='timeCard-Grid-Name-Class']"));
					System.out.println(objEmpName.getText().trim());
					if(empName.contentEquals(objEmpName.getText().trim())){
						System.out.println(empName);
						flag=true;
						Assert.assertTrue("Verification Passed: Verification of Employee Name - '"+objEmpName.getText().trim(),true);
						WebElement actEmpApprove=empTimecard.findElement(By.xpath(".//span[contains(@class,'fa fa-') and contains(@class,'isEmployeeApprovals')]"));
						String actempApproval=actEmpApprove.getAttribute("class").trim();
						if(empApproval.equalsIgnoreCase("APPROVED")) {
							if (actempApproval.contains("Green")) Assert.assertTrue("Verification Passed: Timecard is Approved by Employee", true);
							else Assert.assertTrue("Verification Failed: Timecard is Not Approved by Employee", false);
						} else if(empApproval.equalsIgnoreCase("NOT APPROVED")) {
							if (actempApproval.contains("Red")) Assert.assertTrue("Verification Passed: Timecard is Not Approved by Employee", true);
							else Assert.assertTrue("Verification Failed: Timecard is Approved by Employee", false);
						}
						WebElement objTotal=empTimecard.findElement(By.xpath(".//div[contains(@class,'Employee-Approvals-Number timeCard-Grid-Name-Class')]"));
						String actTotals=objTotal.getText().trim();
						if(actTotals.contentEquals(totals))
							Assert.assertTrue("Verification Passed: Verification of Totals - '"+actTotals,true);
						else Assert.assertTrue("Verification Failed: Verification of Totals - '"+actTotals,false);
						//verification of Totals value text color
						if(!totalsColor.contentEquals("")){
							boolean actColor=objTotal.findElement(By.xpath(".//div[@class='isEmployeeApprovals-Red']")).isDisplayed();
							if(totalsColor.toUpperCase().contentEquals("RED")&&actColor){
								Assert.assertTrue("Verification Passed: Verification of Totals color when it is '0.00' - '"+totalsColor,true); }
							else {
								Assert.assertTrue("Verification Failed: Verification of Totals color when it is '0.00' - '"+totalsColor,false);
							}
						}
						if(!regular.contentEquals("")){
							String actRegular=empTimecard.findElement(By.xpath(".//div[contains(@class,'timeCard-Grid-Name-Class column-5')]")).getText().trim();
							if(actRegular.contentEquals(regular))
								Assert.assertTrue("Verification Passed: Verification of Regular - '"+actRegular,true);
							else Assert.assertTrue("Verification Failed: Verification of Regular - '"+actRegular,false);					
						}
						if(!OT.contentEquals("")){
							String actOT=empTimecard.findElement(By.xpath(".//div[contains(@class,'timeCard-Grid-Name-Class column-6')]")).getText().trim();
							if(actOT.contentEquals(OT))
								Assert.assertTrue("Verification Passed: Verification of Regular - '"+actOT,true);
							else Assert.assertTrue("Verification Failed: Verification of Regular - '"+actOT,false);
						}
						break;
					}	
				}
				if(!flag) {
					Assert.assertTrue("Verification Failed: Timecard not found in the Grid", false);
				}
			} else {Assert.assertTrue("No Timecards available for Timeperiod '" + timePeriod + "'", false); }
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyTimeCardExistanceinTASlider(String timePeriod,String empName,String objExistance) {
		// Get Timecards List
		WaitForPageLoad();
		String[] fullTimePeriod=timePeriod.split(":");
		List<WebElement> empTimecards=getDriver().findElements(By.xpath("//div[contains(@class,'timecard-Approvals-Subheader-Class')][contains(.,'"+fullTimePeriod[0].trim()+"')][contains(.,'"+fullTimePeriod[1].trim()+"')]/ancestor::div[contains(@class,'mdf-grid-subheader')]/following-sibling::div[contains(@class,'mdf-grid-row')]"));
		//identify the timecard
		WebElement objEmpName=null;
		boolean flag=false;
		if(!empTimecards.isEmpty()) {
			for(WebElement empTimecard: empTimecards) {
				objEmpName=empTimecard.findElement(By.xpath(".//div[@class='timeCard-Grid-Name-Class']"));
				if(empName.contentEquals(objEmpName.getText().trim()))
					flag=true;
				Assert.assertTrue("Verification Passed: Timecard of Employee Name - '"+empName+"' is exist on Ready for Approval Grid",true);
				break;
			}
			if(!flag) {
				if(objExistance.equalsIgnoreCase("EXISTS"))Assert.assertTrue("Verification Passed: Timecard of Employee Name - '"+empName+"' is exist on Ready for Approval Grid",true);
				else if(objExistance.equalsIgnoreCase("DOESNOTEXIST"))Assert.assertTrue("Verification Failed: Timecard of Employee Name - '"+empName+"' is exist on Ready for Approval Grid",false);
			}
		} else { if(objExistance.equalsIgnoreCase("EXISTS"))Assert.assertTrue("Verification Failed: Timecard of Employee Name - '"+empName+"' is exist on Ready for Approval Grid",false);
		else if(objExistance.equalsIgnoreCase("DOESNOTEXIST"))Assert.assertTrue("Verification Passed: No Timecards of Employee Name - '"+empName+"' exist on Ready for Approval Grid",true);}
	}

	public void clickOnViewTimecardLink(String timePeriod, String empName) {
		try{
			WaitForPageLoad();
			String[] fullTimePeriod=timePeriod.split(":");
			List<WebElement> empTimecards=getDriver().findElements(By.xpath("//div[contains(@class,'timecard-Approvals-Subheader-Class')][contains(.,'"+fullTimePeriod[0].trim()+"')][contains(.,'"+fullTimePeriod[1].trim()+"')]/ancestor::div[contains(@class,'mdf-grid-subheader')]/following-sibling::div[contains(@class,'mdf-grid-row')]"));
			WebElement objEmpName=null;
			boolean flag=false;
			if(!empTimecards.isEmpty()) {
				for(WebElement empTimecard: empTimecards) {
					objEmpName=empTimecard.findElement(By.xpath(".//div[@class='timeCard-Grid-Name-Class']"));
					if (empName.contentEquals(objEmpName.getText().trim())) {
						flag = true;
						Assert.assertTrue("Verification Passed: Timecard of Employee Name - '" + empName
								+ "' is exist on Ready for Approval Grid", true);
						if(empTimecard.findElement(By.xpath(".//div[contains(@class,'fa fa-chevron-right')]")).isDisplayed()){
							empTimecard.findElement(By.xpath(".//div[contains(@class,'fa fa-chevron-right')]")).click();
						}else Assert.assertTrue("Chevron Icon to navigate to Timecard not found!!", false);
						break;
					}
				}
			}	
			if(!flag) {
				Assert.assertTrue("Verification Failed: Timecard of Employee Name - '"+empName+"' is not exist on Ready for Approval Grid",false);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void clickButtonOnTASlider(String buttonName) {
		WaitForPageLoad();		
		try {
			if (!buttonName.equalsIgnoreCase("")) {
				switch (buttonName.toUpperCase()) {
				case "APPROVE":
					timecardApprovalsApprove.click();
					break;
				case "REMIND EMPLOYEE TO APPROVE":
					timecardApprovalsRemindEmployeetoApprove.click();
					break;
				case "BACK":
					timecardApprovalsBack.click();
					break;
				case "MISSED PUNCHES":
					timecardApprovalsMissedPunches.click();
					break;
				case "OTHER EXCEPTIONS":
					timecardApprovalsOtherExceptions.click();
					break;							
				}
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	public void VerifyWorkerLongerThanExpectedexistence(String shifttoreviewtile) {
		// TODO Auto-generated method stub
		try {
			if(shifttoreviewtile.equalsIgnoreCase("exists"))
			{Assert.assertTrue("shifttoreviewlink is displayed in Things To Do Tile",!VerifyWorkerLongerThanExpectedexistence.isDisplayed());}
			else if((shifttoreviewtile.equalsIgnoreCase("doesexists"))) {
				Assert.assertTrue("shifttoreviewlink is displayed in Things To Do Tile", !VerifyWorkerLongerThanExpectedexistence.isDisplayed());
			}

		}	
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	public void verifyshifttoreviewtile(String shifttoreviewtile) {
		// TODO Auto-generated method stub
		try {
			if(shifttoreviewtile.equalsIgnoreCase("exists"))
			{Assert.assertTrue("shifttoreviewlink is displayed in Things To Do Tile",!verifyshifttoreviewtitle.isDisplayed());}
			else if((shifttoreviewtile.equalsIgnoreCase("doesexists"))) {
				Assert.assertTrue("shifttoreviewlink is displayed in Things To Do Tile", !verifyshifttoreviewtitle.isDisplayed());
			}

		}	
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	public void WorkedlaterThanExpected(String arg1) {
		// TODO Auto-generated method stub
		selectToggleButton(WorkedlaterThanExpected,arg1);
	}

	public void WorkedlaterThanExpectedtext(String arg1) {
		// TODO Auto-generated method stub
		WorkedlaterThanExpectedtext.sendKeys(arg1);
	}

	public void WorkedlongerThanExpectedoutsideofshift(String arg1) {
		// TODO Auto-generated method stub
		selectToggleButton(WorkedlongerThanExpectedoutsideofshift,arg1);
	}

	public void WorkedlongerThanExpectedoutsideofshifttext(String arg1) {
		WorkedlongerThanExpectedoutsideofshifttext.sendKeys(arg1);
	}

	public void verifyEmployeeContactDetails(String employeename,List<String> contactlist)
	{
		String businesscontact = getDriver().findElement(By.xpath("(//*[text()='"+employeename+"']/../../..//text[3])[1]")).getText();
		String personalcontact = getDriver().findElement(By.xpath("(//*[text()='"+employeename+"']/../../..//text[3])[2]")).getText();
		String businessemail = getDriver().findElement(By.xpath("(//*[text()='"+employeename+"']/../../..//text[3])[3]")).getText();
		Assert.assertEquals(contactlist.get(0),businesscontact);
		Assert.assertEquals(contactlist.get(1),personalcontact);
		Assert.assertEquals(contactlist.get(2),businessemail);
	}

	public void verifyClickOnTimecardOpensLegacyTimecard()
	{
		viewTimecard.click();
		WaitForPageLoad();
		waitForElementToLoad(timecardRevit);
		checkElementVisible(timecardRevit);
		timecardBackButton.click();
		waitForElementToLoad(missedPunchesAndEmployeeCountOnMissedPunchesPage);

	}

	public void clickSaveButtonOnMissedPunchesPage()
	{
		waitABit(1000);
		saveButton.click();
		WaitForPageLoad();
		waitForElementToLoad(missedPunchesAndEmployeeCountOnMissedPunchesPage);

	}

	public void addTimePair(String timePunches, String timecardDate,String Approve) {
		try {
			timecardTable.waitUntilPresent();
			List<WebElementFacade> timecardTableRows=timecardTable.thenFindAll(By.xpath("//tr[contains(@class,'dR')]"));
			WaitForAjax();
			boolean timeEntered = false;
			String[] splitPunches=null;
			if(!timecardTableRows.isEmpty()) {
				if (!timecardDate.contentEquals("")&&!timePunches.contentEquals("")) {
					String tcDay=(timecardDate.split(" "))[0];
					String tcDate=(timecardDate.split(" "))[1];
					String strInPunch="";
					String strOutPunch="";
					splitPunches=timePunches.split("-");
					if(splitPunches.length>1){
						strInPunch=(timePunches.split("-"))[0];
						strOutPunch=(timePunches.split("-"))[1];
					} else {
						strInPunch=(timePunches.split("-"))[0];
					}
					for (WebElementFacade tcRow : timecardTableRows) {
						if (tcRow.findBy(By.xpath(".//td[contains(@id,'DayName')]")).getText().toString().contentEquals(tcDay) && tcRow.findElement(By.xpath(".//td[contains(@id,'InDate')]")).getText().toString().contentEquals(tcDate)) {
							WebElementFacade inPunch=tcRow.findBy(By.xpath(".//div[contains(@id,'InTime')]"));		
							if(!Approve.contentEquals("")) {
								WebElementFacade ApproveCheckBox=tcRow.findBy(By.xpath(".//div[contains(@class,'revitCheckBox dijitCheckBox')]"));
								selectWebCheckBox(ApproveCheckBox,Approve);
							}
							inPunch.click();
							timePunchTextBox.type(strInPunch);
							timePunchTextBox.type(strOutPunch);
							timeEntered = true;
							break;
						}
					}if(!timeEntered) {
						Assert.fail("No Timecards found for given date -'"+timecardDate+"'");
					}
				}else {
					Assert.fail("Date and/or time pair are not provided to enter in Timecard");
				}
			} else { 
				Assert.fail("Timecards not available to enter Timepair"); 
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void employeeEntersTimePair(String timePunches, String timecardDate) {
		try {
			timecardTable.waitUntilPresent();
			List<WebElementFacade> timecardTableRows=timecardTable.thenFindAll(By.xpath("//tr[contains(@class,'dR')]"));
			WaitForAjax();
			boolean timeEntered = false;
			if(!timecardTableRows.isEmpty()) {
				if (!timecardDate.contentEquals("")&&!timePunches.contentEquals("")) {
					String tcDay=(timecardDate.split(" "))[0];
					String tcDate=(timecardDate.split(" "))[1];
					String strInPunch=(timePunches.split("-"))[0];
					String strOutPunch=(timePunches.split("-"))[1];
					for (WebElementFacade tcRow : timecardTableRows) {
						if (tcRow.findBy(By.xpath(".//td[contains(@id,'DayName')]")).getText().toString().contentEquals(tcDay) && tcRow.findElement(By.xpath(".//td[contains(@id,'InDate')]")).getText().toString().contentEquals(tcDate)) {
							WebElementFacade inPunch=tcRow.findBy(By.xpath(".//div[contains(@id,'InTime')]"));		
							inPunch.click();
							timePunchTextBox.type(strInPunch);
							timePunchTextBox.type(strOutPunch);
							timeEntered = true;
							break;
						}
					}if(!timeEntered) {
						Assert.fail("No Timecards found for given date -'"+timecardDate+"'");
					}
				}else {
					Assert.fail("Date and/or time pair are not provided to enter in Timecard");
				}
			} else { 
				Assert.fail("Timecards not available to enter Timepair"); 
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void selectEmployee(String empName) {
		try {
			waitABit(3000);
			timecardEmpName.waitUntilVisible();
			String actEmpName=timecardEmpName.getText().trim();
			boolean empFound=false;
			List<WebElement> empLinks;
			if(!empName.contentEquals(actEmpName)) {
				timecardEmpSearch.waitUntilClickable().click();
				waitABit(2000);
				selectEmpPopupSearch.waitUntilClickable();
				selectEmpPopupSearch.type(empName);
				waitABit(2000);
				empSearchResultsGrid.waitUntilClickable();
				empLinks=empSearchResultsGrid.findElements(By.xpath(".//button[@id='skinnylist-empname']"));
				if(!empLinks.isEmpty()) {
					for(WebElement empLink:empLinks) {
						if(empLink.getText().trim().contentEquals(empName)) {
							waitABit(1000);
							empLink.click();
							empFound=true;
							waitABit(3000);
							break;
						}
					}if(!empFound) {
						Assert.fail("No Employees found with name '"+empName+"'");
					}
				} else {Assert.fail("No Employees found in the search employee pop up");}
			}
			timecardEmpName.waitUntilVisible();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void clickButtonOnIndividualTimcardPage(String buttonName) {
		WaitForPageLoad();		
		try {
			if (!buttonName.equalsIgnoreCase("")) {
				switch (buttonName.toUpperCase()) {
				case "APPROVE TIMECARD":
					clickUsingJavaScript(individualTimecardApproveTimecard);
					break;
				case "FIND":
					individualTimecardFind.click();
					break;
				case "SAVE":
					clickUsingJavaScript(individualTimecardSave);
					if(alertOK.isDisplayed()) {
						alertOK.click();
					}else {
						waitForElementToLoad(individualTimecardPreferencesOperationSuccessful);
					}
					break;
				case "REFRESH":
					individualTimecardRefresh.click();
					break;
				case "PREFERENCES":
					individualTimecardPreferences.click();
					break;							
				}
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}

	}

	public void verifyshifttoreviewtile(String shifttoreviewtile,String verifyEmployeeCount, String verifyshiftCount) {
		// TODO Auto-generated method stub 
		try {
			if(shifttoreviewtile.equalsIgnoreCase("exists"))
			{Assert.assertTrue("shifttoreviewlink is displayed in Things To Do Tile",verifyshifttoreviewtile.isDisplayed());}
			else if((shifttoreviewtile.equalsIgnoreCase("doesexists"))) {
				Assert.assertTrue("shifttoreviewlink is displayed in Things To Do Tile", !verifyshifttoreviewtile.isDisplayed());
			}
			String actShiftEmpCount=verifyshifttoreviewtileemployee.getText().trim();
			//String[] actualTimecards=actShiftEmpCount.split(",");
			String[] actualEmp=actShiftEmpCount.split(",")[0]. split(" ");
			String actNewShift=actShiftEmpCount.split(",")[1].trim();
			String[] strActualShift=actNewShift.split(" ");
			String   actualEmpCount=actualEmp[0];
			String   actualShiftCount=strActualShift[0];

			Assert.assertTrue("Verify Employees Count of shift to review - "+actualEmpCount,actualEmpCount.contentEquals(verifyEmployeeCount));
			Assert.assertTrue("Verify Shifts Count of shift to review - "+actualShiftCount,actualShiftCount.contentEquals(verifyshiftCount));

		}            
		catch (Exception ex) {
			ex.printStackTrace();
		}      
	}
	
	public HashMap<String,String> getWeekDate(String crntWeek) {
		Calendar c = GregorianCalendar.getInstance();
		// Set the calendar to required day of the current week
		switch (crntWeek.toUpperCase()) {
		case "SUNDAY":
			c.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
			break;
		case "MONDAY":
			c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
			break;
		case "TUESDAY":
			c.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY);
			break;
		case "WEDNESDAY":
			c.set(Calendar.DAY_OF_WEEK, Calendar.WEDNESDAY);
			break;
		case "THURSDAY":
			c.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
			break;
		case "FRIDAY":
			c.set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY);
			break;
		case "SATURDAY":
			c.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
			break;
		}

		DateFormat df = new SimpleDateFormat("dd");
		HashMap<String,String> dateMap=new HashMap<String,String>();
		System.out.println(df.format(c.getTime()));
		dateMap.put("currentWeekStartDate", df.format(c.getTime()));
		c.add(Calendar.DATE, 6);
		System.out.println(df.format(c.getTime()));
		dateMap.put("currentWeekEndDate", df.format(c.getTime()));
		c.add(Calendar.DATE, 1);
		System.out.println(df.format(c.getTime()));
		dateMap.put("nextWeekStartDate", df.format(c.getTime()));
		c.add(Calendar.DATE, 6);
		System.out.println(df.format(c.getTime()));
		dateMap.put("nextWeekEndDate", df.format(c.getTime()));

		return dateMap;
	}

	public void verifyTimeOffTileHeaders(String weekStartDay) {
		try {
			HashMap<String, String> dateMap = getWeekDate(weekStartDay);
			waitForElementToLoad(nextWeekView);
			Assert.assertTrue(timeOffTileName.isDisplayed());
			int dayCount = getDriver()
					.findElements(
							By.xpath(".//div[contains(@class,'vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 column')]"))
					.size();
			Assert.assertTrue("Verification of Number of days displayed on Time Off This Week Tile", dayCount == 8);
			Assert.assertTrue(timeOffTileStartWeek.getText().contentEquals(dateMap.get("currentWeekStartDate")));
			Assert.assertTrue(timeOffTileEndWeek.getText().contentEquals(dateMap.get("currentWeekEndDate")));
			nextWeekView.click();
			waitForElementToLoad(previousWeekView);
			Assert.assertTrue(timeOffTileName.isDisplayed());
			dayCount = getDriver()
					.findElements(
							By.xpath(".//div[contains(@class,'vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 column')]"))
					.size();
			Assert.assertTrue("Verification of Number of days displayed on Time Off Next Week Tile", dayCount == 8);
			Assert.assertTrue(timeOffTileStartWeek.getText().contentEquals(dateMap.get("nextWeekStartDate")));
			Assert.assertTrue(timeOffTileEndWeek.getText().contentEquals(dateMap.get("nextWeekEndDate")));
			previousWeekView.click();
			waitForElementToLoad(nextWeekView);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<WebElement> getEmpRows() {
		List<WebElement> objEmpList = null;
		try {
			objEmpList = getDriver()
					.findElements(By.xpath("//div[@class='timeoffTileMainClass']//div[@class='vdl-row mdf-grid-row']"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return objEmpList;
	}

	public void verifyEmployeeListOnTimeOffTile(String empList) {
		if (empList.contentEquals(""))
			return;
		try {
			List<WebElement> actEmpList = getDriver().findElements(By.xpath(".//div[@class='timeOffTileNameFont']"));
			if (actEmpList.size() != 0) {
				int i = 0;
				if(empList.contains(";") && actEmpList.size() >= 1 ){
					String[] emps = empList.split(";");
					if(emps.length==actEmpList.size()){
						for (WebElement actEmp : actEmpList) {
							Assert.assertTrue(actEmp.getText().trim().contentEquals(emps[i]));
							i++;
						}						
					}else{
						Assert.fail("Expected Employees are not displayed on Time Off tile");
					}
				} else {
					if(actEmpList.size() == 1){
						Assert.assertTrue(actEmpList.get(0).getText().trim().contentEquals(empList));
					}else{
						Assert.fail("More than Expected Employees are displayed on Time Off tile");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyEmployeeOrderTORTile(String empList) {
		try {
			List<WebElement> objEmpList = getDriver().findElements(By.xpath(".//div[@class='timeOffTileNameFont']"));
			String actEmpList = "";
			String actEmpName = "";
			if (!objEmpList.isEmpty()) {
				for (WebElement objEmp : objEmpList) {
					actEmpName = objEmp.getText().trim();
					if (actEmpList.contentEquals("")) {
						actEmpList = actEmpList.concat(actEmpName + ";");
					} else {
						actEmpList = actEmpList.concat(";" + actEmpName);
					}
				}
				Assert.assertTrue(actEmpList.contentEquals(empList));
			} else {
				Assert.fail("No Employees Found on Time Off Tile");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public WebElement getEmpRow(String empName) {
		WebElement objEmp = null;
		try {
			boolean bFound = false;
			List<WebElement> objList = getEmpRows();
			if (objList.isEmpty()) {
				Assert.fail("No Employees Found on Time Off Tile");
			} else {
				for (WebElement obj : objList) {
					if (empName.contentEquals(
							obj.findElement(By.xpath(".//div[@class='timeOffTileNameFont']")).getText().trim())) {
						objEmp = obj;
						bFound = true;
						break;
					}
				}
				if (!bFound) {
					Assert.fail("'"+empName+"' Employee is not listed in Time Off Request Tile");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return objEmp;
	}
	
	public String getDateHeaderLocator(String requestDate){
		String locator="";
		try{
			List<WebElement> objDateList=getDriver().findElements(By.xpath(".//div[contains(@class,'vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 column-')]"));
			if(!objDateList.isEmpty()){
				for(WebElement objDate:objDateList){
					if(Integer.parseInt(requestDate)==Integer.parseInt(objDate.getText().trim())){
						locator=objDate.getAttribute("class").replace("vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 ", "");
						break;
					}
				}
			}
		}catch (Exception e){
			e.printStackTrace();
		}
		return locator;
	}
	
	public String getRequestDateClass(String empName, String requestDate) {
		String findClass = "";
		try {
			List<WebElement> objList = getEmpRows();
			String dateHeaderLocator=getDateHeaderLocator(requestDate);
			if (objList.isEmpty()) {
				Assert.fail("No Employees Found on Time Off Tile");
			} else {
				WebElement objEmp = getEmpRow(empName);
				WebElement objRequest = objEmp.findElement(
						By.xpath(".//div[contains(@class,'vdl-col-xs mdf-grid-cell vdl-col-sm-1') and contains(@class,'"+dateHeaderLocator+"')]/div"));
				findClass = objRequest.getAttribute("class");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return findClass;
	}

	public void verifyWeekOfRequestDate(String requestDate){
		boolean dtFound=false;
		WaitForPageLoad();
		waitForElementToLoad(nextWeekView);
		List<WebElement> wkDates=getDriver().findElements(By.xpath(".//div[contains(@class,'vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 column')]"));
		if(!wkDates.isEmpty()){
			for(WebElement wkDate : wkDates){
				if(Integer.parseInt(wkDate.getText().trim())==Integer.parseInt(requestDate)){
					dtFound=true;
					break;
				}
			}
			if(!dtFound){
				nextWeekView.click();
				waitForElementToLoad(previousWeekView);
				wkDates=getDriver().findElements(By.xpath(".//div[contains(@class,'vdl-col-xs mdf-grid-headerCell vdl-col-sm-1 column')]"));
				if(!wkDates.isEmpty()){
					for(WebElement wkDate : wkDates){
						if(Integer.parseInt(wkDate.getText().trim())==Integer.parseInt(requestDate)){
							dtFound=true;
							break;
						}
					}
					if(!dtFound){
						Assert.fail("Invalid Request Date");
					}
			}
		}
		}
	}
	
	public void verifyRequestStatusTimeOffTile(String empName, String requestDate, String Status) {
		try {
			//verify requested date is in Current week or Next week
			String rd=requestDate;
			verifyWeekOfRequestDate(rd);
			String actStatus = getRequestDateClass(empName, requestDate);
			
			if (!actStatus.contentEquals("")) {
				switch (Status.toUpperCase()) {
				case "PENDING":
					Assert.assertTrue(actStatus.contentEquals("timeOffRequestSquareBoxClass"));
					break;
				case "APPROVED":
					Assert.assertTrue(actStatus.contentEquals("timeOffRequestSquareBoxGreenColorClass"));
					break;
				}
			} else {
				Assert.fail("Class of Date not returned");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void navigateToNextWeekViewTORTile() {
		try {
			WaitForPageLoad();
			waitForElementToLoad(nextWeekView);
			waitABit(4000);
			nextWeekView.click();
			waitABit(4000);
			waitForElementToLoad(previousWeekView);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void navigateToPreviousWeekViewTORTile() {
		WaitForPageLoad();
		waitForElementToLoad(previousWeekView);
		previousWeekView.click();
		waitForElementToLoad(nextWeekView);
	}
	
	public void clickButtonOnTORTile(String strBtn){
		switch (strBtn) {
		case "TIME OFF THIS WEEK": timeOffThisWeekTitle.click(); break;
		case "TIME OFF NEXT WEEK": timeOffNextWeekTitle.click(); break;
		case "PENDING": pending.click(); break;
		case "APPROVED": approved.click(); break;
		case "TITLE ICON": titleIcon.click(); break;
		}
		waitForElementToLoad(lorPendingBucket);
	}
	
	public void verifyContentsTimeOffTile(String title, String pendCount, String apprCount){
		try{
		if(!title.contentEquals("")) {
			switch(title.toUpperCase()){
			case "TIME OFF THIS WEEK": 
				waitForElementToLoad(timeOffThisWeekTitle);
				Assert.assertTrue(timeOffThisWeekTitle.isDisplayed());
				break;
			case "TIME OFF Next WEEK": 
				waitForElementToLoad(timeOffNextWeekTitle);
				Assert.assertTrue(timeOffNextWeekTitle.isDisplayed()); 
				break;
			}
		}
		Assert.assertTrue(pending.isDisplayed());
		Assert.assertTrue(pendCount.contentEquals(pendingCount.getText().trim()));
		Assert.assertTrue(approved.isDisplayed());
		Assert.assertTrue(apprCount.contentEquals(approvedCount.getText().trim()));
		Assert.assertTrue(employeesLabel.isDisplayed());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void SelectEmployeePTOCalendar(String empName){
		try{
			WebElement objEmp=getDriver().findElement(By.xpath(".//td[contains(@class,'listfirstcolumn')][.='"+empName+"']"));
			if(objEmp.isDisplayed()){
				objEmp.click();
			}
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void clickOnRequestTimeOffButton() {
		WaitForPageLoad();		
		try {
			requestTimeOffButton.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void enterTimeOffRequestDetails(String stDay,String endDay,String strPolicy,String amount,String strStartTime,String comments,String respondBy) {
		try {
			selectFrame(ptoFrame);
			waitForElementToLoad(torStartDay);
			torStartDay.type(stDay);
			torEndDay.clear();
			torEndDay.type(endDay);
			waitABit(5000);
			waitForElementToLoad(ptoSelectedDate);
			ptoSelectedDate.click();
			waitABit(5000);
			strPolicy="PTO - Vacation";
			selectValueFromComboBox(policy,strPolicy);
			torAmount.type(amount);
			selectValueFromComboBox(startTime,strStartTime);
//			if(!comments.contentEquals("")){
//				torComments.type(comments);
//			}
			if(!respondBy.contentEquals("")){
				torRespondBy.type(respondBy);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			switchToDefaultContent();
		}
	}
	
	public void submitTimeOffRequest(){
		WaitForPageLoad();		
		selectFrame(ptoFrame);
		try {
			torSubmit.click();
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			switchToDefaultContent();
		}
	}
	
	//List of Requests page
	
	public WebElement getRequestTab(String reqType){
		boolean bfound=false;
		WebElement reqTab=null;
		try {
			List <WebElement> tabList=getDriver().findElements(By.xpath(".//div[contains(@class,'lor-count-tab')]"));
			for(WebElement oTab:tabList){
				if(oTab.findElement(By.xpath(".//h4[@class='lor-request-tab-title']")).getText().trim().contentEquals(reqType)){
					bfound=true;
					reqTab=oTab;
					break;
				}
			}
			if(!bfound){
				Assert.fail(reqType+" tab is not exist");
			}			
		}catch(Exception e){
			e.printStackTrace();
		}
		return reqTab;
	}

	public void clickOnRequestTypeTab(String reqType){
		try {
			WebElement oTab=getRequestTab(reqType);
			if(oTab!=null){
				oTab.click();
			}
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void clickBackButtonLORSlider(){
		try{
		waitForElementToLoad(lorBack);
		lorBack.click();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void verifyRequestCountsOnRequestTypeTab(String reqType,String reqCount){
		try{
			WebElement oTab=getRequestTab(reqType);
			if(oTab!=null){			
				String actCount=oTab.findElement(By.xpath(".//h2[contains(@class,'lor-request-count')]")).getText().trim();
				Assert.assertEquals(actCount,reqCount);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<WebElement> getReqListLOR() {
		List<WebElement> objReqList=null;
		try{
			objReqList=getDriver().findElements(By.xpath("//div[contains(@class,'pracManagerLorGrid')]/descendant::div[@class='vdl-row mdf-grid-row']"));
			if(objReqList.isEmpty()){
				Assert.fail("No Request Listed under Pending tab");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return objReqList;
	}
	
	public WebElement getRequestEntryLOR(String empName, String reqPeriod, String reqHrs) {
		WebElement objRequest = null;
		try {
			List<WebElement> reqList = getReqListLOR();
			String actName;
			actName = "";
			String actPeriod = "";
			boolean bfound = false;
			if (!empName.contentEquals("") && !reqPeriod.contentEquals("")) {
				for (WebElement objReq : reqList) {
					actName = objReq.findElement(By.xpath(".//button[contains(@id,'lor-grid-emp-name-btn')]"))
							.getText();
					actPeriod = objReq.findElement(By.xpath(".//div[contains(@id,'lor-grid-request-period')]"))
							.getText();
					if (empName.contentEquals(actName) && reqPeriod.contentEquals(actPeriod)) {
						if (!reqHrs.contentEquals("")) {
							String atHrs = objReq
									.findElement(By.xpath(".//div[contains(@id,'lor-grid-requested-amount')]"))
									.getText();
							if (atHrs.contentEquals(reqHrs)) {
								objRequest = objReq;
								bfound = true;
								break;
							}
						}
						objRequest = objReq;
						bfound = true;
						break;
					}
				}
				if (!bfound) {
					Assert.fail("No request found for employee '" + empName + "'");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return objRequest;
	}

	public void takeActionOnRequestLOR(String action, String empName, String reqPeriod, String reqHrs) {
		try{
		WebElement objReq = getRequestEntryLOR(empName, reqPeriod, reqHrs);
		boolean lFound=false;
		if (!action.contentEquals("")) {
//EAP content			
//			Select objAction = new Select(
//					objReq.findElement(By.xpath(".//div[@id='DropdownListId'][@role='combobox']")));
//			objAction.selectByValue(action);
//			waitForElementToLoad(lorProcessRequest);
//			lorProcessRequest.click();
			WebElement objAction=objReq.findElement(By.xpath(".//span[@class='fa fa-ellipsis-v lor-grid-actions-button']"));
			objAction.click();
			List<WebElement> popOverLinks=getDriver().findElements(By.xpath(".//button[contains(@id,'lor-actions-popover-item')]"));
			for(WebElement popOverLink:popOverLinks){
				if(popOverLink.getText().trim().equalsIgnoreCase(action)){
					lFound=true;
					popOverLink.click();
					waitForElementToLoad(lorApproveAll);
					break;
				}
			}if(!lFound){
				Assert.fail("Given action is Invalid or not Found");
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void processActionOnLOR(String processAction){
		if(processAction.contentEquals("")) return;
		try{
			switch (processAction.toUpperCase()){
			case "APPROVE": waitForElementToLoad(lorApproveAll);lorApproveAll.click();waitForElementToLoad(lorSubmit);lorSubmit.click();break;
			case "DENY": waitForElementToLoad(lorDenyAll);lorDenyAll.click();waitForElementToLoad(lorSubmit);lorSubmit.click();break;
			case "CANCEL":waitForElementToLoad(lorCancel);lorCancel.click();break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@FindBy(xpath="//span[@id='lblSubject']/ancestor::tr/following-sibling::tr[1]/td[@class='FLD_Value']")
	public WebElementFacade messageSubject;
	@FindBy(xpath="//span[@id='lblBody']/ancestor::tr/following-sibling::tr//td[@class='FLD_Value']/p")
	public WebElementFacade messageBody;
	@FindBy(xpath="//span[@id='btnGoToMessageCenter']")
	public WebElementFacade goBackToMC;
	public void verifyNotificationMessageDetails(String subject, String message) {
		try{
			WaitForPageLoad();	
			getDriver().switchTo().frame("eZlmIFrame_iframe");
			if(!subject.contentEquals("")) {
				String actSub=messageSubject.getText().trim();
				System.out.println(actSub);
				if(actSub.contentEquals(subject)){
					Assert.assertTrue("Verification Passed:Message Subject is correctly displayed", true);
				}else {
					Assert.assertTrue("Verification Failed:Message Subject is incorrect", false);
				}
			}
			if(!message.contentEquals("")) {
				String actMsg=(messageBody.getText().trim().replaceAll("<br>", "")).replaceAll("  ", " ");
				if(actMsg.contentEquals(message)){
					Assert.assertTrue("Verification Passed:Message is correctly displayed", true);
				}else {
					Assert.assertTrue("Verification Failed:Message is incorrect", false);
				}
			}		
			getDriver().switchTo().defaultContent();
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	public void navigateBackToMessageCenter() {
		try{
			getDriver().switchTo().frame("eZlmIFrame_iframe");
			WaitForPageLoad();
			goBackToMC.click();
			getDriver().switchTo().defaultContent();
			WaitForPageLoad();
		} catch(Exception e){
			e.printStackTrace();
		}

	}
	//Over Time Tile and Slider
	@FindBy(xpath="//div[contains(@class,'overtime-hit-overtime')]/ancestor::div[@data-grid-index]")
	private WebElementFacade hitOverTimesection;
	@FindBy(xpath="//div[contains(@class,'overtime-hit-overtime')]/text[contains(text(),'HIT OVERTIME')]")
	private WebElementFacade hitOverTimeCount;
	@FindBy(xpath="//div[contains(@class,'overtime-no-overtime')]/ancestor::div[@data-grid-index]")
	private WebElementFacade noOverTimePredictionsection;
	@FindBy(xpath="//div[contains(@class,'overtime-no-overtime')]/text[contains(text(),'NO OVERTIME PREDICITON')]")
	private WebElementFacade noOverTimePredictionCount;
	@FindBy(xpath="//div[contains(@class,'overtime-may-hit-overtime')]/ancestor::div[@data-grid-index]")
	private WebElementFacade mayHitOverTimesection;
	@FindBy(xpath="//div[contains(@class,'overtime-may-hit-overtime')]/text[contains(text(),'MAY HIT OVERTIME')]")
	private WebElementFacade mayHitOverTimeCount;

	public void verifyOvertimeSectionsOnSlider(String hitOT,String noOT,String mayHitOT){
		if(hitOT.toUpperCase().contentEquals("EXISTS")){
			Assert.assertTrue("Verification of Hit Overtime section on Slider", hitOverTimesection.isDisplayed());
		}else if (hitOT.toUpperCase().contentEquals("DOESNOTEXIST")){
			Assert.assertTrue("Verification of Hit Overtime section on Slider", !hitOverTimesection.isDisplayed());
		}
		if(noOT.toUpperCase().contentEquals("EXISTS")){
			Assert.assertTrue("Verification of No Overtime Prediction section on Slider", noOverTimePredictionsection.isDisplayed());
		}else if (noOT.toUpperCase().contentEquals("DOESNOTEXIST")){
			Assert.assertTrue("Verification of No Overtime Prediction section on Slider", !noOverTimePredictionsection.isDisplayed());
		}
		if(mayHitOT.toUpperCase().contentEquals("EXISTS")){
			Assert.assertTrue("Verification of May Hit Overtime section on Slider", noOverTimePredictionsection.isDisplayed());
		}else if (mayHitOT.toUpperCase().contentEquals("DOESNOTEXIST")){
			Assert.assertTrue("Verification of May Hit Overtime section on Slider", !noOverTimePredictionsection.isDisplayed());
		}
	}
	public void verifyOvertimeCountsOnSlider(String hitOTCount,String noOTCount,String mayHitOTCount){
		if(!hitOTCount.contentEquals("")&&hitOverTimesection.isDisplayed()){
			String actHitOTCount=hitOverTimeCount.getText();
			if(actHitOTCount.contentEquals("HIT OVERTIME - "+hitOTCount.trim())) {
				Assert.assertTrue("Verification Passed:Number of Employees Hit Overtime is-"+hitOTCount, true);
			} else {
				Assert.assertTrue("Verification Failed:Number of Employees Hit Overtime is not macthed with expected", false);
			}
		}	
		if(!noOTCount.contentEquals("")&&noOverTimePredictionsection.isDisplayed()){
			String actNoOTCount=noOverTimePredictionCount.getText();
			if(actNoOTCount.contentEquals("NO OVERTIME PREDICTION - "+noOTCount.trim())) {
				Assert.assertTrue("Verification Passed:Number of Employees with No Overtime Prediction is-"+hitOTCount, true);
			} else {
				Assert.assertTrue("Verification Failed:Number of Employees with No Overtime Prediction is not macthed with expected", false);
			}
		}
		if(!mayHitOTCount.contentEquals("")&&mayHitOverTimesection.isDisplayed()){
			String actMayHitOTCount=mayHitOverTimeCount.getText();
			if(actMayHitOTCount.contentEquals("MAY HIT OVERTIME - "+mayHitOTCount.trim())) {
				Assert.assertTrue("Verification Passed:Number of Employees May Hit Overtime is-"+hitOTCount, true);
			} else {
				Assert.assertTrue("Verification Failed:Number of Employees May Hit Overtime is not macthed with expected", false);
			}
		}
	}	
	public void verifyEmployeeDetailsOvertime(String empName,String mobileNumber,String phoneNumber,String regularHours,String overTimeHours,String totalHours){
		try{
			WebElement empRecord=getEmployeeRecordOverTimeSlider(empName);
			String actMobile=empRecord.findElement(By.xpath(".//text[@class='fa fa-phone']/following-sibling::text")).getText().trim();
			String actHome=empRecord.findElement(By.xpath(".//text[@class='fa fa-home']/following-sibling::text")).getText().trim();

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void getEmployeeDetailsOvertime(String empName,String mobileNumber,String phoneNumber,String regularHours,String overTimeHours,String totalHours){
		try{
			HashMap<String,WebElement> empMap=new HashMap<String,WebElement>();
			WebElement empRecord=getEmployeeRecordOverTimeSlider(empName);
			empMap.put("phone", empRecord.findElement(By.xpath(".//text[@class='fa fa-phone']/following-sibling::text")));
			empMap.put("home", empRecord.findElement(By.xpath(".//text[@class='fa fa-home']/following-sibling::text")));
			empMap.put("regular", empRecord.findElement(By.xpath(".//text[@class='fa fa-home']/following-sibling::text")));
			String actMobile=empRecord.findElement(By.xpath(".//text[@class='fa fa-phone']/following-sibling::text")).getText().trim();
			String actHome=empRecord.findElement(By.xpath(".//text[@class='fa fa-home']/following-sibling::text")).getText().trim();

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public WebElement getEmployeeRecordOverTimeSlider(String empName){
		WebElement objEmpRec=null;
		try {
			boolean efound=false;
			List<WebElement> objEmpRows=getDriver().findElements(By.xpath("//div[contains(@class,'vdl-row mdf-grid-row') and not (contains(@class,'mdf-grid-subheader'))]"));
			if(!objEmpRows.isEmpty()) {
				for(WebElement objEmp: objEmpRows){
					String actEmpName=objEmp.findElement(By.xpath(".//text[@class='overtime-name-text']")).getText().trim();
					if(actEmpName.equalsIgnoreCase(empName)) {
						objEmpRec=objEmp;
						efound=true;
						Assert.assertTrue("Employee found with name-"+empName, true);
						break;
					}
				}
				if(!efound){
					Assert.assertTrue("No Employee Record found with name-"+empName, true);
				}
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		return objEmpRec;
	}

	public void verifyColorOfNote(String employeename,String date,String color)
	{
		String attributevalue = getDriver().findElement(By.xpath("//*[text()='"+employeename+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[contains(@class,'notes-icon')]")).getAttribute("class");
		if(color.equals("blue"))
			Assert.assertEquals("fa fa-sticky-note missedPunches-notes-icon",attributevalue);
		else if(color.equals("white"))
			Assert.assertEquals("fa fa-sticky-note-o missedPunches-notes-icon",attributevalue);
		else if(color.equals("read"))
			Assert.assertEquals(false,checkElementVisible("//*[text()='"+employeename+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[contains(@class,'alert-number-indicator')]"));
		else if(color.equals("unread"))
			Assert.assertEquals(true,checkElementVisible("//*[text()='"+employeename+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[contains(@class,'alert-number-indicator')]"));
	}

	public void clickButtonOnNotesPage(String buttonName)
	{
		try {
			if (!buttonName.equalsIgnoreCase("")) {
				switch (buttonName.toUpperCase()) {
				case "CANCEL":
					waitABit(2000);
					notesSliderCancelButton.click();
					waitABit(2000);
					break;
				case "SAVE":
					waitABit(2000);
					notesSliderSaveButton.click();
					waitABit(2000);
					break;
				case "BACK":
					waitABit(2000);
					noteSliderbackButton.click();
					waitABit(2000);
					break;

				}
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	public void clickASpecificNote(String employeename,String date)
	{
		getDriver().findElement(By.xpath("//*[text()='"+employeename+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[contains(@class,'notes-icon')]")).click();
		WaitForPageLoad();
		waitABit(1000);
	}

	public void enterSupervisorNote(String note)
	{
		supervisornotes.click();
		supervisornotes.clear();
		supervisornotes.sendKeys(note);
		supervisornotes.sendKeys(Keys.TAB);
	}

	public void clickEmployeeViewableButton(String buttonnname)
	{
		String attribute = employeeviewabletogglestatus.getAttribute("class");
		if(buttonnname.equals("ON"))
		{
			if(!attribute.contains("checked"))
			{
				employeeviewabletoggle.click();
			}
		}
		else if(buttonnname.equals("OFF"))
		{
			if(attribute.contains("checked"))
			{
				employeeviewabletoggle.click();
			}
		}

	}

	public void verifyEmployeeNoteOnNotesPage(String notetype,String employeename,String note)
	{
		if(notetype.equals("Row"))
		{
			Assert.assertTrue(notesUsername.getText().contains(employeename.split(",")[0]));
			Assert.assertTrue(checkElementVisible("//*[text()='"+note+"']"));
			//Assert.assertFalse(checkElementVisible(notesType));

		}
		else if(notetype.equals("Department")){

			Assert.assertTrue(notesUsername.getText().contains(employeename.split(",")[0]));
			Assert.assertEquals(notetype, notesType.getText());
			Assert.assertTrue(checkElementVisible("//*[text()='"+note+"']"));
		}
		else if(notetype.equals("Pay Code"))
		{
			Assert.assertTrue(notesUsername.getText().contains(employeename.split(",")[0]));
			Assert.assertEquals(notetype.toUpperCase(), notesType.getText());
			Assert.assertTrue(checkElementVisible("//*[text()='"+note+"']"));
		}
		else if(notetype.equals("In"))
		{
			Assert.assertTrue(notesUsername.getText().contains(employeename.split(",")[0]));
			Assert.assertEquals("INTIME", notesType.getText());
			Assert.assertTrue(checkElementVisible("//*[text()='"+note+"']"));
		}
		else if(notetype.equals("Out"))
		{
			Assert.assertTrue(notesUsername.getText().contains(employeename.split(",")[0]));
			Assert.assertEquals("OUTTIME", notesType.getText());
			Assert.assertTrue(checkElementVisible("//*[text()='"+note+"']"));
		}

	}


	public void verifyScheduleCountOnShiftsTOReviewTile(String scheduleCount, String empname, String date)
	{
		int count = getObjectCount("//*[text()='"+empname+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[@class='vdl-row timepair-cell shift-class']");
		Assert.assertEquals(scheduleCount, String.valueOf(count));
	}

	public void verifyRuleOnShiftsTOReviewTile(String rulename,String flag,String empname,String date)
	{
		String violations = getDriver().findElement(By.xpath("//*[text()='"+empname+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[@class='vdl-row shiftsToReview-violation']/../..")).getText();
		System.out.println("Violation on date:"+date+" are "+violations);
		if(flag.equals("YES"))
			Assert.assertTrue(violations.contains(rulename));
		else if(flag.equals("NO"))
			Assert.assertFalse(violations.contains(rulename));
	}

	public void dismissShiftOfSpecificEmployee(String empname,String date)
	{
		waitABit(2000);
		getDriver().findElement(By.xpath("//*[text()='"+empname+"']/../../../../../..//*[contains(text(),'"+date+"')]/../../../..//*[@class='missedPunches-checkbox-div']//label")).click();
		waitABit(2000);
		shiftsToReviewDismiss.click();
	}

	public void verifyCountOnShiftsToReviewTTDTile(String employeecount,String shiftcount)
	{
		String employeecountandmissedpunches = ShiftsAndEmployeeCount.getText();
		String employees = employeecountandmissedpunches.split(",")[0].trim();
		String missedpunches = employeecountandmissedpunches.split(",")[1].trim();
		Assert.assertEquals(employees.split(" ")[0].trim(), employeecount);
		Assert.assertEquals(missedpunches.split(" ")[0].trim(), shiftcount);
	}

	public void verifyDataOnShiftsToReviewSlider(String employeecount,String missedpunchescount)
	{
		String employeecountandmissedpunches = ShiftsAndEmployeeCountOnSlider.getText();
		String employees = employeecountandmissedpunches.split(",")[0].trim();
		String missedpunches = employeecountandmissedpunches.split(",")[1].trim();
		Assert.assertEquals(employees.split(" ")[0].trim(), employeecount);
		Assert.assertEquals(missedpunches.split(" ")[0].trim(), missedpunchescount);


	}
	
	public void clickShiftSwapRequestsOnTTDTile()
    	{
    		WaitForPageLoad();
    		waitForElementToLoad(shiftSwapRequests);
    		shiftSwapRequests.click();
    		WaitForPageLoad();
    		waitForElementToLoad(shiftSwapRequestSliderCount);
    		
    	}

        public void verifyCOuntOfShiftSwapRequestOnSlider(String count)
    	{
    		String request = shiftSwapRequestSliderCount.getText();
    		String requestcount = request.split("(")[1].split(")")[0].trim();
    		Assert.assertEquals(requestcount, count);
    	}
        public void approveOrRejectShiftSwapRequest(String approveorreject,String comment)
    	{
    		if(approveorreject.equals("approve"))
    		{
    			shiftSwapComment.clear();
    			shiftSwapComment.sendKeys(comment);
    			waitABit(2000);
    			approveShiftSwapRequest.click();
    			waitABit(2000);
    		}
    		
    		else if(approveorreject.equals("reject"))
    		{
    			shiftSwapComment.clear();
    			shiftSwapComment.sendKeys(comment);
    			waitABit(2000);
    			rejectShiftSwapRequest.click();
    			waitABit(2000);
    		}
    	}
        
        public void clickBackOnShiftSwapSlider()
    	{
    		ShiftSwapBack.click();
    		waitABit(2000);
    	}

    	public void verifyShiftSwapTileIsNotDisplayed()
    	{
    		Assert.assertEquals(checkElementVisible(shiftSwapRequests), false);
    	}
    	
    	public void approveOrRejectShiftSwapRequestOnSubSlider(String approveorreject,String comment)
    	{
    		
    		impactOfApprovingLink.click();
    		waitABit(2000);
    		if(approveorreject.equals("approve"))
    		{
    			approveShiftSwapRequestSlider.click();
    			waitABit(2000);
    			commentinsubslider.clear();
    			commentinsubslider.sendKeys(comment);
    			waitABit(2000);
    			yesButtonInSubSlider.click();
    			
    		}
    		
    		else if(approveorreject.equals("reject"))
    		{
    			rejectShiftSwapRequestSlider.click();
    			waitABit(2000);
    			commentinsubslider.clear();
    			commentinsubslider.sendKeys(comment);
    			waitABit(2000);
    			yesButtonInSubSlider.click();
    		}
    	}
    	
        public void verifyCOuntOfShiftSwapRequestOnTTDTile(String count)
    	{
    		String request = shiftSwapRequestCountTTDTile.getText();
    		String requestcount = request.split(" ")[0].trim();
    		Assert.assertEquals(requestcount, count);
    	}
}
