package com.adp.tlmbdd.pages.editors;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.pages.GenericPageObject;

public class PayClasses extends GenericPageObject {
	
	@FindBy(xpath = ".//*[@id='txtPayGroupID']")
	private WebElementFacade PayClassID;
	
	@FindBy(xpath = ".//*[@id='multDesc']")
	private WebElementFacade PayClassDesc;
	
	@FindBy(xpath = ".//*[@id='lkpPayCycle']")
	private WebElementFacade PayCycleID;		

	@FindBy(xpath = ".//*[@id='lkpTimeCalcProgram']")
	private WebElementFacade TimeCalcProg;
		
	@FindBy(xpath = ".//*[@id='lkpDailyCalcProgram']")
	private WebElementFacade DailyCalcProg;
	
	@FindBy(xpath = ".//*[@id='lkpTimeEntryPlan']")
	private WebElementFacade TimeEntryPlan;
	
	@FindBy(xpath = ".//*[@id='barButtons_btnSubmit']")
	private WebElementFacade PayClassSubmitButton;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElement mainiframe;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame1_iframe']")
	private WebElement subframe;
		
	
	public void createPayClass(String PayCycle, String TimeCalcProgr, String DailyCalcProgr, String TimeEntryPlanP)
	{
		PayClassID.sendKeys("");
		PayClassDesc.sendKeys("");
		PayCycleID.sendKeys("");
		TimeCalcProg.sendKeys("");
		DailyCalcProg.sendKeys("");
		TimeEntryPlan.sendKeys("");
		PayClassSubmitButton.click();
	}
	
	public void changeTimeEntryPlanInPayclass(String timeentryplan,String payclass)
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		WaitForAjax();
		getDriver().findElement(By.xpath("//*[@id='objZoomTable']//a[contains(text(),'"+payclass+"')]")).click();
		WaitForAjax();
		TimeEntryPlan.clear();
		TimeEntryPlan.sendKeys(timeentryplan);
		PayClassSubmitButton.click();
		WaitForAjax();
		switchToDefaultContent();
	}

}
