package com.adp.tlmbdd.pages.editors;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class EmployeeBar extends GenericPageObject{
	
	@FindBy(xpath = "//*[@id='employeeIdBarEmpListTooltipBtn']")
	private WebElementFacade usingTimeAndAttendanceBtn;
	
	@FindBy(xpath = "//*[@id='idBarSscrollGrid_search']")
	private WebElementFacade usingTimeAndAttendanceSearchBar;
	
	
	@FindBy(xpath = "//*[@id='idBarSscrollGridIdCol_Id_1']")
	private WebElementFacade searchedEmployeeSelecter;
	
	
	public void openSearchPopup() {
		usingTimeAndAttendanceBtn.waitUntilVisible();
		usingTimeAndAttendanceBtn.click();
	}

	public void enterTextAndSeach(String employeeName) {
		WaitForAjax();
		usingTimeAndAttendanceSearchBar.waitUntilVisible();
		usingTimeAndAttendanceSearchBar.typeAndEnter(employeeName);
	}

	public void selectFirstEmployee() {
		WaitForAjax();
		searchedEmployeeSelecter.waitUntilVisible();
		searchedEmployeeSelecter.click();
	}

}
