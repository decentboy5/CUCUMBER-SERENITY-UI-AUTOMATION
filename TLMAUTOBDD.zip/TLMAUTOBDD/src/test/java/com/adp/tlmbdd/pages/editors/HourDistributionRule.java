package com.adp.tlmbdd.pages.editors;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class HourDistributionRule extends GenericPageObject{

	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElement mainiframe;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame1_iframe']")
	private WebElement subframe;
	
	@FindBy(xpath = "//*[@id='divlkpTimecardAccum']")
	private WebElementFacade timeCardAccumulator;
	
	@FindBy(xpath = "//a[text()='ACROSSPRDTOT']")
	private WebElementFacade acrossPrdTot;
	
	@FindBy(xpath = "//*[@id='windowShade']")
	private WebElementFacade closeTimecardAccumulator;
	
	@FindBy(xpath = "//*[@id='btnAddNew']")
	private WebElementFacade addNewButton;
	
	@FindBy(xpath = "//*[@id='btnCopy']")
	private WebElementFacade copyButton;
	
	
	
	
	public void clickHourDistributionRule(String rule)
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		getDriver().findElement(By.xpath("//*[@id='objZoomTable']//*[contains(text(),'"+rule+"')]")).click();
		switchToDefaultContent();
	}
	
	public void verifyACROSSPRDTOTNotAvailable()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		timeCardAccumulator.click();
		Assert.assertTrue(checkElementVisible(acrossPrdTot));
		closeTimecardAccumulator.click();
		switchToDefaultContent();
		
	}
	
	public void addNewHourDistributionRule()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		addNewButton.click();
		switchToDefaultContent();
	}
	
	public void copyHourDistributionRule()
	{
		selectFrame(mainiframe);
		selectFrame(subframe);
		copyButton.click();
		switchToDefaultContent();
	}
	
	
	
	
	
}
