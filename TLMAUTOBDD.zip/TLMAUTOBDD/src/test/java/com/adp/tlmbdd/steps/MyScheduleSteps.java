package com.adp.tlmbdd.steps;

import org.openqa.selenium.By;

import com.adp.tlmbdd.pages.MySchedule;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;


public class MyScheduleSteps extends ScenarioSteps{

	MySchedule mySchedule;
	
	@Step
	public void createShiftSwapRequestOnSpecificDate(String date, String comment,String recipientname)
	{
		mySchedule.createShiftSwapRequestOnSpecificDate(date, comment, recipientname);
	}
	
	@Step
	public void acceptShiftSwapRequest(String date,String comment)
	{
		mySchedule.acceptShiftSwapRequest(date, comment);		
	}

	
}
