package com.adp.tlmbdd.steps;

import java.util.List;

import org.openqa.selenium.Keys;

import com.adp.tlmbdd.pages.TeamDashboard;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class TeamDashboardSteps extends ScenarioSteps {

	TeamDashboard teamDashboard;
	
	@Step
	public void clickbackbuttonshifttoreview() {
		teamDashboard.clickbackbuttonshifttoreview();
	}
	
	@Step
	public void clickOnMissedPunchesOnTTDTile()
	{
		teamDashboard.clickMissedPunchesOnTTDTile();
	}
	
	@Step
	public void verifySaveAndCancel()
	{
		teamDashboard.verifyDefaultSaveAndCancel();
	}
	
	@Step
	public void clickBackButton()
	{
		teamDashboard.clickBackButton();
	}
	
	@Step
	public void verifyEmployeeOrder()
	{
		teamDashboard.verifyEmployeeAlphabeticalOrder();
	}
	
	@Step
	public void resolveMissedPunchOfEmployee(String employeeName,String time,String date)
	{
		teamDashboard.resolveAMissedPunchOfEmployee(employeeName, time, date);
	}
	
	@Step
	public void clickSaveOnMissedPunchesScreen()
	{
		teamDashboard.clickSaveButtonOnMissedPunchesScreen();
	}
	@Step
	public void clickonshifttoreviewbutton() {
		// TODO Auto-generated method stub
		teamDashboard.clickonshifttoreviewbutton();
	}

	@Step
	public void clickonpreference() {
		teamDashboard.clickonpreference();
	}

	@Step
	public void verifyShiftToReviewtogglebutton(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.verifyShiftToReviewtogglebutton(arg1);
	}
	@Step
	public void shifttoreview(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.shifttoreview(arg1);
	}
	@Step
	public void PrefenceSavebutton() {
		// TODO Auto-generated method stub
		teamDashboard.preferencesavebutton();
	}
	
	@Step
     public void WorkedLongerThanExpected(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.WorkedLongerThanExpected(arg1);
		
	}
    @Step
	public void WorkedLongerThanExpectedtext(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.WorkedLongerThanExpectedtext(arg1);
	}

	@Step
	public void verifyEmployeeAndMissedPunchCount(String employeecount,String missedpunchescount)
	{
		teamDashboard.verifyDataOnMissedPunchesTTDTile(employeecount, missedpunchescount);
	}

	@Step
	public void WorkedEarlierThanExpected(String arg1) {
		teamDashboard.WorkedEarlierThanExpected(arg1);
	}
	
	@Step
	public void verifySaveAndCancelEnabledOrNotAndBackDisabled()
	{
		teamDashboard.verifySaveAndCancelEnabledOrNot();
	}
	
	@Step
	public void verifyEmployeeAndMissedPunchCountOnMissedPunchesPage(String employeecount,String missedpunchescount)
	{
		teamDashboard.verifyDataOnMissedPunchesPage(employeecount, missedpunchescount);
	}
	
	@Step
	public void verifyTimecardApprovalandcountinThingsToDoTile(String approvalLink, String approvalCount) {
		teamDashboard.verifyTimecardApprovalandcountinThingsToDoTile(approvalLink,approvalCount);
	}
	
	@Step
	public void clickTimecardApprovalsOnTTDTile() {
		teamDashboard.clickTimecardApprovalsOnTTDTile();
	}
	
	@Step
	public void verifyStatusofButton(String arg1, String arg2) {
		teamDashboard.verifyStatusofButton(arg1, arg2);
	}
	
	@Step
	public void verifyDataAndObjectsOnTASlider(String arg1, String arg2, String arg3,String arg4) {
		teamDashboard.verifyDataAndObjectsOnTASlider(arg1,arg2,arg3,arg4);
	}
	
	@Step
	public void verifyTextOrMessageOnPage(String arg1) {
		teamDashboard.verifyMessageOnScreen(arg1);
	}
	
	@Step
	public void chooseTimecardForApproval(String arg1, String arg2, String arg3) {
		teamDashboard.selectTimeCardinTASlider(arg1, arg2, arg3);
	}
	
	@Step
	public void clickButtonOnTASlider(String arg1) {
		teamDashboard.clickButtonOnTASlider(arg1);		
	}

	@Step
	public void verifyMessageOnScreen(String arg1) {
		teamDashboard.verifyMessageOnScreen(arg1);
	}

	@Step
	public void VerifyWorkerLongerThanExpectedexistence(String arg1) {
		teamDashboard.VerifyWorkerLongerThanExpectedexistence(arg1);
	}

	@Step
	public void verifyshifttoreviewtile(String arg1) {
		teamDashboard.verifyshifttoreviewtile(arg1);
	}
	
	@Step
	public void verifyTimeCardExistanceinTASlider(String arg1, String arg2, String arg3) {
		teamDashboard.verifyTimeCardExistanceinTASlider(arg1,arg2,arg3);
	}
	@Step
	public void WorkedLaterThanExpected(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.WorkedlaterThanExpected(arg1);
	}
	@Step
	public void WorkedLaterThanExpectedtext(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.WorkedlaterThanExpectedtext(arg1);
	}
	@Step
	public void WorkedLongerThanExpectedOutsideofShift(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.WorkedlongerThanExpectedoutsideofshift(arg1);
	}
	@Step
	public void WorkedLongerThanExpectedOutsideofShifttext(String arg1) {
		teamDashboard.WorkedlongerThanExpectedoutsideofshifttext(arg1);
	}
	
	@Step
	public void verifyEmployeeContactDetails(String employeename, List<String> contactlist) {
		teamDashboard.verifyEmployeeContactDetails(employeename,contactlist);
	}
	
	@Step
	public void verifyClickOnTimecardOpensLegacyTimecard() {
		teamDashboard.verifyClickOnTimecardOpensLegacyTimecard();
	}
	
	@Step
	public void clickSaveButtonOnMissedPunchesPage() {
		teamDashboard.clickSaveButtonOnMissedPunchesPage();
	}
	
	@Step
	public void enterTimePairforEmployee(String arg1, String arg2, String arg3,String arg4) {
		teamDashboard.selectEmployee(arg3);
		teamDashboard.addTimePair(arg1, arg2,arg4);
	}
	@Step
	public void clickButtonOnIndividualTimcardPage(String arg1) {
		teamDashboard.clickButtonOnIndividualTimcardPage(arg1);
	}
	@Step
	public void clickRequestTimeOffButtonOnPTOPage() {
		teamDashboard.clickOnRequestTimeOffButton();
	}
	@Step
	public void clickButtonOnPopup(String buttonName) {
		teamDashboard.clickButtonOnPopup(buttonName);
	}
	@Step
	public void verifyTimecardDataonReadytoApproveSection(String timecardCheckbox, String timePeriod, String empName,
			String empApproval, String totals, String regular, String OT,String totalsColor) {
		teamDashboard.verifyTimeCardDatainTASlider(timecardCheckbox,timePeriod,empName,empApproval,totals,regular,OT,totalsColor);
	}
	@Step
	public void employeeEnterTimePair(String timePunches, String timecardDate) {
		teamDashboard.employeeEntersTimePair(timePunches, timecardDate);
	}
	@Step
	public void openMessageCenterNotificationsTab() {
		teamDashboard.openNotificationsTab();
	}
	@Step
	public void verifyMCNotification(String notificationType, String subject, String status, String message) {
		teamDashboard.verifyNotification(notificationType, subject, status, message);
	}
	@Step
	public void performActionOnNotification(String notificationType, String subject, String status, String message,String action) {
		teamDashboard.performActionOnNotification(notificationType, subject, status, message,action);
	}
	@Step
	public void verifyMessageDetails(String subject, String message) {
		teamDashboard.verifyNotificationMessageDetails(subject,message);
		
	}
	@Step
	public void navigateBackToMessageCenter() {
		teamDashboard.navigateBackToMessageCenter();
	}
	@Step
	public void verifyColorOfNote(String employeename,String date,String color)
	{
		teamDashboard.verifyColorOfNote(employeename, date, color);
	}
	
	@Step
	public void clickButtonOnNotesPage(String buttonName) {
		teamDashboard.clickButtonOnNotesPage(buttonName);
	}
	@Step	
	public void clickNoteIcon(String employeename,String date)
	{
		teamDashboard.clickASpecificNote(employeename, date);
	}
	@Step	
	public void enterSupervisorNote(String note)
	{
		teamDashboard.enterSupervisorNote(note);
	}
	@Step	
	public void clickEmployeeViewableButton(String buttonnname)
	{
		teamDashboard.clickEmployeeViewableButton(buttonnname);
	}
	@Step	
	public void verifyEmployeeNoteOnNotesPage(String notetype,String employeename,String note)
	{
		teamDashboard.verifyEmployeeNoteOnNotesPage(notetype, employeename, note);
	}
	@Step	
	public void clickOnViewTimecardLink(String timePeriod, String empName) {
		teamDashboard.clickOnViewTimecardLink(timePeriod,empName);
		
	}
	@Step
	public void clickOnRequestTimeOffButton() {
		teamDashboard.clickOnRequestTimeOffButton();
	}
	@Step
	public void enterTimeOffDetailsTOSlider(String startDate, String endDate, String policy, String amount,
			String startTime, String comments, String respondBy) {
		teamDashboard.enterTimeOffRequestDetails(startDate, endDate, policy, amount, startTime, comments, respondBy);
	}
	@Step
	public void clickOnSubmitTimeOffRequest() {
		teamDashboard.submitTimeOffRequest();
	}
	
	@Step	
	public void verifyScheduleCountOnShiftsTOReviewTile(String scheduleCount, String empname, String date)
	{
		teamDashboard.verifyScheduleCountOnShiftsTOReviewTile(scheduleCount, empname, date);
	}

	@Step	
	public void verifyRuleOnShiftsTOReviewTile(String rulename,String flag,String empname,String date)
	{
		teamDashboard.verifyRuleOnShiftsTOReviewTile(rulename, flag, empname, date);
	}
	
	@Step
	public void clickShiftsToReviewOnTTDTile()
	{
		teamDashboard.clickShiftsToReviewOnTTDTile();
	}
	
	@Step
	public void dismissShiftOfSpecificEmployee(String empname,String date)
	{
		teamDashboard.dismissShiftOfSpecificEmployee(empname, date);
	}
	
	@Step
	public void verifyCountOnShiftsToReviewTTDTile(String employeecount,String shiftcount)
	{
		teamDashboard.verifyCountOnShiftsToReviewTTDTile(employeecount, shiftcount);
	}

	@Step
	public void verifyDataOnShiftsToReviewSlider(String employeecount,String shiftcount)
	{
		teamDashboard.verifyDataOnShiftsToReviewSlider(employeecount, shiftcount);
	}
	
	@Step
	public void verifyshifttoreviewtile(String shifttoreviewtile,String verifyEmployeeCount, String verifyshiftCount ) {
		// TODO Auto-generated method stub
		teamDashboard.verifyshifttoreviewtile(shifttoreviewtile, verifyEmployeeCount,verifyshiftCount);
	}
	
	@Step
	public void WorkedLongerThanExpectedtogglebutton(String arg1) {
		// TODO Auto-generated method stub
		teamDashboard.WorkedLongerThanExpected(arg1);
	}

	@Step
	public void clickTimeOffRequestsOnTTDTile()
	{
		teamDashboard.clickTimeOffRequestOnTTDTile();
	} 
		@Step
			public void navigateToNextWeekViewTORTile() {
				teamDashboard.navigateToNextWeekViewTORTile();
			}

			@Step
			public void takeActionOnRequestLOR(String action, String empName, String reqPeriod, String hrs) {
				teamDashboard.takeActionOnRequestLOR(action,empName,reqPeriod,hrs);
			} 
			@Step
			public void clickBackButtonLORSlider() {
				teamDashboard.clickBackButtonLORSlider();
			}
			
			@Step
			public void processActionOnLOR(String process) {
				teamDashboard.processActionOnLOR(process);
			}	

			@Step
			public void verifyEmployeesonTimeOffTile(String empList) {
				teamDashboard.verifyEmployeeListOnTimeOffTile(empList);
			} 
		 
		@Step
			public void verifyContentsTimeOffTile(String title, String pendingCount, String approvedCount) {
				teamDashboard.verifyContentsTimeOffTile(title,pendingCount,approvedCount);
			}

			@Step
			public void verifyDataOnTimeOffRequestTTDTile(String empCount, String reqCount) {
				teamDashboard.verifyDataOnTimeOffRequestTTDTile(empCount,reqCount);
			}
			@Step
			public void verifyTimeOffRequestsTTDtile(String status) {
				teamDashboard.verifyTimeOffRequestsTTDtile(status);
			} 
			@Step
			public void verifyRequestStatusTimeOffTile(String empName, String requestDate, String requestStatus) {
				teamDashboard.verifyRequestStatusTimeOffTile(empName,requestDate,requestStatus);
			}  	 

			@Step
			public void clickShiftSwapRequestsOnTTDTile()
			{
				teamDashboard.clickShiftSwapRequestsOnTTDTile();
				
			}		

			@Step
			public void selectEmployeePTOcalendar(String empName) {
				teamDashboard.SelectEmployeePTOCalendar(empName);
			}

			@Step
			public void verifyCOuntOfShiftSwapRequestOnTTDTile(String count)
			{
				teamDashboard.verifyCOuntOfShiftSwapRequestOnTTDTile(count);
			}
			
			@Step
			public void verifyCOuntOfShiftSwapRequestOnSlider(String count)
			{
				teamDashboard.verifyCOuntOfShiftSwapRequestOnSlider(count);
			}
			@Step
			public void approveOrRejectShiftSwapRequest(String approveorreject,String comment)
			{
				teamDashboard.approveOrRejectShiftSwapRequest(approveorreject, comment);
			}
			@Step
			public void clickBackOnShiftSwapSlider()
			{
				teamDashboard.clickBackOnShiftSwapSlider();
			}
			@Step
			public void verifyShiftSwapTileIsNotDisplayed()
			{
				teamDashboard.verifyShiftSwapTileIsNotDisplayed();
			}
			@Step
			public void approveOrRejectShiftSwapRequestOnSubSlider(String approveorreject,String comment)
			{
				teamDashboard.approveOrRejectShiftSwapRequest(approveorreject, comment);
			}
			@Step
			public void verifyWeekDatesonTimeOffTile(String weekStartDay) {
				teamDashboard.verifyTimeOffTileHeaders(weekStartDay);
			}			
	
}
