package com.adp.tlmbdd.stepDefinition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.adp.tlmbdd.common.SQLQueryConstant;
import com.adp.tlmbdd.common.SQLScriptRunner;
import com.adp.tlmbdd.steps.TeamDashboardSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class TeamDashboardStepDefinition {

    public static String Client = "ATLMFTL1";
    public static String SupervisorID = "Super, emp";
    public static String FirstEmployee = "First, emp";
    public static String FirstEmployeeUserID = "";
    public static String FirstEmployeePassword = "adpadp15";
    public static String SecondEmployee = "Second, emp";
    public static String SecondEmployeeUserID = "";
    public static String SecondEmployeePassoword = "adpadp15";
    public static String ThirdEmployee = "Third, emp";
    public static String ThirdEmployeeUserID = "";
    public static String ThirdEmployeePassword = "adpadp15";
    public static String FirstEmployeeID = "IDE2003300";
    public static String SecondEmployeeID = "IDE2003302";
    public static String ThirdEmployeeID = "IDE2003303";
    public static String FirstEmployeeBadge = "01415";
    public static String SecondEmployeeBadge = "013135";
    public static String ThirdEmployeeBadge= "041516";
    public static String DCTAddress = "ETH1";



	@Steps
	TeamDashboardSteps supDashboardSteps;

	@Then("^I Verify Timecard Approvals Link \"([^\"]*)\" and Count \"([^\"]*)\" in Things To Do Tile$")
	public void i_Verify_Timecard_Approvals_Link_and_Count_in_Things_To_Do_Tile(String arg1, String arg2)
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String approvalLink = arg1;
		String approvalCount = arg2;
		supDashboardSteps.verifyTimecardApprovalandcountinThingsToDoTile(approvalLink, approvalCount);
		// throw new PendingException();
	}
	@When("^I Click on Timecard Approval Link in Things To Do Tile$")
	public void i_Click_on_Timecard_Approval_Link_in_Things_To_Do_Tile() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		supDashboardSteps.clickTimecardApprovalsOnTTDTile();
		//throw new PendingException();
	}
	@Then("^I Verify Status of the \"([^\"]*)\" is \"([^\"]*)\"$")
	public void i_Verify_Status_of_the_is(String arg1, String arg2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		supDashboardSteps.verifyStatusofButton(arg1,arg2);
		//throw new PendingException();
	}

	@Then("^I Verify Static Data and Objects on Timecard Approvals Slider \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Static_Data_and_Objects_on_Timecard_Approvals_Slider(String arg1, String arg2, String arg3,String arg4) throws Throwable {
		supDashboardSteps.verifyDataAndObjectsOnTASlider(arg1,arg2,arg3,arg4);
	}

	@Then("^I Verify Message \"([^\"]*)\" on Screen$")
	public void i_Verify_Message_on_Screen(String arg1) throws Throwable {

		supDashboardSteps.verifyTextOrMessageOnPage(arg1);
	}
	@When("^I Choose Timecard \"([^\"]*)\" of \"([^\"]*)\" for \"([^\"]*)\" to Approve$")
	public void i_Choose_Timecard_of_for_to_Approve(String arg1, String arg2, String arg3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		supDashboardSteps.chooseTimecardForApproval(arg1,arg2,arg3);
	}

	@When("^I click on Shift to review on TTD tile$")
	public void i_click_on_Shift_to_review_on_TTD_tile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.clickonshifttoreviewbutton();
	    //throw new PendingException();
	}
	
	@When("^I click on the icon in Things to do section$")
	public void i_click_on_the_icon_in_section() throws Throwable {
	    //Write code here that turns the phrase above into concrete actions
		supDashboardSteps.clickonpreference();
	}
	@Then("^I click on Back button$")
	public void i_click_on_Back_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.clickbackbuttonshifttoreview();
	}
	@Then("^I Verify shift to review tile \"([^\"]*)\"$")
	public void i_Verify_shift_to_review_tile(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.verifyshifttoreviewtile(arg1);
	}
	@Then("^I verify Shift to review toggle is on or OFF with \"([^\"]*)\"$")
	public void i_verify_Shift_to_review_toggle_is_on_or_OFF_with(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.verifyShiftToReviewtogglebutton(arg1);
	}
	@When("^I click on shift to review toggle button\"([^\"]*)\"$")
	public void i_click_on_shift_to_review_toggle_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.shifttoreview(arg1);
	}
	
	@When("^I click on Save button$")
	public void i_click_on_Save_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.PrefenceSavebutton();
	}

	@When("^I click on Worked Longer Than Expected toggle button\"([^\"]*)\"$")
	public void i_click_on_Worked_Longer_Than_Expected_toggle_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.WorkedLongerThanExpected(arg1);
	}
	
	@Given("^I enter input in Worked Longer Than Expected filled with\"([^\"]*)\"$")
	public void i_enter_input_in_Worked_Longer_Than_Expected_filled_with(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.WorkedLongerThanExpectedtext(arg1);
	}
	@When("^I click on Worked earlier Than Expected toggle button\"ON$")
	public void i_click_on_Worked_Earlier_Than_Expected_toggle_button(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.WorkedEarlierThanExpected(arg1);
	}

    @When("^I Click on Button on Timecard Approvals Slider \"([^\"]*)\"$")
	public void i_Click_on_Button_on_Timecard_Approvals_Slider(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		supDashboardSteps.clickButtonOnTASlider(arg1);
	}
    @Then("^I verify the sucess message in preference slider with \"([^\"]*)\"$")
    public void i_verify_the_sucess_message_in_preference_slider_with(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	supDashboardSteps.verifyMessageOnScreen(arg1);
    }
    
    @Then("^I verify the existance of \"([^\"]*)\"$")
    public void i_verify_the_existance_of(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	supDashboardSteps.VerifyWorkerLongerThanExpectedexistence(arg1);
    }
	@Then("^I Verify Timecard existance on Timecard Approvals Slider \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Timecard_existance_on_Timecard_Approvals_Slider(String arg1, String arg2, String arg3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		supDashboardSteps.verifyTimeCardExistanceinTASlider(arg1,arg2,arg3);
	}

	@When("^I click on Worked Later Than Expected toggle button\"OFF$")
	public void i_click_on_Worked_Later_Than_Expected_toggle_button_OFF(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   supDashboardSteps.WorkedLaterThanExpected(arg1);
	}
	@Given("^I enter input in Worked Later Than Expected filled with\"([^\"]*)\"$")
	public void i_enter_input_in_Worked_Later_Than_Expected_filled_with(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.WorkedLaterThanExpectedtext(arg1);
	    
	}
	@When("^I click on Worked Later Than Expected Outside of shift toggle button\"OFF$")
	public void i_click_on_Worked_Longer_Than_Expected_Outsideofshift_toggle_button_OFF(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   supDashboardSteps.WorkedLongerThanExpectedOutsideofShift(arg1);
	}
	@Given("^I enter input in Worked Later Than Expected Outside of Shift  filled with\"([^\"]*)\"$")
	public void i_enter_input_in_Worked_Longer_Than_Expected_outsideofshift_filled_with(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		supDashboardSteps.WorkedLongerThanExpectedOutsideofShifttext(arg1);
	}
	@Then("^I Verify Timecard Data in Ready to Approve section\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Timecard_Data_in_Ready_to_Approve_section(String timecardCheckbox, String timePeriod, String empName, String empApproval, String totals,String regular, String OT,String totalsColor) throws Throwable {
		supDashboardSteps.verifyTimecardDataonReadytoApproveSection(timecardCheckbox,timePeriod,empName,empApproval,totals,regular,OT,totalsColor);
	}	

	public static LocalDate getRequiredDate(String dateformat)
	{
		int intendeddate;
		LocalDate dateUsed;

		LocalDate localDate = LocalDate.now();
		System.out.println(localDate);

		//set date and in punch values
		if(dateformat.contains("MINUS"))
		{
			intendeddate = Integer.valueOf(dateformat.split("MINUS")[1].trim());
			dateUsed = localDate.minusDays(intendeddate);
		}
		else if(dateformat.contains("PLUS"))
		{
			intendeddate = Integer.valueOf(dateformat.split("PLUS")[1].trim());
			dateUsed = localDate.plusDays(intendeddate);
		}
		else
		{
			dateUsed = localDate;
		}

		return dateUsed;
	}
	
	public static String getEmployeeName(String name)
	{
		String employeename = "";
		if(name.equals("first"))
		{
			employeename = FirstEmployee;
		}
		else if(name.equals("second"))
		{
			employeename = SecondEmployee;
		}
		else if(name.equals("third"))
		{
			employeename = ThirdEmployee;
		}
		return employeename;
	}



	@When("^I clear the timecard for \"([^\"]*)\" employee$")
	public void i_clear_the_timecard_for_employee(String employeenumber) throws Throwable {
		Map<String, Object> params = new HashMap<>();
		if(employeenumber.equals("first"))
		{
			params.put("EMPLOYEEID", FirstEmployeeID);

		}
		else if(employeenumber.equals("second"))
		{
			params.put("EMPLOYEEID", SecondEmployeeID);
		}
		else if(employeenumber.equals("third"))
		{
			params.put("EMPLOYEEID", ThirdEmployeeID);
		}

		//SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMECARDTAB_CLEAR, params);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPAIRTAB_CLEAR, params);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.PAYROLLTAB_CLEAR, params);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPAIREXCEPTIONTAB_CLEAR, params);
		//SQLScriptRunner.executeUpdate(SQLQueryConstant.TIMEPUNCHTAB_CLEAR, params);

	}

	@When("^I enter \"([^\"]*)\" punch for \"([^\"]*)\" employee as \"([^\"]*)\" on \"([^\"]*)\"$")
	public void i_enter_punch_for_employee_as(String punchtype, String employeenumber, String punchtime,String dateidentifier) throws Throwable {
		Map<String, Object> params = new HashMap<>();
		if(employeenumber.equals("first"))
		{
			params.put("EMPLOYEEBADGE", FirstEmployeeBadge);

		}
		else if(employeenumber.equals("second"))
		{
			params.put("EMPLOYEEBADGE", SecondEmployeeBadge);
		}
		else if(employeenumber.equals("third"))
		{
			params.put("EMPLOYEEBADGE", ThirdEmployeeBadge);
		}

		String inDateTime = getRequiredDate(dateidentifier).toString();
		inDateTime = inDateTime+" "+punchtime;
		System.out.println("FinalDateTime :" +inDateTime);

		params.put("TIMEPUNCHCODE", punchtype);
		params.put("INDATETIME", inDateTime);
		params.put("DCTADDRESS", DCTAddress);
		System.out.println(SQLQueryConstant.INSERTTIMEPUNCH);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.INSERTTIMEPUNCH, params);

	}

	@When("^I click on missed punches on TTD tile$")
	public void i_click_on_missed_punches_on_TTD_tile() throws Throwable {
		supDashboardSteps.clickOnMissedPunchesOnTTDTile();
	}

	@Then("^I verify save button is disbled and cancel button is disabled by default$")
	public void i_verify_save_button_is_disbled_and_cancel_button_is_enabled_by_default() throws Throwable {
		supDashboardSteps.verifySaveAndCancel();
	}

	@Then("^I navigate back to manager dashboard$")
	public void i_navigate_back_to_manager_dashboard() throws Throwable {
		supDashboardSteps.clickBackButton();
	}

	@Then("^I verify all the employees are in alphabetical order or not$")
	public void i_verify_all_the_employees_are_in_alphabetical_order_or_not() throws Throwable {
		supDashboardSteps.verifyEmployeeOrder();
	}

	@Then("^I verify employee count as \"([^\"]*)\" and missed punches count as \"([^\"]*)\" on TTD Tile$")
	public void i_verify_employee_count_as_and_missed_punches_count_as_on_TTD_Tile(String employeecount, String missedpunchescount) throws Throwable {
		supDashboardSteps.verifyEmployeeAndMissedPunchCount(employeecount, missedpunchescount);
	}

	@When("^I resolve missed punch of \"([^\"]*)\" employee with time \"([^\"]*)\" for date \"([^\"]*)\"$")
	public void i_resolve_missed_punch_of_employee_with_time_for_date(String name, String time, String date) throws Throwable {

		String employeename = "";
		String requireddate;
		if(name.equals("first"))
		{
			employeename = FirstEmployee;
		}
		else if(name.equals("second"))
		{
			employeename = SecondEmployee;
		}
		else if(name.equals("third"))
		{
			employeename = ThirdEmployee;
		}

		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = getRequiredDate(date).format(formatters).toString();

		supDashboardSteps.resolveMissedPunchOfEmployee(employeename, time, requireddate);


	}

	@When("^I Enter value \"([^\"]*)\" for missed punch of employee \"([^\"]*)\" for date \"([^\"]*)\"$")
	public void i_enter_value_for_missed_punch_of_employee_for_date(String punchValue, String empName, String date) throws Throwable {
		supDashboardSteps.resolveMissedPunchOfEmployee(empName, punchValue, date);		
	}
	@Then("^I verify save button and cancel buttons are enabled and back button is disabled$")
	public void i_verify_save_button_and_cancel_buttons_are_enabled_and_back_button_is_disabled() throws Throwable {
		supDashboardSteps.verifySaveAndCancelEnabledOrNotAndBackDisabled();
	}

	@Then("^I verify employee count as \"([^\"]*)\" and missed punches count as \"([^\"]*)\" on missed punches page$")
	public void i_verify_employee_count_as_and_missed_punches_count_as_on_missed_punches_page(String employeecount, String missedpunchescount) throws Throwable {
		supDashboardSteps.verifyEmployeeAndMissedPunchCountOnMissedPunchesPage(employeecount, missedpunchescount);
	}

	@Then("^I verify contact details of \"([^\"]*)\" employee$")
	public void i_verify_contact_details_of_employee(String employeenumber, List<String> contactlist) throws Throwable {

		String employeename = "";
		if(employeenumber.equals("first"))
		{
			employeename = FirstEmployee;
		}
		else if(employeenumber.equals("second"))
		{
			employeename = SecondEmployee;
		}
		else if(employeenumber.equals("third"))
		{
			employeename = ThirdEmployee;
		}

		supDashboardSteps.verifyEmployeeContactDetails(employeename, contactlist);
	}
	@Then("^I verify cliking on view timecard takes to legacy timecard$")
	public void i_verify_cliking_on_view_timecard_takes_to_legacy_timecard() throws Throwable {
		supDashboardSteps.verifyClickOnTimecardOpensLegacyTimecard();
	}
	@When("^I click on save button on missed punches page$")
	public void i_click_on_save_button_on_missed_punches_page() throws Throwable {
	   supDashboardSteps.clickSaveButtonOnMissedPunchesPage();
	}
	
	@When("^I Enter time pair \"([^\"]*)\" in Timecard \"([^\"]*)\" for Employee \"([^\"]*)\" and Approve \"([^\"]*)\"$")
	public void i_Enter_time_pair_in_Timecard_for_Employee_and_Approve(String arg1, String arg2, String arg3, String arg4) throws Throwable {
		supDashboardSteps.enterTimePairforEmployee(arg1,arg2,arg3,arg4);
	}
	@When("^I Enter time pair \"([^\"]*)\" in Timecard \"([^\"]*)\"$")
	public void i_Enter_time_pair_in_Timecard(String arg1, String arg2) throws Throwable {
		supDashboardSteps.employeeEnterTimePair(arg1,arg2);
	}
	@When("^I Click on Button on Individual Timecard Page \"([^\"]*)\"$")
	public void i_Click_on_Button_on_Individual_Timecard_Page(String arg1) throws Throwable {
		supDashboardSteps.clickButtonOnIndividualTimcardPage(arg1);
	}
	@When("^I Click Request Time Off button on PTO Page$")
	public void i_Click_Request_Time_Off_button_on_PTO_Page() throws Throwable {
		supDashboardSteps.clickRequestTimeOffButtonOnPTOPage();
	}
	@When("^I Click Button \"([^\"]*)\" on Popup$")
	public void i_Click_Button_on_Popup(String buttonName) throws Throwable {
		supDashboardSteps.clickButtonOnPopup(buttonName);
	}
	@When("^I Open Message Center Notifications Tab Page$")
	public void i_Open_MessageCenter_NotificationsTab() throws Throwable {
		supDashboardSteps.openMessageCenterNotificationsTab();
	}	
	@Then("^I Verify Notification in Notifications Tab Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Notification_MessageCenter_NotificationsTab(String notificationType, String subject, String status, String message) throws Throwable {
		supDashboardSteps.verifyMCNotification(notificationType,subject,status,message);
	}
	@When("^I Perform Action on Notification \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Perform_Action_on_Notification(String notificationType, String subject, String status, String message,String action) throws Throwable {
		supDashboardSteps.performActionOnNotification(notificationType,subject,status,message,action);
	}
	@Then("^I Verify Message Details on Message Review Page \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_MessageDetails_ReviewPage(String subject,String message) throws Throwable {
		supDashboardSteps.verifyMessageDetails(subject,message);
	}
	@When("^I Navigate Back to Message Center from Message Review Page$")
	public void i_Navigate_Back_MessageCenter() throws Throwable {
		supDashboardSteps.navigateBackToMessageCenter();
	}	
	
	@Then("^I verify notes icon for \"([^\"]*)\" employee for date \"([^\"]*)\" as \"([^\"]*)\"$")
	public void i_verify_notes_icon_for_employee_for_date_as(String employeenumber, String dateformat, String color) throws Throwable {
	   String employeename = getEmployeeName(employeenumber);
	   DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
	   String requireddate = getRequiredDate(dateformat).format(formatters).toString();
	   supDashboardSteps.verifyColorOfNote(employeename, requireddate, color);

	}
	
	@Then("^I click on notes icon for \"([^\"]*)\" employee for date \"([^\"]*)\"$")
	public void i_click_on_notes_icon_for_employee_for_date(String employeenumber, String dateformat) throws Throwable {
	   String employeename = getEmployeeName(employeenumber);
	   DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
	   String requireddate = getRequiredDate(dateformat).format(formatters).toString();
	   supDashboardSteps.clickNoteIcon(employeename, requireddate);
	}

	@Then("^I click on \"([^\"]*)\" button on notes page$")
	public void i_click_on_button_on_notes_page(String buttonname) throws Throwable {
	   supDashboardSteps.clickButtonOnNotesPage(buttonname);
	}
	
	@Then("^I verify \"([^\"]*)\" level note of \"([^\"]*)\" employee as \"([^\"]*)\"$")
	public void i_verify_data_of_employee_note_as(String notetype,String employeenumber, String note) throws Throwable {
		String employeename = getEmployeeName(employeenumber);
		supDashboardSteps.verifyEmployeeNoteOnNotesPage(notetype, employeename, note);
	}
	
	@Then("^I enter note as \"([^\"]*)\"$")
	public void i_enter_note_as(String supnote) throws Throwable {
		supDashboardSteps.enterSupervisorNote(supnote);
	}

	@Then("^I toggle \"([^\"]*)\" the employee viewable button$")
	public void i_toggle_the_employee_viewable_button(String button) throws Throwable {
	    
		supDashboardSteps.clickEmployeeViewableButton(button);
	}
	
	@When("^I click on shifts to review on TTD tile$")
	public void i_click_on_shifts_to_review_on_TTD_tile() throws Throwable {
		
		supDashboardSteps.clickShiftsToReviewOnTTDTile();
	}

	@Then("^I verify schedule count as \"([^\"]*)\" for \"([^\"]*)\" employee on date \"([^\"]*)\"$")
	public void i_verify_schedule_count_as_for_employee_on_date(String schedulecount, String employeenumber, String dateformat) throws Throwable {

		String employeename = getEmployeeName(employeenumber);
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		String requireddate = getRequiredDate(dateformat).format(formatters).toString();
		supDashboardSteps.verifyScheduleCountOnShiftsTOReviewTile(schedulecount, employeename, requireddate);
		
	}

	@Then("^I verify rule \"([^\"]*)\" existance is \"([^\"]*)\" for \"([^\"]*)\" employee on date \"([^\"]*)\"$")
	public void i_verify_rule_existance_is_for_employee_on_date(String rulename, String flag, String employeenumber, String dateformat) throws Throwable {
		String employeename = getEmployeeName(employeenumber);
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		String requireddate = getRequiredDate(dateformat).format(formatters).toString();
		supDashboardSteps.verifyRuleOnShiftsTOReviewTile(rulename, flag, employeename, requireddate);
	}
	
	@Then("^I verify employee count as \"([^\"]*)\" and shifts count as \"([^\"]*)\" on TTD Tile$")
	public void i_verify_employee_count_as_and_shifts_count_as_on_TTD_Tile(String employeecount, String shiftcount) throws Throwable {
	   
		supDashboardSteps.verifyCountOnShiftsToReviewTTDTile(employeecount, shiftcount);
	}
	
	@Then("^I verify employee count as \"([^\"]*)\" and shifts count as \"([^\"]*)\" on shifts to review slider$")
	public void i_verify_employee_count_as_and_shifts_count_as_on_shifts_to_review_slider(String employeecount, String shiftcount) throws Throwable {
	   
		supDashboardSteps.verifyDataOnShiftsToReviewSlider(employeecount, shiftcount);
	}
	
	@When("^I dismiss the shift of \"([^\"]*)\" employee on date \"([^\"]*)\"$")
	public void i_dismiss_the_shift_of_employee_on_date(String employeenumber, String dateformat) throws Throwable {
		String employeename = getEmployeeName(employeenumber);
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		String requireddate = getRequiredDate(dateformat).format(formatters).toString();
		supDashboardSteps.dismissShiftOfSpecificEmployee(employeename, requireddate);
	}



	@When("^I Click on View Timecard link in Ready to Approve section \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_click_on_View_Timecard_Link_in_ReadyToApprove_section(String timePeriod,String empName) throws Throwable {
	    
		supDashboardSteps.clickOnViewTimecardLink(timePeriod,empName);
	}
//Time Off Requests stuff	
	@When("^I Select \"([^\"]*)\" employee on PTO calendar$")
	public void i_select_employee_on_PTO_calendar(String empName) throws Throwable {
		supDashboardSteps.selectEmployeePTOcalendar(empName);
	}
	
	@When("^I Click on Request Time Off Button$")
	public void i_click_on_Request_Timeoff_Button() throws Throwable {
		supDashboardSteps.clickOnRequestTimeOffButton();
	}	
	@When("^I Enter Time Off Details on Request Time Off Slider \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Time_Off_Details_on_Request_TimeOffSlider(String startDate,String endDate,String policy,String amount,String startTime,String comments,String respondBy) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String stDate = getRequiredDate(startDate).format(formatters).toString();
		String edDate = getRequiredDate(endDate).format(formatters).toString();
		supDashboardSteps.enterTimeOffDetailsTOSlider(stDate,edDate,policy,amount,startTime,comments,respondBy);
	}
	@When("^I Click on Submit Button on Request Time Off Slider$")
	public void i_click_on_Submit_Button_RequestTimeOff_Slider() throws Throwable {
		supDashboardSteps.clickOnSubmitTimeOffRequest();
	}
//	@When("^I Click on Submit Button on Request Time Off Slider$")
//	public void i_click_on_Submit_Button_RequestTimeOff_Slider() throws Throwable {
//		supDashboardSteps.clickOnSubmitTimeOffRequest();
//	}
	@Then("^I Verify shift to review tile \"([^\"]*)\" with employee count as \"([^\"]*)\" and shift count as \"([^\"]*)\"$")
	public void i_Verify_shift_to_review_tile_with_employee_count_as_and_shift_count_as(String shifttoreviewtile,String verifyEmployeeCount, String verifyshiftCount) throws Throwable {
		supDashboardSteps.verifyshifttoreviewtile(shifttoreviewtile,verifyEmployeeCount,verifyshiftCount);
	}

	@Then("^I verify contact details of \"([^\"]*)\"$")
	public void i_verify_contact_details(String employeename, List<String> contactlist) throws Throwable {
	supDashboardSteps.verifyEmployeeContactDetails(employeename, contactlist);
	}
	
    @Then("^I verify \"([^\"]*)\" shift swap requests are on TTD tile$")
    public void i_verify_shift_swap_requests_are_on_TTD_tile(String count) throws Throwable {
        supDashboardSteps.verifyCOuntOfShiftSwapRequestOnTTDTile(count);
    }

    @When("^I click on shift swap requests on TTD Tile$")
    public void i_click_on_shift_swap_requests_on_TTD_Tile() throws Throwable {
        supDashboardSteps.clickShiftSwapRequestsOnTTDTile();
    }
    
    @Then("^I verify \"([^\"]*)\" pending shift swap requests are on shift swap request slider$")
    public void i_verify_pending_shift_swap_requests_are_on_shift_swap_request_slider(String count) throws Throwable {
        supDashboardSteps.verifyCOuntOfShiftSwapRequestOnSlider(count);
    }
    
    @When("^I \"([^\"]*)\" shift swap request with comment \"([^\"]*)\"$")
    public void i_shift_swap_request_with_comment(String approveorreject, String comment) throws Throwable {
        supDashboardSteps.approveOrRejectShiftSwapRequest(approveorreject, comment);
    }
    
    @When("^I click back on shift swap slider$")
    public void i_click_back_on_shift_swap_slider() throws Throwable {
       supDashboardSteps.clickBackOnShiftSwapSlider();
    }
    
    @When("^I verify shift swap tile is not displayed$")
    public void i_verify_shift_swap_tile_is_not_displayed() throws Throwable {
       supDashboardSteps.verifyShiftSwapTileIsNotDisplayed();
    }
    
    @When("^I \"([^\"]*)\" shift swap request with comment \"([^\"]*)\" from impact slider$")
    public void i_shift_swap_request_with_comment_from_impact_slider(String approveorreject, String comment) throws Throwable {
       supDashboardSteps.approveOrRejectShiftSwapRequestOnSubSlider(approveorreject, comment);
    }

	@When("^I Click on Time Off Requests on TTD Tile$")
	public void i_click_on_TOR_on_TTD_tile() throws Throwable {
		supDashboardSteps.clickTimeOffRequestsOnTTDTile();
	}
	@Then("^I Verify Week Dates on Time Off Tile \"([^\"]*)\"$")
	public void i_Verify_Week_Dates_on_Time_Off_Tile(String weekStartDay) throws Throwable {
		supDashboardSteps.verifyWeekDatesonTimeOffTile(weekStartDay);
	}

	@Then("^I Verify Employees on Time Off Tile \"([^\"]*)\"$")
	public void i_Verify_Employees_displayed_on_Time_Off_This_Week_Tile(String empList) throws Throwable {
		supDashboardSteps.verifyEmployeesonTimeOffTile(empList);
	}
	
	@When("^I Navigate to Time Off Next Week Tile$")
	public void i_Navigate_to_Time_Off_Next_Week_Tile() throws Throwable {
		supDashboardSteps.navigateToNextWeekViewTORTile();
	}
	
	@Then("^I Verify contents on Time Off Tile \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_contents_on_Time_Off_This_Week_Tile(String title, String pendingCount, String approvedCount) throws Throwable {
		supDashboardSteps.verifyContentsTimeOffTile(title,pendingCount,approvedCount);
	}

	@Then("^I Verify Request Status of Employee on Time Off Tile \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Request_Status_of_Employee_on_Time_Off_Tile(String EmpName, String requestDate, String requestStatus) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("dd");
		String reqDate = getRequiredDate(requestDate).format(formatters).toString();
		supDashboardSteps.verifyRequestStatusTimeOffTile(EmpName,reqDate,requestStatus);
	}

	@Then("^I Verify Data on Time Off Requests TTD Tile \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Data_don_Time_Off_Requests_TTD_Tile(String empCount,String reqCount) throws Throwable {
		supDashboardSteps.verifyDataOnTimeOffRequestTTDTile(empCount,reqCount);
	}
	
	@Then("^I Verify Time Off Requests TTD Tile \"([^\"]*)\"$")
	public void i_Verify_Time_Off_Requests_TTD_Tile(String status) throws Throwable {
		supDashboardSteps.verifyTimeOffRequestsTTDtile(status);
	}
	
	@When("^I Click on Time Off Requests TTD Tile$")
	public void i_Click_on_Time_Off_Requests_TTD_Tile() throws Throwable {
		supDashboardSteps.clickTimeOffRequestsOnTTDTile();
	}
	
	@Then("^I Take Action on Time Off Request LOR Slider \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Take_Action_On_TimeOffRequest_LOR_Slider(String action,String empName,String reqPeriod,String hrs) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String reqDate = getRequiredDate(reqPeriod).format(formatters).toString();
		supDashboardSteps.takeActionOnRequestLOR(action,empName,reqDate,hrs);
	}
	
	@When("^I Click Back button LOR Slider$")
	public void i_Click_Back_button_LOR_Page() throws Throwable {
		supDashboardSteps.clickBackButtonLORSlider();
	}
	
	@When("^I Process Action on LOR Slider \"([^\"]*)\"$")
	public void i_Click_Back_button_LOR_Page(String Process) throws Throwable {
		supDashboardSteps.processActionOnLOR(Process);
	}


	
}
