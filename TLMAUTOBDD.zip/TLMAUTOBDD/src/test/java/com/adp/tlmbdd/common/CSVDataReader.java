package com.adp.tlmbdd.common;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class CSVDataReader {

	private static BufferedReader bufferedReader;

	/**
	 * 
	 * @param CSVFileName
	 *            Absolute CSV path
	 * @param appName
	 * @return
	 */
	public static List<HashMap<String, String>> loadTestData(String CSVFileName) {
		List<HashMap<String, String>> testdata = new ArrayList<HashMap<String, String>>();
		try {
			String splitBy = ",";
			bufferedReader = new BufferedReader(new FileReader(CSVFileName));
			String line = bufferedReader.readLine();
			boolean firstRecord = true;
			Integer recordCounter = 0;
			String[] headerData = null;
			while (line != null) {
				if (firstRecord) {
					headerData = line.split(splitBy);
					firstRecord = false;
				} else {
					String[] columnData = line.split(splitBy);
					LinkedHashMap<String, String> currentData = new LinkedHashMap<String, String>();
					for (Integer i = 0; i < headerData.length; i++) {
						// currentData.put(headerData[i], columnData[i].replaceAll("&COMMA", ","));
						currentData.put(headerData[i], columnData[i]);
					}
					testdata.add(recordCounter, currentData);
					recordCounter = recordCounter + 1;
				}
				line = bufferedReader.readLine();
			}
		} catch (Exception exp) {
			testdata = null;
		}
		return testdata;
	}

	/**
	 * Used to Check whether specific text present in the PDF
	 * 
	 * @param CSVFileName
	 *            Absolute CSV path
	 * @param texttoverify
	 *            Text which you want to verify in the CSV
	 * @return Returns true if Specific Text present in the CSV. else it returns
	 *         false.
	 */
	public static boolean verifyText_inPDFContent(String CSVFileName, String texttoverify) {

		String line = null;

		try {
			bufferedReader = new BufferedReader(new FileReader(CSVFileName));
		} catch (FileNotFoundException e) {
			System.out.println(CSVFileName + "  Not Found" + e.getMessage());
		}
		try {
			line = bufferedReader.readLine();
		} catch (IOException e) {
			System.out.println("Error while Reading : " + CSVFileName + e.getMessage());
			e.printStackTrace();
		}
		while (line != null) {

			if (line.toLowerCase().contains(texttoverify.toLowerCase())) {
				return true;
			} else {
				try {
					line = bufferedReader.readLine();
				} catch (IOException e) {
					System.out.println("Error while Reading : " + CSVFileName + e.getMessage());
				}
			}
		}
		return false;

	}
	/*
	 * public static void main(String[] args) throws IOException {
	 * 
	 * loadTestData("C:\\Users\\pandisany\\Downloads\\Meal Attestation Report.csv");
	 * 
	 * verifyText_inPDFContent("C:\\Users\\pandisany\\Downloads\\Meal Attestation Report.csv"
	 * , "Rejec"); }
	 */
}
