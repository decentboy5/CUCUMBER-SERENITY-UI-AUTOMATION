package com.adp.tlmbdd.steps;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import com.adp.tlmbdd.pages.*;

public class UserLoginsSteps extends ScenarioSteps {

	Logins login;	

	@Step
	public void wfUaUserLogin(String p_userName, String p_password, String clientId) {
		login.pracUserLogin(p_userName, p_password);
		System.out.println("Logged In");
		waitABit(5000);
		login.searchForClientAccess(clientId, "");
		System.out.println("Searched");
		login.closeWhatsNewDialog();
		login.closeBridgeDialog();
	}

	@Step
	public void wfnPracUerLogin(String p_userName, String p_password) {
		login.pracUserLogin(p_userName, p_password);
		login.closeWhatsNewDialog();
		login.closeBridgeDialog();
	}

	@Step
	public void wfnEmpUserLogin(String p_userName, String p_password) {
		
		login.empUserLogin(p_userName, p_password);
	}
	
	@Step
	public void displayHomePage() {
		login.dislayHomePage();
	}
	
	@Step
	public void closeBrowser() {
		login.quitBrowser();
	}
	
	@Step
	public void RUNNepLogin(String p_userName, String p_password)
	{
		login.RUNNepLogin(p_userName, p_password);
	}
	
	@Step
	public void NonTLMLogin(String p_userName, String p_password)
	{
		login.NonTLMLogin(p_userName, p_password);
	}
	
	@Step
	public void MyADPLogin(String p_userName, String p_password, String p_URL)
	{
		login.MyADPLogin(p_userName, p_password, p_URL);
	}
	
	@Step
	public void awsUserLogin(String username, String password) {
		login.empUserLogin(username, password);
	}
	@Step
	public void awsPracUserLogin(String aws_p_username, String aws_p_password) {
		login.pracUserLogin(aws_p_username, aws_p_password);
	} 
}
