package com.adp.tlmbdd.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import net.serenitybdd.core.Serenity;

public class TestDataReader {

	//public static HashMap<String,String> storeValues = new HashMap();
	
	   public  List<HashMap<String,String>> dataReaderSingleSheet(String filepath)
	   {
	      List<HashMap<String,String>> mydata = new ArrayList<>();
	      try
	      {
	    	  System.out.println("TestDataReader reading");
	         FileInputStream fs = new FileInputStream(filepath);
	         XSSFWorkbook workbook = new XSSFWorkbook(fs);
	         XSSFSheet sheet = workbook.getSheetAt(0);	
	         
	         /*int lastRowInSheet = sheet.getLastRowNum();	         
	         for (int i=0; i < lastRowInSheet; i++) {
	        	XSSFRow row = sheet.getRow(i);
	        	
	         }*/
	         
	         Row HeaderRow = sheet.getRow(0);
	         for(int i=1;i<sheet.getPhysicalNumberOfRows();i++)
	         {
	            Row currentRow = sheet.getRow(i);
	            HashMap<String,String> currentHash = new HashMap<String,String>();
	            for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
	            {
	               Cell currentCell = currentRow.getCell(j);
	               switch (currentCell.getCellType())
	            	{
	               case Cell.CELL_TYPE_STRING:
	                  System.out.print(currentCell.getStringCellValue() + "\t");
	                  currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
	                  break;
	               }
	            }
	            mydata.add(currentHash);
	         }
	         fs.close();
	      }
	      catch (Exception e)
	      {
	         e.printStackTrace();
	      }
	      return mydata;
	   }  
	   
	  public static LinkedHashMap<String,String> GetGlobalPropertiesDataExcelData(String excelFilePath, String sheetname) throws IOException {

           try {
           
                 LinkedList<String> Header_data = new LinkedList<String>();
                 LinkedHashMap<String,String> testdata = new LinkedHashMap<String,String>();

                 FileInputStream inputStream = new FileInputStream(excelFilePath);

                 XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
                 XSSFSheet sheet = workbook.getSheet(sheetname);
                 XSSFCell cell;
                 // For storing the headers
                 XSSFRow Header = sheet.getRow(0);

                 int totalheaders = Header.getPhysicalNumberOfCells();

                 for (int i = 0; i < totalheaders; i++) {
                       cell=Header.getCell(i);
                       if(cell!=null)
                       Header_data.add(cell.getStringCellValue());
                 }

                 int Testdata_rows = sheet.getLastRowNum() - sheet.getFirstRowNum();
                 int _cell = 0;

                 for (String header : Header_data) {

                       String data = null;
                       //LinkedList<String> data = new LinkedList<String>();

                       XSSFRow Row = sheet.getRow(1);

                       if (Row != null) {
                             cell = Row.getCell(_cell);
                             if (cell != null) {
                                   if (cell.getCellType() == cell.CELL_TYPE_STRING) {
                                         data=sheet.getRow(1).getCell(_cell).getStringCellValue();
                                         //data.add(sheet.getRow(rownumber - 1).getCell(_cell).getStringCellValue());
                                   } else if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
                                         //data.add(String.valueOf(sheet.getRow(1).getCell(_cell).getNumericCellValue()));
                                         data=String.valueOf(sheet.getRow(1).getCell(_cell).getNumericCellValue());
                                   }
                             }

                       }

                       _cell++;
                       testdata.put(header, data);
                 }

                 return testdata;
           }

           catch (Exception e) {
                 System.out.println(e.getMessage());
                 return null;
           }
     }

	   	   
	   public List<HashMap<String,String>> datamap;
	   public void testDataRead(String filePath) {// each excel name should be same as feature			
			System.out.println(filePath);
			//datamap = dataReaderSingleSheet(filePath,fileName);
			System.out.println(datamap);
			Serenity.setSessionVariable("dataReadermap").to(datamap);	
			
		}
	   	   
	   
}















