package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.AdditionalConfigurationSteps;

import cucumber.api.java.en.And;
import net.thucydides.core.annotations.Steps;

public class AdditionalConfigurationStepDefinition {

	@Steps
	AdditionalConfigurationSteps additionalConfigurationSteps;
	
	@And("^I click on company preferences$")
	public void i_click_on_company_preferences() throws Throwable {
	    
		additionalConfigurationSteps.clickCompanyPreferences();
		
	}
	
	@And("^I click on work day rules$")
	public void i_click_on_work_day_rules() throws Throwable {
	    
		additionalConfigurationSteps.clickWorkDayRules();
	}
	
	@And("^I click on Pay Classes$")
	public void i_click_on_pay_classes() throws Throwable {
	    
		additionalConfigurationSteps.clickPayClasses();
	}
	
	@And("^I click on Timecard Accumulators$")
	public void i_click_on_timecard_accumulators() throws Throwable {
	    
		additionalConfigurationSteps.clickTimecardAccumulators();
	}
	
	@And("^I click on Hour Distribution Plan$")
	public void i_click_on_Hour_Distribution_Plan() throws Throwable {
	  additionalConfigurationSteps.clickHourDistributionRule();
	}
	
	@And("^I click on PayCodes$")
	public void i_click_on_PayCodes() throws Throwable {
	  additionalConfigurationSteps.clickPayCodes();
	}
}
