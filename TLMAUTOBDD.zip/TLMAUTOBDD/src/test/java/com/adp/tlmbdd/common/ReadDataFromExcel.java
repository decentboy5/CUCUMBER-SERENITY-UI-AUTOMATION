package com.adp.tlmbdd.common;

import java.io.FileInputStream;
import java.io.IOException; 
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
public class ReadDataFromExcel {
	
public static String [] getClientsList() throws IOException {
  FileInputStream file = new FileInputStream("C:\\Users\\naveeds\\Desktop\\clientlist.xlsx");
 XSSFWorkbook workbook = new XSSFWorkbook(file);
 XSSFSheet sheet = workbook.getSheetAt(0);
// XSSFRow row1 = null;
 //row1 = sheet.getRow(0);
// int colCount = row1.getLastCellNum();
	 int rowCount = sheet.getLastRowNum() + 1;		
	 String clients[] = new String[rowCount];
	for(int i=0;i<rowCount;i++) {			
		String clientName= sheet.getRow(i).getCell(0).toString();
        clients[i] = clientName;	
	}
 return clients;
 
 } 
}



