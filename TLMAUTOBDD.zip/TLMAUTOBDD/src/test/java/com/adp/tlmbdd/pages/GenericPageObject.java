package com.adp.tlmbdd.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

public class GenericPageObject extends PageObject {

	private final Properties myDynamicElements = loadDynamicElements();
	Properties prop;

	public void WaitForAjax() {
		try {
			while (true) // Handle timeout somewhere
			{
				Thread.sleep(1000);
				boolean ajaxIsComplete = (Boolean) (((JavascriptExecutor) getDriver())
						.executeScript("return jQuery.active == 0"));
				if (ajaxIsComplete)
					break;
				Thread.sleep(1000);
			}
		} catch (Exception e) {
		}

	}

	private Properties loadDynamicElements() {

		String propertyFileName = "/dynamicelements/" + getClass().getSimpleName().toLowerCase()
				+ "_dynamicelements.properties";
		System.out.println(propertyFileName);
		Properties properties = new Properties();
		try {
			final InputStream stream = this.getClass().getResourceAsStream(propertyFileName);
			if (stream != null)
				properties.load(stream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return properties;
	}

	public void ReadXMLData() {
		try {
			File file = new File("C:\\Users\\ChinnaoP\\workspace\\TLMAUTOBDD\\Environment.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(file);
			doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("Env");
			System.out.println("----------------------------");
			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				System.out.println("\nCurrent Element :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					System.out.println("Env : " + eElement.getAttribute("id"));

					System.out.println("URL : " + eElement.getElementsByTagName("URL").item(0).getTextContent());

				}
			}
		} catch (Exception e) {
		}

	}

	@SuppressWarnings("rawtypes")
	public void ReadFileData() {
		File file = new File("C:\\TLMAUTOBDDNEW\\TLMAUTOBDD\\Locators.properties");
		FileInputStream fileinput = null;
		try {
			fileinput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		try {
			prop.load(fileinput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Enumeration KeyValues = prop.keys();
		while (KeyValues.hasMoreElements()) {
			String key = (String) KeyValues.nextElement();
			String value = prop.getProperty(key);
			System.out.println(key + ":- " + value);
		}
	}

	@SuppressWarnings("rawtypes")
	public void ReadConfigFile() throws Exception {
		Properties prop = new Properties();
		String fileName = "C:\\TLMAUTOBDDNEW\\TLMAUTOBDD\\app.config";
		FileInputStream is = new FileInputStream(fileName);

		prop.load(is);
		Enumeration KeyValues = prop.keys();
		while (KeyValues.hasMoreElements()) {
			String key = (String) KeyValues.nextElement();
			String value = prop.getProperty(key);
			System.out.println(key + ":- " + value);
		}
		// System.out.println(prop.getProperty("app.environment"));
		// System.out.println(prop.getProperty("app.environment"));
		// System.out.println(prop.getProperty("app.url"));

	}

	public WebElementFacade getLocator(String strElement) throws Exception {

		// retrieve the specified object from the object list
		String locator = prop.getProperty(strElement);

		// extract the locator type and value from the object
		String locatorType = locator.split(":")[0];
		String locatorValue = locator.split(":")[1];

		// for testing and debugging purposes
		System.out.println(
				"Retrieving object of type '" + locatorType + "' and value '" + locatorValue + "' from the object map");

		// return a instance of the By class based on the type of the locator
		// this By can be used by the browser object in the actual test
		if (locatorType.toLowerCase().equals("id"))
			return find(By.id(locatorValue));
		else if (locatorType.toLowerCase().equals("name"))
			return find(By.name(locatorValue));
		else if ((locatorType.toLowerCase().equals("classname")) || (locatorType.toLowerCase().equals("class")))
			return find(By.className(locatorValue));
		else if ((locatorType.toLowerCase().equals("tagname")) || (locatorType.toLowerCase().equals("tag")))
			return find(By.tagName(locatorValue));
		else if ((locatorType.toLowerCase().equals("linktext")) || (locatorType.toLowerCase().equals("link")))
			return find(By.linkText(locatorValue));
		else if (locatorType.toLowerCase().equals("partiallinktext"))
			return find(By.partialLinkText(locatorValue));
		else if ((locatorType.toLowerCase().equals("cssselector")) || (locatorType.toLowerCase().equals("css")))
			return find(By.cssSelector(locatorValue));
		else if (locatorType.toLowerCase().equals("xpath"))
			return find(By.xpath(locatorValue));
		else
			throw new Exception("Unknown locator type '" + locatorType + "'");
	}

	protected WebElementFacade getElementByDynamicXpath(String xpathIdentifier, String... dynamicElementName) {

		if (myDynamicElements != null) {
			String navMenuXpath = myDynamicElements.getProperty(xpathIdentifier);

			for (int i = 0; i < dynamicElementName.length; i++) {
				navMenuXpath = navMenuXpath.replace("{" + i + "}", dynamicElementName[i]);
			}

			return find(By.xpath(navMenuXpath));
		}

		return null;
	}

	protected WebElementFacade getElementByDynamicValues(String locatorType, String identifier,
			String... dynamicElementName) {
		String locatorPlaceHolder = myDynamicElements.getProperty(identifier);

		for (int i = 0; i < dynamicElementName.length; i++) {
			locatorPlaceHolder = locatorPlaceHolder.replace("{" + i + "}", dynamicElementName[i]);
		}
		return returnElementType(locatorType, locatorPlaceHolder);

	}

	public WebElementFacade returnElementType(String locatorType, String navMenuXpath) {
		if (locatorType.equalsIgnoreCase("id"))
			return find(By.id(navMenuXpath));
		else if (locatorType.equalsIgnoreCase("name"))
			return find(By.name(navMenuXpath));
		else if (locatorType.equalsIgnoreCase("class"))
			return find(By.className(navMenuXpath));
		else if (locatorType.equalsIgnoreCase("link"))
			return find(By.linkText(navMenuXpath));
		else if (locatorType.equalsIgnoreCase("partial"))
			return find(By.partialLinkText(navMenuXpath));
		else if (locatorType.equalsIgnoreCase("css"))
			return find(By.cssSelector(navMenuXpath));
		else if (locatorType.equalsIgnoreCase("xpath"))
			return find(By.xpath(navMenuXpath));
		return find(By.id(navMenuXpath));

	}

	protected void browserLaunch() {
		try {
			open();
			getDriver().manage().window().maximize();
			//getDriver().manage().window().setSize(new Dimension(1920,1080));
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}
	
	protected void browserLaunchbyURL(String URL) {
		try {
			//open();
			getDriver().get(URL);
			getDriver().manage().window().maximize();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}


	// check for the element present and click on it
	public boolean clickOnElementIfExists(WebElementFacade checkElement) {
		boolean elementPresent = false;
		if (checkElement.isVisible()) {
			elementPresent = true;
			checkElement.click();
		}
		return elementPresent;
	}

	public void clickUsingJavaScript(WebElementFacade element) {
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", element);
		WaitForAjax();
	}

	public void scrollIntoView(WebElementFacade element) {
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].scrollIntoView();", element);
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].scrollIntoView();", element);
	}
	
	public boolean checkElementVisible(WebElementFacade element) {
		boolean flag = false;
		try {
			if (element.isDisplayed())
				flag = true;

		} catch (Exception e) {
			flag = false;
		}

		return flag;
	}
	
	public boolean checkElementVisible(WebElement element) {
		boolean flag = false;
		try {
			if (element.isDisplayed())
				flag = true;

		} catch (Exception e) {
			flag = false;
		}

		return flag;
	}

	public boolean checkElementVisible(String element) {
		boolean flag = false;
		try {
			if (getDriver().findElement(By.xpath(element)).isDisplayed())
				flag = true;

		} catch (Exception e) {
			flag = false;
		}

		return flag;
	}

	public void selectFrame(WebElement frame) {
		getDriver().switchTo().frame(frame);
	}

	public void switchToDefaultContent() {
		getDriver().switchTo().defaultContent();
	}

	public void switchToSpecificWindowUsingIndex(int windowNumber) {
		Set<String> s = getDriver().getWindowHandles();
		Iterator<String> ite = s.iterator();
		int i = 1;
		while (ite.hasNext() && i < 10) {
			String popupHandle = ite.next().toString();
			getDriver().switchTo().window(popupHandle);
			System.out.println("Window title is : " + getDriver().getTitle());
			if (i == windowNumber)
				break;
			i++;
		}

	}

	public void closeDriver() {
		getDriver().close();
	}

	public int getObjectCount(String xpath) {
		return getDriver().findElements(By.xpath(xpath)).size();

	}

	public void rightClickOnElement(WebElementFacade element) {
		Actions act = new Actions(getDriver()).contextClick(element);
		act.build().perform();
	}
	
	public void doubleClick(WebElementFacade element)
	{
		Actions act = new Actions(getDriver()).doubleClick(element);
		act.build().perform();
	}
	
	public void dragAndDropElement(WebElementFacade source, WebElementFacade target)
	{
		Actions act = new Actions(getDriver()).dragAndDrop(source, target);
		act.build().perform();
	}

	public void typeInActiveElement(Object text)
	{
		  getDriver().switchTo().activeElement().sendKeys(text.toString());
	}

	public void selectValueFromDropDownByVisibleText(By by, String value) {
		Select select = new Select(getDriver().findElement(by));
		select.selectByVisibleText(value);
	}

	public void openComboBoxDropdown(By by,String value){
			WebElement objComboBox = getDriver().findElement(by);
			waitForWebElementToLoad(objComboBox);
			waitABit(5000);
			if(objComboBox.findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__control')]")).size()!=0){
				objComboBox.findElement(By.xpath(".//div[contains(@class,'MDFSelectBox__dropdown-indicator')]")).click();
				waitABit(2000);
			}else if (objComboBox.findElements(By.cssSelector(".vdl-dropdown-list__picker")).size()!= 0){
				objComboBox.findElement(By.cssSelector(".vdl-dropdown-list__picker")).click();
				waitABit(2000);
			}else if (objComboBox.findElements(By.xpath(".//span[contains(@class,'vdl-date-time-picker__select')]")).size()!=0) {
				objComboBox.findElement(By.xpath(".//span[contains(@class,'vdl-date-time-picker__select')]")).click();
				waitABit(2000);
				objComboBox.findElement(By.xpath(".//input")).clear();
				waitABit(2000);
				if(!value.contentEquals(""))
				objComboBox.findElement(By.xpath(".//input")).sendKeys(value,Keys.TAB);
				waitABit(2000);				
			} else {
				Assert.assertFalse("ComboBox is not displayed", true);
			}			
	}

	//Return values of combobox dropdown
	public List<WebElement> getValuesOfComboBox(By by) {
		WebElement objMenu = null;
		List<WebElement> objOptions = null;
		openComboBoxDropdown(by, "");
		if (getDriver().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__menu')]")).size()!=0) {
			objMenu = getDriver().findElement(By.xpath(".//div[contains(@class,'MDFSelectBox__menu')]"));
			objOptions = objMenu.findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__option')]"));
		} else if (getDriver().findElement(by).findElements(By.xpath(".//ul[@class='vdl-list']")).size()!=0) {
			objMenu = getDriver().findElement(by).findElement(By.xpath(".//ul[@class='vdl-list']"));
			objOptions = objMenu.findElements(By.xpath(".//li[contains(@class,'vdl-list__option')]"));
		}
		if (objOptions.isEmpty()) {
			Assert.assertFalse("No Options present in Dropdown Menu", true);
		}
		return objOptions;
	}	
	
	//Select value of combobox using value
	public void selectValueFromComboBox(By by, String value) {
		if (value.contentEquals(""))
			return;
		List<WebElement> objOptions = getValuesOfComboBox(by);
		if (!objOptions.isEmpty()) {
			for (WebElement objOption : objOptions) {
				if (objOption.getText().trim().contentEquals(value)) {
					objOption.click();
					break;
				}
			}
		}
	}

	//Select value of combobox using index
	public void selectValueFromComboBox(By by, int index) {
		if ((index + "").contentEquals(""))
			return;
		List<WebElement> objOptions = null;
		objOptions = getValuesOfComboBox(by);
		if (!objOptions.isEmpty()) {
			objOptions.get(index).click();
		}
	}
	
	public void waitForElementToLoad(WebElementFacade element) {
		for (int i = 0; i <= 3; i++) {
			try {
				element.isDisplayed();
				break;
			} catch (Exception e) {
				waitABit(3000);
				System.out.println("Waited for 3 sec to load element: " + element.toString());
			}
		}

	}

	public void waitForWebElementToLoad(WebElement element) {
		for (int i = 0; i <= 3; i++) {
			try {
				element.isDisplayed();
				break;
			} catch (Exception e) {
				waitABit(3000);
				System.out.println("Waited for 3 sec to load element: " + element.toString());

			}
		}

	}

	@SuppressWarnings("unused")
	private void WaitUntilJSLoad() {
		JavascriptExecutor js = ((JavascriptExecutor) getDriver());
		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		ExpectedCondition<Boolean> waituntil_jsLoad = d -> js.executeScript("return document.readyState").toString()
				.equals("complete");

		Boolean status = js.executeScript("return document.readyState").toString().equals("complete");
		if (!status) {
			//wait.until(waituntil_jsLoad);
		}
	}

	private void WaitUntilJQueryLoad() {
		JavascriptExecutor js = ((JavascriptExecutor) getDriver());
		@SuppressWarnings("unused")
		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> waituntil_jQueryLoad = d -> ((long) js.executeScript("return jQuery.active") == 0);

		Boolean status = (Boolean) js.executeScript("return jQuery.active==0");
		if (!status) {
			//wait.until(waituntil_jQueryLoad);
		}
	}

	public void WaitForPageLoad() {
		JavascriptExecutor js = ((JavascriptExecutor) getDriver());
		@SuppressWarnings("unused")
		WebDriverWait wait = new WebDriverWait(getDriver(), 300);
		Boolean jQueryDefined = (Boolean) js.executeScript("return typeof jQuery !='undefined'");
		if (jQueryDefined) {
			WaitUntilJQueryLoad();

			WaitUntilJSLoad();
		}
	}
	
	public void JsClick(WebElement element) {
		JavascriptExecutor js = ((JavascriptExecutor) getDriver());

		js.executeScript("arguments[0].click();", element);
	}
	
	public boolean checkElementEnabled(WebElementFacade element) {
		for (int i = 0; i <= 3; i++) {
			try {

				if (element.isCurrentlyEnabled()) {
					return true;
				}
			} catch (Exception e) {
				waitABit(5000);
				System.out.println("Waited for 5 sec to load element: " + element.toString());

			}
		}
		return false;

	}


	public void waitForWebElementToEnable(WebElementFacade element) {
		for (int i = 0; i <= 3; i++) {
			try {

				if (element.isCurrentlyEnabled()) {
					break;
				}
			} catch (Exception e) {
				waitABit(5000);
				System.out.println("Waited for 5 sec to load element: " + element.toString());

			}
		}

	}

	public String readSernenityPropertiesFile(String keyvalue)

	{
		String property = null;
		try {
			EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();
			property = variables.getProperty(keyvalue);
		} catch (Exception e) {
			System.out.println("Error while reading the Serenity.properties file : " + e.getMessage());
		}
		return property;
	}
	
	public String verifyObjectStatus(WebElementFacade objWebElement) {
		waitForElementToLoad(objWebElement);
		String retStatus = "";
		String status = objWebElement.getAttribute("aria-disabled");
		System.out.println(status);
		if (status.contentEquals("true")) {
			retStatus = "disabled";
		} else if (status.contentEquals("false")) {
			retStatus = "enabled";
		}
		return retStatus;
	}
	//common method to select toggle switch button - values to be passed: ON,OFF
	public void selectToggleButton(WebElementFacade toggleButton, String value) {
		if(value.contentEquals("")) {
			return;
		}
		try {
				waitForWebElementToEnable(toggleButton);
				String currentState=toggleButton.getAttribute("class");
				if(currentState.contains("checked")) {
					if(value.contentEquals("OFF")) {
						toggleButton.click();
						System.out.println("Toggle Button is set to 'OFF'");
					}else if(value.contentEquals("ON")) {
						System.out.println("Toggle Button is set to 'ON'");
						return;
					}
				}else{
					if(value.contentEquals("OFF")) {
						System.out.println("Toggle Button is set to 'OFF'");
						return;
					}else if(value.contentEquals("ON")) {
						toggleButton.click();
						System.out.println("Toggle Button is set to 'ON'");
					}					
				}
				
			} catch (Exception e) {
				waitABit(5000);
				System.out.println("Waited for 5 sec to load element: " + toggleButton.toString());
			}
	}
	//Verify the state of toggle button
	public void verifyToggleButton(WebElementFacade toggleButton, String value) {
		if(value.contentEquals("")) {
			return;
		}
		try {
				waitForWebElementToEnable(toggleButton);
				String currentState=toggleButton.getAttribute("class");
				if(currentState.contains("checked")) {
					if(value.contentEquals("OFF")) {
						Assert.assertTrue("Verification Failed: Toggle Button is not tunred ON",false);
					}else if(value.contentEquals("ON")) {
						Assert.assertTrue("Verification Passed: Toggle Button is tunred ON",true);
					}
				}else if(currentState.contains("unchecked")) {
					if(value.contentEquals("OFF")) {
						Assert.assertTrue("Verification Passed: Toggle Button is tunred OFF",true);
					}else if(value.contentEquals("ON")) {
						Assert.assertTrue("Verification Failed: Toggle Button is not tunred OFF",false);
					}					
				}
				
			} catch (Exception e) {
				waitABit(5000);
				System.out.println("Waited for 5 sec to load element: " + toggleButton.toString());
			}
	}
	//common method to select Web CheckBox - values to be passed: ON,OFF
	public void selectWebCheckBox(WebElementFacade webCheckBox, String value) {
		if(value.contentEquals("")) {
			return;
		}
		try {
				waitForWebElementToEnable(webCheckBox);
				String currentState=webCheckBox.getAttribute("class");
				//String currentState1=webCheckBox.getAttribute("aria-checked");
				if(currentState.contains("Checked")) {
					if(value.contentEquals("OFF")) {
						webCheckBox.click();
						System.out.println("Web Checkbox is set to 'OFF'");
					}else if(value.contentEquals("ON")) {
						System.out.println("Web Checkbox is set to 'ON'");
						return;
					}
				}else if(!currentState.contains("Checked")) {
					if(value.contentEquals("OFF")) {
						System.out.println("Web Checkbox is set to 'OFF'");
						return;
					}else if(value.contentEquals("ON")) {
						webCheckBox.click();
						System.out.println("Web Checkbox is set to 'ON'");
					}					
				}
				
			} catch (Exception e) {
				waitABit(5000);
				System.out.println("Waited for 5 sec to load element: " + webCheckBox.toString());
				e.printStackTrace();
			}
	}

	public void selectWebCheckBox(WebElement webCheckBox, String value) {
		if(value.contentEquals("")) {
			return;
		}
		try {
				String currentState=webCheckBox.getAttribute("class");
				//String currentState1=webCheckBox.getAttribute("aria-checked");
				if((!currentState.contains("Checked") || !currentState.contains("Checked"))){
					if((webCheckBox.findElement(By.xpath(".//input[@type='checkbox']")).isSelected()&&value.toUpperCase().contentEquals("OFF"))||(!webCheckBox.findElement(By.xpath(".//input[@type='checkbox']")).isSelected()&&value.toUpperCase().contentEquals("ON")))
						webCheckBox.findElement(By.xpath(".//label[contains(@for,'checkbox_')]")).click();
				} else if(currentState.contains("Checked")) {
					if(value.contentEquals("OFF")) {
						webCheckBox.click();
						System.out.println("Web Checkbox is set to 'OFF'");
					}else if(value.contentEquals("ON")) {
						System.out.println("Web Checkbox is set to 'ON'");
						return;
					}
				}else if(!currentState.contains("Checked")) {
					if(value.contentEquals("OFF")) {
						System.out.println("Web Checkbox is set to 'OFF'");
						return;
					}else if(value.contentEquals("ON")) {
						webCheckBox.click();
						System.out.println("Web Checkbox is set to 'ON'");
					}					
				}
				
			} catch (Exception e) {
				waitABit(5000);
				System.out.println("Waited for 5 sec to load element: " + webCheckBox.toString());
				e.printStackTrace();
			}
	}	
	
	public void clickButtonOnPopup(String buttonName) {
		if(buttonName.contentEquals("")) {
			return;
		}
		try {
		List<WebElement> listButtons=getDriver().findElements(By.xpath("//*[@role='dialog']/descendant::*[@role='button']"));
		//listButtons.addAll(getDriver().findElements(By.xpath(".//span[contains(@class,'dijitButtonText') or contains(@class,'revitButton')]")));
		listButtons.addAll(getDriver().findElements(By.cssSelector(".vdl-modal-content * button,button.reactVDL.reactButton,button.reactVDL.reactButton.secondaryButton,button.vdl-button,#NAPDB_ConfirmMsg.yesButton,#NAPDB_ConfirmMsg.noButton,#okButton1,span.ng-binding.ng-scope")));
		String actBtnName="";
		@SuppressWarnings("unused")
		boolean btnFound=false;
		if(!listButtons.isEmpty()) {
			for(WebElement btn:listButtons) {
				if(!btn.getText().trim().contentEquals("")) {
					actBtnName=btn.getText().trim();
				}
				if(actBtnName.equalsIgnoreCase(buttonName)) {
					System.out.println("Found button - '"+buttonName+"' on the Popup");
					btnFound=true;
					if(btn.isEnabled()) {
						btn.click();
						waitForLoadingSpinnerToComplete();
					}
					else Assert.fail("Found Button - '"+buttonName+"' on the Popup, but is disabled");
					break;
				}
			}
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}	
	public void waitForLoadingSpinnerToComplete() {
		try {
			int waitTime = 0;
			String spinnerSelector = "//*[(contains(@class,'gridSpinner') or contains(@class,'vdl-busy-indicator') or contains(@id,'BPEDefault.Standby') or contains(@class,'gridSpinner') or contains(@class,'revitLoadingIndicator')) and not (ancestor-or-self::*[contains(@style,'none')])]";
			do {
				boolean spinnerFound = true;
				List<WebElement> spinnerObjects = getDriver().findElements(By.xpath(spinnerSelector));
				if (spinnerObjects.isEmpty())
					spinnerFound = false;
				else {
					for (WebElement spinnerObj : spinnerObjects) {
						if (!spinnerObj.isDisplayed()) {
							spinnerFound = false;
							break;
						}
					}	
				}
				if (spinnerFound) {
					waitTime = waitTime + 1;
					getDriver().wait(1000);
				} else {
					break;
				}
			} while (waitTime <= 60);
			return;
		}	catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void openNotificationsTab(){
		WebElement mcIcon=getDriver().findElement(By.xpath("//i[contains(@class,'enhancedMessageCenter')][@title='Enhanced Message Center']"));
		mcIcon.click();
		waitABit(20000);
		WaitUntilJSLoad();
		WebElement viewAllMessages=getDriver().findElement(By.xpath("//span[text()='View All messages'][@class='ng-binding ng-scope']"));
		waitForWebElementToLoad(viewAllMessages);
		viewAllMessages.click();
		WebElement notificationsLeftMenu=getDriver().findElement(By.xpath("//li[@id='emcNorNot']"));
		waitForWebElementToLoad(notificationsLeftMenu);
		notificationsLeftMenu.click();
		WaitForPageLoad();
	}

	public void performActionOnNotification(String notificationType,String subject,String status,String message,String action) {
		try {
			WaitForPageLoad();	
			HashMap<String, WebElement> notiCard=new HashMap<String, WebElement>();
			notiCard=getNotificationCard(notificationType,subject,status,message);
			if(notiCard.isEmpty()) {
				Assert.assertTrue("Notification not found", true);
			} else {
				if(action.equalsIgnoreCase("ARCHIVE")) {
					WebElement archive=notiCard.get("archive");
					archive.click();
				} else if(action.equalsIgnoreCase("REVIEW")) {
					WebElement actions=notiCard.get("actions");
					actions.click();
					WaitUntilJSLoad();
					WebElement review=getDriver().findElement(By.xpath(".//button[@class='btn btn-direct ng-binding'][contains(text(),'Review') and not(parent::div[@class='hide ng-scope'])]"));
					review.click();
				} else if(action.equalsIgnoreCase("SELECT")) {
					WebElement select=notiCard.get("select");
					//verify if checkbox already selected
					if(!select.getAttribute("class").contains("checked")) {
						select.click();
					}else {
						Assert.assertTrue("Notification is already selected", true);
					}
				}	
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void verifyNotification(String notificationType,String subject,String status,String message) {
		try {
			HashMap<String, WebElement> notiCard=new HashMap<String, WebElement>();
			notiCard=getNotificationCard(notificationType,subject,status,message);
			System.out.println(notiCard.size());
			//verify if no notifications found
			if(notiCard.isEmpty()) {
				Assert.assertTrue("Notification not found", true);
			} else {
				Assert.assertTrue("Notification found with Subject-'"+subject+"' and Message-'"+message+"'", true);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public HashMap<String, WebElement> getNotificationCard(String notificationType, String subject, String status,
			String message) {
		WaitForPageLoad();	
		List<WebElement> notifications = getDriver().findElements(By.xpath("//table[@class='messagesTable']"));
		boolean blType = true;
		boolean blSubject = true;
		boolean blStatus = true;
		boolean blMessage = true;
		boolean blnotification = false;
		HashMap<String, WebElement> NotificationMap = new HashMap<String, WebElement>();
		for (WebElement notification : notifications) {
			NotificationMap.clear();
			WebElement objSelect = notification.findElement(By.xpath(
					".//td[contains(@class,'col-md-3')]/descendant::adp-checkbox[@type='checkbox']/input[@type='checkbox']"));
			WebElement objType = notification
					.findElement(By.xpath(".//td[contains(@class,'col-md-3')]/div[@class='ng-binding']"));
			WebElement objSubject = notification.findElement(By.xpath(".//td[contains(@class,'col-md-4')]"));
			WebElement objStatus = notification
					.findElement(By.xpath(".//td[contains(@class,'col-md-2 mc-td mc-wrapword')]"));
			WebElement objMessage = notification.findElement(By.xpath(".//div[@class='accordianDiv ng-binding']/p"));
			WebElement objArchive = notification
					.findElement(By.xpath(".//td[contains(@class,'col-md-1')]/div[@class='mc-archive-icon']"));
			WebElement objActions = notification.findElement(
					By.xpath(".//td[contains(@class,'col-md-1')]//i[contains(@class,'mc-ellipsis fa fa-ellipsis-h')]"));

			if (!notificationType.contentEquals("")) {
				if (!objType.getText().trim().contentEquals(notificationType)) {
					blType = false;
				}
			}
			if (!notificationType.contentEquals("")) {
				if (!objSubject.getText().trim().contentEquals(subject)) {
					blSubject = false;
				}
			}
			if (!status.contentEquals("")) {
				if (!objStatus.getText().trim().contentEquals(status)) {
					blStatus = false;
				}
			}
			if (!message.contentEquals("")) {
				if (!objMessage.getText().trim().contentEquals(message)) {
					blMessage = false;
				}
			}
			if (blType && blSubject && blStatus && blMessage) {
				Assert.assertTrue("Notification Found with Subject-'" + subject + "' and Message-'" + message + "'",
						true);
				blnotification = true;
				NotificationMap.put("select", objSelect);
				NotificationMap.put("actions", objActions);
				NotificationMap.put("archive", objArchive);
				break;
			}
		}
		if (!blnotification) {
			Assert.assertTrue("Notification not found with Subject-'" + subject + "' and Message-'" + message + "'",
					false);
		}
		return NotificationMap;
	}	
	

	/**
	 * Used to delete the specific Files in the mentioned absolute Path
	 * 
	 * @param path
	 * @param FileName
	 */
	public void deleteFiles(String path, String FileName) {

		try {
			File files = new File(path);
			for (File file : files.listFiles()) {
				if (file.getName().contains(FileName)) {
					file.delete();
				}
			}
		} catch (Exception e) {
			System.out.println("unable to Delete  " + FileName + "in Path :" + path + "Error is :" + e.getMessage());
		}

	}
	
	
	public boolean checkElementEnabled(WebElement element) {
		for (int i = 0; i <= 3; i++) {
			try {

				if (element.isEnabled()) {
					return true;
				}
			} catch (Exception e) {
				waitABit(5000);
				System.out.println("Waited for 5 sec to load element: " + element.toString());

			}
		}
		return false;

	}

}
