package com.adp.tlmbdd.stepDefinition;

import java.time.Month;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.adp.tlmbdd.pages.editors.MonthlySchedule;
import com.adp.tlmbdd.steps.MonthlyScheduleSteps;

import net.thucydides.core.annotations.Steps;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import java.time.format.DateTimeFormatter;

public class MonthlyScheduleStepDefinition {


	@Steps
	MonthlyScheduleSteps monthlyschedulesteps;
		
	@Then("^Observe that new MDF screen is displayed$")
	public void observe_that_new_MDF_screen_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		monthlyschedulesteps.VerifyMonthlyScheduleMDF6();
	}

	@Then("^Observe Calendar Control, Employee Details from WFN employee ID bar, Remove Schedule Deviations and Non Work Scheduler$")
	public void observe_Calendar_Control_Employee_Details_from_WFN_employee_ID_bar_Remove_Schedule_Deviations_and_Non_Work_Scheduler() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		monthlyschedulesteps.ValidateEmpDetails();
	}

	@When("^I Add Daily Shifts to the employees$")
	public void i_Add_Daily_Shifts_to_the_employees() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		monthlyschedulesteps.AddSchedules();
	}

	@When("^I then Navigate to \"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_then_Navigate_to_and(String arg1, String arg2, String arg3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^Observe that created schedule is displayed under Monthly Schedule page$")
	public void observe_that_created_schedule_is_displayed_under_Monthly_Schedule_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

	}

	@And("^I Add Template Shifts to the employees$")
	public void iAddTemplateShiftsToTheEmployees() throws Throwable {
		
	}

	@And("^Click on any Day \\[Where we dont have shifts\\] - Add a schedule$")
	public void clickOnAnyDayWhereWeDontHaveShiftsAddASchedule() throws Throwable {
		monthlyschedulesteps.AddSchedules();
	}

	@Then("^Observe that data is displayed properly$")
	public void observeThatDataIsDisplayedProperly() throws Throwable {
		
	}

	@And("^I Click on any existing schedule , edit the schedule and Submit$")
	public void iClickOnAnyExistingScheduleEditTheScheduleAndSubmit() throws Throwable {
		monthlyschedulesteps.EditSchedules();
	}

	@And("^I Click on any existing shifts - Delete the shift$")
	public void iClickOnAnyExistingShiftsDeleteTheShift() throws Throwable {
		monthlyschedulesteps.DeleteSchedules();
	}

	@Then("^Observe that data is deleted$")
	public void observeThatDataIsDeleted() throws Throwable {
		
	}

	@And("^I Click on Schedule template link$")
	public void iClickOnScheduleTemplateLink() throws Throwable {
		//throw new PendingException();
	//	monthlyschedulesteps.ScheduleTemplate();
	}

	@And("^I Assign a template and date - Apply the changes$")
	public void iAssignATemplateAndDateApplyTheChanges() throws Throwable 
		{
	//monthlyschedulesteps.AssignTemp();
	}

	@Then("^Observe that Shifts gets added to the monthly schedule$")
	public void observeThatShiftsGetsAddedToTheMonthlySchedule() throws Throwable {
	
	}

	@Then("^Observe that Annual Summary link is displayed$")
	public void observeThatAnnualSummaryLinkIsDisplayed() throws Throwable {
	monthlyschedulesteps.ValidateAnnualSummaryLink();
	}

	@Then("^Observe that HOLIDAYS are listed under Monthly Schedule$")
	public void observeThatHOLIDAYSAreListedUnderMonthlySchedule() throws Throwable {
	monthlyschedulesteps.ValidateHoliday();
	}

	@Then("^Observe that Data is updated properly$")
	public void observeThatDataIsUpdatedProperly() throws Throwable {
		
	}

	@And("^Select a date in the calendar falling under previous pay period$")
	public void selectADateInTheCalendarFallingUnderPreviousPayPeriod() throws Throwable {
		//throw new PendingException();
		monthlyschedulesteps.SelectDate();
	}
	
	
	/*REMOVESCHEDULE DEVIATIONS*/
	@When("^I Click on Action items in the first week$")
	public void i_Click_on_action_items_in_the_first_week() throws Throwable {
		monthlyschedulesteps.clickActionItemsIntheFirstWeek();
	}
	
	@When("^I Click on RemoveSchedule Deviation link in the first week$")
	public void i_Click_on_RemoveSchedule_Deviation_link_in_the_first_week() throws Throwable {
		monthlyschedulesteps.openRemoveScheduleDeviationsPopup();
	}

	@Then("^Observe that Remove Schedule Deviations Popup is Displayed$")
	public void observe_that_Remove_Schedule_Deviations_Popup_is_Displayed() throws Throwable {
	    monthlyschedulesteps.validateRemoveScheduleDeviationsPopup();
	}
	
	@Then("^Observe Remove Schedule Deviations Options are Enabled$")
	public void observe_Remove_Schedule_Deviations_start_date_and_end_date_options_enabled() throws Throwable {
		monthlyschedulesteps.validateRemoveScheduleDeviationsInfoTextInPopup();
		monthlyschedulesteps.validateRemoveScheduleDeviationsOptionsInPopup();
	}
	
	@Then("^I Close Remove Schedule Deviations Popup$")
	public void colse_remove_schedule_deviations_popup() throws Throwable {
		monthlyschedulesteps.closeRemoveScheduleDeviationsPopup();
	}
	
	
	@Then("^I Submit Remove Schedule Deviations Popup$")
	public void submit_remove_schedule_deviations_popup() throws Throwable {
		monthlyschedulesteps.submitRemoveScheduleDeviationsPopup();
	}
	
	@Then("^Observe Remove Schedule Deviations Success Message \"([^\"]*)\"$")
	public void observe_remove_schedule_deviations_success_message(int noOfSchedules) throws Throwable {
		monthlyschedulesteps.verifyRemoveScheduleDeviationsMessage(noOfSchedules);
	}
	/*END REMOVESCHEDULE DEVIATIONS*/

	@And("^Click on any shift Observe that - shift is grayed out with a message$")
	public void clickOnAnyShiftObserveThatShiftIsGrayedOutWithAMessage() throws Throwable {
		//throw new PendingException();
		//monthlyschedulesteps.
	}

	@And("^Select employee - Edit the shift , change department from (\\d+) to  (\\d+) Click on Submit button$")
	public void selectEmployeeEditTheShiftChangeDepartmentFromToClickOnSubmitButton(int arg1, int arg2)
			throws Throwable {
		monthlyschedulesteps.ChangeDepartment();

	}

	@And("^Add schedules for entire month$")
	public void addSchedulesForEntireMonth() throws Throwable {
		//throw new PendingException();
		monthlyschedulesteps.AddSchedulesAll();
	}

	@And("^Click on calendar control - select any date in previous months$")
	public void clickOnCalendarControlSelectAnyDateInPreviousMonths() throws Throwable {
		//throw new PendingException();
		monthlyschedulesteps.SelectDate();

	}

	@Then("^Observe that data is retrieved and displayed$")
	public void observeThatDataIsRetrievedAndDisplayed() throws Throwable {
	//	monthlyschedulesteps.SelectDatePast();

	}

	@And("^I Add Daily Shift with Department and Job$")
	public void iAddDailyShiftWithDepartmentAndJob() throws Throwable {
		//throw new PendingException();
		monthlyschedulesteps.AddSchedulesWithJobDept();

	}

	@Then("^observe the shift gets created$")
	public void observeTheShiftGetsCreated() throws Throwable {
		//throw new PendingException();
	}

	@When("^I click on the created shift$")
	public void iClickOnTheCreatedShift() throws Throwable {
		//throw new PendingException();
	}

	@Then("^observe that the Department and Job stay intact$")
	public void observeThatTheDepartmentAndJobStayIntact() throws Throwable {
		//throw new PendingException();
	}

	@And("^Select employee - Edit the shift , change Lunch Plan from (\\d+) AUTO to  (\\d+) AUTO$")
	public void selectEmployeeEditTheShiftChangeLunchPlanFromAUTOToAUTO(int arg1, int arg2) throws Throwable {
		monthlyschedulesteps.ChangeMealPlan();
	}

	@And("^Select Calendar , select any date$")
	public void selectCalendarSelectAnyDate() throws Throwable {
		monthlyschedulesteps.ChangeCalendar();
	}

	@And("^I Click on Remove Schedule Deviations and For the Particular week - Click on submit button$")
	public void iClickOnRemoveScheduleDeviationsAndForTheParticularWeekClickOnSubmitButton() throws Throwable {
		monthlyschedulesteps.RemoveDeviation();
	}

	@Then("^Observe that temp scheduled is reverted$")
	public void observeThatTempScheduledIsReverted() throws Throwable {
		monthlyschedulesteps.ValidateSchedDeviationsMessage();
	}

	@And("^I click on More Link and click Preferences$")
	public void iClickOnMoreLinkAndClickPreferences() throws Throwable {
		 monthlyschedulesteps.ClickPreferences();
	}

	@Then("^Observe that Default Start Week field is displayed on the slider$")
	public void observeThatDefaultStartWeekFieldIsDisplayedOnTheSlider() throws Throwable {
		monthlyschedulesteps.ValidatePreferenceSlider();

	}

	/*@Then("^Observe that First Week in the Month is selected on the slider$")
	public void observeThatFirstWeekInTheMonthIsSelectedOnTheSlider(String DefaultStartWeek) throws Throwable {
		monthlyschedulesteps.ValidateFirstWeekIntheMonth(DefaultStartWeek);
	}*/

	@Then("^observe that the entire calendar month should display$")
	public void observeThatTheEntireCalendarMonthShouldDisplay() throws Throwable {
		monthlyschedulesteps.ValidateCalendarMonth();
	}	

	@And("^I select First Week in the Month Radio button	\"([^\"]*)\"$")
	public void iSelectFirstWeekInTheMonthRadioButton(String DefaultStartWeek) throws Throwable {
		monthlyschedulesteps.ValidateFirstWeekIntheMonth(DefaultStartWeek);
	}

	@And("^I select Week containing todays date \"([^\"]*)\"$")
	public void iSelectWeekContainingTodaysDate(String DefaultStartWeek) throws Throwable {
		monthlyschedulesteps.ValidateFirstWeekIntheMonth(DefaultStartWeek);

	}

	@Then("^observe that the calendar should display starting with the week containing today's date$")
	public void observeThatTheCalendarShouldDisplayStartingWithTheWeekContainingTodaySDate() throws Throwable {
		
		monthlyschedulesteps.ValidateThisWeek();

	}

	@Then("^Observe that First Week in the Month is selected on the slider \"([^\"]*)\"$")
	public void observeThatFirstWeekInTheMonthIsSelectedOnTheSlider(String DefaultStartWeek) throws Throwable {
		monthlyschedulesteps.ValidateFirstWeekIntheMonth(DefaultStartWeek);
	}
	
	@And("^I click on calendar \"([^\"]*)\"$")
	public void iClickOnCalendar(String Month) throws Throwable {		
		monthlyschedulesteps.MovetoMonth(Month);
		
		 
	}

	@And("^I click on \"([^\"]*)\" from calendar control$")
	public void iClickOnFromCalendarControl(String Month) throws Throwable {
		//throw new PendingException();
		monthlyschedulesteps.MovetoMonthFromCalendar(Month);

	}
	
	
	@Given("^I search for \"([^\"]*)\" employee$")
	public void i_search_for_employee(String employeenumber) throws Throwable {
		String employeename = TeamDashboardStepDefinition.getEmployeeName(employeenumber);
		monthlyschedulesteps.searchEmployee(employeename);
		
	}

	
	@Given("^I add schedules on \"([^\"]*)\"$")
	public void i_add_schedules_on(String intendeddate, List<String> schedulelist) throws Throwable {
	  
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/d");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(intendeddate).format(formatters).toString();
		monthlyschedulesteps.addSingleOrMultipleScheduleOnSpecificDay(requireddate,schedulelist);
	}
	





	
}
