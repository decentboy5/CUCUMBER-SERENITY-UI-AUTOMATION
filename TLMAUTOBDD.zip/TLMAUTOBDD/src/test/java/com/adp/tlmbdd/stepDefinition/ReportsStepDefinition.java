package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.ReportsSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class ReportsStepDefinition {

	@Steps
	ReportsSteps reportSteps;

	@Then("^I Enter \"([^\"]*)\" Report in Report Text Box and Filter it$")
	public void i_Enter_Report_in_Report_Text_Box_and_Filter_it(String ReportName) throws Throwable {

		reportSteps.filterReport(ReportName);
	}

	@Then("^I Verify That \"([^\"]*)\" Shows in the page$")
	public void i_Verify_That_Shows_in_the_page(String ReportName) throws Throwable {

		reportSteps.verifyReportAfterSearch(ReportName);
	}

	@Then("^I Run the Report and Verify it in Output section$")
	public void i_Run_the_Report_and_Verify_it_in_Output_section() throws Throwable {

		reportSteps.runNowandVerifyItinOutputsection();
	}

	@Then("^I Verify the content in  \"([^\"]*)\"$")
	public void i_Verify_the_content_in(String ReportName) throws Throwable {
		
		reportSteps.verifyContentinReport(ReportName,"");
	}

	@Then("^I Run Report with \"([^\"]*)\" option and Verify it in Output section$")
	public void i_Run_Report_with_option_and_Verify_it_in_Output_section(String Report_Output_Format) throws Throwable {

		reportSteps.RunWithSpecficFormatAndVerifyItinOutputsection(Report_Output_Format);
	}

	@Given("^I Verify the content in  \"([^\"]*)\" \"([^\"]*)\" File$")
	public void i_Verify_the_content_in_File(String ReportName, String OutPut_FileType) throws Throwable {
		reportSteps.verifyContentinReport(ReportName,OutPut_FileType);
	}

}
