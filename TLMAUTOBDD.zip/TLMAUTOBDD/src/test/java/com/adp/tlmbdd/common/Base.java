package com.adp.tlmbdd.common;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Random;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.GeckoDriverService;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.apache.commons.io.FileUtils;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Base {

	public static WebDriver driver;
    public StringBuilder verificationErrors;
    
   @Before
    public void initialiseBrowser() {
    	//driver = new ChromeDriver();
    	}
    
   /*  @After
    public void closeBrowser() {
    driver.quit();
    }
        */
	
    public static void BaseClass()
    {
        //driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(60));
        //verificationErrors = new StringBuilder();
    	System.out.println("Test first");
        
    }
    
    public WebDriver ConfigureBrowser()
    {
		return driver;
    	
    }
    
    public boolean IsElementDispNew(WebDriver _driver, By locator)
    {
        boolean flag = false;
        //Set the timeout to something low
        _driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        try
        {
            if (_driver.findElement(locator).isDisplayed())
            {
                flag = true;
                //If element is found set the timeout back and return true
                _driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            }
            else
            {
                flag = false;
            }


        }
        catch (NoSuchElementException e)
        {
            //If element isn't found, set the timeout and return false
            _driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        }
        return flag;
    }   
           
    public void ReadFileData()
    {
		File file = new File("C:\\TLMAUTOBDDNEW\\TLMAUTOBDD\\Locators.properties");
		FileInputStream fileinput = null;
		try {
			fileinput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		try {
			prop.load(fileinput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Enumeration KeyValues = prop.keys();
		while (KeyValues.hasMoreElements()) {
			String key = (String) KeyValues.nextElement();
			String value = prop.getProperty(key);
			System.out.println(key + ":- " + value);
		}
    }
    
    public void WaitForAjax()
    {
        try
        {
            while (true) // Handle timeout somewhere
            {
                Thread.sleep(1000);
                boolean ajaxIsComplete =
                		(Boolean)(((JavascriptExecutor)driver).executeScript("return jQuery.active == 0"));
                if (ajaxIsComplete)
                    break;
                Thread.sleep(1000);
            }
        }
        catch (Exception e)
        {
        }

    }
    
    public void getscreenshot() throws Exception 
    {
    	    Random r = new Random();
    	    int filenumber = r.nextInt(99);
    	    String filename = "SC" + filenumber; 
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            File DestFile= new File("C:\\iTeam\\Selenium\\Results\\"+ filename +".png");
            FileUtils.copyFile(scrFile, DestFile);
    }
    
    public class ScreenshotListener extends RunListener {

        private TakesScreenshot screenshotTaker;

        @Override
        public void testFailure(Failure failure) throws Exception {
        	Random r = new Random();
     	    int filenumber = r.nextInt(99);
     	    String filename = "SC" + filenumber; 
             File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
             File DestFile= new File("C:\\iTeam\\Selenium\\Results\\"+ filename +".png");
             FileUtils.copyFile(scrFile, DestFile);
        }


    }
    
    
    }

 


    





