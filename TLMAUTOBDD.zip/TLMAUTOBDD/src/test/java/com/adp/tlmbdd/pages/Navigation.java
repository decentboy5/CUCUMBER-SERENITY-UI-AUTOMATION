package com.adp.tlmbdd.pages;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import org.openqa.selenium.support.ui.ExpectedConditions;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.pages.WebElementFacadeImpl;
import net.serenitybdd.core.pages.WebElementResolverByLocator;
import net.serenitybdd.core.pages.WebElementState;

public class Navigation extends GenericPageObject {

	// **************** Main Page Navigation
	// locators********************************//
	@FindBy(xpath = "//span[contains(@id,'Setup_navItem_label')]")
	private WebElementFacade megaMenuNav;
	// private WebElement megaMenuNav;

	@FindBy(xpath = "//div[contains(text(),'SWITCH TO EXPANDED MENU')]")
	private WebElementFacade megaMenuExpandNav;
	
	@FindBy(xpath = "//div[contains(text(),'EXPAND MENU')]")
	private WebElementFacade megaMenuExpandNavShell;

	@FindBy(xpath = "//span[text()='Time & Attendance']/parent::span[@class='tabLabel']")
	private WebElementFacade subMenuNav;

	@FindBy(xpath = "//div[contains(@id,'Setup_ttd_SetupTabTimeAttendanceCategoryLaborChargeFields')]")
	private WebElementFacade mainTabNav;
	// *************** Page Frames************************************
	@FindBy(id = "eZlmIFrame_iframe")
	private WebElementFacade eZlmIFrame;
	
	@FindBy(id = "eZlmIFrame1_iframe")
	private WebElementFacade eZlmIFrame1;

	public void wfnmainPageNavigation(String megaMenu, String subMenu, String mainTab) {
		try {
			System.out.println("#####Entered into method");
			WebElementFacade megaMenuNavItem = getElementByDynamicValues("xpath", "megaMenu", megaMenu);
			System.out.println(megaMenuNavItem);
			WebElementFacade mainTabavItem = getElementByDynamicValues("xpath", "mainTab", megaMenu, subMenu, mainTab);
			System.out.println(mainTabavItem);
			megaMenuNavItem.waitUntilClickable();
			megaMenuNavItem.click();
			if (megaMenuExpandNav.isVisible()) {
				megaMenuExpandNav.click();
				}
			mainTabavItem.waitUntilClickable();
			mainTabavItem.click();
			WaitForAjax();
			
					} catch (Exception ex) {
			System.out.println("error in navigation");
			ex.printStackTrace();
		}
	}
	
	public void wfnmainShellPageNavigation(String megaMenu, String subMenu, String mainTab) {
		try {
			
			WebElementFacade megaMenuNavItem;
			if (megaMenu.contentEquals("Setup")) {
				megaMenuNavItem = getElementByDynamicValues("xpath", "megaMenuShellSetup", megaMenu);
			} else {
				megaMenuNavItem = getElementByDynamicValues("xpath", "megaMenuShell", megaMenu);
			}
			WebElementFacade mainTabavItem = getElementByDynamicValues("xpath", "mainTabShell", megaMenu, subMenu, mainTab);
			if(megaMenu.contentEquals("MyTeam")) megaMenu="My Team";
			WebElementFacade megaMenuExpandNavShell = getElementByDynamicValues("xpath", "megaMenuExpandNavShell", megaMenu, subMenu, mainTab);			
			System.out.println("megaMenuNavItem is " + megaMenuNavItem);
			System.out.println("mainTabavItem is " + mainTabavItem);
			System.out.println("megaMenuExpandNavShell is " + megaMenuExpandNavShell);
			megaMenuNavItem.waitUntilClickable();
			megaMenuNavItem.click();	
			waitABit(3000);			
			
			if (megaMenuExpandNavShell.isVisible()) {
				megaMenuExpandNavShell.click();
			}			
			
			mainTabavItem.waitUntilClickable();
			mainTabavItem.click();
			WaitForAjax();
			
					} catch (Exception ex) {
			System.out.println("error in navigation");
			ex.printStackTrace();
		}
	}

	// additional configuration
	public void wfnEditorsleftPaneNavigation(String leftPaneMainOption, String leftPaneSubOption) {
		try {
			wfnEditorsParentFrameSelection();
			WebElementFacade editorTitle =  getElementByDynamicValues("xpath", "editorTitle", leftPaneSubOption);
		if (editorTitle.isPresent()) return;
		  if (getElementByDynamicValues("xpath", "leftPanelExpandXpath", leftPaneMainOption).isVisible()) {
				getElementByDynamicValues("xpath", "navMenuXpath", leftPaneSubOption).click();
			} else {
				getElementByDynamicValues("xpath", "navMenuXpath", leftPaneMainOption).click();
				getElementByDynamicValues("xpath", "navMenuXpath", leftPaneSubOption).click();
			}
			waitFor(editorTitle);			
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			getElementByDynamicXpath("navMenuXpath", leftPaneMainOption).click();
			getDriver().switchTo().frame(eZlmIFrame1);			
		}
	}
    
	public void wfnEditorsParentFrameSelection() {
		getDriver().switchTo().defaultContent();
		waitFor(eZlmIFrame);
		getDriver().switchTo().frame(eZlmIFrame);		
	}
	
	public void wfnEditorsFrameSelection() {
		getDriver().switchTo().defaultContent();
		waitFor(eZlmIFrame);
		getDriver().switchTo().frame(eZlmIFrame);	
		waitFor(eZlmIFrame1);
		getDriver().switchTo().frame(eZlmIFrame1);	
	}
	
}
