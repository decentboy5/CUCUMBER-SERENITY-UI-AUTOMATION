package com.adp.tlmbdd.common;

import java.util.HashMap;
import java.util.Map;

public class TestCaseContext {
	static ThreadLocal<Map<String,Object>> localHash= new ThreadLocal<>();
	
	private static void init() {
		localHash.set(new HashMap<String,Object>());
	} 
	
	public static Object getValue(String key){
		if(localHash.get() == null){
			init();
		}
		return localHash.get().get(key);
	}
	
	public static void setValue(String key,Object value){
		if(localHash.get() == null){
			init();
		}
		localHash.get().put(key, value);
	}
	public static void clear(){
		localHash.get().clear();
	}
}
