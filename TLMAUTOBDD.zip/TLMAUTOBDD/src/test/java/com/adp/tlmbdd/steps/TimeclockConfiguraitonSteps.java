package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.TimeclockConfiguration;

import net.thucydides.core.annotations.Step;

public class TimeclockConfiguraitonSteps {

	TimeclockConfiguration timeclockconfig;
	
	
	
	@Step
	public void VerifyTimeclockConfigurationpageloads()
	{
		timeclockconfig.VerifyTimeclockConfigurationpageloads();
		
	}


    @Step
	public void ClickonAddDevicesandverifythedropdown(String devicetype) {
		
		timeclockconfig.ClickonAddDevicesandverifythedropdown(devicetype);
	}


	public void AddDevice(String DeviceType) {
		
		timeclockconfig.AddDevice(DeviceType);
		
		
	}


	public void EnterID_Desc_Profile_SNo_Submit(String devicetype) {
		timeclockconfig.EnterID_Desc_Profile_SNo_Submit(devicetype);
		
	}


	public void verify_dctid_in_setup_instrcuctions_dialog() {
		timeclockconfig.verify_dctid_in_setup_instrcuctions_dialog();
		
	}


	public void edit_device() {
		timeclockconfig.edit_device();
		
	}


	public void edit_device_details(String devicetype) {
		timeclockconfig.edit_device_details(devicetype);
		
	}


	public void remove_device(String devicetype) {
		timeclockconfig.remove_device(devicetype);
		
	}


	public void delete_device(String devicetype) {
		timeclockconfig.delete_device(devicetype);
	}



}
