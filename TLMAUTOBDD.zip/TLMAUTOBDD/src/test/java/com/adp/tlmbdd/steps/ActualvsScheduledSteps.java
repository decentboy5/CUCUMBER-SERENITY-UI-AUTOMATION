package com.adp.tlmbdd.steps;


import com.adp.tlmbdd.pages.editors.ActualVsScheduled;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class ActualvsScheduledSteps {
	
	ActualVsScheduled actualVsScheduledObj;
	
	@Step
	public void verifyRedistributedHourColumnInPayrollSummaryStep() {
		
		actualVsScheduledObj.verifyRedistributedHourColumnInPayrollSummary();
	}
	
	@Step
	public void verifyFinalHourColumnInPayrollSummaryStep() {
		
		actualVsScheduledObj.verifyFinalHourColumnInPayrollSummary();
	}
	
	@Step
	public void verifyDayColumnInPayrollSummaryStep() {
		actualVsScheduledObj.verifyDayColumnInPayrollSummary();
	}
	
	@Step
	public void verifyPayCodeColumnInPayrollSummaryStep() {
		actualVsScheduledObj.verifyPayCodeColumnInPayrollSummary();
	}

	@Step
	public void verifyTimeCardApprovalLinkStep() {
		actualVsScheduledObj.verifyTimeCardApprovalLink();
	}

	public void verifyAmountHiddenByDefaultAndShowThenVerifyItStep() {
		actualVsScheduledObj.verifyAmountHiddenByDefaultAndShowThenVerifyIt();
		
	}

	public void verifyPayCodeLinksOpeningPopUpInPayrollSummaryStep() {
		actualVsScheduledObj.verifyPayCodeLinksOpeningPopUpInPayrollSummary();
	}

	
	public void selectHistoricalPayPeriodFromPayPeriodListAndVerifyPopUpStep() {
		actualVsScheduledObj.selectHistoricalPayPeriodFromPayPeriodListAndVerifyPopUp();
	}

	public void verifyActualHoursLinkDisplayedAndWorkingSteps() {
		actualVsScheduledObj.verifyActualHoursLinkDisplayedAndWorking();
	}

	public void verifyScheduleHoursLinkDisplayedAndWorkingSteps() {
		actualVsScheduledObj.verifyScheduleHoursLinkDisplayedAndWorking();
	}

	

	public void selectOtherPayPeriodForDateStep(String pickDate) {
		
		actualVsScheduledObj.selectOtherPayPeriodForDate(pickDate);
	}

	public void verfyTodayPayPeriodIsSelectedStep() {
		actualVsScheduledObj.verfyTodayPayPeriodIsSelected();
	}

	public void verifyTimeCardInfoPayrollSummaryApprovalLinkShouldNotEnabledStep() {
		actualVsScheduledObj.verifyTimeCardInfoPayrollSummaryApprovalLinkShouldNotEnabled();
		
	}

	public void selectCurrentPayPeriodStep() {
		actualVsScheduledObj.selectCurrentPayPeriod();
	}

	public void selectNextPayPeriodStep() {
		
		actualVsScheduledObj.selectNextPayPeriod();
	}

	public void verifyMoreLinkStep() {
		actualVsScheduledObj.verifyMoreLink();
	}

	public void verifyTimeCardApprovedLinkStep() {
		actualVsScheduledObj.verifyTimeCardApprovedLink();
	}

	public void approveTimeCardStep() {
		actualVsScheduledObj.approveTimeCard();
		
	}

	public void unApproveTimeCardStep() {
		actualVsScheduledObj.unApproveTimeCard();
	}

	public void searchEmployeeOnMyTeamAVSPageStep(String employee) {
		actualVsScheduledObj.searchEmployeeOnMyTeamAVSPage(employee);
	}

	public void verifyTimeCardApprovalHistoryLinkWorkingStep() {
		actualVsScheduledObj.verifyTimeCardApprovalHistoryLinkWorking();
	}

	public void verifyEditAuditHistoryLinkWorkingStep() {
		actualVsScheduledObj.verifyEditAuditHistoryLinkWorking();
	}

	public void verifyToggleButtonShouldNotBeEnabledStep() {
		actualVsScheduledObj.verifyToggleButtonShouldNotBeEnabled();
	}

	public void verifyDollarAmountInPayrollSummaryStep() {
		actualVsScheduledObj.verifyAmountColumnInPayrollSummar();
	}

	public void selectPreviousPayPeriodStep() {
		actualVsScheduledObj.selectPreviousPayPeriod();
	}

	public void selectOtherPayPeriodStep(String selectDate1,String selectDate2, String selectDate3) {
		actualVsScheduledObj.selectOtherPayPeriod(selectDate1,selectDate2,selectDate3);
	}

		
	public void changeRedistributionHourFlagInPayClassStep(String flag,	String payClass) {
		actualVsScheduledObj.changeRedistributionHourFlagInPayClass(flag, payClass);
	}

	public void verifyRedistributedHourAndFinalHourColumnShouldNotBeDisplayedStep() {
		actualVsScheduledObj.verifyRedistributedHourAndFinalHourColumnShouldNotBeDisplayed();
	}

	public void changeMaskingOfAmountStep(String enableOrDisableMaking) {
		actualVsScheduledObj.changeMaskingOfAmount(enableOrDisableMaking);
	}

	public void verifyAmountMaskingIsDisabledStep() {
		actualVsScheduledObj.verifyAmountMaskingIsDisabled();
	}

	public void verifyAmountMaskingIsEnabledStep() {
		actualVsScheduledObj.verifyAmountMaskingIsEnabled();
	}

	public void verifyOvertimeLinkStep() {
		actualVsScheduledObj.verifyOvertimeLink();
		
	}

	public void verifyRegularLinkStep() {
		actualVsScheduledObj.verifyRegularLink();
		
	}

	public void verifyScheduleLinkInMoreLinkIsWorkingStep() {
		actualVsScheduledObj.verifyScheduleLinkInMoreLinkIsWorking();
	}

	public void verifyLegendInMoreLinkIsWorkingStep() {
		actualVsScheduledObj.verifyLegendInMoreLinkIsWorking();
	}

	public void verifyTimeLinkInMoreLinkIsWorkingStep() {
		actualVsScheduledObj.verifyTimecardLinkInMoreLinkIsWorking();
	}

	public void searchEmployeeOnMyTeamAVSTLMPageStep(String employee) {
		actualVsScheduledObj.searchEmployeeOnMyTeamAVSTLMPage(employee);
		
	}

	public void verifyThatEditAuditLinkIsWorkingStep() {
		// TODO Auto-generated method stub
		actualVsScheduledObj.verifyThatEditAuditLinkIsWorkingStep();
	}

	public void verifyTimeCardApprovalLinkNotPossibleStep() {
		// TODO Auto-generated method stub
		actualVsScheduledObj.verifyTimeCardApprovedLinkNotPossible();
	}

	public void changeRedistributionHourFlagInPayClassTLMStep(String flag, String payClass) {
		actualVsScheduledObj.changeRedistributionHourFlagInPayClassTLM(flag, payClass);
		
	}

	public void changeMaskingTLMOfAmountStep(String enableOrDisableMasking) {
		actualVsScheduledObj.changeMaskingTLMOfAmount(enableOrDisableMasking);
	}

	public void SelectTimeAttendanceAndEnableTimecardApprovalForEmployee() {
		actualVsScheduledObj.SelectTimeAttendanceAndEnableTimecardApprovalForEmployee();
	}

	public void CheckActualHoursAndScheduleHoursTimePairs() {
		actualVsScheduledObj.CheckActualHoursAndScheduleHoursTimePairs();
		
	}

	public void VerifySupplementalPaycodeLinksOpeningPopUpInPayrollSummary() {
		actualVsScheduledObj.VerifySupplementalPaycodeLinksOpeningPopUpInPayrollSummary();
		
	}

	public void verifyAmountFormatAsAAAAInPreferences() {
		actualVsScheduledObj.verifyAmountFormatAsAAAAInPreferences();
		
	}

	public void VerifySupplementalPaycodesAmountIsNotMasked() {
		actualVsScheduledObj.VerifySupplementalPaycodesAmountIsNotMasked();
		
	}
	
	public void UpdateNotesAndVerifyUponHover() {
		actualVsScheduledObj.UpdateNotesAndVerifyUponHover();
		
	}

	public void iVerifyPageIsNotLoadedForTerminatedEmployee() {
		actualVsScheduledObj.VerifyPageIsNotLoadedForTerminatedEmployee();
		
	}

	public void iVerifyActualVsSchedulePageIsLoading() {
		actualVsScheduledObj.VerifyActualVsSchedulePageIsLoading();
		
	}

	public void iDeleteScheduleNoteforAShift() {
		actualVsScheduledObj.DeleteScheduleNoteforAShift();
	}

	public void iVerifyStartDateOfThePeriod() {
		actualVsScheduledObj.VerifyStartDateOfThePeriod();
		
	}

	public void iAddShiftWithParentLCFAndVerifyChildLCFValuesAreDisplayed() {
		actualVsScheduledObj.AddShiftWithParentLCFAndVerifyChildLCFValuesAreDisplayed();
		
	}

	public void iVerifyPreceedingZeroValue() {
		actualVsScheduledObj.VerifyPreceedingZeroValue();
		
	}

	public void iVerifyApprovedPTO() {
		actualVsScheduledObj.VerifyApprovedPTO();
		
	}

	
}
