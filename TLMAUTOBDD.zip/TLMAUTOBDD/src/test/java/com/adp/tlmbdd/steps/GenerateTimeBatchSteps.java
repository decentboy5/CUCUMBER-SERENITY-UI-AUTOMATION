package com.adp.tlmbdd.steps;

import java.io.IOException;

import com.adp.tlmbdd.pages.GenerateTimeBatch;
import com.adp.tlmbdd.pages.editors.DailyCalculationProgram;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class GenerateTimeBatchSteps extends ScenarioSteps {
	
	GenerateTimeBatch timeBatch;
	
	@Step
	public void timeBatchsingle(String compCode, String payCycleID) throws IOException {
		timeBatch.timeBatchGeneration(compCode, payCycleID);

	}
	

}
