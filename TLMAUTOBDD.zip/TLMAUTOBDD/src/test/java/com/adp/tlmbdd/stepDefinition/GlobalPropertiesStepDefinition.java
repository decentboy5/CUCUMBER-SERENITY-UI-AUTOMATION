package com.adp.tlmbdd.stepDefinition;

import java.util.LinkedHashMap;

import com.adp.tlmbdd.common.TestDataReader;

import cucumber.api.java.en.Given;

public class GlobalPropertiesStepDefinition {

	public static String uaUserId;
	public static String uaUserPassword;
	public static String pracUserId;
	public static String pracUserPassword;
	public static String supUserId;
	public static String supUserPassword;
	public static String empUserId;
	public static String empUserPassword;
	public static String clientName;
	public static String employeeName;
	public static String payClassName;
	public static String workDayRule;
	
	
	@Given("^I read all global level data and set into variables$")
	public void i_read_all_global_level_data_and_set_into_variables() throws Throwable {
		LinkedHashMap<String,String> testData = TestDataReader.GetGlobalPropertiesDataExcelData("C:\\Users\\pathivra\\Desktop\\GlobalProperties.xlsx", "FIT1");
		
		System.out.println("Data Map is ====>>> "+testData);
		
		uaUserId = 	testData.get("UaUserId");
		uaUserPassword = testData.get("UaUserPassword");
		pracUserId = testData.get("PracUserId");
		pracUserPassword = testData.get("PracUserPassword");
		supUserId = testData.get("SupUserId");
		supUserPassword = testData.get("SupUserPassword");
		empUserId = testData.get("EmpUserId");
		empUserPassword = testData.get("EmpUserPassword");
		employeeName = testData.get("EmployeeName");
		workDayRule = testData.get("WorkDayRule");
		payClassName = testData.get("PayClassName");
		clientName = testData.get("ClientName");
		
	}

}