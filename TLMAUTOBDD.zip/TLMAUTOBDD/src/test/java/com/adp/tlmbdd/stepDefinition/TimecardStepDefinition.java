package com.adp.tlmbdd.stepDefinition;

import java.time.format.DateTimeFormatter;
import java.util.List;

import com.adp.tlmbdd.steps.IndividualTimecardSteps;
import com.adp.tlmbdd.steps.MyTimecardSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class TimecardStepDefinition {

	@Steps
	MyTimecardSteps myTimecardSteps;
	@Steps
	IndividualTimecardSteps individualTimecardSteps;
	
	@Then("^MyTimecard page should load sucessfully$")
	public void mytimecard_page_should_load_sucessfully() throws Throwable {
	  
	}

	@When("^I enter the timepair in current pay period and save timepair  \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_enter_the_timepair_in_current_pay_period_and_save_timepair(String payPeriod, String hours, String department, String job) throws Throwable {
		myTimecardSteps.empEnterTime(payPeriod,hours,department,job);
		myTimecardSteps.saveTimecard();
		myTimecardSteps.approveTimecard(payPeriod);		
	}

	@Then("^Time pair should save successfully$")
	public void time_pair_should_save_successfully() throws Throwable {
		
	}
	
	@When("^Search for an employee and approve the timecard \"([^\"]*)\" and \"([^\"]*)\"$")
	public void search_for_an_employee_and_approve_the_timecard(String payPeriod,String empName) throws Throwable {
		individualTimecardSteps.searchForEmpOnIndividualTimecard(empName);
		myTimecardSteps.selectPayPeriod(payPeriod);
		myTimecardSteps.approveTimecard(payPeriod);	
	}
	
	@And("^I search for employee as \"([^\"]*)\"$")
	public void i_search_for_employee_as(String empName) throws Throwable {
	    
		individualTimecardSteps.searchForEmpOnIndividualTimecard(empName);
	}

	@And("^I Uncheck date out field$")
	public void i_Uncheck_date_out_field() throws Throwable { 
		
	   individualTimecardSteps.uncheckDateOutCheckBox();
	}

	@Then("^I verify date out is not visible in individual timecard$")
	public void i_verify_date_out_is_not_visible_in_individual_timecard() throws Throwable {
	   individualTimecardSteps.verifyDateOutNotVisible();
	}

	@And("^I check date out field$")
	public void i_check_date_out_field() throws Throwable {
		individualTimecardSteps.checkDateOutCheckBox();
	}

	@Then("^I verify date out is visible in individual timecard$")
	public void i_verify_date_out_is_visible_in_individual_timecard() throws Throwable {
	   
		individualTimecardSteps.verifyDateOutVisible();
	}
	
	@And("^I enter a time pair greater than \"([^\"]*)\" hours in individual timecard in \"([^\"]*)\" pay period with paycode \"([^\"]*)\"$")
	public void i_enter_a_time_pair_greater_than_hours_in_individual_timecard_in_pay_period_with_paycode(String hours, String payperiod, String paycode) throws Throwable {
	    
		individualTimecardSteps.enterTimePair(hours,payperiod,paycode);
	}
	
	@Then("^I verify time pair is successfully processed$")
	public void i_verify_time_par_is_successfully_processed() throws Throwable {
	    
		individualTimecardSteps.verifyTimepairProcessed();
	}
	
	@Then("^I verify date out is diffrence is \"([^\"]*)\"$")
	public void i_verify_date_out_is_diffrence_is(String datedifference) throws Throwable {
	   
		individualTimecardSteps.verifyDateOutInIndividualTimecard(datedifference);
	}
	
	@Then("^I verify date out in print timecard$")
	public void i_verify_date_out_in_print_timecard() throws Throwable {
	   
		individualTimecardSteps.verifyDateOutInPrintTimecard();
	}
	
	@Then("^I verify date out in view transaction details$")
	public void i_verify_date_out_in_view_transaction_details() throws Throwable {
	   
		individualTimecardSteps.verifyDateOutInViewTransactionDetails();
	}
	
	@Then("^I verify date out in view edit audit$")
	public void i_verify_date_out_in_view_edit_audit() throws Throwable {
	   
		individualTimecardSteps.verifyDateOutInViewEditAudit();
	}
	
	@And("^I enter a time pair greater than \"([^\"]*)\" hours in individual timecard$")
	public void i_enter_a_time_pair_greater_than_hours_in_individual_timecard(String hours) throws Throwable {
	   
	   individualTimecardSteps.enterHoursInTimecard(hours);
	}

	@Then("^I verify error message is displayed$")
	public void i_verify_error_message_is_displayed() throws Throwable {
	    
		individualTimecardSteps.verifymaxHoursInTimecard();
	}
	
	@Then("^I verify date out field is editable$")
	public void i_verify_date_out_field_is_editable_for_ua_user() throws Throwable {
	    individualTimecardSteps.verifyDateOutEditable();
	}
	
	@Then("^I verify date out field is not editable$")
	public void i_verify_date_out_field_is_not_editable_for_ua_user() throws Throwable {
	    individualTimecardSteps.verifyDateOutNotEditable();
	}
	
	@And("^I copy row to the next row and save timecard$")
	public void i_copy_row_to_the_next_row_and_save_timecard() throws Throwable {
	   individualTimecardSteps.copyRow();
	}
	
	@And("^I copy row to the next day and save timecard$")
	public void i_copy_row_to_the_next_day_and_save_timecard() throws Throwable {
	   individualTimecardSteps.copyRowToNextDate();
	}

	@Then("^I verify \"([^\"]*)\" is successful$")
	public void i_verify_is_successful(String copytype) throws Throwable {
	   individualTimecardSteps.verifyCopiedRow(copytype);
	}
	
	@Then("^I transfer out time to the next row and verify transfered time$")
	public void i_transfer_out_time_to_the_next_row_and_verify_transfered_time() throws Throwable {
	    individualTimecardSteps.transferTimeAndVerify();
	}
	
	@And("^I select \"([^\"]*)\" pay period from dropdown$")
	public void i_select_pay_period_from_dropdown(String payperiod) throws Throwable {
	   individualTimecardSteps.selectPayperiod(payperiod);
	}

	@When("^I click view transaction details$")
	public void i_click_view_transaction_details() throws Throwable {
	    individualTimecardSteps.clickViewTransactionDetails();
	}
	
	@Then("^I Verify Status of Timecard \"([^\"]*)\"$")
	public void i_Verify_Status_of_Timecard(String status) throws Throwable {
	   individualTimecardSteps.verifyTimecardStatus(status);
	}
	@Then("^I Remove Approval of Timecard on Individual Timecard Page$")
	public void i_Remove_Approval_of_Timecard() throws Throwable {
	   individualTimecardSteps.removeApprovalOfTimecard();
	}
	
	@Then("^I \"([^\"]*)\" a \"([^\"]*)\" note on date \"([^\"]*)\" as \"([^\"]*)\"$")
	public void i_enter_a_note_on_date_as(String operation,String applynoteto, String date, String note) throws Throwable {
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
		individualTimecardSteps.addNoteForEmployeeOnSpecificDate(operation,applynoteto,requireddate, note);
	}
	
	@Then("^I click on submit button on individual timecard$")
	public void i_click_on_submit_button() throws Throwable {
		
		individualTimecardSteps.clickOnSubmitButton();
	}
	
	@Then("^I verify note as \"([^\"]*)\" on \"([^\"]*)\"$")
	public void i_verify_note_as_on(String note, String date) throws Throwable {
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
		individualTimecardSteps.verifyNoteOnTimecard(note, requireddate);
	}
	
	@When("^I enter \"([^\"]*)\" punch for \"([^\"]*)\" employee as \"([^\"]*)\" on \"([^\"]*)\" from timecard$")
	public void i_enter_punch_for_employee_as_on_from_timecard(String punchtype, String emp, String punch, String date) throws Throwable {
	    
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
		String employeename = TeamDashboardStepDefinition.getEmployeeName(emp);
		individualTimecardSteps.enterTimePairOnSpecificDate(punchtype, employeename, punch, requireddate);
		
		
	}
	
	
	@When("^I add \"([^\"]*)\" rows for employee on \"([^\"]*)\"$")
	public void i_add_rows_for_employee_on(String rowcount, String date) throws Throwable {
	    
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
		individualTimecardSteps.addRowsOnIndividualTimecard(rowcount, requireddate);
	}

	@When("^I enter \"([^\"]*)\" punches on \"([^\"]*)\"$")
	public void i_enter_punches_on(String punchtype, String date, List<String> punches) throws Throwable {
	    
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
		individualTimecardSteps.enterMultipleTimePairOnSpecificDate(punchtype, requireddate, punches);
	    
	}


	
}
