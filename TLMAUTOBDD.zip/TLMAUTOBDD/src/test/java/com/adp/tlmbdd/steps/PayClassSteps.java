package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.editors.PayClasses;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class PayClassSteps extends ScenarioSteps{
	
	PayClasses classes;
	
	@Step
	public void changeTimeEntryPlan(String timeentryplan,String payclass)
	{
		classes.changeTimeEntryPlanInPayclass(timeentryplan, payclass);
	}
}
