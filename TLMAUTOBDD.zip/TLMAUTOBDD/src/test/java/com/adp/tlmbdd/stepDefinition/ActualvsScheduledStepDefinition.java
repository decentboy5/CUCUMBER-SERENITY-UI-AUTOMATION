package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.*;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;


public class ActualvsScheduledStepDefinition {
	@Steps
	ActualvsScheduledSteps actualVsScheduledStepObj;
	

	@Then("^I verify Days Column in payroll Summary$")
	public void iVerifyDaysColumnInPayrollSummary() throws Throwable {
		actualVsScheduledStepObj.verifyDayColumnInPayrollSummaryStep();
	}

	@Then("^I verify Redistributed Hour Column in payroll Summary$")
	public void iVerifyRedistributedHourColumnInPayrollSummary(){
	actualVsScheduledStepObj.verifyRedistributedHourColumnInPayrollSummaryStep();
	}

	@Then("^I verify Final Hour Column in payroll Summary$")
	public void iVerifyFinalHourColumnInPayrollSummary() throws Throwable {
		actualVsScheduledStepObj.verifyFinalHourColumnInPayrollSummaryStep();
	}

	@Then("^I verify PayCode Column Column in payroll Summary$")
	public void iVerifyPayCodeColumnColumnInPayrollSummary() throws Throwable {
		actualVsScheduledStepObj.verifyPayCodeColumnInPayrollSummaryStep();
	}

	@Then("^I verify TimeCard Approval link is displayed$")
	public void iVerifyTimeCardApprovalLinkIsDisplayed() throws Throwable {
		actualVsScheduledStepObj.verifyTimeCardApprovalLinkStep();
	}
	
	@Then("^I verify TimeCard approved link is displayed$")
	public void iVerifyTimeCardApprovedLinkIsDisplayed() throws Throwable {
		actualVsScheduledStepObj.verifyTimeCardApprovedLinkStep();
	}
	
	@Then("^I verify Amount column is hidden byDefault then revert it and verify that Amount is displayed$")
	public void iVerifyAmountColumnIsHiddenByDefaultThenRevertItAndVerifyThatAmountIsDisplayed()throws Throwable {
		actualVsScheduledStepObj.verifyAmountHiddenByDefaultAndShowThenVerifyItStep();
		
	}

	@Then("^I verify paycode links opening popUp in payroll summary$")
	public void iVerifyPaycodeLinksOpeningPopUpInPayrollSummary()throws Throwable {
		actualVsScheduledStepObj.verifyPayCodeLinksOpeningPopUpInPayrollSummaryStep();
	}

	@Then("^I select historical pay period from pay period list and Verify popUp$")
	public void iSelectHistoricalPayPeriodFromPayPeriodListAndVerifyPopUp(){
		actualVsScheduledStepObj.selectHistoricalPayPeriodFromPayPeriodListAndVerifyPopUpStep();
	}

	@Then("^I verify actual hours link is displayed and through link able to navigate$")
	public void iVerifyActualHoursLinkIsDisplayedAndThroughLinkAbleToNavigate(){
		actualVsScheduledStepObj.verifyActualHoursLinkDisplayedAndWorkingSteps();
	}

	@Then("^I verify schedule hours link is displayed and through link able to navigate$")
	public void iVerifyScheduleHoursLinkIsDisplayedAndThroughLinkAbleToNavigate()throws Throwable {
		actualVsScheduledStepObj.verifyScheduleHoursLinkDisplayedAndWorkingSteps();
	}

	@Then("^I select other pay period for date \"([^\"]*)\"$")
	public void iSelectOtherPayPeriodForDate(String pickDate) throws Throwable {
		actualVsScheduledStepObj.selectOtherPayPeriodForDateStep(pickDate);
	}

	@Then("^I verify  Today pay period is shown in select pay period dropdown list$")
	public void iVerifyTodayPayPeriodIsShownInSelectPayPeriodDropdownList()	throws Throwable {
		actualVsScheduledStepObj.verfyTodayPayPeriodIsSelectedStep();
	}

	@Then("^I verify that time card info , payroll summary and approval link should not be displayed$")
	public void iVerifyThatTimeCardInfoPayrollSummaryAndApprovalLinkShouldNotBeDisplayed()	throws Throwable {
		actualVsScheduledStepObj.verifyTimeCardInfoPayrollSummaryApprovalLinkShouldNotEnabledStep();
	}

	@Then("^I select current pay period$")
	public void iSelectCurrentPayPeriod() throws Throwable {
		actualVsScheduledStepObj.selectCurrentPayPeriodStep();
	}

	@Then("^I select Next pay period$")
	public void iSelectNextPayPeriod() throws Throwable {
		actualVsScheduledStepObj.selectNextPayPeriodStep();
	}

	@Then("^I verify More Link on the page$")
	public void iVerifyMoreLinkOnThePage() throws Throwable {
		actualVsScheduledStepObj.verifyMoreLinkStep();
	}

	@Then("^I approve time card from ActualvsSchedule page$")
	public void iApproveTimeCardFromActualvsSchedulePage() throws Throwable {
		actualVsScheduledStepObj.approveTimeCardStep();
	}

	

	@Then("^I Unapprove TimeCard from ActualvsSchedule page$")
	public void iUnapproveTimeCardFromActualvsSchedulePage() throws Throwable {
		actualVsScheduledStepObj.unApproveTimeCardStep();
	}

	@Then("^I search employee \"([^\"]*)\" on Actual vs Schedule page$")
	public void iSearchEmployeeOnActualVsSchedulePage(String employee)	throws Throwable {
		actualVsScheduledStepObj.searchEmployeeOnMyTeamAVSPageStep(employee);
	}

	@Then("^I verify that TimeCard Approval History link is working$")
	public void iVerifyThatTimeCardApprovalHistoryLinkIsWorking() throws Throwable {
		actualVsScheduledStepObj.verifyTimeCardApprovalHistoryLinkWorkingStep();
	}

	@Then("^I verify that Edit Audit History link is working$")
	public void iVerifyThatEditAuditHistoryLinkIsWorking() throws Throwable {
		actualVsScheduledStepObj.verifyEditAuditHistoryLinkWorkingStep();
	}

	@Then("^I verify that Toggle Button for Dollar/Amount should not be enabled$")
	public void iVerifyThatToggleButtonForDollarAmountShouldNotBeEnabled()	throws Throwable {
		actualVsScheduledStepObj.verifyToggleButtonShouldNotBeEnabledStep();
	}

	@Then("^I verify Dollar/amount column in payroll Summary$")
	public void iVerifyDollarAmountColumnInPayrollSummary() throws Throwable {
		actualVsScheduledStepObj.verifyDollarAmountInPayrollSummaryStep();
	}

	@Then("^I select Previous Pay Period$")
	public void iSelectPreviousPayPeriod() throws Throwable {
		actualVsScheduledStepObj.selectPreviousPayPeriodStep();
	}

	@Then("^I select other pay period for date \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void iSelectOtherPayPeriodForDate(String selectDate1, String selectDate2,String selectDate3) throws Throwable {
		actualVsScheduledStepObj.selectOtherPayPeriodStep(selectDate1,selectDate2,selectDate3);
	}


	@Then("^I change Show Redistribution Hour flag to \"([^\"]*)\" in Payclass \"([^\"]*)\"$")
	public void iChangeShowRedistributionHourFlagToInPayclass(String flag, String payClass) throws Throwable {
		actualVsScheduledStepObj.changeRedistributionHourFlagInPayClassStep(flag, payClass);
	}

	@Then("^I verify Redistribution Hours and Final Hours should not be displayed in payroll summary$")
	public void iVerifyRedistributionHoursAndFinalHoursShouldNotBeDisplayedInPayrollSummary()	throws Throwable {
		actualVsScheduledStepObj.verifyRedistributedHourAndFinalHourColumnShouldNotBeDisplayedStep();
	}

	@Then("^I change Masking of Amount/Dollar to \"([^\"]*)\"$")
	public void iChangeMaskingOfAmountDollarTo(String enableOrDisableMaking) throws Throwable {
		actualVsScheduledStepObj.changeMaskingOfAmountStep(enableOrDisableMaking);
	}

	@Then("^I verify Amount Masking is Disabled$")
	public void iVerifyAmountMaskingIsDisabled() throws Throwable {
		actualVsScheduledStepObj.verifyAmountMaskingIsDisabledStep();
	}

	@Then("^I verify Amount Masking is Enabled$")
	public void iVerifyAmountMaskingIsEnabled() throws Throwable {
		actualVsScheduledStepObj.verifyAmountMaskingIsEnabledStep();
	}

	@Then("^I Select Overtime link and verify the popUp$")
	public void iSelectOvertimeLinkAndVerifyThePopUp() throws Throwable {
		actualVsScheduledStepObj.verifyOvertimeLinkStep();
	}

	@Then("^I Select Regular Link and verify the popUp$")
	public void iSelectRegularLinkAndVerifyThePopUp() throws Throwable {
		actualVsScheduledStepObj.verifyRegularLinkStep();
	}

	@Then("^I verify Schedule link in more link is working$")
	public void iVerifyScheduleLinkInMoreLinkIsWorking() throws Throwable {
		actualVsScheduledStepObj.verifyScheduleLinkInMoreLinkIsWorkingStep();
		}

	@Then("^I verify legend in more link is working$")
	public void iVerifyLegendInMoreLinkIsWorking() throws Throwable {
		actualVsScheduledStepObj.verifyLegendInMoreLinkIsWorkingStep();
	}

	@Then("^I verify Timecard link in more link is working$")
	public void iVerifyTimecardLinkInMoreLinkIsWorking() throws Throwable {
		actualVsScheduledStepObj.verifyTimeLinkInMoreLinkIsWorkingStep();
	}

	@Then("^I search employee \"([^\"]*)\" on Actual vs\\. Schedule page$")
	public void iSearchEmployeeOnActualVsScheduleTLMPage(String employee) throws Throwable {
		actualVsScheduledStepObj.searchEmployeeOnMyTeamAVSTLMPageStep(employee);
	}

	@Then("^I verify that Edit Audit link is working$")
	public void iVerifyThatEditAuditLinkIsWorking() throws Throwable {
		actualVsScheduledStepObj.verifyThatEditAuditLinkIsWorkingStep();
	}

	@Then("^I verify TimeCard Approval Not Possible link is displayed$")
	public void iVerifyTimeCardApprovalNotPossibleLinkIsDisplayed() throws Throwable {
		actualVsScheduledStepObj.verifyTimeCardApprovalLinkNotPossibleStep();
	}

	@Then("^I change Show Redistribution Hour flag in TLM to \"([^\"]*)\" in Payclass \"([^\"]*)\"$")
	public void iChangeShowRedistributionHourFlagInTLMToInPayclass(String flag, String payClass) throws Throwable {
		actualVsScheduledStepObj.changeRedistributionHourFlagInPayClassTLMStep(flag, payClass);
	}

	@Then("^I change Masking of Amount/Dollar TLM to \"([^\"]*)\"$")
	public void iChangeMaskingOfAmountDollarTLMTo(String enableOrDisableMasking) throws Throwable {
		actualVsScheduledStepObj.changeMaskingTLMOfAmountStep(enableOrDisableMasking);
	}

	@Then("^I select Time & attendance and Enable timecard approval for employee$")
	public void iSelectTimeAttendanceAndEnableTimecardApprovalForEmployee() throws Throwable {
		actualVsScheduledStepObj.SelectTimeAttendanceAndEnableTimecardApprovalForEmployee();
	}
	
	@Then("^I check actual hours and Schedule hours time pairs$")
	public void iCheckActualHoursAndScheduleHoursTimePairs() throws Throwable {
		actualVsScheduledStepObj.CheckActualHoursAndScheduleHoursTimePairs();
	}

	@Then("^I verify Supplemental paycode links opening popUp in payroll summary$")
	public void iVerifySupplementalPaycodeLinksOpeningPopUpInPayrollSummary() throws Throwable {
		actualVsScheduledStepObj.VerifySupplementalPaycodeLinksOpeningPopUpInPayrollSummary();

	}

	@Then("^Verify amount format as AA\\.AA in preferences$")
	public void verifyAmountFormatAsAAAAInPreferences() throws Throwable {
		actualVsScheduledStepObj.verifyAmountFormatAsAAAAInPreferences();
	}

	@Then("^I verify supplemental paycodes amount is not masked$")
	public void iVerifySupplementalPaycodesAmountIsNotMasked() throws Throwable {
		actualVsScheduledStepObj.VerifySupplementalPaycodesAmountIsNotMasked();
	}

	@Then("^I update notes and verify upon hover$")
	public void iUpdateNotesAndVerifyUponHover() throws Throwable {
		actualVsScheduledStepObj.UpdateNotesAndVerifyUponHover();
	}
	
	@Then("^I Delete schedule note for a shift$")
	public void iDeleteScheduleNoteforAShift() throws Throwable {
		actualVsScheduledStepObj.iDeleteScheduleNoteforAShift();
	}
	
	@Then("^I verify page is not loaded for terminated employee$")
	public void iVerifyPageIsNotLoadedForTerminatedEmployee() throws Throwable {
		actualVsScheduledStepObj.iVerifyPageIsNotLoadedForTerminatedEmployee();
	}
	
	
	@Then("^I verify actual vs schedule page is loading$")
	public void iVerifyActualVsSchedulePageIsLoading() throws Throwable {
		actualVsScheduledStepObj.iVerifyActualVsSchedulePageIsLoading();
	}
	
	@Then("^I verify start date of the period$")
	public void iVerifyStartDateOfThePeriod() throws Throwable {
		actualVsScheduledStepObj.iVerifyStartDateOfThePeriod();
	}
	
	@Then("^I add shift with parent LCF and verify child LCF values are displayed$")
	public void iAddShiftWithParentLCFAndVerifyChildLCFValuesAreDisplayed() throws Throwable {
		actualVsScheduledStepObj.iAddShiftWithParentLCFAndVerifyChildLCFValuesAreDisplayed();
	}
	
	@Then("^I verify preceeding zero value$")
	public void iVerifyPreceedingZeroValue() throws Throwable {
		actualVsScheduledStepObj.iVerifyPreceedingZeroValue();
	}
	
	@Then("^I verify approved PTO$")
	public void iVerifyApprovedPTO() throws Throwable {
		actualVsScheduledStepObj.iVerifyApprovedPTO();
	}
}
