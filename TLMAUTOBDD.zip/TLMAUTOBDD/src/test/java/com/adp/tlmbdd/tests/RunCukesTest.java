package com.adp.tlmbdd.tests;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = {"src/test/resources/features"},
        		plugin = {
				"pretty", "html:target/cucumber", "json:target/json/cucumber.json" },				
	 		glue = {"com.adp.tlmbdd.stepDefinition","com.adp.tempus.stepDefinition"},tags= {"@Webclocking_EndWorkwithNotes"} ,  
      
                dryRun=false)


public class RunCukesTest {

}
