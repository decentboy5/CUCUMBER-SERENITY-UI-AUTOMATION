package com.adp.tlmbdd.pages;

import java.util.List;

import org.openqa.selenium.By;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class MyTimecard extends GenericPageObject {

	@FindBy(id = "dateRangeselect")
	private WebElementFacade dateRangeSelectedText;

	@FindBy(xpath = "//table[@id='TcGrid']//tr")
	private List<WebElementFacade> timeCardTableRowCount;

	@FindBy(xpath = "//input[starts-with(@id, 'TLMWidgets_TimeEntry_DurationTextBox_')]")
	private WebElementFacade timeEntryhoursTextBox;

	@FindBy(xpath = "//div[starts-with(@id,'dgrid') and contains(@id,'-row-')][1]//td[1]")
	private WebElementFacade lookUpPopoup;

	@FindBy(xpath = "//div[@id='widget_dateRangeselect']//input[contains(@class,'dijitArrowButtonInner')]")
	private WebElementFacade dateRangeSelectDropdownIcon;

	@FindBy(id = "dateRangeselect_popup")
	private WebElementFacade dateRangeselectPopup;
    
	@FindBy(xpath = "//td[contains(@id,'DepartmentID')]//span[text()='Search']/preceding-sibling::span")	
	private WebElementFacade deptSearchButton;
	
	@FindBy(xpath = "//td[contains(@id,'WorkedJobID')]//span[text()='Search']/preceding-sibling::span")
	private WebElementFacade jobSearchButton;
	
	@FindBy(xpath = "//div[contains(@id,'revitLocal_form_AutoSuggestDialog') and @role='dialog']")
	private WebElementFacade lookupDailog;
	
	@FindBy(xpath = "//label[text()='Active Only']/preceding-sibling::div//input[contains(@id,'CheckBox')]")
	private WebElementFacade activeCheckBox;
	
	@FindBy(xpath = "//div[contains(@id,'revitLocal_form_AutoSuggestDialog') and @role='dialog']//input[contains(@id,'revitLocal_form_ClearableTextBox')]")
	private WebElementFacade lookupSearchTextBox;	

	@FindBy(xpath = "//div[contains(@id,'revitLocal_form_AutoSuggestDialog') and @role='dialog']//div[@class='revitTid3Message dijitInline']")
	private WebElementFacade nodataFoundText;
	
	@FindBy(xpath = "//div[contains(@id,'revitLocal_form_AutoSuggestDialog') and @role='dialog']//span[contains(@class,'dijitDialogCloseIcon')]")
	private WebElementFacade lookpupCloseIcon;
	
	@FindBy(id = "TcGrid")
	protected WebElementFacade timcardTable;
	
	@FindBy(id = "btnSubmit")
	private WebElementFacade timecardSaveButton;
	// ************************** Alerts  ********************************************************//
	@FindBy(xpath = "//div[contains(@id,'AlertDialog') and @role='dialog']")
	private WebElementFacade alertDialog;
	
	@FindBy(xpath = "//div[contains(@id,'AlertDialog') and @role='dialog']//span[contains(@id,'revit_form_Button') and @role='button']")
	private WebElementFacade alertOkButton;
	
	// ************************** Approve  ********************************************************//
	@FindBy(xpath = "//span[@id='approvalControl']/span[contains(@class,'dijitReset revitButton')]")
	private WebElementFacade approveTimecardButton;
	
	@FindBy(css = "div#ApprovalDialog")
	private WebElementFacade approveTimecardDailog;
	
	@FindBy(xpath = "//span[text()='Approve']/ancestor::span[@role='button']")
	private WebElementFacade approveButton;
	// **************************************************************************************//

	public void addTimePair(String payPeriod, String hours, String department, String job) {
		try {
			timcardTable.waitUntilPresent();
            selectpayPeriod(payPeriod);
			boolean timeEntered = false;
			WaitForAjax();			
			for (int i = 1; i < timeCardTableRowCount.size(); i++) {
				WebElementFacade hoursValueTextBox = getElementByDynamicValues("id", "hoursTextBox",Integer.toString(i));		
				if (hoursValueTextBox.isPresent()) {
					if (hoursValueTextBox.getText().equals("0.00")) {
						String dayText = getElementByDynamicValues("id", "dayNameTextBox", Integer.toString(i))
								.getText();
						if (!dayText.equals("Sat") && !dayText.equals("Sun")) {
							if (!hours.isEmpty()) {			
							// make it as common function
								evaluateJavascript("arguments[0].scrollIntoView(true);", hoursValueTextBox);
								hoursValueTextBox.waitUntilClickable();		
								hoursValueTextBox.click();
								timeEntryhoursTextBox.clear();
								timeEntryhoursTextBox.type(hours);
								timeEntered = true;
							}
							if (!department.isEmpty()) {
								assignLcf(i, "departMentTextBox","departMentRow",department,"DepartmentID");
							}
							if (!job.isEmpty()) {
								assignLcf(i, "workJobTextBox","workJobRow",job,"WorkedJobID");
							}

						  if (timeEntered == false)
								continue;
							break;
						} 
						}
					}else {
						i = i + 1;// next week start
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// check and select pay period
	public void selectpayPeriod(String payPeriod) {
		try {
			WaitForAjax();	
			System.out.println(dateRangeSelectedText.getTextValue());
			if (!dateRangeSelectedText.getTextValue().contains(payPeriod)) {
				dateRangeSelectDropdownIcon.click();
				waitFor(dateRangeselectPopup);
				getElementByDynamicValues("xpath", "dateSelectedDropDownOption", payPeriod).click();
				WaitForAjax();			
			} 
			} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/*
	i = row count
	lcfIdentifier = dynamic xpath name in property file
	lcfRow = lcf row in the timecard table
	lcfValue = lcf valuec to search for in lookup
	lcfSearchDynamicValue = dynamic xpath value
	*/
	public void assignLcf(int i, String lcfIdentifier,String lcfRow,String lcfValue,String lcfSearchDynamicValue) {
		try {
			WebElementFacade lcfTextBox = getElementByDynamicValues("id", lcfIdentifier, Integer.toString(i));
			if (lcfTextBox.isPresent()) {
				getElementByDynamicValues("id", lcfRow, Integer.toString(i)).click();
				//lcfTextBox.click();
				getElementByDynamicValues("xpath", "lcsfSearchButton", lcfSearchDynamicValue).click();
				lookupDailog.waitUntilVisible();
				selectLcfFromLookup(lcfValue);  				
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void selectLcfFromLookup(String lcfValue) {
		try {
			/*if(active == false ) {
				activeCheckBox.click();
			}	*/
		lookupSearchTextBox.click();
		lookupSearchTextBox.sendKeys(lcfValue);
		waitABit(500);
		WebElementFacade lcfSearchValue = getElementByDynamicValues("xpath", "lcfValueLabel", lcfValue);
			if(lcfSearchValue.isPresent()){
				lcfSearchValue.click();
			  waitABit(500); 
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(lookpupCloseIcon.isVisible()) {lookpupCloseIcon.click();}			
		}		
	}
	
	public void saveTimecard() {
		try {
		timecardSaveButton.click();
		WaitForAjax();	
		}catch (Exception ex) {
			ex.printStackTrace();
		}
		finally {
		 if(alertDialog.isPresent()) {
		 alertOkButton.click();	
		 }	
		}	
	 }
	
	//Approve timecard
	public void approveTimecard(String payPeriod) {
		selectpayPeriod(payPeriod);
		if(approveTimecardButton.isEnabled()) {
			approveTimecardButton.click();
			approveTimecardDailog.waitUntilVisible();
			approveButton.click();
			timcardTable.waitUntilVisible();
		}				
	}
	

	
	
	
}
