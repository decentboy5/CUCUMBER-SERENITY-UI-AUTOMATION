package com.adp.tlmbdd.stepDefinition;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.opera.core.systems.scope.services.desktop.SystemInput;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.SerenitySystemProperties;
import net.thucydides.core.ThucydidesSystemProperty;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;
//initialization
public class GenericHooks extends GenericDeclaration{
	
	//@Inject
	//EnvironmentVariables environmentVariables;
	public static WebDriver Driver;
	static EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();
	public static String waitTime = environmentVariables.getProperty("webdriver.timeouts.implicitlywait");
	public static String url = environmentVariables.getProperty("webdriver.base.url");

	@Before
	public void beforeTest(Scenario scenario) throws FileNotFoundException,
			IOException {

		for (String s : scenario.getSourceTagNames()) {
			System.out.println("Tag:" + s);
		}
		//Properties prop = new Properties();
		//prop.load(new FileInputStream(Configpath));	
		System.out.println("below is url" + url);
        
		
	 }
	
	
	
}
