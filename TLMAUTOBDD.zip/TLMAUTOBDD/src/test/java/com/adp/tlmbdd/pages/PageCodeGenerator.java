package com.adp.tlmbdd.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.javapoet.AnnotationSpec;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.TypeSpec;
import javax.lang.model.element.Modifier;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class PageCodeGenerator{
	
	private static final List<FieldSpec> fieldsList = new ArrayList<FieldSpec>();
	
	/**
	 * Auto generates a class with WebElement fields from a Json object repository
	 */
	public void generateClassFromJsonFile(String jsonFileName){
		    String generatedClassName = jsonFileName+"Gen";
		    String filePath = System.getProperty("user.dir") + "/src/test/resources/JsonObjectRepository/"+jsonFileName+".json";
			BufferedReader br = null;
			try {
				   br = new BufferedReader(new FileReader(filePath));
				   JsonParser parser = new JsonParser();
				   JsonObject jsonObject = parser.parse(br).getAsJsonObject();
				   final JsonArray webElements = jsonObject.get("webObjects").getAsJsonArray();

				   //loop through all web objects
				  for(int i=0; i<webElements.size(); i++){
					 String webElementName = webElements.get(i).getAsJsonObject().get("name").toString().replace("\"", "");
					 JsonElement  locator = webElements.get(i).getAsJsonObject().get("locator");
					 String locatorType = locator.toString().split(";")[0].toString().replace("\"", "");
					 String locatorValue = locator.toString().split(";")[1];
					 // returns webObjects as FieldSpec and add them to the field list
					  String value = locatorType+" =" + "\""+locatorValue;
					  FieldSpec field = getFields(webElementName, value);
					  fieldsList.add(field);
				 }
			} catch (FileNotFoundException e){
				   System.out.println("File NOT Found!!! Application is unable to generate generate class." );
				   System.out.println("Please edit Json file name and try again" );
				   System.exit(1);
				  } 
				generateCode(fieldsList, generatedClassName);
	   }
	
	/**
	 * Builds the auto generated class variables
	 *  @return JavaPoet FieldSpec
	 */
	public FieldSpec getFields (String field, String value) {
		FieldSpec name = FieldSpec.builder(WebElementFacade.class, field)
				  .addModifiers(Modifier.PUBLIC)
				  .addAnnotation(AnnotationSpec.builder(FindBy.class)
				  .addMember("value", value)
				  .build())
				  .build();
			return name;
	}

	/**
	 * Auto generated a class 
	 */
	public void generateCode(List<FieldSpec> elementFields, String className) {
		String classDirectory = System.getProperty("user.dir") + "/src/test/java";
		File outputFile = new File(classDirectory);
		TypeSpec PageObjectClass =  TypeSpec.classBuilder(className)
				                    .addModifiers(Modifier.PUBLIC)
				                    .superclass(GenericPageObject.class)
				                    .addFields(elementFields)
				                    .build();				 
		JavaFile javaFile = JavaFile
				  .builder("com.adp.tlmbdd.pages.objects", PageObjectClass)
				  .indent("    ")
				  .build();				 
				try {
					javaFile.writeTo(outputFile);
					System.out.println("A class name "+className+ " is generated at com.adp.tlmbdd.pages.objects package. "
							          + "Extend this class to access all it's Web Elements.");
				} catch (IOException e) {
					System.out.println("File not found!");
				}
	}

	public static void main(String[] args) {
		PageCodeGenerator generator = new PageCodeGenerator();
		generator.generateClassFromJsonFile(args[0]);
	}
}
