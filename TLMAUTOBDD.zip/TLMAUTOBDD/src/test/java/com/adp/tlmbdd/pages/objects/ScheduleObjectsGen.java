package com.adp.tlmbdd.pages.objects;

import com.adp.tlmbdd.pages.GenericPageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class ScheduleObjectsGen extends GenericPageObject {
    @FindBy(xpath ="//*[@id='timepair.0.6.0']")
    public WebElementFacade firstShiftCellTimePair;

    @FindBy(xpath ="//*[@id='SchedulingCalendar_SchedulingGrid.0.4']")
    public WebElementFacade shiftcell;

    @FindBy(xpath ="//button[@id='mastheadGlobalOptions']")
    public WebElementFacade loggedUserName;

    @FindBy(xpath ="//div[@id='SchedulingCalendarEAPFeatureFeedbackMessage']//span[.='LIKE THE CHANGE? LET US KNOW']")
    public WebElementFacade likeTheChangeLink;

    @FindBy(xpath ="//*[@id='parentLink.0.4']")
    public WebElementFacade addShiftIcon;

    @FindBy(xpath ="//*[@id=' AddEditDialog.0.4']")
    public WebElementFacade addEditDialog;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.InTime.input']")
    public WebElementFacade addShiftIntime;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.OutTime.input']")
    public WebElementFacade addShiftOutTime;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.PayCode.input']")
    public WebElementFacade addShiftPayCode;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.LunchPlan.input']")
    public WebElementFacade addShiftLunchPlan;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.Department.input']")
    public WebElementFacade addShiftDepartment;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.Location.input']")
    public WebElementFacade addShiftLocation;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.Job.input']")
    public WebElementFacade addShiftJob;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.ReasonCode.input']")
    public WebElementFacade addShiftReasonCode;

    @FindBy(xpath ="//textarea[@id='SchedulingCalendarAddEditDialog.Notes.textArea']")
    public WebElementFacade addShiftNote;

    @FindBy(xpath ="//button[@id='SchedulingCalendarAddEditDialog.Save']")
    public WebElementFacade addShiftSave;

    @FindBy(xpath ="//div[@id='shift.0.4']")
    public WebElementFacade addedShift;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.Find']")
    public WebElementFacade findButton;

    @FindBy(xpath ="//*[@id='SchedulingCalendar.Print']")
    public WebElementFacade printIcon;

    @FindBy(xpath ="//div[@id='timepair.0.4.0']//i[contains(@class, 'edit')]")
    public WebElementFacade editIcon;

    @FindBy(xpath ="//div[@id='timepair.0.4.0']//i[contains(@class, 'delete')]")
    public WebElementFacade deleteIcon;

    @FindBy(xpath ="//button[@id='SchedulingCalendarDeleteDialog.DeleteButton']")
    public WebElementFacade confirmDeleteDialogYesButton;

    @FindBy(xpath ="//div[@id='SchedulingCalendarAddEditDialog.PayCode.option.0']")
    public WebElementFacade payCodeLookupOption;

    @FindBy(xpath ="//div[@id='SchedulingCalendarAddEditDialog.LunchPlan.option.0']")
    public WebElementFacade lunchPlanLookupOption;

    @FindBy(xpath ="//div[@id='SchedulingCalendarAddEditDialog.Department.option.0']")
    public WebElementFacade shiftAddLookupOption;

    @FindBy(xpath ="//div[@id='SchedulingCalendarAddEditDialog.Location.option.0']")
    public WebElementFacade shiftAddLocationOption;

    @FindBy(xpath ="//div[@id='SchedulingCalendarAddEditDialog.Job.option.0']")
    public WebElementFacade shiftAddJobOption;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.btnNewAction']")
    public WebElementFacade actionBarAddShiftLink;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.btnEditAction']")
    public WebElementFacade actionBarEditShiftLink;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.btnDeleteAction']")
    public WebElementFacade actionBarDeleteShiftLink;

    @FindBy(xpath ="//input[@id='inLineEditInTime']")
    public WebElementFacade inLineEditInTime;

    @FindBy(xpath ="//input[@id='inLineEditOutTime']")
    public WebElementFacade inLineEditOutTime;

    @FindBy(xpath ="//input[@id='SchedulingCalendar.Search']")
    public WebElementFacade employeeSearchTextBox;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.SchedulingGrid.HeaderLabel.1']")
    public WebElementFacade employeeCount;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.Search.button']")
    public WebElementFacade employeeSearchIcon;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.CalendarView.wrapper']")
    public WebElementFacade scheduleDateDropDown;

    @FindBy(xpath ="//input[@id='SchedulingCalendar.StartDateBox']")
    public WebElementFacade scheduleStartDateInput;

    @FindBy(xpath ="//input[@id='SchedulingCalendar.EndDateBox']")
    public WebElementFacade scheduleEndDateInput;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.Next']")
    public WebElementFacade nextDateRowArrowIcon;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.Previous']")
    public WebElementFacade previousDateRowArrowIcon;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.Find']")
    public WebElementFacade scheduleFindButton;

    @FindBy(xpath ="//i[@id='SchedulingCalendar.StartDateBox.icon']")
    public WebElementFacade startDateCalendarIcon;

    @FindBy(xpath ="//i[@id='SchedulingCalendar.EndDateBox.icon']")
    public WebElementFacade endDateCalendarIcon;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.CalendarView.button']")
    public WebElementFacade dateShortCutDropDown;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.StartDateBox.cp_month_display']/span")
    public WebElementFacade calendarStartDatMonth;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.EndDateBox.cp_month_display']/span")
    public WebElementFacade calendarEndDateMonth;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.StartDateBox.cp_year_display']/span")
    public WebElementFacade calendarStartDateYear;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.EndDateBox.cp_year_display']/span")
    public WebElementFacade calendarEndDateYear;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.StartDateBox.cp_calendar']//div[@class='cp_sel_date']")
    public WebElementFacade calendarStartDateDay;

    @FindBy(xpath ="//div[@class='SchedulingCalendar_SchedulingGridheader2']")
    public WebElementFacade firstDayCellHeader;

    @FindBy(xpath ="//div[@class='SchedulingCalendar_SchedulingGridheader15']")
    public WebElementFacade lastDayCellHeader;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.SchedulingGridUnlockedRowsOuter']/div[@class='ps__rail-x']")
    public WebElementFacade horizontalScrollBar;

    @FindBy(xpath ="//div[@id='statusTooltip']")
    public WebElementFacade dateErrorMsgDialog;

    @FindBy(xpath ="//div[@class='reactVDL messageText errorMessageText']")
    public WebElementFacade scheduleErrorMsgDiv;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.StartDateBox.cp_toolbar']/div[contains(@class, 'left')]")
    public WebElementFacade calendarStartDatePreviousMonthArrow;

    @FindBy(xpath ="//div[@id='SchedulingCalendar.EndDateBox.cp_toolbar']/div[contains(@class, 'right')]")
    public WebElementFacade calendarEndDateNextMonthArrow;

    @FindBy(xpath ="//button[@id='action-0-0']")
    public WebElementFacade rowGrabberMenu1;

    @FindBy(xpath ="//span[text() ='Schedule Audit']")
    public WebElementFacade rowGrabberMenuScheduleAuditOption;

    @FindBy(xpath ="//button[@id='ScheduleAuditSlideIn_Close']")
    public WebElementFacade scheduleAuditSliderBackButton;

    @FindBy(xpath ="//input[@id='SchedulingTemplateVersionAddEditDialog.TemplateVersionEffectiveDate']")
    public WebElementFacade templateEditEffectiveDateInput;

    @FindBy(xpath ="//button[@id='SchedulingTemplateVersionAddEditDialog.DoneButton']")
    public WebElementFacade templateEnterEffectiveDateDialogDoneButton;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.Template']")
    public WebElementFacade scheduleTemplateLink;

    @FindBy(xpath ="//button[@id='SchedulingTemplateList.NewTemplate']")
    public WebElementFacade createNewTemplateButton;

    @FindBy(xpath ="//input[@id='SchedulingTemplateCreator.TemplateName']")
    public WebElementFacade templateNameInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateCreator.TemplateDescription']")
    public WebElementFacade templateDescriptionInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateCreator.TemplateVersionsView_0.TemplateStartDate']")
    public WebElementFacade templateStartDateInput;

    @FindBy(xpath ="//button[@id='SchedulingTemplateCreator.TemplateSave']")
    public WebElementFacade SaveTemplateButton;

    @FindBy(xpath ="//a[@id='parentLink.0.2']")
    public WebElementFacade templateAddShiftIcon;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.InTime.input']")
    public WebElementFacade templateAddShiftStartTimeInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.OutTime.input']")
    public WebElementFacade templateAddShiftEndTimeInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.PayCode.input']")
    public WebElementFacade templateAddShiftPayCodeInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.Department.input']")
    public WebElementFacade templateAddShiftDepartmentInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.Job.input']")
    public WebElementFacade templateAddShiftJobInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.Location.input']")
    public WebElementFacade templateAddShiftLocationInput;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.Department.input']")
    public WebElementFacade templateAddDepartmentLookUpOption;

    @FindBy(xpath ="//div[@id='SchedulingTemplateAddEditDialog.Job.option.0']")
    public WebElementFacade templateAddJobLookUpOption;

    @FindBy(xpath ="//div[@id='SchedulingTemplateAddEditDialog.PayCode.option.0']")
    public WebElementFacade templateAddPaycodeLookUpOption;

    @FindBy(xpath ="//div[@id='SchedulingTemplateAddEditDialog.Location.option.0']")
    public WebElementFacade templateAddLocationLookUpOption;

    @FindBy(xpath ="//input[@id='SchedulingTemplateAddEditDialog.LunchPlan.input']")
    public WebElementFacade templateAddShiftMealPlanInput;

    @FindBy(xpath ="//button[@id='SchedulingTemplateAddEditDialog.Save']")
    public WebElementFacade templateAddShiftSaveButton;

    @FindBy(xpath ="//button[@id='SchedulingTemplateCreator.TemplateVersionsView_0.DeleteRecordButton']")
    public WebElementFacade templateDeleteRecord;

    @FindBy(xpath ="//button[contains(@id,'.yesButton')]")
    public WebElementFacade confirmTemplateDeleteButton;

    @FindBy(xpath ="//span[.='View Schedule Template Audit']")
    public WebElementFacade templateRowGrabberAuditOptionLink;

    @FindBy(xpath ="//div[@id='ScheduleTemplateAuditOverviewSlideIn_Title']/div")
    public WebElementFacade templateAuditSlideInTitle;

    @FindBy(xpath ="//button[@id='SchedulingTemplateToolTipDialog.Add']")
    public WebElementFacade editTemplateAddShiftLink;

    @FindBy(xpath ="//button[@id='SchedulingTemplateToolTipDialog.Delete']")
    public WebElementFacade editTemplateDeleteShiftLink;

    @FindBy(xpath ="//button[@id='SchedulingTemplateToolTipDialog.Edit']")
    public WebElementFacade editTemplateEditShiftLink;

    @FindBy(xpath ="//button[@id='SchedulingTemplateDeleteDialog.DeleteButton']")
    public WebElementFacade editTemplateConfirmShiftDelete;

    @FindBy(xpath ="//button[@id='ScheduleTemplateAuditOverviewSlideIn_Close']")
    public WebElementFacade templateAuditPageBackButton;

    @FindBy(xpath ="//span[text() ='Schedule Audit']")
    public WebElementFacade scheduleAuditTitle;

    @FindBy(xpath ="//div[.='Edit Type']/following::div[contains(@class, 'column-0')]")
    public WebElementFacade scheduleEditTypeColumn;

    @FindBy(xpath ="//div[.='Old Start Time']/following::div[contains(@class, 'column-3')]")
    public WebElementFacade scheduleOldStartTimeColumn;

    @FindBy(xpath ="//div[.='New Start Time']/following::div[contains(@class, 'column-4')]")
    public WebElementFacade scheduleNewStartTimeColumn;

    @FindBy(xpath ="//div[.='Old End Time']/following::div[contains(@class, 'column-5')]")
    public WebElementFacade scheduleOldEndTimeColumn;

    @FindBy(xpath ="//div[.='New End Time']/following::div[contains(@class, 'column-6')]")
    public WebElementFacade scheduleNewEndTimeColumn;

    @FindBy(xpath ="//div[.='Old Department']/following::div[contains(@class, 'column-7')]")
    public WebElementFacade scheduleOldDepartmentColumn;

    @FindBy(xpath ="//div[.='New Department']/following::div[contains(@class, 'column-8')]")
    public WebElementFacade scheduleNewDepartmentColumn;

    @FindBy(xpath ="//div[@title='Edit Type']//span")
    public WebElementFacade editColumnSortIcon;

    @FindBy(xpath ="//div[@title='Old Department']//span")
    public WebElementFacade oldDepartmentColumnSortIcon;

    @FindBy(xpath ="//a[@id='SchedulingTemplateList.ViewDeleteAuditLink']")
    public WebElementFacade viewDeleteAuditLink;

    @FindBy(xpath ="//button[@id='ScheduleTemplateDeleteAuditSlideIn_Close']")
    public WebElementFacade viewDeleteAuditCloseButton;

    @FindBy(xpath ="//div[contains(@class,'mdf-grid-cell')][contains(@class,'column-0')]")
    public WebElementFacade viewDeleteAuditTemplateNameColumn;

    @FindBy(xpath ="//div[contains(@class,'mdf-grid-cell')][contains(@class,'column-1')]")
    public WebElementFacade viewDeleteAuditDeletedDateColumn;

    @FindBy(xpath ="//div[contains(@class,'mdf-grid-cell')][contains(@class,'column-2')]")
    public WebElementFacade viewDeleteAuditDeletedByColumn;

    @FindBy(xpath ="//div[@title='Day of Week']/span")
    public WebElementFacade viewDeleteAuditDetailsDaySortIcon;

    @FindBy(xpath ="//div[@title='Edit Type']/span")
    public WebElementFacade viewDeleteAuditDetailsEditTypeSortIcon;

    @FindBy(xpath ="//span[.='View Audit']/..")
    public WebElementFacade viewDeleteAuditDetailLink;

    @FindBy(xpath ="//*[@id='wfn_body']/div[18]/div/div[2]/div/div/div[1]/button")
    public WebElementFacade viewDeleteAuditDetailsCloseButton;

    @FindBy(xpath ="//span[@class='vdl-slide-in-title']")
    public WebElementFacade scheduleTemplateAuditTitle;

    @FindBy(xpath ="//div[@class='vdl-slide-in-header']/button")
    public WebElementFacade scheduleTemplateAuditCloseButton;

    @FindBy(xpath ="//span[.='View Details']/..")
    public WebElementFacade scheduleTemplateAuditViewDetailsLink;

    @FindBy(xpath ="//div[@class='details-template-name']")
    public WebElementFacade scheduleTemplateAuditDetailsTemplateName;

    @FindBy(xpath ="//label[.='Changed By']/following::label[2]")
    public WebElementFacade scheduleTemplateAuditDetailsChangedBy;

    @FindBy(xpath ="//div[.='Template Description']/following::div[1]")
    public WebElementFacade scheduleTemplateAuditDetailsEditType;

    @FindBy(xpath ="//div[.='Template Description']/following::div[2]")
    public WebElementFacade scheduleTemplateAuditDetailsOldDesc;

    @FindBy(xpath ="//div[.='Template Description']/following::div[3]")
    public WebElementFacade scheduleTemplateAuditDetailsNewDesc;

    @FindBy(xpath ="//div[contains(@class,'mdf-grid-cell')][contains(@class,'column-4')]")
    public WebElementFacade scheduleTemplateAuditEffDateColumn;

    @FindBy(xpath ="//div[contains(@class,'mdf-grid-cell')][contains(@class,'column-5')]")
    public WebElementFacade scheduleTemplateAuditDescColumn;

    @FindBy(xpath ="//div[.='Changed Date']/span")
    public WebElementFacade scheduleTemplateAuditChangedDateSortIcon;

    @FindBy(xpath ="//div[.='Effective Date']/span")
    public WebElementFacade scheduleTemplateAuditEffDateSortIcon;

    @FindBy(xpath ="//div[.='Description']/span")
    public WebElementFacade scheduleTemplateAuditDescriptionSortIcon;

    @FindBy(xpath =" //button[.='Back']")
    public WebElementFacade closeSlideInButton;

    @FindBy(xpath ="//iframe[@id='frmEmployeeInformationId']")
    public WebElementFacade empInfoIframe;

    @FindBy(xpath ="//span[@id='txtUserFirstName']")
    public WebElementFacade empInfoFirstName;

    @FindBy(xpath ="//span[@id='txtUserLastName']")
    public WebElementFacade empInfoLastName;

    @FindBy(xpath ="//span[@id='txtPositionPayGroup']")
    public WebElementFacade empInfoPayClass;

    @FindBy(xpath ="//span[@id='txtPositionSupervisor']")
    public WebElementFacade empInfoSupervisor;

    @FindBy(xpath ="//span[@id='txtPaycycle']")
    public WebElementFacade empInfoPayCycle;

    @FindBy(xpath ="//span[@id='btnPrint']")
    public WebElementFacade empInfoPrintIcon;

    @FindBy(xpath ="//button[@id='SchedulingCalendarEmpInfoDialog.slideIn_Close']")
    public WebElementFacade empInfoBackButton;

    @FindBy(xpath ="//div[@id='SchedulingCalendarPositionNotesView.EmployeeHeader.wrapper']")
    public WebElementFacade viewAllNotesEmpName;

    @FindBy(xpath ="//div[@id='SchedulingCalendarPositionNotesView.EmployeeHeaderDates.wrapper']")
    public WebElementFacade viewAllNotesDateRange;

    @FindBy(xpath ="//button[@id='ViewAllNotesSlideIn_Close']")
    public WebElementFacade viewAllBackButton;

    @FindBy(xpath ="//div[@class = 'se-error-list']")
    public WebElementFacade overLapErrorDialog;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.More']")
    public WebElementFacade scheduleMoreLink;

    @FindBy(xpath ="//a[@id='MoreOptions.QuickShiftLink']")
    public WebElementFacade quickShiftLink;

    @FindBy(xpath ="//a[@id='Add']")
    public WebElementFacade addQuickShift;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.ShiftName']")
    public WebElementFacade quickShiftName;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.QStartTime.input']")
    public WebElementFacade quickShiftInTime;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.QEndTime.input']")
    public WebElementFacade quickShiftOutTime;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.QPayCode.input']")
    public WebElementFacade quickShiftPayCode;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.QLunchPlan.input']")
    public WebElementFacade quickShiftMealPlan;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.QDepartment.input']")
    public WebElementFacade quickShiftDepartment;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.QJob.input']")
    public WebElementFacade quickShiftJob;

    @FindBy(xpath ="//input[@id='AddEditQuickShiftDialog.QLocation.input']")
    public WebElementFacade quickShiftLocation;

    @FindBy(xpath ="//button[@id='AddEditQuickShiftDialog.QDone']/span")
    public WebElementFacade quickShiftDoneButton;

    @FindBy(xpath ="//div[@id='AddEditQuickShiftDialog.QDepartment.option.0']")
    public WebElementFacade quickShiftDeptDropDownOption;

    @FindBy(xpath ="//div[@id='AddEditQuickShiftDialog.QPayCode.option.0']")
    public WebElementFacade quickShiftPaycodeDropDownOption;

    @FindBy(xpath ="//div[@id='AddEditQuickShiftDialog.QJob.option.0']")
    public WebElementFacade quickShiftJobDropDownOption;

    @FindBy(xpath ="//div[@id='AddEditQuickShiftDialog.QLocation.option.0']")
    public WebElementFacade quickShiftLocationDropDownOption;

    @FindBy(xpath ="//div[contains(@id,'Confirmation.Pane')]//button[.='YES']")
    public WebElementFacade quickShiftConfirmDelete;

    @FindBy(xpath ="//div[@id='SchedulingCalendarMonthlyView.viewHeader_0.txtFullName.wrapper']")
    public WebElementFacade monthlyScheduleEmpName;

    @FindBy(xpath ="//div[@id='SchedulingCalendarMonthlyView.MonthWeekToggleButton.wrapper']")
    public WebElementFacade monthlyScheduleWeekMonthSchedule;

    @FindBy(xpath ="//button[@id='SchedulingCalendarMonthlyView.btnPrevMonth']")
    public WebElementFacade monthlySchedulePreviousMonth;

    @FindBy(xpath ="//div[@id='SchedulingCalendarMonthlyView.txtCurrentDate.wrapper']")
    public WebElementFacade monthlyScheduleCurrentDate;

    @FindBy(xpath ="//button[@id='SchedulingCalendarMonthlyView.btnNextMonth']")
    public WebElementFacade monthlyScheduleNextMonth;

    @FindBy(xpath ="//button[@id='SchedulingCalendarMonthlyView.slideIn_Close']")
    public WebElementFacade monthlyScheduleCloseButton;

    @FindBy(xpath ="//button[@id='SchedulingCalendarMonthlyView.slideIn_Close']")
    public WebElementFacade monthlyScheduleShiftPayCode;

    @FindBy(xpath ="//div[@id='ShiftSwapToolTipID_Title']/div")
    public WebElementFacade monthlyScheduleShiftDetailsHeader;

    @FindBy(xpath ="//button[@id='ShiftSwapToolTip.Close']")
    public WebElementFacade monthlyScheduleShiftDetailsClose;

    @FindBy(xpath ="//div[@id='ShiftSwapToolTip.ShiftTime.wrapper']")
    public WebElementFacade monthlyScheduleShiftDetailsTime;

    @FindBy(xpath ="//div[@class ='TLMEmpHorizontakWeekView']//th[.='Time']")
    public WebElementFacade monthlyScheduleWeekView;

    @FindBy(xpath ="//div[@id='TimecardSlideIn_Title']/div")
    public WebElementFacade individualTimecardHeader;

    @FindBy(xpath ="//a[@id='aSch']")
    public WebElementFacade individualTimecardScheduleTab;

    @FindBy(xpath ="//a[@id='aTor']")
    public WebElementFacade individualTimecardTOR;

    @FindBy(xpath ="//div[@id='widget_dateRangeselect']")
    public WebElementFacade individualTimecardDateRangeSelection;

    @FindBy(xpath ="//div[@id='widget_dateRangeselect']")
    public WebElementFacade individualTimecardTimeOffBalanceTable;

    @FindBy(xpath ="//div[@class='Editable'][contains(@id,'_Value')]")
    public WebElementFacade individualTimecardHour;

    @FindBy(xpath ="//span[@id='btnSubmit']")
    public WebElementFacade individualTimecardSaveButton;

    @FindBy(xpath ="//div[.='Operation Successful.']")
    public WebElementFacade individualTimecardOperationSuccessful;

    @FindBy(xpath ="//button[@id='TimecardSlideIn_Close']")
    public WebElementFacade individualTimecardBackButton;

    @FindBy(xpath ="//div[@id='widget_dateRangeselect']//input")
    public WebElementFacade individualTimecardDropDown;

    @FindBy(xpath ="//input[@id='dateRangestart']")
    public WebElementFacade individualTimecardStartDate;

    @FindBy(xpath ="//input[@id='dateRangeend']")
    public WebElementFacade individualTimecardEndDate;

    @FindBy(xpath ="//div[@class='Schedule'][contains(@id,'_Value')]")
    public WebElementFacade individualTimecardScheduleHourValue;

    @FindBy(xpath ="//a[@id='aPay']")
    public WebElementFacade individualTimecardTotalsTab;

    @FindBy(xpath ="//td[@class = 'NumericValuePayCode']")
    public WebElementFacade individualTimecardTotalsTabTotalValue;

    @FindBy(xpath ="//input[@id='asOfDate']")
    public WebElementFacade timeOffBalancesAsOfDate;

    @FindBy(xpath ="//button[@id='SchedulingCalendarTimeOffBalancesView.slideIn_Close']")
    public WebElementFacade timeOffBalancesBackButton;

    @FindBy(xpath ="//div[@id='SchedulingCalendarTimeOffBalancesView.slideIn_Title']/div")
    public WebElementFacade timeOffBalancesTitle;

    @FindBy(xpath ="//iframe[@id='timeOffBalances']")
    public WebElementFacade timeOffBalancesIframe;

    @FindBy(xpath ="//table[@id='myTimeOffBalanceGrid_table']")
    public WebElementFacade timeOffBalancesTable;

    @FindBy(xpath ="//div[@id='SchedulingCalendarPreferenceDialog.ShiftsBy.node_0.radio']")
    public WebElementFacade preferenceViewShiftByStartTime;

    @FindBy(xpath ="//div[@id='SchedulingCalendarPreferenceDialog.ShiftsBy.node_1.radio']")
    public WebElementFacade preferenceViewShiftByHours;

    @FindBy(xpath ="//a[@id='MoreOptions.Preference']")
    public WebElementFacade morePreferenceLink;

    @FindBy(xpath ="//button[@id='SchedulingCalendarPreferenceDialog.apply']")
    public WebElementFacade preferenceApplyButton;

    @FindBy(xpath ="//span[@class='Shift-name'][contains(.,'QS00')]/..")
    public WebElementFacade quickShiftQS00;

    @FindBy(xpath ="//span[@class='Shift-name'][contains(.,'QS00')]/..//div[@class = 'Delete-Icon']")
    public WebElementFacade quickShiftQS00Delete;

    @FindBy(xpath ="//input[@id='OnlineScheduling.Locations.input']")
    public WebElementFacade locationSearchInput;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.btnClearAllAction']")
    public WebElementFacade actionBarClearAll;

    @FindBy(xpath ="//button[@id='AddEditQuickShiftDialog.QCancel']")
    public WebElementFacade quickShiftCancel;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.CopyButton']")
    public WebElementFacade actionBarCopyShiftLink;

    @FindBy(xpath ="//button[@id='SchedulingCalendar.PasteButton']")
    public WebElementFacade actionBarPasteShiftLink;

    @FindBy(xpath ="//button[@id = 'SchedulingAssignmentDialog.btnNext']")
    public WebElementFacade nextScheduleAssignment;

    @FindBy(xpath ="//span[@id = 'SchedulingAssignmentSetDates.btnSetMultiple.label']")
    public WebElementFacade setDateRangeForEmployees;

    @FindBy(xpath ="//button[@id= 'SchedulingAssignmentSetDates.btnSubmit']")
    public WebElementFacade submitSchedulingAssignmentDates;

    @FindBy(xpath ="//button[@id= 'SchedulingTemplateList.slideIn_Close']")
    public WebElementFacade closeBtn;

    @FindBy(xpath ="//button[@id= 'SchedulingAssignment_Close']")
    public WebElementFacade closeManageAssignments;

    @FindBy(xpath ="//*[@id= 'SchedulingCalendar.Template.label']")
    public WebElementFacade templateBtn;

    @FindBy(xpath ="//div[@id='SchedulingAssignmentSetMultiDateDialog.StartDateToggle.wrapper']")
    public WebElementFacade startDateToggle;

    @FindBy(xpath ="//div[@id='SchedulingAssignmentSetMultiDateDialog.EndDateToggle.wrapper']")
    public WebElementFacade endDateToggle;

    @FindBy(xpath ="//div[@id='SchedulingAssignmentSetMultiDateDialog.StartDateToggle.wrapper']/div")
    public WebElementFacade startDateToggleSwitch;

    @FindBy(xpath ="//div[@id='SchedulingAssignmentSetMultiDateDialog.EndDateToggle.wrapper']/div")
    public WebElementFacade endDateToggleSwitch;

    @FindBy(xpath ="//input[@id='SchedulingAssignmentSetMultiDateDialog.txtStartDate']")
    public WebElementFacade startDateSchedulingAssignment;

    @FindBy(xpath ="//input[@id='SchedulingAssignmentSetMultiDateDialog.txtEndDate']")
    public WebElementFacade endDateSchedulingAssignment;

    @FindBy(xpath ="//button[@id='SchedulingAssignmentSetMultiDateDialog.btnApplyAll']")
    public WebElementFacade applyAllSchedulingAssignment;

    @FindBy(xpath ="//button[@id= 'SchedulingAssignmentDialog.btnRemoveAssignments']")
    public WebElementFacade removeAssignments;

    @FindBy(xpath ="//div[@id= 'SchedulingShiftsDeleteDialog.DeleteShiftsRadioMulti.node_0.radio']")
    public WebElementFacade removeCurrentShifts;

    @FindBy(xpath ="//button[@id= 'SchedulingShiftsDeleteDialog.Delete']")
    public WebElementFacade schedulingShiftsDelete;

    @FindBy(xpath ="//button[@id= 'SchedulingAssignment_Close']")
    public WebElementFacade schedulingAssignmentClose;

    @FindBy(xpath ="//span[@id = 'SchedulingAssignmentDialog.EmployeeGrid.selectAll.0.icon']")
    public WebElementFacade selectAllEmployees;

    @FindBy(xpath ="//button[@id = 'SchedulingTemplateList.slideIn_Close']")
    public WebElementFacade templateListClose;

    @FindBy(xpath ="//div[@class = 'reactVDL messageText errorMessageText']")
    public WebElementFacade overlapErrorMessage;

    @FindBy(xpath ="//button[@id='SchedulingTemplateCreator.TemplateCancel']")
    public WebElementFacade cancelButton;

    @FindBy(xpath ="//button[@id='SchedulingTemplateCreator.btnAssignment']")
    public WebElementFacade manageAssignments;

    @FindBy(xpath ="//input[@id = 'SchedulingTemplateCreator.TemplateStatusCombo.input']")
    public WebElementFacade templateStatus;

    @FindBy(xpath ="//input[@id = 'SchedulingTemplateCreator.TemplateAccessCombo.input']")
    public WebElementFacade templateAccess;

    @FindBy(xpath ="//button[@id = 'SchedulingTemplateCreator.btnBack']")
    public WebElementFacade templateCreatorBackButton;

    @FindBy(xpath ="//div[@class = 'reactVDL messageText errorMessageText']")
    public WebElementFacade schedulingAssignmentsDateErrorMsg;

    @FindBy(xpath ="//div[@id = 'SchedulingAssignmentDialog.chkFilterRows.wrapper']/div")
    public WebElementFacade assignedOnlyToggleSwitch;

    @FindBy(xpath ="//button[@id = 'SchedulingAssignmentDialog.btnCancel']")
    public WebElementFacade schedulingAssignmentCancel;

    @FindBy(xpath ="//input[@id='SchedulingCalendar.Search']")
    public WebElementFacade searchByName;

    @FindBy(xpath ="//*[@id='SchedulingCalendar_SchedulingGrid.0.1']")
    public WebElementFacade selfShiftCell;

    @FindBy(xpath ="//button[@id='mastheadGlobalOptions']")
    public WebElementFacade username;

    @FindBy(xpath ="//*[@id='Employee.Footer.Icon']")
    public WebElementFacade moreIcon;

    @FindBy(xpath ="//*[@id='Footer-Employee-Totals-Main']")
    public WebElementFacade totlHours;

    @FindBy(xpath ="//*[@id='Employee.Footer.1.1']")
    public WebElementFacade totalWorkedHours;

    @FindBy(xpath ="//*[@id='Employee.Footer.1.4']")
    public WebElementFacade employeeWorkedHours;

    @FindBy(xpath ="//*[@id='SchedulingCalendar.RetrieveSchedules.button']")
    public WebElementFacade downButton;

    @FindBy(xpath ="//input[@id='SchedulingCalendarAddEditDialog.PayCode.input']")
    public WebElementFacade payCode;

    @FindBy(xpath ="//*[@id='SchedulingCalendarAddEditDialog.PayCode.option.0']")
    public WebElementFacade paySelect;

    @FindBy(xpath ="//*[@id='Employee.Footer.2.4']")
    public WebElementFacade employeeNonWorkedHours;

    @FindBy(xpath ="//*[@id='Employee.Footer.2.1']")
    public WebElementFacade totalNonWorkedHours;

    @FindBy(xpath ="//*[@id='Employee.Footer.3.1']")
    public WebElementFacade totalShifts;

    @FindBy(xpath ="//*[@id='Employee.Footer.4.1']")
    public WebElementFacade totalWorkedShifts;

    @FindBy(xpath ="//*[@id='Employee.Footer.4.4']")
    public WebElementFacade employeeWorkedShift;

    @FindBy(xpath ="//*[@id='Employee.Footer.5.1']")
    public WebElementFacade totalNonWorkedShifts;

    @FindBy(xpath ="//*[@id='Employee.Footer.5.4']")
    public WebElementFacade employeeNonWorkedShifts;

    @FindBy(xpath ="//input[@id='SchedulingCalendar.RetrieveSchedules.input']")
    public WebElementFacade employeeFilter;

    @FindBy(xpath ="//*[@id='SchedulingCalendar.RetrieveSchedules.option.1']")
    public WebElementFacade scheduledEmployees;

    @FindBy(xpath ="//*[@id='SchedulingCalendar.RetrieveSchedules.option.2']")
    public WebElementFacade nonShceduledEmployees;

    @FindBy(xpath ="//div[contains(@id, 'timepair')]")
    public WebElementFacade checkSchedule;

    @FindBy(xpath ="//input[@id='searchBox']")
    public WebElementFacade clientName;

    @FindBy(xpath ="//*[@class='uaClientId']")
    public WebElementFacade searchResults;

    @FindBy(xpath ="//*[@class='uaActionList']/li[1]")
    public WebElementFacade selection;

    @FindBy(xpath ="//*[@id='wfnnav_top_item_pracSetup']")
    public WebElementFacade setUpSelection;

    @FindBy(xpath ="//button[@class='wfnnav-sub-item'][2]")
    public WebElementFacade securityTab;

    @FindBy(xpath ="//button[@id='manage-profiles']")
    public WebElementFacade menuAccessTab;

    @FindBy(xpath ="//a[contains(.,'Standard Time and Attendance Supervisor')]")
    public WebElementFacade supervisor;

    @FindBy(xpath ="//li[contains(.,'My Team')]")
    public WebElementFacade myTeamTab;

    @FindBy(xpath ="//*[@class='fa neutral-dark fa-xs expand-icon ng-scope fa-plus-circle']")
    public WebElementFacade editPrivilegesMoreIcon;

    @FindBy(xpath ="//span[contains(.,'Schedules')]//..//..//span[contains(.,'Edit Privileges')]/..//i[1]")
    public WebElementFacade editPrivilegesChecked;

    @FindBy(xpath ="//span[contains(.,'Schedules')]//..//..//span[contains(.,'Edit Privileges')]")
    public WebElementFacade editPrivileges;

    @FindBy(xpath ="//span[contains(.,'Self Editing')]")
    public WebElementFacade selfEditing;

    @FindBy(xpath ="//span[contains(.,'Self Editing')]/..//i[1]")
    public WebElementFacade selfEditingCheckBoxChecked;

    @FindBy(xpath ="//span[contains(.,'Self Editing')]/..//i[2]")
    public WebElementFacade selfEditingCheckBoxUnChecked;

    @FindBy(xpath ="//input[@id='saveProfile']")
    public WebElementFacade savePrivileges;

    @FindBy(xpath ="////div[contains(@id, 'timepair')]")
    public WebElementFacade timePair;
}
