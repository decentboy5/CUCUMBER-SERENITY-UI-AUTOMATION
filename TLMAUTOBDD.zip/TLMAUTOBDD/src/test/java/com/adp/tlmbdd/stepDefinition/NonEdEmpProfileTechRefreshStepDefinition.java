package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.pages.editors.EmploymentProfileTechRefresh;
import com.adp.tlmbdd.steps.EmploymentProfileTechRefreshSteps;
import com.adp.tlmbdd.steps.NonEdEmpProfileTechRefreshSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;


public class NonEdEmpProfileTechRefreshStepDefinition {
	@Steps
	NonEdEmpProfileTechRefreshSteps nonemploymentProfileTechRefreshStep;
	EmploymentProfileTechRefreshSteps employmentProfileTechRefreshStep;


//Test 1
	
	@Then("^Validate The Employee \"([^\"]*)\" Non Effective dating Time Tile Fields using$")
	public void validate_The_Employee_Non_Effective_dating_Time_Tile_Fields_using(String employeeName) throws Throwable {
		nonemploymentProfileTechRefreshStep.ValidateTimeTile(employeeName);
		nonemploymentProfileTechRefreshStep.convertNonTimeToTime("Shaun");
		
	}
	//Test 2
	@Given("^I select a Non Time Employee \"([^\"]*)\"$")
	public void i_select_a_Non_Time_Employee(String employeeName) throws Throwable {
		nonemploymentProfileTechRefreshStep.ValidateTimeTile(employeeName);
		
		}

	

	@Then("^Add details on Time tile slide for Non Effective dating client including \"([^\"]*)\"  and convert it to Time Employee$")
	public void add_details_on_Time_tile_slide_for_Non_Effective_dating_client_including_and_convert_it_to_Time_Employee(String supervisor) throws Throwable {
		nonemploymentProfileTechRefreshStep.convertNonTimeToTime(supervisor);
	}
	
	//Test 3
	
	@Given("^I select a Time Employee$")
	public void i_select_a_Time_Employee() throws Throwable {
		nonemploymentProfileTechRefreshStep.selectTimeTile();
		}

	@Then("^Add update Time  employee on  slide for Non Effective dating client  and convert it to Non Time Employee$")
	public void add_update_Time_employee_on_slide_for_Non_Effective_dating_client_and_convert_it_to_Non_Time_Employee() throws Throwable {
		nonemploymentProfileTechRefreshStep.ConveertTimeToNonTime();		
		}
	
	//Test4
	
	@Then("^Add update Time  employee  To Supervisor$")
	public void add_update_Time_employee_To_Supervisor() throws Throwable {
		nonemploymentProfileTechRefreshStep.ConvertEmployeeToSupervisor();
	}	
	//Test5
	@Given("^I select a Time Supervisor$")
	public void i_select_a_Time_Supervisor() throws Throwable {
		nonemploymentProfileTechRefreshStep.selectTimeTile();
	}

	@Then("^Add update Time  Supervisor To Employee$")
	public void add_update_Time_Supervisor_To_Employee() throws Throwable {
		nonemploymentProfileTechRefreshStep.ConvertSupervisorToEmployee();
		}
	
	//Test6

@Then("^Add update Time  Shift rule and Time zone for the employee$")
public void add_update_Time_Shift_rule_and_Time_zone_for_the_employee() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}
	
	//Test7

@Then("^Add update Time Supervisor \"([^\"]*)\" for the employee$")
public void add_update_Time_Supervisor_for_the_employee(String supervisor) throws Throwable {
	nonemploymentProfileTechRefreshStep.NonTimeEditSupervisor(supervisor);
}

	//Test9

@Then("^Add Validate PayClass Summary$")
public void add_Validate_PayClass_Summary() throws Throwable {
	nonemploymentProfileTechRefreshStep.ValidatePayClassSummary();
    throw new PendingException();
}
	
	
//Prac read ony

@Given("^Select Time & Attendance Link for  Non ED Time Employee$")
public void select_Time_Attendance_Link_for_Non_ED_Time_Employee() throws Throwable {
	nonemploymentProfileTechRefreshStep.PracReadOnly();
    throw new PendingException();
}

//ManagerOnly
@Then("^Select Non ED  employee \"([^\"]*)\" and Validate Time Tile is not displayed$")
public void select_Non_ED_employee_and_Validate_Time_Tile_is_not_displayed(String manager) throws Throwable {
	nonemploymentProfileTechRefreshStep.ValidateManager(manager);
    throw new PendingException();
}

//Employee Login
@Given("^I login as WFN Employee user with \"([^\"]*)\" and \"([^\"]*)\"$")
public void i_login_as_WFN_Employee_user_with_and(String arg1, String arg2) throws Throwable {
	
	//Need to add step for Employee Login
    throw new PendingException();
}

//Supervisor only
@Then("^Validate Supervisor able to see Time tile and  is accessible and Read only$")
public void validate_Supervisor_able_to_see_Time_tile_and_is_accessible_and_Read_only() throws Throwable {
	nonemploymentProfileTechRefreshStep.ValidateSupervisor() ;
    throw new PendingException();
}

//superman only

@Then("^Validate Non ED Time Tile is  displayed as supervisor \"([^\"]*)\" and not for \"([^\"]*)\" as manager$")
public void validate_Non_ED_Time_Tile_is_displayed_as_supervisor_and_not_for_as_manager(String employee1, String employee2) throws Throwable {
	nonemploymentProfileTechRefreshStep.ValdiateSupermanAsManagerAndSupervisor(employee1, employee2);
    throw new PendingException();
}

//Employee only
@Given("^Validate Non ED  Time Tile is  displayed for Employee and Slidein is readOnly$")
public void validate_Non_ED_Time_Tile_is_displayed_for_Employee_and_Slidein_is_readOnly() throws Throwable {
	nonemploymentProfileTechRefreshStep.ValidateEmployee();
    throw new PendingException();
}


/*************/



	
}
