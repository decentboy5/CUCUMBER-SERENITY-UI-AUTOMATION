package com.adp.tlmbdd.pages;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import com.adp.tlmbdd.pages.GenericPageObject;
import com.adp.tlmbdd.pages.AdditionalConfiguration;



public class AdditionalConfiguration extends GenericPageObject{
	
    static String TimeConfig = org.joda.time.DateTime.now().toString("ss");


	@FindBy(xpath = "//td[text()='Company Preferences']")
	private WebElementFacade companyPreferences;
	
	@FindBy(xpath = "//td[text()='Work Day Rules']")
	private WebElementFacade workDayRules;
	
	@FindBy(xpath = "//td[text()='Pay Classes']")
	private WebElementFacade payClasses;
	
	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElement mainiframe;
	
	@FindBy(xpath = "//span[contains(text(),'ADD NEW')]")
	private WebElementFacade AddNewLinkMDF6;
	
	@FindBy(xpath = "//div[@class='vdl-textbox vdl-textbox--touched']/input")
	private WebElementFacade IDTextBoxMDF6;
	
	@FindBy(xpath = "//div[@class='vdl-textbox vdl-textbox--touched']/input[@id='desc']")
	private WebElementFacade DescTextBoxMDF6;
	
	@FindBy(xpath = "//button[@class='vdl-button vdl-button--primary']/span[contains(text(),'Submit')]")
	private WebElementFacade SubmitButtonMDF6;
	
	@FindBy(xpath = "//div[contains(text(),'Add')]")
	private WebElementFacade OperationSuccessfulAddMDF6;

	@FindBy(xpath = "//div[contains(text(),'Update')]")
	private WebElementFacade OperationSuccessfulUpdateMDF6;
	
	@FindBy(xpath = "//div[contains(text(),'Delet')]")
	private WebElementFacade OperationSuccessfulDeleteMDF6;
		
	
	@FindBy(xpath = "//input[@title='Search....']")
	private WebElementFacade SearchTextBoxMDF6;
	
	@FindBy(xpath = "//div[@class='vdl-row vdl-row mdf-grid-row']/div[2]/a")
	private WebElementFacade FirstRow;	
	
	@FindBy(xpath = "//td[text()='Timecard Accumulators']")
	private WebElementFacade timecardAccumulators;
	
	@FindBy(xpath = "//td[text()='Hour Distribution Rules']")
	private WebElementFacade HourDistributionRule;
	
	@FindBy(xpath = "//td[text()='Pay Codes']")
	private WebElement payCodes;
	
	
	public void clickCompanyPreferences()
	{
		selectFrame(mainiframe);
		companyPreferences.click();
		WaitForAjax();
		switchToDefaultContent();
		
	}
	
	public void clickWorkDayRules()
	{
		selectFrame(mainiframe);
		workDayRules.click();
		WaitForAjax();
		switchToDefaultContent();
		
	}
	
	public void clickPayClasses()
	{
		selectFrame(mainiframe);
		payClasses.click();
		WaitForAjax();
		switchToDefaultContent();
		
	}
	
	public void WFN_AddConfig_MDF6(String EditorName)
	{
		  String IdConfigAdd = EditorName.substring(0, 8) + TimeConfig; 
          String DescConfigAdd = "Desc" + EditorName + TimeConfig;
          AddNewLinkMDF6.click();
          IDTextBoxMDF6.sendKeys(IdConfigAdd);
          DescTextBoxMDF6.sendKeys(DescConfigAdd);
          SubmitButtonMDF6.click();
          waitABit(3000);
          OperationSuccessfulAddMDF6.waitUntilPresent();
          
	}
	
	public void WFN_UpdateConfig_MDF6(String EditorName)
	{
		String IdConfigAdd = EditorName.substring(0, 8) + TimeConfig; 
        String DescConfigAdd = "Desc" + EditorName + TimeConfig;
		SearchTextBoxMDF6.sendKeys(IdConfigAdd);       
        waitABit(2000);
        FirstRow.click();
        DescTextBoxMDF6.clear();
        DescTextBoxMDF6.sendKeys(DescConfigAdd + "Updated");
        SubmitButtonMDF6.click();
        OperationSuccessfulUpdateMDF6.waitUntilPresent();

	}
	
	public void WFN_DeleteConfig_MDF6(String EditorName)
	{
		String IdConfigAdd = EditorName.substring(0, 8) + TimeConfig; 
        String DescConfigAdd = "Desc" + EditorName + TimeConfig;
		SearchTextBoxMDF6.sendKeys(IdConfigAdd);       
        waitABit(2000);
        FirstRow.click();
        DescTextBoxMDF6.clear();
        DescTextBoxMDF6.sendKeys(DescConfigAdd + "Updated");
        SubmitButtonMDF6.click();
        OperationSuccessfulUpdateMDF6.waitUntilPresent();

	}
	
	public void clickTimecardAccumulators()
	{
		selectFrame(mainiframe);
		timecardAccumulators.click();
		WaitForAjax();
		switchToDefaultContent();
		
	}
	
	public void clickHourDistributionRules()
	{
		selectFrame(mainiframe);
		HourDistributionRule.click();
		WaitForAjax();
		switchToDefaultContent();
		
	}
	
	public void clickPayCodes()
	{
		WaitForAjax();
		waitForWebElementToLoad(mainiframe);
		selectFrame(mainiframe);
		waitForWebElementToLoad(payCodes);
		payCodes.click();
		WaitForAjax();
		switchToDefaultContent();
		
	}

}
