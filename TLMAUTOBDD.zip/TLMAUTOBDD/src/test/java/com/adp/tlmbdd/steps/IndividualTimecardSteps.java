package com.adp.tlmbdd.steps;

import java.util.List;

import com.adp.tlmbdd.pages.IndividualTimecard;

import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class IndividualTimecardSteps extends ScenarioSteps {
	IndividualTimecard individualTimecard;
	
	
	@Step
	public void searchForEmpOnIndividualTimecard(String empName) {
		individualTimecard.employeeSearch(empName);		
		}
	
	@Step
	public void checkDateOutCheckBox()
	{
		individualTimecard.checkDateOutCheckbox();
	}
	
	@Step
	public void uncheckDateOutCheckBox()
	{
		individualTimecard.uncheckDateOutCheckbox();
	}
	
	@Step
	public void verifyDateOutNotVisible()
	{
		individualTimecard.verifyDateOutNotVisible();
	}
	
	@Step
	public void verifyDateOutVisible()
	{
		individualTimecard.verifyDateOutVisible();
	}
	
	@Step
	public void enterTimePair(String hours,String payperiod,String paycode)
	{
		individualTimecard.enterTimePair(hours,payperiod,paycode);
	}
	
	@Step
	public void verifyTimepairProcessed()
	{
		individualTimecard.verifyTimePairSuccesfullyProcessed();
	}
	
	@Step
	public void verifyDateOutInIndividualTimecard(String datedifference)
	{
		individualTimecard.verifyDateOutInIndividualTimecard(datedifference);
	}
	
	@Step
	public void verifyDateOutInViewTransactionDetails()
	{
		individualTimecard.verifyDateOutInViewTransactionDetails();
	}
	
	@Step
	public void verifyDateOutInViewEditAudit()
	{
		individualTimecard.verifyDateOutInViewEditAudit();
	}
	
	@Step
	public void verifyDateOutInPrintTimecard()
	{
		individualTimecard.verifyDateOutInPrintTimecard();
	}
	
	@Step
	public void enterHoursInTimecard(String hours)
	{
		individualTimecard.enterHoursInCurrentPayPeriod(hours);
	}
	
	@Step
	public void verifymaxHoursInTimecard()
	{
		individualTimecard.verifyMaxHoursErrorMessage();
	}
	
	@Step
	public void enterDateRangeAndSearch()
	{
		individualTimecard.verifyMaxHoursErrorMessage();
	}
	
	@Step
	public void verifyDateOutEditable()
	{
		individualTimecard.verifyDateOutEditable();
	}
	
	@Step
	public void verifyDateOutNotEditable()
	{
		individualTimecard.verifyDateOutNotEditable();
	}
	
	@Step
	public void copyRow()
	{
		individualTimecard.CopyRow();
	}
	
	@Step
	public void copyRowToNextDate()
	{
		individualTimecard.CopyRowToNextDay();
	}
	
	@Step
	public void verifyCopiedRow(String copytype)
	{
		individualTimecard.verifyDetailsAfterRowCopied(copytype);
	}
	
	@Step
	public void transferTimeAndVerify()
	{
		individualTimecard.transferAndVerifyOutTime();
	}
	
	@Step
	public void clickViewTransactionDetails()
	{
		individualTimecard.ViewTransactionDetails();
	}
	
	@Step
	public void selectPayperiod(String payperiod)
	{
		individualTimecard.selectPayPeriod(payperiod);
	}

	@Step
	public void verifyTimecardStatus(String status) {
		individualTimecard.verifyStatusOfTimecard(status);
	}
	@Step
	public void removeApprovalOfTimecard() {
		individualTimecard.removeEmpApprovalOfTimecard();
		
	}
	
	@Step
	public void addNoteForEmployeeOnSpecificDate(String operation,String applynoteto,String date,String note)
	{
		individualTimecard.addNoteForEmployeeOnDate(operation,applynoteto, date, note);
	}
	

	@Step
	public void clickOnSubmitButton()
	{
		individualTimecard.clickOnSubmitButton();
	}
	
	@Step
	public void verifyNoteOnTimecard(String note,String date)
	{
		individualTimecard.verifyNote(note, date);
	}
	
	@Step
	public void enterTimePairOnSpecificDate(String punchType,String employeename,String punch,String date)
	{
		individualTimecard.enterTimePairOnSpecificDate(punchType, employeename, punch, date);
	}
	
	@Step
	public void addRowsOnIndividualTimecard(String rowcount,String date)
	{
		individualTimecard.addRowsOnIndividualTimecard(rowcount, date);
		
	}
	
	@Step
	public void enterMultipleTimePairOnSpecificDate(String punchType,String date,List<String> punches)
	{
		individualTimecard.enterMultipleTimePairOnSpecificDate(punchType, date, punches);
	}

}
