package com.adp.tlmbdd.pages;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.actions.selectactions.SelectByValueFromBy;

import com.adp.tlmbdd.common.CSVDataReader;
import com.adp.tlmbdd.common.PDFReader;
import com.adp.tlmbdd.pages.GenericPageObject;
import com.adp.tlmbdd.pages.Report;

public class Report extends GenericPageObject {

	@FindBy(xpath = "//label[text()='Report Name']")
	private WebElementFacade ReportNameText;

	@FindBy(xpath = "//*[text()='Report Name']/..//input")
	private WebElementFacade TextBoxtoEnterReportName;

	@FindBy(xpath = "//iframe[@id='adprIframe_iframe']")
	private WebElementFacade mainiframe;

	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElementFacade mainiframe_RunReportPage;

	@FindBy(xpath = "(//*[contains(@id,'reporting_form_DropDownButton')])[1]")
	private WebElementFacade LoadedReportConfirmation;

	@FindBy(xpath = "//span[contains(text(),'Meal Attestation Report')]")
	private WebElementFacade report_AfteFilter;

	@FindBy(xpath = "//*[@class='rptFilterPanelControls']/span[2]")
	private WebElementFacade filter_Button;

	@FindBy(xpath = "(//span[contains(text(),'Meal Attestation Report')]/following::span)[2]/span")
	private WebElementFacade threedotedlink_beforeRunReport;

	@FindBy(xpath = "//a[normalize-space(text()) = 'Run Now']")
	private WebElementFacade runNow_link;

	@FindBy(xpath = "//a[normalize-space(text()) = 'Run']")
	private WebElementFacade run_link;

	By report_Output_Dropdown = By.xpath("//*[@id='ddlReportOutput']");

	@FindBy(xpath = "//*[@id='ddlReportOutput']/option[text()='CSV']")
	private WebElementFacade report_CSV_Type;

	@FindBy(xpath = "//*[@id='btnRunReport']")
	private WebElementFacade RunButton_RunReportPage;

	@FindBy(xpath = "(//*[contains(@id,'reporting_form_DropDownButton_')]/span[1])[1]")
	private WebElementFacade threedotedlink_AfterRunReport;

	@FindBy(xpath = "//*[@class='dojoxGridContent']/div/div[1]//td[6]")
	private WebElementFacade ReportStatus;

	@FindBy(xpath = "//*[text()='Refresh']")
	private WebElementFacade RefreshLink;

	@FindBy(xpath = "//*[text()='View as PDF']")
	private WebElementFacade viewAsPDFlink;

	public void filterReport(String reportName) {

		try {

			System.out.println("");
			waitABit(15000);
			switchToDefaultContent();
			// mainiframe.waitUntilEnabled();
			waitForWebElementToEnable(mainiframe);
			selectFrame(mainiframe);
			WaitForPageLoad();
			waitForWebElementToEnable(LoadedReportConfirmation);

			TextBoxtoEnterReportName.click();
			TextBoxtoEnterReportName.typeAndTab(reportName);
			waitABit(2000);
			filter_Button.click();
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void verifyReportAfterSearch(String reportName) {

		try {

			waitForElementToLoad(report_AfteFilter);
			boolean flag = checkElementVisible(report_AfteFilter);
			if (!flag) {
				Assert.assertEquals(true, flag);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void runNowandVerifyItinOutputsection() {

		try {
			System.out.println(" ");
			threedotedlink_beforeRunReport.click();
			waitForElementToLoad(runNow_link);
			runNow_link.click();

			waitForElementToLoad(RefreshLink);
			String status = null;

			int i = 0;
			do {

				waitABit(10000);
				JsClick(RefreshLink);
				waitForWebElementToEnable(ReportStatus);
				status = ReportStatus.getText();
				i++;

				if (i >= 30) {
					System.out.println("Report Stuck at Processsing... please check Birt Report Processor");
					break;
				}
			} while (status.equalsIgnoreCase("Processing..."));

			threedotedlink_AfterRunReport.click();
			viewAsPDFlink.click();
			// Waiting for downloading the PDF
			waitABit(10000);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void RunWithSpecficFormatAndVerifyItinOutputsection(String ReportOutpoutType) {

		try {
			System.out.println("    ");
			switchToDefaultContent();
			waitForWebElementToEnable(mainiframe);
			selectFrame(mainiframe);

			threedotedlink_beforeRunReport.click();
			waitForElementToLoad(run_link);
			run_link.click();
			waitABit(10000);
			WaitForPageLoad();
			switchToDefaultContent();
			waitForWebElementToEnable(mainiframe_RunReportPage);
			selectFrame(mainiframe_RunReportPage);

			waitForElementToLoad(RunButton_RunReportPage);
			RunButton_RunReportPage.waitUntilClickable();
			if (ReportOutpoutType.equalsIgnoreCase("CSV")) {

				selectValueFromDropDownByVisibleText(report_Output_Dropdown, ReportOutpoutType);
			}
			RunButton_RunReportPage.click();
			waitABit(15000);
			switchToDefaultContent();
			waitForWebElementToEnable(mainiframe);
			selectFrame(mainiframe);
			String status = null;

			int i = 0;
			do {

				waitABit(5000);
				JsClick(RefreshLink);
				waitForWebElementToEnable(ReportStatus);
				status = ReportStatus.getText();
				i++;

				if (i >= 30) {
					System.out.println("Report Stuck at Processsing... please check Birt Report Processor");
					break;
				}
			} while (status.equalsIgnoreCase("Processing..."));

			threedotedlink_AfterRunReport.click();

			WebElementFacade viewAsLink1 = getElementByDynamicValues("xpath", "viewAsLink", ReportOutpoutType);

			viewAsLink1.waitUntilClickable();
			viewAsLink1.click();
			// Waiting for downloading the Report
			waitABit(10000);
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}

	public void clickWorkDayRules() {
		selectFrame(mainiframe);

		WaitForAjax();
		switchToDefaultContent();

	}

	public void clickPayClasses() {
		selectFrame(mainiframe);

		WaitForAjax();
		switchToDefaultContent();

	}

	public void verifyContentInReport(String reportName, String OutPut_FileType)  {
		
		

		if (reportName.equalsIgnoreCase("Meal Attestation Report")) {

			if (OutPut_FileType.equalsIgnoreCase("CSV")) {

				boolean result = CSVDataReader.verifyText_inPDFContent(
						"C:\\Users\\pandisany\\Downloads\\Meal Attestation Report.csv", "Approved");
				Assert.assertTrue("Expected Content Not present in the Meal attestation CSV Report", result);

			} else {
				boolean result = PDFReader.verifyText_inPDFContent("C:\\Naidu\\NavyTeam\\Meal Attestation Report.pdf",
						"Total Number of Employees");
				Assert.assertTrue("Total Number of Employees Text doesnot Present in the report", result);

			}
		}
	}
	
	public void clearOldReports(String reportName)
	{
		String DownloadFilePath=readSernenityPropertiesFile("chrome_preferences.download.default_directory");
		deleteFiles(DownloadFilePath, reportName);
		
	}

}
