package com.adp.tlmbdd.fault;

public class TlmBddComponentException {

	
}
