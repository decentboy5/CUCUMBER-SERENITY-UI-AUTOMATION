package com.adp.tlmbdd.pages.objects;

import com.adp.tlmbdd.pages.GenericPageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class ReportObjectsGen extends GenericPageObject {
    @FindBy(xpath ="//span[contains(.,'Standard')]")
    public WebElementFacade standardTab;

    @FindBy(xpath ="//span[contains(.,'My Reports')]")
    public WebElementFacade myReportsTab;

    @FindBy(xpath ="//span[contains(.,'Output')]")
    public WebElementFacade outputTab;

    @FindBy(xpath ="//iframe[@id='adprIframe_iframe']")
    public WebElementFacade iframeMain;

    @FindBy(xpath ="//input[@name='sFilterName']")
    public WebElementFacade searchReports;

    @FindBy(xpath ="//span[contains(.,'Timecard Report')]")
    public WebElementFacade searchedReportName;

    @FindBy(xpath ="//div[@id='ExternalRunStandard_filterpanel']//div[@class='rptFilterPanelControlsContainer revitTaskPanelInner']//div[@class='rptFilterPanelControls']")
    public WebElementFacade filterDiv;

    @FindBy(xpath ="//div[@id='ExternalRunStandard_filterpanel']//div[@class='rptFilterPanelControlsContainer revitTaskPanelInner']//div[@class='rptFilterPanelControls']/span[2]")
    public WebElementFacade filterButton;

    @FindBy(xpath ="//td[@idx='7']")
    public WebElementFacade threeDots;

    @FindBy(xpath ="//span[contains(.,'Who appears on this report')]")
    public WebElementFacade whoAppearsSection;

    @FindBy(xpath ="//a[contains(.,'Company Code')]")
    public WebElementFacade companyCode;

    @FindBy(xpath ="//span[contains(.,'Select All')]")
    public WebElementFacade selectAllCompanies;

    @FindBy(xpath ="//i[@class='fa fa-plus-circle']")
    public WebElementFacade selectOneCompany;

    @FindBy(xpath ="//a[contains(.,'Employee List')]")
    public WebElementFacade employeeList;

    @FindBy(xpath ="//label[contains(.,'Include Archived Employees')]")
    public WebElementFacade includeArchivedEmployees;

    @FindBy(xpath ="//label[contains(.,'Include Terminated Employees')]")
    public WebElementFacade includeTerminatedEmployees;

    @FindBy(xpath ="//label[contains(.,'Include Inactive Employees')]")
    public WebElementFacade includeInactiveEmployees;

    @FindBy(xpath ="//input[@id='datePicker1562332853868']")
    public WebElementFacade employeeEffectiveDate;

    @FindBy(xpath ="//a[contains(.,'Time Frame')]")
    public WebElementFacade timeFrame;

    @FindBy(xpath ="//div[@class='vdl-dropdown-list__input-container']")
    public WebElementFacade timeFrameDropdown;

    @FindBy(xpath ="//input[@id='datePicker1562681878504']")
    public WebElementFacade fromDate;

    @FindBy(xpath ="//input[@id='datePicker1562681878509']")
    public WebElementFacade toDate;

    @FindBy(xpath ="//a[contains(.,'Department')]")
    public WebElementFacade department;

    @FindBy(xpath ="//span[contains(.,'Select All')]")
    public WebElementFacade selectAllDepartment;

    @FindBy(xpath ="//i[@class='fa fa-plus-circle']")
    public WebElementFacade selectOneDepartment;

    @FindBy(xpath ="//a[contains(.,'Select Specific Employees Instead')]")
    public WebElementFacade selectSpecificEmployees;

    @FindBy(xpath ="//div[@title='AUTO, ClockTime01']")
    public WebElementFacade selectEmployee1;

    @FindBy(xpath ="//div[@title='Auto, EmpNine']")
    public WebElementFacade selectEmployee2;

    @FindBy(xpath ="//div[@title='Auto, EmpEight']")
    public WebElementFacade selectEmployee3;

    @FindBy(xpath ="//div[@title='Auto, EmpFive']")
    public WebElementFacade selectEmployee4;

    @FindBy(xpath ="//div[@title='Auto, EmpFour']")
    public WebElementFacade selectEmployee5;

    @FindBy(xpath ="//span[contains(.,'Apply')]")
    public WebElementFacade apply;

    @FindBy(xpath ="//span[contains(.,'What's displayed on the report')]")
    public WebElementFacade whatsDisplayedSection;

    @FindBy(xpath ="//span[contains(.,'Archived')]")
    public WebElementFacade archived;

    @FindBy(xpath ="//span[contains(.,'Badge')]")
    public WebElementFacade badge;

    @FindBy(xpath ="//span[contains(.,'Company Code')]")
    public WebElementFacade companycode;

    @FindBy(xpath ="//span[contains(.,'Status')]")
    public WebElementFacade status;

    @FindBy(xpath ="//span[contains(.,'File Number')]")
    public WebElementFacade fileNumber;

    @FindBy(xpath ="//span[contains(.,'Override Pay Class Wage Rate')]")
    public WebElementFacade override;

    @FindBy(xpath ="//span[contains(.,'Payclass')]")
    public WebElementFacade payClass;

    @FindBy(xpath ="//span[contains(.,'Supervisor')]")
    public WebElementFacade supervisor;

    @FindBy(xpath ="//span[contains(.,'Payroll Id')]")
    public WebElementFacade payrollID;

    @FindBy(xpath ="//span[contains(.,'Adjust Tran Date Tc')]")
    public WebElementFacade adjustTranDate;

    @FindBy(xpath ="//span[contains(.,'Clockin Id')]")
    public WebElementFacade clockInID;

    @FindBy(xpath ="//span[contains(.,'Clockout Id')]")
    public WebElementFacade clockOutId;

    @FindBy(xpath ="//span[contains(.,'Pay Date')]")
    public WebElementFacade payDate;

    @FindBy(xpath ="//span[contains(.,'Rate modifiers')]")
    public WebElementFacade rateModifier;

    @FindBy(xpath ="//span[contains(.,'Supervisor Approved')]")
    public WebElementFacade supervisorApproved;

    @FindBy(xpath ="//span[contains(.,'Time Pair Actual Gap')]")
    public WebElementFacade timePairActualGap;

    @FindBy(xpath ="//span[contains(.,'Time Pair Rounded Gap')]")
    public WebElementFacade timePairRoundedGap;

    @FindBy(xpath ="//span[contains(.,'Time shift rule id')]")
    public WebElementFacade timeShiftRuleID;

    @FindBy(xpath ="//span[contains(.,'Time Pair day Part')]")
    public WebElementFacade timePairDayPart;

    @FindBy(xpath ="//span[contains(.,'Appearance and Other Settings')]")
    public WebElementFacade appearanceSection;

    @FindBy(xpath ="//label[contains(.,'Include Notes')]")
    public WebElementFacade includeNotes;

    @FindBy(xpath ="//label[contains(.,'Include Pending Time Off')]")
    public WebElementFacade includePendingTimeOff;

    @FindBy(xpath ="//label[contains(.,'Include Payroll Adjustment as per')]")
    public WebElementFacade includePayRollAdjustment;

    @FindBy(xpath ="//label[contains(.,'Pay Date')]")
    public WebElementFacade payDateinPayrollAdjustment;

    @FindBy(xpath ="//label[contains(.,'Adjusted Transaction Date')]")
    public WebElementFacade adjustedTransactionDate;

    @FindBy(xpath ="//label[contains(.,'Display Payroll Adjustment Hours and Include them in Totals')]")
    public WebElementFacade displayPayrollAdjustment;

    @FindBy(xpath ="//label[contains(.,'Print Runtime Settings')]")
    public WebElementFacade printRuntimeSetting;

    @FindBy(xpath ="//span[contains(.,'Add Note')]")
    public WebElementFacade addNote;

    @FindBy(xpath ="//textarea")
    public WebElementFacade notesTextArea;

    @FindBy(xpath ="//span[contains(.,'RUN AS EXCEL')]")
    public WebElementFacade runAsExcelButton;

    @FindBy(xpath ="//span[contains(.,'RUN AS PDF')]")
    public WebElementFacade runAsPDFButton;

    @FindBy(xpath ="//span[contains(.,'RUN AS CSV')]")
    public WebElementFacade runAsCSV;

    @FindBy(xpath ="//span[contains(.,'Cancel')]")
    public WebElementFacade cancelButton;

    @FindBy(xpath ="//span[contains(.,'Save My Settings')]")
    public WebElementFacade saveMySettings;

    @FindBy(xpath ="//input[@id='myReportName']")
    public WebElementFacade reportName;

    @FindBy(xpath ="//span[contains(.,'Save My Settings')]")
    public WebElementFacade saveMySettingsInDialog;

    @FindBy(xpath ="//span[@id='revit_form_Button_92']")
    public WebElementFacade checkReportShows;

    @FindBy(xpath ="//label[contains(.,'Excel')]")
    public WebElementFacade saveAsExcel;

    @FindBy(xpath ="//label[contains(.,'CSV')]")
    public WebElementFacade saveAsCSV;
}
