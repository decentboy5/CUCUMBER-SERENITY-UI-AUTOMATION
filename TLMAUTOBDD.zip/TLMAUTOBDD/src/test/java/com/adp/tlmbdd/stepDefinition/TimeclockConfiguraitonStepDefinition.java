package com.adp.tlmbdd.stepDefinition;

import com.adp.tlmbdd.steps.TimeclockConfiguraitonSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class TimeclockConfiguraitonStepDefinition {

	@Steps
	TimeclockConfiguraitonSteps timeclockconfigurationsteps;

	
	@Then("^timelclock configuration page shall be displayed$")
	public void timelclock_configuration_page_shall_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timeclockconfigurationsteps.VerifyTimeclockConfigurationpageloads();
	}

	@When("^I click on Add New Device it shall  show the (\\d+) device in the dropdown$")
	public void i_click_on_Add_New_Device_it_shall_show_the_device_in_the_dropdown(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	}
	
	
	@Given("^I click on Add New Device it shall  show the \"([^\"]*)\" device in the dropdown$")
	public void i_click_on_Add_New_Device_it_shall_show_the_device_in_the_dropdown(String devicetype) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timeclockconfigurationsteps.ClickonAddDevicesandverifythedropdown(devicetype);
	}
	
	

	/*@When("^on clicking the (\\d+) device it shall display the New timeclock screen$")
	public void on_clicking_the_device_it_shall_display_the_New_timeclock_screen(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    timeclockconfigurationsteps.Add4500Device();
	}*/
	
	@Given("^on clicking the \"([^\"]*)\" device it shall display the New timeclock screen$")
	public void on_clicking_the_device_it_shall_display_the_New_timeclock_screen(String devicetype) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timeclockconfigurationsteps.AddDevice(devicetype);
	}

	@Given("^I enter the \"([^\"]*)\"DCTID,DESCRIPTION, PROFILE and click on Submit$")
	public void i_enter_the_DCTID_DESCRIPTION_PROFILE_and_click_on_Submit(String devicetype ) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    timeclockconfigurationsteps.EnterID_Desc_Profile_SNo_Submit(devicetype);
	}

	@Then("^Setup Instructions report shall be displayed$")
	public void setup_Instructions_report_shall_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timeclockconfigurationsteps.verify_dctid_in_setup_instrcuctions_dialog();
}
	
	@Given("^I click on Edit DeviceName$")
	public void click_on_Edit() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    timeclockconfigurationsteps.edit_device();
	}

	@Given("^I update the details based on the \"([^\"]*)\" and changes are saved succesfully$")
	public void i_update_the_details_based_on_the(String devicetype) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timeclockconfigurationsteps.edit_device_details(devicetype);
	}
	
	@Given("^If device is \"([^\"]*)\" is then remove the device from the device details screen$")
	public void if_the_is_then_remove_the_device_from_the_device_details_screen(String devicetype) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   timeclockconfigurationsteps.remove_device(devicetype);
	}
	    
	@Given("^if the device is \"([^\"]*)\" I Delete the device and the device is deleted$")
	public void if_the_device_is_I_Delete_the_device_and_the_device_is_deleted(String devicetype) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    timeclockconfigurationsteps.delete_device(devicetype);
	}
	

}