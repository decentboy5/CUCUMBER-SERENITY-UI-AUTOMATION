package com.adp.tlmbdd.stepDefinition;
import static org.junit.Assert.assertEquals;

import com.adp.tlmbdd.steps.*;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class AccrualTLMStepDefinition {
	@Steps
	AccrualsTLMSteps accrualTLMSteps;
	
@When("^I enable accruals if not enabled$")
public void VerifyAccrualIsEnabled() throws Throwable {
	assertEquals(true,accrualTLMSteps.verifyAccuralsfeatureEnabledStep());
}


@When("^I add a new accrual progression \"([^\"]*)\" with description \"([^\"]*)\"$")
public void iAddANewAccrualProgressionWithDescription(String arg1, String arg2) throws Throwable {
	accrualTLMSteps.addAccrualProgressionStep();
}


@When("^I add new accrual definition$")
public void iAddNewAccrualDefinition() throws Throwable {
	accrualTLMSteps.addAccrualDefinitionStep();
}

}
