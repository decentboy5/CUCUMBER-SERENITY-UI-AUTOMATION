package com.adp.tlmbdd.pages;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.support.ui.ExpectedCondition;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.waits.WaitUntil;

public class TimeclockConfiguration extends GenericPageObject {

	@FindBy(xpath = "(//span[text()='Intouch' or text()='4500' or text()='ADP300 Basic' or text()='ADP700 Touchscreen' or text()='ADP Time' or text()='Non Hosted Models'])[2]")
	private WebElementFacade TimeclockConfigurationpage;

	String SpinnerforTimeclockDetails="//span[@class='fa fa-spinner fa-spin fa-2x']";
	
	static String SpinnerforAddTimeclock = "//*[contains(@class,'vdl-busy-indicator ')]";

	@FindBy(xpath = "//span[text()='ADD NEW DEVICE']")
	private WebElementFacade AddNewDeviceButton;

	/*
	 * @FindBy(xpath = "//li[text()='Add 4500']") private WebElementFacade
	 * AddNew4500Button;
	 */

	// span[text()='H02jbJ8 (H02jbJ8) '] clock identifier

	@FindBy(id = "DctID")
	private WebElementFacade kronosDeviceID;

	@FindBy(xpath = "//span[text()='ID:']/../following-sibling::div/input")
	private WebElementFacade atsDCTID;

	@FindBy(xpath = "//span[text()='Description:']/../following-sibling::div/input")
	private WebElementFacade atsDESCRIPTION;

	@FindBy(xpath = "//span[text()='Serial Number:']/../following-sibling::div/input")
	private WebElementFacade atsSerialNo;

	public static String devid;

	public static String serialno = null;
	
	public static int numberofdevices;

	@FindBy(id = "Descriptions")
	private WebElementFacade kronosDescriptions;

	@FindBy(xpath = "//span[@class='vdl-dropdown-list__picker']")
	private WebElementFacade TimeclockProfileDropdown;

	@FindBy(xpath = "//li[@id='DctProfileId__listbox__option__0']")
	private WebElementFacade FirstTimeclockProfileFromTheDropdown;

	@FindBy(xpath = "//li[@id='DctProfileId__listbox__option__2']")
	private WebElementFacade SecondTimeclockProfileFromTheDropdown;

	@FindBy(xpath = "//iframe[@id='eZlmIFrame_iframe']")
	private WebElementFacade FrameAddTimeclock;

	@FindBy(xpath = "//button[contains(.,'Submit')]")
	private WebElementFacade SubmitButton;

	@FindBy(xpath = "//button[contains(.,'Delete')]")
	private WebElementFacade DeleteButton;

	@FindBy(xpath = "//button[contains(.,'Yes')]")
	private WebElementFacade YesButton;

	@FindBy(xpath = "//iframe[contains(@src,'GetPDFInstructions')]") // span[@id='lblHasBiometricPOD']
	private WebElementFacade ReportGenerationFrame;

	@FindBy(xpath = "//div[text()='Your changes have been successfully saved']")
	private WebElementFacade ChangesSaved;

	@FindBy(xpath = "//div[text()='The device was successfully deleted.']")
	private WebElementFacade Delete_Remove_Success;

	@FindBy(xpath = "//span[text()='Setup Instructions']")
	private WebElementFacade SetupInstructionsHeader;

	@FindBy(xpath = "//button[@aria-label='Close']")
	private WebElementFacade PDFCloseButton;

	@FindBy(xpath = "//span[text()='\"+devid+\" (\"+devid+\") ']/../../../div[1]")
	private WebElementFacade editDeviceButton;

	@FindBy(xpath = "//span[text()='\"+devid+\" (\"+devid+\") ']/../../../div[1]..//span[text()='EDIT DEVICE SETTINGS']/..")
	private WebElementFacade editDeviceSettingsButton;

	static WebElementFacade AddNewButton;

	// span[text()='a3BF6J3 (a3BF6J3) ']/../../../div[1]/..//span[text()='EDIT
	// DEVICE SETTINGS']/..


	static int count = 0;

	public void VerifyTimeclockConfigurationpageloads() {

		try {
			waitABit(5000);
			WaitForPageLoad();
			switchToDefaultContent();
			waitForElementToLoad(FrameAddTimeclock);

			selectFrame(FrameAddTimeclock);

		

			waitForAbsenceOf(SpinnerforTimeclockDetails);
			
			numberofdevices= getObjectCount("(//span[text()='Intouch' or text()='4500' or text()='ADP300 Basic' or text()='ADP700 Touchscreen' or text()='ADP Time' or text()='Non Hosted Models'])");
			if (checkElementEnabled(TimeclockConfigurationpage)) {
				System.out.println("TimeclockConfigurationpage Page Loaded ");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void ClickonAddDevicesandverifythedropdown(String devicetype) {

		try {
			AddNewDeviceButton.click();

			WebElementFacade AddNewButton = getElementByDynamicValues("xpath", "AddDevice", devicetype);
			waitForElementToLoad(AddNewButton);
			if (checkElementVisible(AddNewButton)) {
				System.out.println("Devices list is loading");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void AddDevice(String DeviceType) {

		try {
			WebElementFacade AddNewButton = getElementByDynamicValues("xpath", "AddDevice", DeviceType);
			AddNewButton.click();
			if (DeviceType.equals("4500") | DeviceType.equals("Intouch")) {
				waitForElementToLoad(kronosDeviceID);
				System.out.println("Kronos DCTID is present");
			}

			else {
				System.out.println("ATS DCTID is present");
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void EnterID_Desc_Profile_SNo_Submit(String devicetype) {

		try {

			System.out.println(" ");
			switchToDefaultContent();
			waitForWebElementToEnable(FrameAddTimeclock);
			selectFrame(FrameAddTimeclock);
			waitForAbsenceOf(SpinnerforAddTimeclock);
			devid = RandomStringUtils.random(7, true, true);
			if (devicetype.contains("4500") | devicetype.contains("Intouch"))// kronos related details being entered
			{
				kronosDeviceID.sendKeys(devid);
				waitForElementToLoad(kronosDescriptions);
				kronosDescriptions.sendKeys(devid);
				waitForWebElementToLoad(TimeclockProfileDropdown);
				TimeclockProfileDropdown.click();
				waitForElementToLoad(FirstTimeclockProfileFromTheDropdown);
				FirstTimeclockProfileFromTheDropdown.click();

			}

			else // ATS related details being entered
			{

				atsDCTID.sendKeys(devid);
				atsDESCRIPTION.sendKeys(devid);
				serialno = RandomStringUtils.random(7, false, true);
				if (serialno.startsWith("0"))
					serialno = serialno.replace("0", "1");
				atsSerialNo.sendKeys(serialno);

			}
			// generic action for both clocks to submit and observe the success message
			SubmitButton.click();
			waitForElementToLoad(ChangesSaved);
			System.out.println("Timeclock is created.Changes saved successfully");

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void verify_dctid_in_setup_instrcuctions_dialog() {

		try {
			System.out.println(" ");
			switchToDefaultContent();
			selectFrame(FrameAddTimeclock);
			waitForElementToLoad(ReportGenerationFrame);
			selectFrame(ReportGenerationFrame);
			String xpath = "//div[contains(text(),'" + devid + "')][1]";
			/*
			 * checkElementVisible(xpath); waitFor(xpath);
			 * checkElementVisible("//div[contains(text(),'"+devid+"')][1]");
			 */
			System.out.println("DCTID is verified in report");
			/* PDFCloseButton.click(); */
			
			switchToDefaultContent();
			
			

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void edit_device() {

		try {
			
			waitABit(5000);
			WaitForPageLoad();
			switchToDefaultContent();
			WaitForPageLoad();
			waitForElementToLoad(FrameAddTimeclock);
			WebElementFacade EditButton;
			WebElementFacade EditDeviceDetails;
			
			System.out.println("  ");
			

			if (count == 1) {
				EditButton = getElementByDynamicValues("xpath", "EditUpdtDeviceNameforRemove", devid);
				EditDeviceDetails = getElementByDynamicValues("xpath", "EditUpdtDeviceNameforDelete", devid);
				count=0;
			} else {
				EditButton = getElementByDynamicValues("xpath", "DeviceName", devid);
				EditDeviceDetails = getElementByDynamicValues("xpath", "EditDeviceName", devid);
				count++;
			}
			waitForElementToLoad(FrameAddTimeclock);
			selectFrame(FrameAddTimeclock);

/*			if (EditButton.containsText("updt")) {
				EditButton = getElementByDynamicValues("xpath", "EditUpdtDeviceNameforRemove", devid);
				EditDeviceDetails = getElementByDynamicValues("xpath", "EditUpdtDeviceNameforDelete", devid);
			}*/
			if(numberofdevices>3)
			{
			waitForElementToLoad(EditButton);
			EditButton.click();
			}
			waitForElementToLoad(EditDeviceDetails);
			EditDeviceDetails.click();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void edit_device_details(String devicetype) {
		try {

			switchToDefaultContent();
			waitForWebElementToEnable(FrameAddTimeclock);
			selectFrame(FrameAddTimeclock);
			waitForAbsenceOf(SpinnerforAddTimeclock);

			if (devicetype.contains("4500") | devicetype.contains("Intouch"))// kronos edit related details being
																				// entered
			{

				waitForElementToLoad(kronosDescriptions);
				kronosDescriptions.clear();
				kronosDescriptions.typeAndTab(devid + "updt");
				waitABit(5000);
				waitForWebElementToLoad(TimeclockProfileDropdown);
				TimeclockProfileDropdown.click();
				waitForElementToLoad(SecondTimeclockProfileFromTheDropdown);
				SecondTimeclockProfileFromTheDropdown.click();

			}

			else // ATS edit related details being entered
			{

				atsDESCRIPTION.clear();
				atsDESCRIPTION.sendKeys(devid + "updt");
				serialno = RandomStringUtils.random(7, false, true);
				if (serialno.startsWith("0"))
					serialno = serialno.replace("0", "1");
				atsSerialNo.clear();
				atsSerialNo.sendKeys(serialno);
			}

			SubmitButton.click();
			waitForElementToLoad(ChangesSaved);
			System.out.println("Timeclock edit successfully.Changes saved successfully");

			switchToDefaultContent();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void remove_device(String devicetype) {

		try {

			WebElementFacade EditButton = getElementByDynamicValues("xpath", "EditUpdtDeviceNameforRemove", devid);
			WebElementFacade RemoveDeviceButton = getElementByDynamicValues("xpath", "RemoveDevice", devid);
			waitForElementToLoad(FrameAddTimeclock);
			selectFrame(FrameAddTimeclock);
			EditButton.click();
			waitForElementToLoad(RemoveDeviceButton);
			RemoveDeviceButton.click();
			waitForElementToLoad(YesButton);
			YesButton.click();
			waitForElementToLoad(Delete_Remove_Success);
			System.out.println("Remove is Success");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void delete_device(String devicetype) {

		try {
			waitForAbsenceOf(SpinnerforAddTimeclock);
			waitForElementToLoad(DeleteButton);
			DeleteButton.click();
			waitForElementToLoad(YesButton);
			YesButton.click();
			waitForElementToLoad(Delete_Remove_Success);
			System.out.println("Delete is success");

		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
