package com.adp.tlmbdd.steps;

import java.io.IOException;

import com.adp.tlmbdd.pages.editors.DailyCalculationProgram;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class DailyCalculationProgramSteps extends ScenarioSteps {

	DailyCalculationProgram dailyCalcPgm;

	@Step
	public void createDCPWithGraceAndLunch(String dailycalcID, String dailyDescription, String graceRound,
			String lunchPlan) throws IOException {
		dailyCalcPgm.addDailycalProgram(dailycalcID, dailyDescription, graceRound, lunchPlan);

	}

	@Step
	public void modifyDailyCalc(String dailycalcID, String dailyDescription, String graceRound, String lunchPlan)
			throws IOException {

		dailyCalcPgm.searchAndModifyDailyCalc(dailycalcID, graceRound, lunchPlan);
		System.out.println("Modification done");
		dailyCalcPgm.verifyDataMatch(dailycalcID, graceRound, lunchPlan);
		System.out.println("verification done");

	}

	@Step
	public void copyDailyCalc(String dailycalcID, String copyCalcID) throws IOException {
		dailyCalcPgm.copyExisting(dailycalcID, copyCalcID);

	}

	@Step
	public void deletefromSearchListPage(String dailycalcID) {
		dailyCalcPgm.deleteSuccessSearchPage(dailycalcID);
	}

	@Step
	public void duplicateErrorMessage(String dailycalcID, String dailyDescription, String graceRound)
			throws IOException {
		dailyCalcPgm.dailycalProgramDuplicate(dailycalcID, dailyDescription, graceRound);
	}

	@Step
	public void withoutRulesErrorMessage(String dailycalcID, String dailyDescription) throws IOException {
		dailyCalcPgm.addDailycalProgramerror(dailycalcID, dailyDescription);

	}

	@Step
	public void invalidDataErrorMessage(String dailycalcID, String dailyDescription)
			throws IOException {
		dailyCalcPgm.dailycalProgramInvaliddata(dailycalcID, dailyDescription);

	}

	@Step
	public void includeInDeselectErrorMessage(String dailycalcID) throws IOException {
		dailyCalcPgm.includeInDeselect(dailycalcID);

	}

	@Step
	public void deleteMappedErrorMessage(String dailycalcID) throws IOException {
		dailyCalcPgm.deleteMapped(dailycalcID);

	}

	@Step
	public void deleteMapSearchPageErrorMessage(String dailycalcID) throws IOException {
		dailyCalcPgm.deleteMappedSearchList(dailycalcID);

	}

}
