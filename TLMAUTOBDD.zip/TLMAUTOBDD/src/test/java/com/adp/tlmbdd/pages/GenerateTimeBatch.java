package com.adp.tlmbdd.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class GenerateTimeBatch extends GenericPageObject {

	@FindBy(xpath = "//*[@id='PayrollDashboard_DashboardWrapper_PayDataSummary_PayData_1_PayDataView.TimeAndTimeOff_LABEL']")
	private WebElementFacade addTimeTimeOffBatchLink;

	@FindBy(xpath = "//*[@id='PayrollDashboard_RightNav.PreviewPayroll.node']")
	private WebElementFacade previewPayrollButton;

	@FindBy(xpath = "//*[@id='companyIDBarContentPane']/table/tbody/tr/td[1]/div/div[1]/h4")
	private WebElementFacade companyCodeLabel;

	@FindBy(xpath = "//*[@id='companyIDBarListDropDown']")
	private WebElementFacade companyCodeDropDown;

	@FindBy(xpath = "//*[@id='PayrollDashboard_RightNav.PayrollSimplificationLinks.node']/div/div[2]")
	private WebElementFacade manageAllTimeCycleLink;

	@FindBy(xpath = "//*[@id='PayrollDashboardAddTimeBatch.slideIn_Title']/div[contains(text(),'Add Time & Attendance/Time Off Batch')]")
	private WebElementFacade titleAddTimeTimeOffBatch;

	@FindBy(xpath = "//*[@id='PayrollDashboardCreateBatch.slideIn_Title']/div[contains(text(),'Add Time/Time Off Batch - Review')]")
	private WebElementFacade titleAddTimeTimeOffBatchReview;

	@FindBy(xpath = "//*[@id='PayrollDashboardBatchProgress.dialog_Title']/div[contains(text(),'Create Time/Time Off Batch')]")
	private String titleBatchProcessdialog;

	@FindBy(xpath = "//*[@id='PayrollDashboardAddTimeBatch.CompanyInformation.wrapper']")
	private WebElementFacade compCodeLabelAddTimePage;

	@FindBy(xpath = "//*[@id='PayrollDashboardTimePanel.PayG_0.EmployeesFromPG.wrapper']")
	private WebElementFacade employeePayGroupLabel;

	@FindBy(xpath = "//*[@id='PayrollDashboardAddTimeBatch.TimeOffPanel.headerText']")
	private WebElementFacade timeoffPanelText;

	@FindBy(xpath = "//*[@id='PayrollDashboardAddTimeBatch.StartBatchProcessing']")
	private WebElementFacade ContinueTimeBatchButton;

	@FindBy(xpath = "//*[@id='PayrollDashboardCreateBatch.Start']")
	private WebElementFacade startBatchButton;

	@FindBy(xpath = "//*[@id='batchProgressDialog.Close']")
	private WebElementFacade batchProgressCloseButton;

	@FindBy(id = "printExcel")
	private WebElementFacade selectCompanyFrame;

	public void checkRTPEnabled(String compCode) {
		try {

			String cname = companyCodeLabel.getText().toString();
			if (cname.contains(compCode)) {
				if (previewPayrollButton.isPresent()) {
					System.out.println("Company code is in Entering payroll State");
				} else {
					System.out.println("Company code is NOT in Entering payroll State");
				}
			} else {
				companyCodeDropDown.click();
				getDriver().switchTo().frame(selectCompanyFrame);
				for (int i = 0; i <= 100; i++) {

					String cValue = null;
					cValue = getDriver()
							.findElement(By
									.xpath("//*[@id='companyIdBarCompListGrid_row_" + i + "_cell_0']/span/div/a/font"))
							.getText();

					if (cValue.equalsIgnoreCase(compCode)) {
						getDriver()
								.findElement(By.xpath(
										"//*[@id='companyIdBarCompListGrid_row_" + i + "_cell_0']/span/div/a/font"))
								.click();
						break;
					}
				}
				getDriver().switchTo().defaultContent();
				if (previewPayrollButton.isPresent()) {
					System.out.println("Company code is in Entering payroll State");
				} else {
					System.out.println("Company code is NOT in Entering payroll State");
				}

			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public boolean checkTLMSimplificationEnabled() throws IOException {
		boolean result = false;
		try {

			if (manageAllTimeCycleLink.isDisplayed()) {
				result = true;
			} else {
				System.out.println("TLM simplification feature is not Enabled");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}

	public void timeBatchGeneration(String compCode, String payCycleID) {
		try {
			checkRTPEnabled(compCode);
			waitABit(5000);
			addTimeTimeOffBatchLink.waitUntilVisible();
			addTimeTimeOffBatchLink.click();

			if (titleAddTimeTimeOffBatch.isDisplayed()) {
				System.out.println("heading is displayed");
				waitABit(5000);
				if (compCodeLabelAddTimePage.containsText(compCode)) {
					System.out.println("Company code is matched");
					uncheckDefaultTimeoff();
					selectPayCycle(payCycleID);
					ContinueTimeBatchButton.click();
					if (titleAddTimeTimeOffBatchReview.isPresent()) {
						waitABit(5000);
						startBatchButton.click();
					}
					//waitForTitleToAppear(titleBatchProcessdialog);
					//waitABit(10000);
					batchProgressCloseButton.click();

				} else {
					System.out.println("User is not is Corrent Company code");
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void timeSummaryPreference(String compCode) {
		try {
			if (titleAddTimeTimeOffBatchReview.isPresent()) {
				waitABit(5000);
				if (compCodeLabelAddTimePage.containsText(compCode)) {
					System.out.println("Company code is matched");
					WebElement wrapperTSP = getDriver().findElement(By.xpath(
							".//*[@id='PayrollDashboardCreateBatch.TimeBatch_0.TimeSummaryPreference.wrapper']"));

					if (wrapperTSP.isDisplayed()) {
						startBatchButton.click();
					} else {
						// select from the drop Down
					}
				} else {
					System.out.println("User is not is Corrent Company code");
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void selectPayCycle(String payCycleID) {
		try {
			if (employeePayGroupLabel.isPresent()) {

				for (int j = 0; j <= 100; j++) {
					String cycleValue = getDriver()
							.findElement(By.xpath("//*[@id='PayrollDashboardTimePanel.PayG_0.PayCycleViews_" + j
									+ ".PayCycleInfo']/div/div/span[2]"))
							.getText();

					if (cycleValue.contentEquals(payCycleID)) {
						WebElement includeCheckbox = getDriver()
								.findElement(By.xpath("//*[@id='PayrollDashboardTimePanel.PayG_0.PayCycleViews_" + j
										+ ".IncludeCheckBox.icon']"));
						if (!includeCheckbox.isEnabled()) {
							System.out.println("Pay cycle have error to resolve. Cannot generate batch");

						} else if (!includeCheckbox.isSelected()) {
							includeCheckbox.click();
							break;

						}
					}

				}

			} else {
				for (int i = 0; i <= 100; i++) {

					String payCycle = getDriver()
							.findElement(By.xpath("//*[@id='PayrollDashboardTimePanel.SinglePayCycle_" + i
									+ ".PayCycleInfo']/div/div/span[2]"))
							.getText();

					if (payCycle.contentEquals(payCycleID)) {
						WebElement includeCheck = getDriver().findElement(By.xpath(
								".//*[@id='PayrollDashboardTimePanel.SinglePayCycle_" + i + ".IncludeCheckBox.icon']"));

						if (!includeCheck.isEnabled()) {
							System.out.println("Pay cycle have error to resolve. Cannot generate batch");

						} else if (!includeCheck.isSelected()) {
							includeCheck.click();
							break;
						}

					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void uncheckDefaultTimeoff() {

		try {

			if (timeoffPanelText.isPresent()) {

				WebElement ptoCheckbox = getDriver().findElement(
						By.xpath(".//*[@id='PayrollDashboardPTOPanel.timeOff_0.timeOffPanel_0.IncludeCheckBox.icon']"));

				ptoCheckbox.click();
				if (!ptoCheckbox.isSelected()) {

				} else {
					ptoCheckbox.click();
				}

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void timeBatchGeneration1(String compCode, String payCycleID) {
		try {
			checkRTPEnabled(compCode);
			waitABit(5000);
			addTimeTimeOffBatchLink.waitUntilVisible();
			addTimeTimeOffBatchLink.click();

			if (titleAddTimeTimeOffBatch.isDisplayed()) {
				System.out.println("heading is displayed");
				waitABit(5000);
				if (compCodeLabelAddTimePage.containsText(compCode)) {
					System.out.println("Company code is matched");
					if (employeePayGroupLabel.isDisplayed()) {
						System.out.println("Pay groups are identified ");

						List<WebElement> payCycleList = getDriver().findElements(
								By.xpath("//*[@id='PayrollDashboardTimePanel.PayG_0.PayCycleViews_CARDS']"));

						for (WebElement payCyc : payCycleList) {

							for (int j = 0; j < 100; j++) {
								String cycleValue = getDriver()
										.findElement(By.xpath("//*[@id='PayrollDashboardTimePanel.PayG_0.PayCycleViews_"
												+ j + ".PayCycleInfo']/div/div/span[2]"))
										.getText();

								if (cycleValue.contentEquals(payCycleID)) {
									WebElement includeCheckbox = getDriver().findElement(
											By.xpath("//*[@id='PayrollDashboardTimePanel.PayG_0.PayCycleViews_" + j
													+ ".IncludeCheckBox.icon']"));
									if (!includeCheckbox.isEnabled()) {
										System.out.println("Pay cycle have error to resolve. Cannot generate batch");

									} else if (!includeCheckbox.isSelected()) {
										includeCheckbox.click();

									}

								} else {
									WebElement uncheckBox = getDriver().findElement(
											By.xpath("//*[@id='PayrollDashboardTimePanel.PayG_0.PayCycleViews_" + j
													+ ".IncludeCheckBox.icon']"));
									if (uncheckBox.isEnabled()) {
										if (uncheckBox.isSelected()) {
											uncheckBox.click();

										}
									}

								}

							}

						}
					} else {
						for (int i = 0; i <= 100; i++) {

							String payCycle = getDriver()
									.findElement(By.xpath("//*[@id='PayrollDashboardTimePanel.SinglePayCycle_" + i
											+ ".PayCycleInfo']/div/div/span[2]"))
									.getText();

							if (payCycle.contentEquals(payCycleID)) {
								WebElement includeCheck = getDriver()
										.findElement(By.xpath(".//*[@id='PayrollDashboardTimePanel.SinglePayCycle_" + i
												+ ".IncludeCheckBox.icon']"));

								if (!includeCheck.isEnabled()) {
									System.out.println("Pay cycle have error to resolve. Cannot generate batch");

								} else if (!includeCheck.isSelected()) {
									includeCheck.click();

								}
								break;
							}
						}
					}

				} else {
					System.out.println("User is not is Corrent Company code");
				}

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
