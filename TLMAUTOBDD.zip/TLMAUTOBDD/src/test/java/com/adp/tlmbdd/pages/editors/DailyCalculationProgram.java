package com.adp.tlmbdd.pages.editors;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.adp.tlmbdd.pages.GenericPageObject;
import com.adp.tlmbdd.pages.Navigation;

import junit.framework.Assert;

public class DailyCalculationProgram extends GenericPageObject {

	// Navigation nav;

	@FindBy(xpath = "//*[@id='ConfigWorkingList.AddNew']")
	private WebElementFacade addNewDailyCalcProgramButton;

	@FindBy(xpath = "//*[@id='ConfigWorkingList.Delete']")
	private WebElementFacade deletefromSearchList;

	@FindBy(linkText = "ConfigWorkingList.CEViewDeleteAudit")
	private WebElementFacade viewDeleteAuditDailyCalcProgram;

	@FindBy(id = "ConfigWorkingList.CESearch")
	private WebElementFacade searchTextBoxDailyCalcProgram;

	@FindBy(id = "ConfigWorkingList.CESearch.button")
	private WebElementFacade searchButtonDailyCalcProgram;

	@FindBy(xpath = "//*[@id='title'][.='Daily Calculation Programs']")
	private WebElementFacade titleDailyCalcProgram;

	@FindBy(id = "ConfigDailyCalcProgramEditor.DailyCalcProgramEditable")
	private WebElementFacade dailyCalcProgIdTextBox;

	@FindBy(id = "ConfigDailyCalcProgramEditor.Description")
	private WebElementFacade dailyCalcProgDescriptionTextBox;

	@FindBy(id = "ConfigDailyCalcProgramEditor.DistributionPlanLookup.input")
	private WebElementFacade dailyCalcProgHourDP;

	@FindBy(id = "ConfigDailyCalcProgramEditor.GraceRoundLookup.button")
	private WebElementFacade dailyCalcProgGraceRoundRuleLookupIcon;

	@FindBy(id = "ConfigDailyCalcProgramEditor.LunchPlanLookup.button")
	private WebElementFacade dailyCalcProgLunchP;

	@FindBy(id = "ConfigDailyCalcProgramEditor.ShiftPlanLookup.input")
	private WebElementFacade dailyCalcProgShiftR;

	@FindBy(id = "ConfigDailyCalcProgramEditor.BreakRuleLookup.input")
	private WebElementFacade dailyCalcProgBreakR;

	@FindBy(id = "ConfigDailyCalcProgramEditor.Active.icon")
	private WebElementFacade dailyCalcProgIncludeIn;

	@FindBy(xpath = ".//*[@id='ConfigDailyCalcProgramEditor.Active.Label']/span")
	private WebElementFacade includeInHelpIcon;

	@FindBy(id = "ConfigDailyCalcProgramEditor.ActiveHelpDialog_Content")
	private WebElementFacade includeInHelpContent;

	@FindBy(id = "ConfigDailyCalcProgramEditor.Help")
	private WebElementFacade dayOverrideHelpIcon;

	@FindBy(id = "ConfigDailyCalcProgramEditor.Active.Label")
	private WebElementFacade includeInLabel;

	@FindBy(id = "ConfigDailyCalcProgramEditor.DCalcSecondInfoLink.Label")
	private WebElementFacade dayOverrideLabel;

	@FindBy(id = "eZlmIFrame1_iframe")
	private WebElementFacade frame_eZlmIFrame;

	@FindBy(id = "eZlmIFrame")
	private WebElementFacade frameEditorConfig;

	@FindBy(xpath = "//div[@id='codeslist_NavMenuItemID0_pane']//*[contains(text(),'Daily Calculation Programs')]")
	private WebElementFacade dailyCalcProgramLink;

	@FindBy(xpath = "//*[@id='DV_Breadcrumb']//*[contains(text(),'You are here')]")
	private WebElementFacade dailyCalcPgmBreadscrum;

	@FindBy(xpath = ".//*[@id='title']")
	private WebElementFacade dailyCalcProgramTitle;

	@FindBy(id = "ConfigDailyCalcProgramEditor.Submit")
	private WebElementFacade dailyCalcSubmitButton;

	@FindBy(id = "ConfigDailyCalcProgramEditor.Delete")
	private WebElementFacade dailyCalcDeleteButton;

	@FindBy(id = "ConfigDailyCalcProgramEditor.Cancel")
	private WebElementFacade dailyCalcCancelButton;

	@FindBy(xpath = "//*[@id='ConfigDailyCalcProgramEditor_MESSAGES']//*[contains(text(),'At least one rule or plan must be selected')]")
	private WebElementFacade atleastOneRuleErrorText;

	@FindBy(xpath = "//*[@id='ConfigDailyCalcProgramEditor_MESSAGES']//*[contains(text(),'Daily Calculation Program already exists.')]")
	private WebElementFacade dailyCalcProgramExistsText;

	@FindBy(xpath = "//*[@id='ConfigWorkingList.ResponseMessages_0.Success.node']//*[contains(text(),'Operation Successful')]")
	private WebElementFacade operationSuccessfulText;

	@FindBy(xpath = "//*[@id='ConfigDailyCalcProgramEditor_MESSAGES']//*[contains(text(),'Daily Calculation Program is assigned to employees as a Day Override and cannot be deleted')]")
	private By DeletemappedError;

	@FindBy(xpath = "//*[@id='ConfigDailyCalcProgramEditor_MESSAGES']//*[contains(text(),'Correct the information in the highlighted field(s).')]")
	private WebElementFacade highlightedErrorText;

	@FindBy(xpath = ".//*[@id='ConfigDailyCalcProgramEditor_MESSAGES']/div/table/tbody/tr/td[2]/div")
	private WebElementFacade deselectMappedErrorText;

	// Daily Calculation program without any rules to validate Error message
	public void addDailycalProgramerror(String dailycalcID, String dailyDescription) {

		try {
			// getDriver().switchTo().defaultContent();
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			addNewDailyCalcProgramButton.click();
			dailyCalcProgIdTextBox.sendKeys(dailycalcID);
			dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String error = atleastOneRuleErrorText.getText().toString();
			if (error.contains("At least one rule or plan must be selected")) {
				System.out.println("At least one rule or plan must be selected");
			}
			dailyCalcCancelButton.click();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Validate Duplicate Daily calc ID error message
	public void dailycalProgramDuplicate(String dailycalcID, String dailyDescription, String graceRound) {

		try {
			// getDriver().switchTo().defaultContent();
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			addNewDailyCalcProgramButton.click();
			dailyCalcProgIdTextBox.sendKeys(dailycalcID);
			dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
			dailyCalcProgGraceRoundRuleLookupIcon.click();
			getElementByDynamicValues("xpath", "graceRoundRuleDropdownValue", graceRound).click();

			helpIcons();
			waitABit(2000);
			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String error = dailyCalcProgramExistsText.getText().toString();

			if (error.contains("Daily Calculation Program already exists.")) {
				System.out.println("Daily Calculation Program already exists.");
			}
			dailyCalcCancelButton.click();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Validate Invalid data error message
	public void dailycalProgramInvaliddata(String dailycalcID, String dailyDescription) {

		try {
			// getDriver().switchTo().defaultContent();
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			addNewDailyCalcProgramButton.click();
			dailyCalcProgIdTextBox.sendKeys(dailycalcID);
			dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
			dailyCalcProgGraceRoundRuleLookupIcon.click();
			dailyCalcProgGraceRoundRuleLookupIcon.sendKeys("155151");

			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String error = highlightedErrorText.getText().toString();
			if (error.contains("Correct the information in the highlighted field(s).")) {
				System.out.println("Correct the information in the highlighted field(s).");
			}
			dailyCalcCancelButton.click();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Daily Calculation program with Hour Distribution Rule
	public void addDailycalProgHourDR(String dailycalcID, String dailyDescription, String hourDistRule) {

		getDriver().switchTo().frame(frame_eZlmIFrame);
		// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
		// "Daily Calculation Program"));

		addNewDailyCalcProgramButton.click();
		dailyCalcProgIdTextBox.sendKeys(dailycalcID);
		dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
		dailyCalcProgHourDP.click();
		getElementByDynamicValues("xpath", "hourDistributionRuleDropdownValue", hourDistRule).click();
		dailyCalcProgIncludeIn.shouldBeEnabled();

		if (!dailyCalcProgIncludeIn.isSelected()) {
			dailyCalcProgIncludeIn.click();
		}
		dailyCalcSubmitButton.click();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String success = operationSuccessfulText.getText().toString();

		if (success.contains("Operation Successful")) {
			System.out.println("Daily calc created successfully");
		}

	}

	// Daily Calculation program with 6 Mins Grace Round Rule
	public void addDailycalProgGraceRR(String dailycalcID, String dailyDescription, String graceRound) {

		getDriver().switchTo().frame(frame_eZlmIFrame);
		// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
		// "Daily Calculation Program"));

		addNewDailyCalcProgramButton.click();
		dailyCalcProgIdTextBox.sendKeys(dailycalcID);
		dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
		dailyCalcProgGraceRoundRuleLookupIcon.click();
		getElementByDynamicValues("xpath", "graceRoundRuleDropdownValue", graceRound).click();
		dailyCalcProgIncludeIn.shouldBeEnabled();

		if (!dailyCalcProgIncludeIn.isSelected()) {
			dailyCalcProgIncludeIn.click();
		}
		dailyCalcSubmitButton.click();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String success = operationSuccessfulText.getText().toString();
		if (success.contains("Operation Successful")) {
			System.out.println("Daily calc created successfully");
		}

	}

	// Daily Calculation program with 30 Mins Auto Deduct Lunch Plan
	public void addDailycalProgLunch(String dailycalcID, String dailyDescription, String lunchPlan) {

		getDriver().switchTo().frame(frame_eZlmIFrame);
		// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
		// "Daily Calculation Program"));
		addNewDailyCalcProgramButton.click();
		dailyCalcProgIdTextBox.sendKeys(dailycalcID);
		dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
		dailyCalcProgLunchP.click();
		getElementByDynamicValues("xpath", "lunchPlanRuleDropdownValue", lunchPlan).click();
		dailyCalcProgIncludeIn.shouldBeEnabled();
		if (!dailyCalcProgIncludeIn.isSelected()) {
			dailyCalcProgIncludeIn.click();
		}
		dailyCalcSubmitButton.click();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String success = operationSuccessfulText.getText().toString();
		if (success.contains("Operation Successful")) {
			System.out.println("Daily calc created successfully");
		}

	}

	// Daily Calculation program with Actual Shift Rule
	public void addDailycalProgShift(String dailycalcID, String dailyDescription, String shiftRule) {

		getDriver().switchTo().frame(frame_eZlmIFrame);
		// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
		// "Daily Calculation Program"));
		addNewDailyCalcProgramButton.click();
		dailyCalcProgIdTextBox.sendKeys(dailycalcID);
		dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
		dailyCalcProgShiftR.click();
		getElementByDynamicValues("xpath", "shiftPlanRuleDropdownValue", shiftRule).click();
		dailyCalcProgIncludeIn.shouldBeEnabled();
		if (!dailyCalcProgIncludeIn.isSelected()) {
			dailyCalcProgIncludeIn.click();
		}
		dailyCalcSubmitButton.click();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String success = operationSuccessfulText.getText().toString();

		if (success.contains("Operation Successful")) {
			System.out.println("Daily calc created successfully");
		}

	}

	// Daily Calculation program with 10 Mins Break Rule
	public void addDailycalProgBreak(String dailycalcID, String dailyDescription, String breakRule) {

		getDriver().switchTo().frame(frame_eZlmIFrame);
		// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
		// "Daily Calculation Program"));
		addNewDailyCalcProgramButton.click();
		dailyCalcProgIdTextBox.sendKeys(dailycalcID);
		dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
		dailyCalcProgBreakR.click();
		getElementByDynamicValues("xpath", "breakRulePlanDropdownValue", breakRule).click();
		dailyCalcProgIncludeIn.shouldBeEnabled();
		if (!dailyCalcProgIncludeIn.isSelected()) {
			dailyCalcProgIncludeIn.click();
		}
		dailyCalcSubmitButton.click();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String success = operationSuccessfulText.getText().toString();

		if (success.contains("Operation Successful")) {
			System.out.println("Daily calc created successfully");
		}

	}

	// Daily Calculation program with 15 Mins Grace Round Rule, 30 Auto Deduct
	// Lunch Plan
	public void addDailycalProgram(String dailycalcID, String dailyDescription, String graceRound, String lunchPlan) {

		try {

			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			addNewDailyCalcProgramButton.click();
			dailyCalcProgIdTextBox.sendKeys(dailycalcID);
			dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
			dailyCalcProgGraceRoundRuleLookupIcon.click();
			getElementByDynamicValues("xpath", "graceRoundRuleDropdownValue", graceRound).click();
			dailyCalcProgLunchP.click();
			getElementByDynamicValues("xpath", "lunchPlanRuleDropdownValue", lunchPlan).click();
			waitABit(2000);
			helpIcons();

			dailyCalcProgIncludeIn.shouldBeEnabled();
			if (!dailyCalcProgIncludeIn.isSelected()) {
				dailyCalcProgIncludeIn.click();
			}
			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			String success = operationSuccessfulText.getText().toString();

			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc created successfully");
			}
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Daily Calculation program with 15 Mins Interval Grace Round Rule, 30 Mins
	// Paid Lunch Plan, 10 Mins Break Rule
	public void addDailycalProgramGRS(String dailycalcID, String dailyDescription, String graceRound, String lunchPlan,
			String shiftRule) {

		try {

			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			addNewDailyCalcProgramButton.click();
			dailyCalcProgIdTextBox.sendKeys(dailycalcID);
			dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
			dailyCalcProgGraceRoundRuleLookupIcon.click();
			getElementByDynamicValues("xpath", "graceRoundRuleDropdownValue", graceRound).click();
			dailyCalcProgLunchP.click();
			getElementByDynamicValues("xpath", "lunchPlanRuleDropdownValue", lunchPlan).click();
			dailyCalcProgShiftR.click();
			getElementByDynamicValues("xpath", "shiftPlanRuleDropdownValue", shiftRule).click();
			dailyCalcProgIncludeIn.shouldBeEnabled();
			if (!dailyCalcProgIncludeIn.isSelected()) {
				dailyCalcProgIncludeIn.click();
			}
			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String success = operationSuccessfulText.getText().toString();

			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc created successfully");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Daily Calculation program with Hour Distribution Rule, Grace Round Rule,
	// Lunch Plan, Shift Rule, Break Rule
	public void addDailycalProgramallRules(String dailycalcID, String dailyDescription, String hourDistRule,
			String graceRound, String lunchPlan, String shiftRule, String breakRule) {

		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			addNewDailyCalcProgramButton.click();
			dailyCalcProgIdTextBox.sendKeys(dailycalcID);
			dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
			dailyCalcProgHourDP.click();
			getElementByDynamicValues("xpath", "hourDistributionRuleDropdownValue", hourDistRule).click();
			dailyCalcProgGraceRoundRuleLookupIcon.click();
			getElementByDynamicValues("xpath", "graceRoundRuleDropdownValue", graceRound).click();
			dailyCalcProgLunchP.click();
			getElementByDynamicValues("xpath", "lunchPlanRuleDropdownValue", lunchPlan).click();
			dailyCalcProgShiftR.click();
			getElementByDynamicValues("xpath", "shiftPlanRuleDropdownValue", shiftRule).click();
			dailyCalcProgBreakR.click();
			getElementByDynamicValues("xpath", "breakRulePlanDropdownValue", breakRule).click();
			waitABit(2000);
			helpIcons();
			dailyCalcProgIncludeIn.shouldBeEnabled();
			if (!dailyCalcProgIncludeIn.isSelected()) {
				dailyCalcProgIncludeIn.click();
			}
			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String success = operationSuccessfulText.getText().toString();

			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc created successfully");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Daily Calculation program with Grace Round Rule Break Rule and INCLUDE
	// checkbox unchecked
	public void addDailycalProgramNoInclude(String dailycalcID, String dailyDescription, String graceRound,
			String breakRule) {
		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			addNewDailyCalcProgramButton.click();
			dailyCalcProgIdTextBox.sendKeys(dailycalcID);
			dailyCalcProgDescriptionTextBox.sendKeys(dailyDescription);
			dailyCalcProgGraceRoundRuleLookupIcon.click();
			getElementByDynamicValues("xpath", "graceRoundRuleDropdownValue", graceRound).click();
			dailyCalcProgBreakR.click();
			getElementByDynamicValues("xpath", "breakRulePlanDropdownValue", breakRule).click();
			dailyCalcProgIncludeIn.shouldBeEnabled();
			if (dailyCalcProgIncludeIn.isSelected()) {
				dailyCalcProgIncludeIn.shouldBeEnabled();
			}
			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String success = operationSuccessfulText.getText().toString();
			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc created successfully");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// HelpIcons in Daily calc Program editor
	public boolean helpIcons() throws IOException {

		boolean result = false;
		// waitFor(ExpectedConditions.elementToBeClickable(IncludeInLabel));
		includeInHelpIcon.isVisible();
		includeInHelpIcon.click();
		System.out.println("Alert 1 popup is opened");
		String includecontent = getDriver()
				.findElement(
						By.xpath("//div[contains(@id,'ConfigDailyCalcProgramEditor.ActiveHelpDialog_Content')]//p"))
				.getText();

		if (includecontent != null) {

			result = true;
			System.out.println("Alert 1 message is validated");

		} else {
			// log the failure (Content in the Help window is mismatching)
			System.out.println("Alert 1 message is not correct");

		}
		includeInHelpIcon.click();

		dayOverrideHelpIcon.click();
		System.out.println("Alert 1 popup is opened");

		String dayoverrideicon = getDriver()
				.findElement(By.xpath("//div[contains(@id,'DCalcSencondInfoText_Content')]//p")).getText();

		if (dayoverrideicon != null) {
			result = true;
			System.out.println("Alert 2 message is validated");

		} else {
			// log the failure (Content in the Help window is mismatching)
			System.out.println("Alert 2 message is not correct");

		}

		return result;

	}

	// Search for Daily Calc program and Modify Grace Round and Lunch Plan
	public void searchAndModifyDailyCalc(String dailycalcID, String graceRound, String lunchPlan) {
		try {

			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);
			waitABit(2000);
			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.equalsIgnoreCase(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.1']//a[contains(@id,'ConfigWorkingList.RuleGrid.cell." + i
									+ ".1.widget')]"))
							.click();
					break;
				} else {
					// log the failure "Could not Find the Daily Program ID
				}
			}
			dailyCalcProgGraceRoundRuleLookupIcon.click();
			getElementByDynamicValues("xpath", "graceRoundRuleDropdownValue", graceRound).click();
			dailyCalcProgLunchP.click();
			getElementByDynamicValues("xpath", "lunchPlanRuleDropdownValue", lunchPlan).click();

			waitABit(2000);
			helpIcons();

			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String success = operationSuccessfulText.getText().toString();

			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc modified successfully");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Verify Data is updated
	public void verifyDataMatch(String dailycalcID, String graceRound, String lunchPlan) {

		try {

			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);
			waitABit(2000);
			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.equalsIgnoreCase(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.1']//a[contains(@id,'ConfigWorkingList.RuleGrid.cell." + i
									+ ".1.widget')]"))
							.click();
					break;
				} else {
					// log the failure "Could not Find the Daily Program ID
				}
			}

			waitABit(2000);
			String dCalcID = getDriver()
					.findElement(By.xpath("//div[@id='ConfigDailyCalcProgramEditor.DailyCalcProgramReadonly.wrapper']"))
					.getText();

			if (dCalcID.equalsIgnoreCase(dailycalcID)) {
				System.out.println("Daily calc ID is " + dailycalcID + "");
				getDriver().findElement(By.xpath("//*[@id='ConfigDailyCalcProgramEditor.GraceRoundLookup.input']"))
						.equals(graceRound);
				getDriver().findElement(By.xpath("//*[@id='ConfigDailyCalcProgramEditor.LunchPlanLookup.input']"))
						.equals(lunchPlan);

				dailyCalcCancelButton.click();
			}
			// DailyCalcProgID.containsValue(dailycalcID);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Copy Existing daily calc Program ID
	public void copyExisting(String dailycalcID, String copyCalcID) {

		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);
			waitABit(2000);
			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.equalsIgnoreCase(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.3']/div/div/a"))
							.click();
					break;
				} else {
					// log the failure "Could not Find the Daily Program ID
				}
			}
			dailyCalcProgIdTextBox.clear();
			dailyCalcProgIdTextBox.sendKeys(copyCalcID);
			dailyCalcProgDescriptionTextBox.clear();
			dailyCalcProgDescriptionTextBox.sendKeys("copy of " + copyCalcID + "");
			waitABit(2000);
			helpIcons();
			dailyCalcSubmitButton.click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String success = operationSuccessfulText.getText().toString();

			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc copied successfully");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Delete daily calc Program ID mapped and validate the error message
	public void deleteMappedSearchList(String dailycalcID) {

		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);
			waitABit(2000);
			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.equalsIgnoreCase(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.0']//div[contains(@id,'ConfigWorkingList.RuleGrid.cell." + i
									+ ".0.widget.wrapper')]"))
							.click();
					break;
				} else {
					// log the failure "Could not Find the Daily Program ID
				}
			}
			deletefromSearchList.click();
			// getDriver().switchTo().alert();
			getDriver().findElement(By.id("confirmRemove.yesButton")).click();
			isElementVisible(DeletemappedError);

			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			String delete = getDriver()
					.findElement(By
							.xpath("//*[@id='ConfigWorkingList.ResponseMessages_0.Success.node']//*[contains(text(),'Daily Calculation Program is assigned to a pay class and cannot be deleted.')]"))
					.getText();

			if (delete.contains("Daily Calculation Program is assigned to a pay class and cannot be deleted")) {
				System.out.println("Daily Calculation Program is assigned to a pay class and cannot be deleted "
						+ dailycalcID + "");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Delete daily calc Program ID unmapped and validate the successful message
	public void deleteSuccess(String dailycalcID) {

		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);
			waitABit(2000);
			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.equalsIgnoreCase(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.0']//div[contains(@id,'ConfigWorkingList.RuleGrid.cell." + i
									+ ".0.widget.wrapper')]"))
							.click();
					break;
				}

				else {
					// log the failure "Could not Find the Daily Program ID
				}
			}
			dailyCalcDeleteButton.click();
			// getDriver().switchTo().alert();
			getDriver().findElement(By.id("confirmRemove.yesButton")).click();
			// isElementVisible(DeletemappedError);

			waitABit(2000);

			String success = operationSuccessfulText.getText().toString();

			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc created successfully");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Delete daily calc Program ID unmapped from Search List page and validate
	// the successful message
	public void deleteSuccessSearchPage(String dailycalcID) {

		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);
			waitABit(2000);
			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.equalsIgnoreCase(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.0']//div[contains(@id,'ConfigWorkingList.RuleGrid.cell." + i
									+ ".0.widget.wrapper')]"))
							.click();
					break;
				}

				else {
					// log the failure "Could not Find the Daily Program ID
				}
			}
			deletefromSearchList.click();
			// getDriver().switchTo().alert();
			getDriver().findElement(By.id("confirmRemove.yesButton")).click();
			// isElementVisible(DeletemappedError);

			waitABit(2000);

			String success = operationSuccessfulText.getText().toString();

			if (success.contains("Operation Successful")) {
				System.out.println("Daily calc Deleted successfully");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// Delete daily calc Program ID mapped from Search page and validate the
	// error message in the Search page
	public void deleteMapped(String dailycalcID) {

		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);

			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.contains(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.1']//a[contains(@id,'ConfigWorkingList.RuleGrid.cell." + i
									+ ".1.widget')]"))
							.click();
					break;
					
				} else {
					// log the failure "Could not Find the Daily Program ID
				}
			}
			dailyCalcDeleteButton.click();
			// getDriver().switchTo().alert();
			getDriver().findElement(By.id("confirmRemove.yesButton")).click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String evalue = getDriver()
					.findElement(By
							.xpath("//div[@id='ConfigDailyCalcProgramEditor_MESSAGES']//div[contains(text(),'Daily Calculation Program is assigned to employees as a Day Override and cannot be deleted.')]"))
					.getText();
			if (evalue.contains(dailycalcID)) {
				System.out.println("Daily calc " + dailycalcID + " cannot be deleted ");
			}
			dailyCalcCancelButton.click();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	// 'Include in Day Override Employee Assignments' cannot be deselected.
	// error message validation
	public void includeInDeselect(String dailycalcID) {

		try {
			// getDriver().switchTo().frame(frame_eZlmIFrame);
			// waitFor(ExpectedConditions.textToBePresentInElementValue(DailyCalcProgramTitle,
			// "Daily Calculation Program"));
			searchTextBoxDailyCalcProgram.clear();
			searchTextBoxDailyCalcProgram.sendKeys(dailycalcID);

			for (int i = 0; i <= 100; i++) {

				String sValue = null;
				sValue = getDriver().findElement(By
						.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
								+ i + ".cell.1']"))
						.getText();

				if (sValue.equalsIgnoreCase(dailycalcID)) {
					getDriver().findElement(By
							.xpath("//div[contains(@id,'ConfigWorkingList.RuleGrid.rows')]//div[@id='ConfigWorkingList.RuleGrid.row."
									+ i + ".cell.1']//a[contains(@id,'ConfigWorkingList.RuleGrid.cell." + i
									+ ".1.widget')]"))
							.click();
					break;

				} else {
					// log the failure "Could not Find the Daily Program ID
				}
			}

			waitABit(2000);

			dailyCalcProgIncludeIn.click();
			dailyCalcSubmitButton.click();

			String emessage = deselectMappedErrorText.getText().toString();
			if (emessage.contains("Include in Day Override Employee Assignments")) {
				System.out.println(
						"Include in Day Override Employee Assignments cannot be deselected.  There are employees currently assigned to it");
			}
			dailyCalcCancelButton.click();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void currentEditorPage(String leftPaneMainOption, String editorpagename) {

		boolean breadcrums = getDriver()
				.findElement(By.xpath("//*[@id='DV_Breadcrumb']//*[contains(text(),'You are here')]")).isDisplayed();

		for (int i = 0; i <= 5; i++) {
			String evalue = null;

			evalue = getDriver().findElement(By.xpath(
					"//div[@id='codeslist_NavMenuItemID" + i + "_pane']//*[contains(text(),'" + editorpagename + "')]"))
					.getText();

			if (evalue.equalsIgnoreCase(editorpagename) && breadcrums == true) {
				ExpectedConditions.titleContains(editorpagename);

			} else {

				// nav.wfnleftPaneNavigation(leftPaneMainOption,
				// editorpagename);
				// ExpectedConditions.titleContains(editorpagename);
			}

		}

	}
}
