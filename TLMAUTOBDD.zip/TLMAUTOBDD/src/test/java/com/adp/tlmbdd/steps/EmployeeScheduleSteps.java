package com.adp.tlmbdd.steps;

import com.adp.tlmbdd.pages.editors.EmployeeSchedules;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

@SuppressWarnings("serial")
public class EmployeeScheduleSteps extends ScenarioSteps {

	EmployeeSchedules employeeSchedules;

	@Step
	public void dateDropDown() {
		employeeSchedules.dateRangeShortcuts();
	}

	@Step
	public void searchForLocation(String location) {
		employeeSchedules.searchForLocation(location);
	}

	@Step
	public void verifyDateInput() {
		employeeSchedules.dateInputValidation();
	}

	@Step
	public void dateInputErrorValidation() {
		employeeSchedules.dateInputErrorValidation();
	}

	@Step
	public void searchEmployee(String name) {
		employeeSchedules.searchEmployeeByName(name);
	}

	@Step
	public void addShiftToSchedule(String dept, String paycode) {
		employeeSchedules.addSingleShift(dept, paycode);
	}

	@Step
	public void deleteSingleShift() {
		employeeSchedules.deleteSingleShift();
	}

	@Step
	public void editSingleShift(String dept, String paycode) {
		employeeSchedules.editSingleShift(dept, paycode);
	}

	@Step
	public void inLineEditingAddShiftAutoAdvance() {
		employeeSchedules.inLineEditAutoAutoAdvancedShiftAdd();
	}

	@Step
	public void inLineEditingEditShiftWithEnterKey() {
		employeeSchedules.inLineEditEnterKeyShiftEdit();
	}

	@Step
	public void inLineEditingInsertShiftWithInsertKey() {
		employeeSchedules.inLineEditInsertKeyShiftAdd();
	}

	@Step
	public void inLineEditingOverlapValidation() {
		employeeSchedules.inLineEditShifOverlapValidation();
	}

	@Step
	public void inLineEditingCleanup() {
		employeeSchedules.inLineEditCleanUpDeleteShifts();
	}

	@Step
	public void addMultipleShift(String paycode, String dept, String job, String location) {
		employeeSchedules.addMultipleShiftsAcrossMultipleEmployees(paycode, dept, job, location);
	}

	@Step
	public void editMultipleShift(String paycode, String dept, String job, String location) {
		employeeSchedules.editMultipleShiftsAcrossMultipleEmployees(paycode, dept, job, location);
	}

	@Step
	public void deleteMultipleShift() {
		employeeSchedules.deleteMultipleShifts();
	}

	@Step
	public void multipleShiftAddValidation(String paycode, String dept, String job, String location) {
		employeeSchedules.multipleShiftAddValidation(paycode, dept, job, location);
	}

	@Step
	public void multipleShiftDeleteValidation() {
		employeeSchedules.validateMultipleShiftDelete();
	}

	@Step
	public void multipleShiftEditValidation(String paycode, String dept, String job, String location) {
		employeeSchedules.multipleShiftEditValidation(paycode, dept, job, location);
	}

	@Step
	public void createQuickShift(String paycode, String name, String dept, String job, String location) {
		employeeSchedules.addQuickShift(name, paycode, dept, job, location);
	}

	@Step
	public void quickShiftEdit(String name, String paycode, String dept, String job, String location) {
		employeeSchedules.editQuickShift(name, paycode, dept, job, location);
	}

	@Step
	public void quickShiftAssignment(String quickShift1, String quickShift2) {
		employeeSchedules.assignQuickShift(quickShift1, quickShift2);
	}

	@Step
	public void quickShiftDelete() {
		employeeSchedules.deleteQuickShift();
	}

	@Step
	public void copyPasteFromMenu(String paycode, String dept, String job, String location) {
		employeeSchedules.copyAndPasteUsingMenuLink(paycode, dept, job, location);
	}

	@Step
	public void copyPasteKeyboardShortcuts() {
		employeeSchedules.copyPasteWithKeyboardShortcut();
	}

	@Step
	public void navigateToScheduleAuditPage() {
		employeeSchedules.navigateToRowGrabberPage("0", "Schedule Audit");
	}

	@Step
	public void validateShiftAddAudit(String newDept, String newPaycode) {
		employeeSchedules.validateShiftInsertAudit(newDept, newPaycode);
	}

	@Step
	public void validateShiftUpdateAudit(String dept, String newDept, String paycode, String newPayCode) {
		employeeSchedules.validateShiftUpdateAudit(dept, newDept, paycode, newPayCode);
	}

	@Step
	public void validateShiftDeleteAudit(String dept, String paycode) {
		employeeSchedules.validateShiftDeleteAudit(dept, paycode);
	}

	@Step
	public void validateShiftAuditSorting() {
		employeeSchedules.columnSortingValidation();
	}

	@Step
	public void createScheduleTemplate(String templateName, String paycode, String dept, String job, String location) {
		employeeSchedules.createSingleWeekTemplate(templateName, paycode, dept, job, location);
	}

	@Step
	public void templateEdit(String templateName, String paycode, String newPaycode, String dept, String newDept,
			String job, String newJob, String location, String newLocation) {
		employeeSchedules.editTemplate(templateName, paycode, newPaycode, dept, newDept, job, newJob, location,
				newLocation);
	}

	@Step
	public void templateDelete(String templateName) {
		employeeSchedules.deleteScheduleTemplate(templateName);
	}

	@Step
	public void templateDeleteAuditValidation(String templateName) {
		employeeSchedules.verifyTemplateDeleteAudit(templateName);
	}

	@Step
	public void templateDeleteAuditDetailsValidation(String templateName, String paycode, String newPaycode,
			String dept, String newDept, String job, String newJob, String location, String newLocation) {
		employeeSchedules.verifyTemplateDeleteAuditDetails(templateName, paycode, newPaycode, dept, newDept, job,
				newJob, location, newLocation);
	}

	@Step
	public void verifyTemplateChangeAudit(String templateName, String description, String effDate) {
		employeeSchedules.verifyTemplateChangeAudit(templateName, description, effDate);
	}

	@Step
	public void validateTemplateAuditColumnSorting() {
		employeeSchedules.validateScheduleTemplateAuditSorting();
	}

	@Step
	public void validateTemplateAuditDetails(String templateName, String paycode, String newPaycode, String dept,
			String newDept, String job, String newJob, String location, String newLocation) {
		employeeSchedules.validateTemplateAuditDetails(templateName, paycode, newPaycode, dept, newDept, job, newJob,
				location, newLocation);
	}

	@Step
	public void validateTemplateAuditDetailsColumnSorting() {
		employeeSchedules.validatedTemplateAuditDetailsSorting();
	}

	@Step
	public void likeTheChangeIsNotDisplayed() {
		employeeSchedules.validateRemoveLikeTheChangeLink();
	}

	@Step
	public void empInfoSlideIn(String paycycle, String supervisor) {
		employeeSchedules.employeeInformationValidation(paycycle, supervisor);
	}

	@Step
	public void viewAllNotesSlideIn() {
		employeeSchedules.viewAllNotesPage();
	}

	@Step
	public void monthlyScheduleSlideInValidation(String dept, String job, String location) {
		employeeSchedules.monthlySchedulePage(dept, job, location);
	}

	@Step
	public void monthlyScheduleSlideInShiftDetails(String dept, String job, String location) {
		employeeSchedules.verifyMonthlyScheduleShiftDetailsDialog(dept, job, location);
	}

	@Step
	public void dateSelectionAndViewToggle() {
		employeeSchedules.monthlyScheduleDateSelectionAndViewToggle();
	}

	@Step
	public void timecardSlideinTimecardTab(String dept, String job, String location) {
		employeeSchedules.timecardSlideInIndividaulTimecardTab(dept, job, location);
	}

	@Step
	public void timecardSlideinScheduleTab(String dept, String job, String location) {
		employeeSchedules.timecardSlideInScheduleTab(dept, job, location);
	}

	@Step
	public void timecardSlideInTotalAndTimeOffTabValidations() {
		employeeSchedules.timecardSlideInTotalAndTimeOffTab();
	}

	@Step
	public void timeOffBalancesValidations() {
		employeeSchedules.timeoffBalancesSlidein();
	}

	@Step
	public void clickManageAssignments(String templateName) {
		employeeSchedules.clickManageAssignments(templateName);
	}

	@Step
	public void selectemployees() {
		employeeSchedules.selectemployees();
	}

	@Step
	public void enterMultipleDateRanges() {
		employeeSchedules.enterMultipleDateRanges();
	}
	
	@Step
	public void goBack() {
		employeeSchedules.goBack();
	}

	@Step
	public void assignedEmployees(String templateName) {
		employeeSchedules.assignedEmployees(templateName);
	}

	@Step
	public void verifyTemplateShiftOnEmployee(String inTime, String outTime, String empName) {
		employeeSchedules.verifyTemplateShiftOnEmployee(inTime, outTime, empName);
	}
	@Step
	public void selectSingleEmployee() {
		employeeSchedules.selectSingleEmployee();
	}
	@Step
	public void navigateToTemplates() {
		employeeSchedules.navigateToTemplates();
	}
	@Step
	public void removeTemplateAssignment() {
		employeeSchedules.removeTemplateAssignment();
	}

	@Step
	public void veriftTemplateRemovalOnEmployee(String empName) {
		employeeSchedules.veriftTemplateRemovalOnEmployee(empName);
	}
	@Step
	public void selectAllEmployees() {
		employeeSchedules.selectAllEmployees();
	}

	@Step
	public void selectSameDateRange() {
		employeeSchedules.selectSameDateRange();
	}

	@Step
	public void validateAssignmentsForSameDateRange(String inTime, String outTime, String empName) {
		employeeSchedules.validateAssignmentsForSameDateRange( inTime,  outTime,  empName);
	}
	@Step
	public void navigateToSchedulesPage() {
		employeeSchedules.navigateToSchedulesPage();
	}

	@Step
	public void validateOverlapErrorMessage() {
		employeeSchedules.validateOverlapErrorMessage();
	}

	@Step
	public void multipleTimesTemplate(String templateName, String startTime, String endTime) {
		employeeSchedules.multipleTimesTemplate(templateName, startTime, endTime);
	}

	@Step
	public void selectEmployee(String employeeName) {
		employeeSchedules.selectEmployee(employeeName);
	}

	@Step
	public void multipleShiftsTemplate(String templateName, String startTime, String endTime) {
		employeeSchedules.multipleShiftsTemplate(templateName, startTime, endTime);
	}

	@Step
	public void validateTemplateDetails(String templateName) {
		employeeSchedules.validateTemplateDetails(templateName);
	}

	@Step
	public void navigateToTemplatesList() {
		employeeSchedules.navigateToTemplatesList();
	}

	@Step
	public void deleteShiftsforTemplate(String templateName) {
		employeeSchedules.deleteShiftsforTemplate(templateName);
	}

	@Step
	public void setWrongDateRange() {
		employeeSchedules.setWrongDateRange();
	}

	@Step
	public void validateGreaterStartDate() {
		employeeSchedules.validateGreaterStartDate();
	}

	@Step
	public void setWrongDateRangeForMultipleEmployees() {
		employeeSchedules.setWrongDateRangeForMultipleEmployees();
	}

	@Step
	public void assignedToggleOn() {
		employeeSchedules.assignedToggleOn();
	}

	@Step
	public void clickAssignmentCancel() {
		employeeSchedules.clickAssignmentCancel();
	}

	@Step
	public void navigateFromAssignmentsToTemplateList() {
		employeeSchedules.navigateFromAssignmentsToTemplateList();
	}

	@Step
	public void scheduleAssignmentsClickNext() {
		employeeSchedules.scheduleAssignmentsClickNext();
	}

	@Step
	public void findUsername() {
		employeeSchedules.findUsername();
	}

	@Step
	public void validateUser(String flag) {
		employeeSchedules.validateUser(flag);
	}

	@Step
	public void addShiftToSchedule() {
		employeeSchedules.addShiftToSchedule(1);
	}
	@Step
	public void addNonWorkedShiftToSchedule() {
		employeeSchedules.addShiftToSchedule(0);
	}

	@Step
	public void validateShift() {
		employeeSchedules.validateShift();
	}
	
	@Step 
	public void deleteShift() {
		employeeSchedules.deleteShift();
	}
	
	@Step
	public void validateWorkedHours() {
		employeeSchedules.validateHours("worked");
	}
	
	@Step
	public void validateNonWorkedHours() {
		employeeSchedules.validateHours("non-worked");
	}
	
	@Step
	public void validateWorkedShifts() {
		employeeSchedules.validateShifts("worked");
	}
	
	@Step
	public void validateNonWorkedShifts() {
		employeeSchedules.validateShifts("non-worked");
	}
	
	@Step
	public void scheduledFilter() {
		employeeSchedules.scheduledFilter();
	}
	
	@Step
	public void unscheduledFilter() {
		employeeSchedules.unscheduledFilter();
	}
	
	@Step 
	public void validateScheduleExists() {
		employeeSchedules.validateScheduleExists();
	}
	
	@Step
	public void validateNoScheduleExists() {
		employeeSchedules.validateNoScheduleExists();
	}
	
	@Step
	public void checkEmployeeCountBefore() {
		employeeSchedules.checkEmployeeCount("before");
	}
	
	@Step
	public void checkEmployeeCountAfter() {
		employeeSchedules.checkEmployeeCount("after");
	}
	
	@Step
	public void access() {
		employeeSchedules.access();
	}
	
	@Step 
	public void editSchedulePrivileges(int flag) {
		employeeSchedules.editSchedulePrivileges(flag);
	}
	
	@Step 
	public void editSelfPrivileges() {
		employeeSchedules.editSelfPrivileges();
	}
	
	@Step
	public void validateScheduleDisable() {
		employeeSchedules.validateScheduleDisable();
	}
	
	
}
