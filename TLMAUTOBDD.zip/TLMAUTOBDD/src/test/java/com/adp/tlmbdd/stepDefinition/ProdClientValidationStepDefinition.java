package com.adp.tlmbdd.stepDefinition;


import com.adp.tlmbdd.steps.EmploymentProfileTechRefreshSteps;
import com.adp.tlmbdd.steps.ProdClientValidationSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ProdClientValidationStepDefinition {
	
	
	@Steps
	ProdClientValidationSteps prodclientvalidation;
	
	
	@Then("^Validate Time Tile, Slide In Pay class Summary and Edit Audit Pages are loading fine\\.$")
	public void validate_Time_Tile_Slide_In_Pay_class_Summary_and_Edit_Audit_Pages_are_loading_fine() throws Throwable {
		prodclientvalidation.ValidateTimeTilePages();
	    throw new PendingException();
	}


}
