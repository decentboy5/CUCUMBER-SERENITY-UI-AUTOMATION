package com.adp.tlmbdd.pages;
import com.adp.tlmbdd.pages.*;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import org.openqa.selenium.support.ui.ExpectedConditions;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.pages.WebElementFacadeImpl;
import net.serenitybdd.core.pages.WebElementResolverByLocator;
import net.serenitybdd.core.pages.WebElementState;

public class AccrualsTLM extends GenericPageObject {

	// locators********************************//
	@FindBy(xpath = "//td[contains(text(),'Company Preferences')]")
	private WebElementFacade settings;
	@FindBy(id = "TLMiFrame")
	private WebElementFacade tlmIFrame;
	@FindBy(id = "eZlmIFrame1_iframe")
	private WebElementFacade ezlmIFrame1;
	@FindBy(xpath = "//li[@id='mnuCompanyPreferencesMenuItemCell1']")
	private WebElementFacade additionalFeature;
	@FindBy(xpath = "//div[@widgetid='chkBenefits']")
	private WebElementFacade checkBenifits;
	//@FindBy(xpath = "//td[contains(text(),'Accrual Progressions')]")
	@FindBy(xpath = "//span[contains(text(),'Accrual Progressions')]")
	private WebElementFacade accrualprogression;
	@FindBy(xpath = "//td[contains(text(),'Accrual Definitions')]")
	private WebElementFacade accrualdefnition;
	@FindBy(xpath = "//span[@widgetid='btnAddNew']")
	private WebElementFacade addNew;
	@FindBy(id = "txtAccrualProgression")
	private WebElementFacade txtAccrual;
	@FindBy(id = "multDesc")
	private WebElementFacade accrualdesc;
	@FindBy(xpath = "//div[@widgetid='optAwdEmpAnnDate']")
	private WebElementFacade awardDataType;
	@FindBy(id = "tabAccProgression_1")
	private WebElementFacade awardDetails;
	@FindBy(id = "lbtAddRow")
	private WebElementFacade addRow;
	@FindBy(id = "barButtons_btnSubmit")
	private WebElementFacade submit;
	@FindBy(xpath = "//table[@id=\"tblAwdServLength\"]/tbody/tr")
	private List<WebElementFacade> timeCardTableRowCount;
	@FindBy(xpath = "//table[@id=\"tblAwdServLength\"]/tbody/tr[1][@class='DataTable-BodyRow-Odd']//input[@id='intervalfrhour_0']")
	private WebElementFacade griddata;
	@FindBy(xpath = "//table[@id=\"tblAwdServLength\"]/tbody/tr[1][@class='DataTable-BodyRow-Odd']//input[@id='intervaltohour_0']")
	private WebElementFacade griddataTo;
	@FindBy(xpath = "//table[@id=\"tblAwdServLength\"]/tbody/tr[1][@class='DataTable-BodyRow-Odd']//input[@id='intervalawamt_0']")
	private WebElementFacade griddataAwardAmount;
	@FindBy(xpath = "//table[@id=\"tblAwdServLength\"]/tbody/tr[1][@class='DataTable-BodyRow-Odd']//input[@id='intervalmaxbal_0']")
	private WebElementFacade griddataMaxBal;
	@FindBy(xpath = "//table[@id=\"tblAwdServLength\"]/tbody/tr[1][@class='DataTable-BodyRow-Odd']//input[@id='intervalmaxcarryamt_0']")
	private WebElementFacade griddataMaxCarryAmt;
	Navigation navigation; 
	public Boolean verifyAccuralsfeatureEnabled() {
		Boolean flag = null;
		try
		{
			getDriver().switchTo().defaultContent();
			waitFor(tlmIFrame);
			getDriver().switchTo().frame(tlmIFrame);
			WaitForAjax();
			waitABit(3000);
			clickOnElementIfExists(settings);
			waitFor(ezlmIFrame1);
			getDriver().switchTo().frame(ezlmIFrame1);
			WaitForAjax();
			waitABit(1000);			
			clickOnElementIfExists(additionalFeature);
			waitABit(3000);
			flag=checkElementEnabled(checkBenifits);
			System.out.println("#########"+flag+"#############");
			if(flag==true)
				System.out.println("Accruals are enabled");		
			else
			{
				selectWebCheckBox(checkBenifits,"ON");
			}
		} 
		catch (Exception ex) 
		{
			System.out.println("error in navigation");
			ex.printStackTrace();
		}
		return flag;
	}
	public void addAccrualProgression()
	{
		
		try
		{
			getDriver().switchTo().defaultContent();
			waitFor(tlmIFrame);
			getDriver().switchTo().frame(tlmIFrame);
			System.out.println("#####successfully entered frame");
			WaitForAjax();
			waitABit(3000);	
			waitForElementToLoad(accrualprogression);
			clickOnElementIfExists(accrualprogression);
			navigation.wfnEditorsFrameSelection();
			//waitFor(ezlmIFrame1);
			//getDriver().switchTo().frame(ezlmIFrame1);
			//WaitForAjax();
			waitABit(3000);	
			System.out.println("#####successfully entered frame");
			clickOnElementIfExists(addNew);
			WaitForAjax();
			waitABit(3000);		
			txtAccrual.waitUntilVisible();
			txtAccrual.clear();
			txtAccrual.sendKeys("Test_Accrual");
			accrualdesc.waitUntilVisible();
			accrualdesc.clear();
			accrualdesc.sendKeys("Test_Accrual");
			waitForElementToLoad(awardDataType);
			clickOnElementIfExists(awardDataType);
			clickOnElementIfExists(awardDetails);
			waitABit(3000);
			clickOnElementIfExists(addRow);
			waitABit(3000);
			addAwardDetails();
//			for (int i = 1; i < timeCardTableRowCount.size(); i++) {
//				List<WebElement> actualWebElementList = getDriver().findElements(By.xpath("//table[@id=\"tblAwdServLength\"]/tbody/tr[1][@class='DataTable-BodyRow-Odd']/td[i]"));
//				for (WebElement webElement : actualWebElementList) {
//					System.out.println(webElement.getText());
//				}
//			}
			waitABit(3000);
			clickOnElementIfExists(submit);			
		}
		catch (Exception ex) 
		{
			System.out.println("error in navigation");
			ex.printStackTrace();
		}
	}
	public void addAwardDetails()
	{
		griddata.waitUntilVisible();
		griddata.clear();
		griddata.sendKeys("10");
		griddataTo.waitUntilVisible();
		griddataTo.clear();
		griddataTo.sendKeys("100");
		griddataAwardAmount.waitUntilVisible();
		griddataAwardAmount.clear();
		griddataAwardAmount.sendKeys("100");
		griddataMaxBal.waitUntilVisible();
		griddataMaxBal.clear();
		griddataMaxBal.sendKeys("10");
		griddataMaxCarryAmt.waitUntilVisible();
		griddataMaxCarryAmt.clear();
		griddataMaxCarryAmt.sendKeys("10");
	}
	
	public void addAccrualDefinition()
	{
		try
		{
			getDriver().switchTo().defaultContent();
			waitFor(tlmIFrame);
			getDriver().switchTo().frame(tlmIFrame);
			System.out.println("#####successfully entered frame");
			WaitForAjax();
			waitABit(3000);	
			waitForElementToLoad(accrualdefnition);
			clickOnElementIfExists(accrualdefnition);
		}
		catch(Exception ex)
		{
			
			System.out.println("error in navigation");
			ex.printStackTrace();
		}
	}
		
}
