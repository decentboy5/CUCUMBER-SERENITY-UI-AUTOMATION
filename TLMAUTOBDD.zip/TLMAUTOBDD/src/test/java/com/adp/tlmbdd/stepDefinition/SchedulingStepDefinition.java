package com.adp.tlmbdd.stepDefinition;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.adp.tlmbdd.common.SQLScriptRunner;
import com.adp.tlmbdd.common.TestCaseConstant;
import com.adp.tlmbdd.common.TestCaseContext;
import com.adp.tlmbdd.common.DateUtils;
import com.adp.tlmbdd.common.SQLQueryConstant;

import cucumber.api.java.en.Given;

public class SchedulingStepDefinition {

	@Given("^I Calculated first week of current month$")
	public void i_calculate_first_week_of_current_month() throws Throwable {
		int startDayOfWeek = this.getStartDayOfTheWeek();
		String startDayofWeekStr = DateUtils.weekDays.get(startDayOfWeek);
		TestCaseContext.setValue(TestCaseConstant.STARTDAYOFTHEWEEK, startDayofWeekStr);
		LocalDate todaydate = LocalDate.now();
		TestCaseContext.setValue(TestCaseConstant.TODAY, todaydate);
		LocalDate firstDate = todaydate.withDayOfMonth(1);
		TestCaseContext.setValue(TestCaseConstant.FIRSTDAYOFMONTH, firstDate);
		String fromDate = DateUtils.getWeekStartEndDateFromDate(DayOfWeek.valueOf(startDayofWeekStr), firstDate, 1);
		String toDate = DateUtils.getWeekStartEndDateFromDate(DayOfWeek.valueOf(startDayofWeekStr), firstDate, 7);
		TestCaseContext.setValue(TestCaseConstant.FROMDATE, fromDate);
		TestCaseContext.setValue(TestCaseConstant.TODATE, toDate);
	}

	@Given("^I Created \"([^\"]*)\" daily schedules in the first week \"([^\"]*)\"$")
	public void i_created_daily_schedules_in_the_first_week(int noOfSChedules, String positionId) throws Exception {
		for (int i = 1; i <= noOfSChedules; i++) {
			createSchedule(i, positionId, "08:00:00", "16:00:00", "28800");
		}
	}
	
	@Given("^I Created template schedules in the first week \"([^\"]*)\"$")
	public void i_created_template_schedules_in_the_first_week(String positionId) throws Exception {
		createTemplateSchedules(positionId, "28800", "56000", "28000", "TTTTTFF");
	}
	
	private void createTemplateSchedules(String positionId,String inTime_seconds,
			String outTime_seconds, String totalTime,String sequenceDays) throws Exception{
		Map<String, Object> params = new HashMap<>();
		params.put("POSITIONID", positionId);
		params.put("TEMPLATEID", "TMPL_AUT_"+System.currentTimeMillis());
		params.put("WEEKLYSCHEDTEMPLATEID", getObjectId(SQLQueryConstant.TABLE_WEEKLYSCHEDTMPLT_TAB));
		params.put("EMPLOYEESCHEDREFID", getObjectId(SQLQueryConstant.TABLE_EMPLOYEESCHEDREF_TAB));
		params.put("FROMDATE",(String)TestCaseContext.getValue(TestCaseConstant.FROMDATE));
		params.put("TODATE",(String)TestCaseContext.getValue(TestCaseConstant.TODATE));
		params.put("TEMPLATE_INTIME", inTime_seconds);
		params.put("TEMPLATE_OUTTIME", outTime_seconds);
		params.put("TEMPLATE_TOTALTIME", totalTime);
		params.put("SEQUENCEDAYS", sequenceDays);
		System.out.println(SQLQueryConstant.SCHEDULING_CREATE_WEEKLYSCHEDTMPLT);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CREATE_WEEKLYSCHEDTMPLT, params);
		System.out.println(SQLQueryConstant.SCHEDULING_CREATE_SEQDAILYDETAIL);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CREATE_SEQDAILYDETAIL, params);
		System.out.println(SQLQueryConstant.SCHEDULING_CREATE_EMPLOYEESCHEDREF);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CREATE_EMPLOYEESCHEDREF, params);
			
	}
	private void createSchedule(int dayIndexOfFirstweek, String positionId, String inTime_hh_colon_mm_colon_ss,
			String outTime_hh_colon_mm_colon_ss, String totalTime) throws Exception {
		Map<String, Object> params = new HashMap<>();
		params.put("POSITIONID", positionId);
		String startDayOftheWeek = (String) TestCaseContext.getValue(TestCaseConstant.STARTDAYOFTHEWEEK);
		LocalDate firstDate = (LocalDate) TestCaseContext.getValue(TestCaseConstant.FIRSTDAYOFMONTH);
		String dateN = DateUtils.getWeekStartEndDateFromDate(DayOfWeek.valueOf(startDayOftheWeek), firstDate,
				dayIndexOfFirstweek);
		System.out.println("startDayoftheWeek   while creating schedules" + startDayOftheWeek);
		params.put("INTIME_IN_MMDDYYYY_HHMMSS", dateN + " " + inTime_hh_colon_mm_colon_ss);
		params.put("OUTTIME_IN_MMDDYYYY_HHMMSS", dateN + " " + outTime_hh_colon_mm_colon_ss);
		params.put("TOTALTIME", totalTime);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CREATE_DAILYSCHEDULE, params);
	}

	@Given("^Clear existing schedules of employee \"([^\"]*)\"$")
	public void clear_existing_schedules_of_employee(String positionId) throws Throwable {
		Map<String, Object> params = new HashMap<>();
		params.put("POSITIONID", positionId);
		// clear daily schedules
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CLEAR_ALL_DAILY_SCHEDULES_BY_POSITION, params);
		// clear template schedules
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CLEAR_EMPLOYEESCHEDREF_BY_POSITION, params);
		params.put("TEMPLATEID_PATTERN", "TMPL_AUT_%");
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CLEAR_SEQDAILYDETAIL, params);
		SQLScriptRunner.executeUpdate(SQLQueryConstant.SCHEDULING_CLEAR_WEEKLYSCHEDTMPLT, params);
	}

	private int getStartDayOfTheWeek() throws Exception {
		int startDayOftheWeek = 0;
		// get first day of week
		Map<String, Object> params = new HashMap<>();
		params.put("ATTRIBUTE", "STARTDAYOFWEEK");
		// clear daily schedules
		List<Map<String, String>> result = SQLScriptRunner
				.executeQuery(SQLQueryConstant.COMPANYCONFIG_GET_VALUE_BY_ATTRIBUTE, params);
		if (result != null && !result.isEmpty()) {
			Map<String, String> attributeValue = result.get(0);
			startDayOftheWeek = Integer.parseInt(attributeValue.get("VALUE"));
		}
		return startDayOftheWeek;
	}
	private String getObjectId(String tableName) throws Exception{
		String objectId = null;
		Map<String, Object> params = new HashMap<>();
		params.put("TABLENAME", tableName);
		// clear daily schedules
		List<Map<String, String>> result = SQLScriptRunner
				.executeQuery(SQLQueryConstant.SCHEDULING_GET_NEW_ID, params);
		if (result != null && !result.isEmpty()) {
			Map<String, String> attributeValue = result.get(0);
			objectId = attributeValue.get("ID");
		}
		return objectId;
	}
}
