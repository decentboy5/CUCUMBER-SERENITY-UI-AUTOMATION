package com.adp.tempus.steps;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import com.adp.tempus.pages.NewHire;
public class NewHireSteps extends ScenarioSteps {
	
	NewHire newHire;
	
	@Step
	public void verify_HireRehire_page_is_loaded_properly() {
		newHire.verify_HireRehire_page_is_loaded_properly();
	}
	
	@Step
	public void validate_HR_Only_Template_is_displayed() {
		newHire.validate_HR_Only_Template_is_displayed();
	}
	
	@Step 
	public void navigate_to_HR_Only_Template() {
		newHire.navigate_to_HR_Only_Template();
	}
	
	@Step 
	public void verify_time_section_is_not_displayed() {
		newHire.verify_time_section_is_not_displayed();
	}
	
	@Step
	public void Cancel_the_New_Hire_creation() {
		newHire.Cancel_the_New_Hire_creation();
	}
	
	@Step
	public void verify_navigate_back_to_HireRehire_page() {
		newHire.verify_navigate_back_to_HireRehire_page();
	}
	
	@Step
	public void validate_Paid_Contractor_Template_is_displayed() {
		newHire.validate_Paid_Contractor_Template_is_displayed();
	}
	
	@Step
	public void navigate_to_Paid_Contractor_Template() {
		newHire.navigate_to_Paid_Contractor_Template();
	}
	
	@Step
	public void validate_Paid_Employee_Template_is_displayed() {
		newHire.validate_Paid_Employee_Template_is_displayed();
	}
	
	@Step
	public void navigate_to_Paid_Employee_Template() {
		newHire.navigate_to_Paid_Employee_Template();
	}
	
	@Step
	public void verify_time_section_is_displayed() {
		
	}
	
}
