package com.adp.tempus.pages;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.openqa.selenium.By;
import com.adp.tlmbdd.pages.GenericPageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class HireRehire extends GenericPageObject {
	public String position_Id="";
	public String pay_Group="";
	@FindBy(xpath = "//div[text()='Paid Employee (W2)']")
	public WebElementFacade btn_PaidEmployee;

	@FindBy(xpath = "//input[@id='Name.first']")
	public WebElementFacade txtBox_FName;

	@FindBy(xpath = "//input[@id='Name.last']")
	public WebElementFacade txtBox_LName;

	By dropDown_TaxIdType = By
			.xpath("//div[@id='TaxIdComponent_taxidtype']");

	@FindBy(xpath = "//input[@id='TaxIdComponent_taxid']")
	public WebElementFacade txtBox_TaxId;

	@FindBy(xpath = "//input[@id='TaxIdComponent_reentertaxid']")
	public WebElementFacade txtBox_ReEnterTaxId;

	@FindBy(xpath = "//div[@class='mdf-taxId-applied-cell']//label")
	public WebElementFacade chkBox_AppliedFor;

	@FindBy(xpath = "//input[@id='HireDate']")
	public WebElementFacade txtBox_HireDate;

	@FindBy(xpath = "//input[@id='BirthDate']")
	public WebElementFacade txtBox_BirthDate;

	By dropDown_HireReason = By.xpath("//div[@id='ReasonForHire']");

	By dropDown_Country = By
			.xpath("//label[text()='Country']/following-sibling::div");

	@FindBy(xpath = "//label[text()='Address Line 1']/following-sibling::input")
	public WebElementFacade txtBox_AddrLine1;

	@FindBy(xpath = "//label[text()='City']/following-sibling::input")
	public WebElementFacade txtBox_City;

	@FindBy(xpath = "//label[text()='Zip Code']/following-sibling::input")
	public WebElementFacade txtBox_Zip;

	By dropDown_State = By
			.xpath("//label[text()='State / Territory']/following-sibling::div");

	@FindBy(xpath = "//div[@id='Personal']//button[.='Next']")
	public WebElementFacade btn_PersonalNext;

	@FindBy(xpath = "//div[@id='Employment']//button[.='Next']")
	public WebElementFacade btn_EmploymentNext;

	@FindBy(xpath = "//div[@id='Payroll']//button[.='Next']")
	public WebElementFacade btn_PayrollNext;

	@FindBy(xpath = "//div[@id='Tax Jurisdiction']//button[.='Next']")
	public WebElementFacade btn_TaxJurisdictionNext;

	@FindBy(xpath = "//div[@id='Time Attendance']//button[.='Next']")
	public WebElementFacade btn_TimeAttendanceNext;

	By dropDown_PayGroup = By.xpath("//div[@id='companyCode']");

	@FindBy(xpath = "//div[@id='posid']//input")
	public WebElementFacade txtBox_PositionId;

	By dropDown_LegalEntity = By.xpath("//div[@id='legalEntity']");

	By dropDown_Supervisor = By.xpath("//div[@id='timePiSupervisor']");

	By dropDown_TimeZone = By.xpath("//div[@name='timezone'][@role='combobox']");

	By dropDown_RegularPayRate = By.xpath("//div[@id='regularPayRate']");

	By dropDown_Overtime = By.xpath("//div[@id='overtimePolicy']");

	@FindBy(xpath = "//div[.='USD']//input")
	public WebElementFacade txtBox_RegPayRate;

	By dropDown_WorkState = By.xpath("//div[@id='stateJurisdiction']");

	By dropDown_ResidenceState = By
			.xpath("//div[@id='resStateJurisdiction']");

	By dropDown_TimeEntry = By.xpath("//div[@name='Time Entry'][@role='combobox']");

	@FindBy(xpath = "//input[@id='badgeNumber']")
	public WebElementFacade txtBox_Badge;

	@FindBy(xpath = "//button[.='Cancel']")
	public WebElementFacade btn_Cancel;
	
	@FindBy(xpath = "//button[.='SAVE & EXIT']")
	public WebElementFacade btn_SaveExit;
	
	@FindBy(xpath = "//button[.='Review']")
	public WebElementFacade btn_Review;
	
	@FindBy(xpath = "//button[.='Done']")
	public WebElementFacade btn_Done;
	
	public void selectHireTemplate(String hireTemplate) {
		if (hireTemplate.contentEquals(""))
			return;
		switch (hireTemplate.toUpperCase().trim()) {
		case "PAID EMPLOYEE":
			btn_PaidEmployee.waitUntilClickable();
			btn_PaidEmployee.waitUntilClickable().click();
			break;
		case "PAID CONTRACTOR":
			break;
		case "HR ONLY":
			break;
		}
	}

	public void enterBasicDetailsOnPersonalStep(String fName, String lName,String taxIdType,String taxId, String hDate,String hireReason) {
		try{if(fName.contentEquals("")&&lName.contentEquals("")) {
			fName=DateTime.now().toString("MMddHHmmss");
			System.out.println(DateTime.now().toString("MMddHHmmss"));
			lName="BVTNewHire";
		}
		txtBox_FName.type(fName);
		txtBox_LName.type(lName);
		// enhancement required
		//String taxIDType = "United States Social Security Number (SSN)";
		if(taxIdType.contentEquals("") || taxIdType.contentEquals("United States Social Security Number (SSN)")){
			taxIdType="United States Social Security Number (SSN)";
			selectValueFromComboBox(dropDown_TaxIdType, taxIdType);
			if (taxId.contentEquals("")) {
				chkBox_AppliedFor.click();
			} else {
				txtBox_TaxId.type(taxId);
				txtBox_ReEnterTaxId.type(taxId);
			}
		}else if(taxIdType.contentEquals("United States Employer Identification Number (EIN)")){
			txtBox_TaxId.type(taxId);
		}
		txtBox_HireDate.type(hDate);
		selectValueFromComboBox(dropDown_HireReason, hireReason);		
		txtBox_BirthDate.type("1/1/1980");
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void enterAddressDetailsOnPersonalStep(String country,String addrLine1,String city,String state,String zip) {
		//String country = "United States";
		scrollIntoView(txtBox_AddrLine1);
		selectValueFromComboBox(dropDown_Country, country);
		txtBox_AddrLine1.type(addrLine1);
		txtBox_City.type(city);
		selectValueFromComboBox(dropDown_State, state);
		txtBox_Zip.type(zip);
	}

	public void enterEmploymentDetailsOnEmploymentStep(String payGroup, String positionId, String legalEntity,
			String supervisor) {
		pay_Group=payGroup;
		selectValueFromComboBox(dropDown_PayGroup, payGroup);
		
		if(positionId.contentEquals("")&&txtBox_PositionId.getValue().contentEquals("")) {
			position_Id=DateTime.now().toString("MMddss");
			txtBox_PositionId.type(position_Id);}
		//Assert.assertTrue("Position Id is mandatory field, please provide value",false);
		else if(!positionId.contentEquals("")){ txtBox_PositionId.type(positionId); position_Id=positionId;}
		else if(!txtBox_PositionId.getValue().contentEquals("")){position_Id=txtBox_PositionId.getValue();}
		selectValueFromComboBox(dropDown_LegalEntity, legalEntity);
		if(!supervisor.contentEquals(""))
		selectValueFromComboBox(dropDown_Supervisor, supervisor);
	}

	public void enterDetailsOnPayrollStep(String regPayRateType, String payRate, String overtime) {
		if(regPayRateType.contentEquals("")||regPayRateType.toUpperCase().contentEquals("HOURLY"))
		selectValueFromComboBox(dropDown_RegularPayRate, "HOURLY");
		else if(regPayRateType.toUpperCase().contentEquals("SALARY")) selectValueFromComboBox(dropDown_RegularPayRate, "SALARY");
		else Assert.assertTrue("Invalid Rate Type",false);
		if(!payRate.contentEquals(""))
		txtBox_RegPayRate.type(payRate);else txtBox_RegPayRate.type("50");
		if(!overtime.contentEquals(""))
		selectValueFromComboBox(dropDown_Overtime, overtime);
	}

	public void enterDetailsOnTaxJurisdictionsStep(String workState, String residenceState) {
		selectValueFromComboBox(dropDown_WorkState, workState);
		selectValueFromComboBox(dropDown_ResidenceState, residenceState);
	}

	public void enterDetailsOnTimeAttendanceStep(String timeEntry, String badge, String timeZone) {
		try{
			if(!timeEntry.contentEquals(""))
		selectValueFromComboBox(dropDown_TimeEntry, timeEntry);
		else Assert.assertFalse("Time Entry policy is Required!!", true);
		if(badge.contentEquals(""))
			badge="B"+DateTime.now().toString("MMddss");
		System.out.println(badge);
		txtBox_Badge.type(badge);
		if(!timeEntry.contentEquals(""))
		selectValueFromComboBox(dropDown_TimeZone, timeZone);
		else selectValueFromComboBox(dropDown_TimeZone, "EST - Eastern Standard Time");
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void clickNextButtonOnStep(String stepName) {
		if (stepName.contentEquals(""))
			return;
		switch (stepName.toUpperCase().trim()) {
		case "PERSONAL":
			scrollIntoView(btn_PersonalNext);
			btn_PersonalNext.waitUntilClickable();
			btn_PersonalNext.click();
			break;
		case "EMPLOYMENT":
			scrollIntoView(btn_EmploymentNext);
			btn_EmploymentNext.waitUntilClickable();
			btn_EmploymentNext.click();
			break;
		case "PAYROLL":
			scrollIntoView(btn_PayrollNext);
			btn_PayrollNext.waitUntilClickable();
			btn_PayrollNext.click();
			break;
		case "TAX JURISDICTIONS":
			scrollIntoView(btn_TaxJurisdictionNext);
			btn_TaxJurisdictionNext.waitUntilClickable();
			btn_TaxJurisdictionNext.click();
			break;
		case "TIME & ATTENDANCE":
			scrollIntoView(btn_TimeAttendanceNext);
			btn_TimeAttendanceNext.waitUntilClickable();
			btn_TimeAttendanceNext.click();
			break;
		}
	}

	public void clickButtonOnHireRehire(String btnName) {
		if (btnName.contentEquals(""))
			return;
		switch (btnName.toUpperCase().trim()) {
		case "CANCEL":
			btn_Cancel.waitUntilClickable();
			btn_Cancel.click();
			break;
		case "SAVE & EXIT":
			btn_SaveExit.waitUntilClickable();
			btn_SaveExit.click();
			break;
		case "REVIEW":
			btn_Review.waitUntilClickable();
			btn_Review.click();
			break;
		case "DONE":
			btn_Done.waitUntilClickable();
			btn_Done.waitUntilClickable();
			btn_Done.click();
			break;
		}
	}
}
