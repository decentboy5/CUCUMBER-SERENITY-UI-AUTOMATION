package com.adp.tempus.steps;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.jruby.ir.operands.Array;

import com.adp.tempus.pages.YourTimecard;

import com.adp.tempus.stepDefinition.YourTimePortletsStepDefinition;

import cucumber.api.java.en.Then;;

public class YourTimecardSteps extends ScenarioSteps {

	YourTimecard yourTimecardBase;
	
	@Steps
	YourTimePortletsSteps yourTimePortletsSteps;


	
	
	
	
	@Step
	public void emp_yourTimecard_Verify_PageLoading() {
		yourTimecardBase.emp_yourTimecard_Verify_PageLoading();
	}

	@Step
	public List<String> emp_youtTimecard_GetPunchTime() {
		return yourTimecardBase.emp_yourTimecard_GetPunchTime();
	}

	@Step
	public Boolean emp_yourTimecard_CheckTimePair_Existence(List<String> timePairList, String timePair) {
		return yourTimecardBase.emp_yourTimecard_CheckTimePair_Existence(timePairList, timePair);
	}

	@Step
	public void emp_YourTimcard_Navigation() {
		yourTimecardBase.emp_YourTimcard_Navigation();
	}

	@Step
	public void emp_yourTimecard_addTimepair(String inTime, String outTime, int rowNumber) {
		yourTimecardBase.emp_yourTimecard_addTimepair(inTime, outTime, rowNumber);
	}

	@Step
	public void emp_yourTimecard_editTimePair(int day) {
		yourTimecardBase.emp_yourTimecard_editTimePair(day);
	}
	
	@Step
	public void emp_yourTimecard_editTimePair_note(int day) {
		yourTimecardBase.emp_yourTimecard_editTimePair_note(day);
	}

	@Step
	public void emp_youTimecard_saveTimePair(Boolean successFlag) {
		yourTimecardBase.emp_youTimecard_saveTimePair(successFlag);
	}

	@Step
	public void emp_yourTimecard_deleteTimePair(boolean deleteMultipleFalg) {
		yourTimecardBase.emp_yourTimecard_deleteTimePair(deleteMultipleFalg);
	}

	@Step
	public void emp_youTime_verify_approveTimecard_pageLoading() {
		yourTimecardBase.emp_youTime_verify_approveTimecard_pageLoading();
	}

	@Step
	public void emp_yourTimecard_verify_approvedTimecard() {
		yourTimecardBase.emp_yourTimecard_verify_approvedTimecard();
	}

	@Step
	public List<String> emp_getListOfDates_withTimePairs() {
		return yourTimecardBase.emp_getListOfDates_withTimePairs();
	}

	@Step
	public void emp_yourTimecard_clickOn_backToTimecard() {
		yourTimecardBase.emp_yourTimecard_clickOn_backToTimecard();
	}

	@Step
	public void emp_yourTimecard_select_timePeriod(String timePeriod) {
		yourTimecardBase.emp_yourTimecard_select_timePeriod(timePeriod);
	}

	@Step
	public void emp_yourTimecard_clickOn_approveTimecard() {
		yourTimecardBase.emp_yourTimecard_clickOn_approveTimecard();
	}

	@Step
	public List<Integer> emp_yourTimecard_get_timePeriod_dateList(String timePeriod) {
		return yourTimecardBase.emp_yourTimecard_get_timePeriod_dateList(timePeriod);
	}

	@Step
	public String emp_yourTimecard_Select_currentPayPeriod(String monthName, int date) {
		return yourTimecardBase.emp_yourTimecard_Select_currentPayPeriod(monthName, date);
	}

	@Step
	public List<String> emp_yourTimecard_getTotalHours() {
		return yourTimecardBase.emp_yourTimecard_getTotalHours();
	}

	@Step
	public List<String> emp_yourTimecard_getTimePairs() {
		return yourTimecardBase.emp_yourTimecard_getTimePairs();
	}

	@Step
	public void emp_yourTimecard_verify_readOnlyStatus(boolean readonlyFlag) {
		yourTimecardBase.emp_yourTimecard_verify_readOnlyStatus(readonlyFlag);
	}
	

	@Step
	public List<String> emp_yourTimecard_timecardGrid_GetPunchTime(int day) {
		return yourTimecardBase.emp_yourTimecard_timecardGrid_GetPunchTime(day);
	}

	@Step
	public void emp_yourTimecard_enable_showDetails(boolean showDetailsFlag) {
		yourTimecardBase.emp_yourTimecard_enable_showDetails(showDetailsFlag);
	}
	
	@Step
	public void emp_yourTimecard_clicOn_addTime() {
		yourTimecardBase.emp_yourTimecard_clicOn_addTime();
	}
	
	
	@Step
	public List<String> emp_yourTimecard_get_allNotes() {
		return yourTimecardBase.emp_yourTimecard_get_allNotes();
	}
	
	@Step
	public void emp_yourTimecard_verify_note_existence(List<String> notesList, String note, boolean noteExistenceFlag) {
		yourTimecardBase.emp_yourTimecard_verify_note_existence(notesList, note , noteExistenceFlag);
	}
	
	@Step
	public void emp_yourTimecard_updateNote(String noteMessage, int rowNo) {
		yourTimecardBase.emp_yourTimecard_updateNote(noteMessage, rowNo);
	}
	
	@Step
	public void emp_verify_element_existence(YourTimecard.data emp_verify_element_existence,boolean existenceFalg) {
		yourTimecardBase.emp_verify_element_existence(emp_verify_element_existence, existenceFalg);
	}
	
	
	@Step
	public String calculate_hours(String time1 , String time2) {
		 return yourTimecardBase.calculate_hours(time1,time2);
	 }
  
	

	
	//----------------------------- common fuctions ------------------------------------------//
	
	/** your timecard ---delete time pairs   
	 * 
	 * @param day   ---- 0 select date and select time period
	 * @param deleteTimecardFlag  true -- delete timecard , false -- delete time pairs in the day
	 */
	
	@Step
	public void emp_yourTimecard_delete_timePairs(String day,boolean deleteTimecardFlag)
	{
		if(day.equals("TODAYDATE"))
		{
			day = "0";
		}else if(YourTimecard.data.toDay.toString().equals(day))
		{
			day = "0";
		}
		
		//************ select time pay period **********************************/
		
		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = yourTimePortletsSteps.get_date(day, "date");

		System.out.println(" date is :" + date);

		String timePeriod = emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		System.out.println(" time period is :" + timePeriod);
		
		emp_YourTimcard_Navigation();

		emp_yourTimecard_select_timePeriod(timePeriod);

		emp_yourTimecard_Verify_PageLoading();
		
		
		//------------- delete timecard  -------------------//
		
		if(deleteTimecardFlag)
		{
			List<String> dates = emp_getListOfDates_withTimePairs();
			for (String t_date : dates) {
				System.out.println(" date is " + t_date);
				emp_yourTimecard_editTimePair(Integer.parseInt(t_date));
				emp_yourTimecard_deleteTimePair(true);
				emp_yourTimecard_clickOn_backToTimecard();
			}
		}else {
			//----------- delete time pair -----------------------//
			emp_yourTimecard_editTimePair(Integer.parseInt(date));
	        emp_yourTimecard_deleteTimePair(true);
			emp_yourTimecard_clickOn_backToTimecard();
			
		}
		
		
	}
	
     /** your timecard --- verify time pairs 
      * 
      * @param pairs  -- need to pass expected timep pairs 10:00 AM - 11:00 AM
      * @param day     --- day we need to select like 0 , 1 
      */
	@Step
	public void emp_yourTimecard_verify_timepairs_and_totalHours(List<String> pairs ,String day)
	{
		
		if(day.equals("TODAYDATE"))
		{
			day = "0";
		}
		
		List<String> timePairs = new ArrayList<String>();
		
		String date = yourTimePortletsSteps.get_date(day, "date");

		System.out.println(" date is :" + date);
		
		emp_yourTimecard_editTimePair(Integer.parseInt(date));
		
		
		timePairs = emp_yourTimecard_getTimePairs();
		
		boolean status = Arrays.asList(timePairs).contains(pairs);
		 
		System.out.println("the result is   "+status);
		 
		assertTrue("verify time pairs and total hours ",status);
		 
	}
	
	/**  your timecard ----- adding time pairs 
	 *   
	 * @param timePairs  --  10:00 AM - 11:00 AM
	 * @param day   ---- day we need to adding time pair  day like - 0 , 1
	 */
	
	@Step
	public void emp_yourTimecard_add_timePairs(List<String> timePairs, String day,boolean addNewRowFlag)
	{
		System.out.println(" date is :");
		
		if(day.equals("TODAYDATE"))
		{
			day = "0";
		}
		

		String date = yourTimePortletsSteps.get_date(day, "date");

		System.out.println(" date is :" + date);
		
		emp_yourTimecard_editTimePair(Integer.parseInt(date));
		
		if(!addNewRowFlag)
		{
		int i=1;
		for(String t_timePairs : timePairs)
		{
			String[] t_time = t_timePairs.split("-");
			
			emp_yourTimecard_addTimepair(t_time[0].trim(), t_time[1].trim(),i);
			
			i++;
		}
		}else {
			
			
			for(String t_timePairs : timePairs)
			{
				String[] t_time = t_timePairs.split("-");
				
				emp_yourTimecard_addTimepair(t_time[0].trim(), t_time[1].trim(),-1);
				
			}
		}
		
		emp_youTimecard_saveTimePair(true);
		
		emp_yourTimecard_clickOn_backToTimecard();
		
	}
	
	/**
	 *  your timecard ---verify-- time punch existence on timecard
	 * @param Day  ---0 , 1 , -1
	 * @param punchType  --- ClockIn, ClockOut, TakeAMeal, MealReturn
	 */
	@Step
	public void emp_yourTimecard_verify_punch(String Day , String punchType)
   {
	   
		HashMap<String, String> monthDate = new HashMap<String, String>();
		
		monthDate = emp_yourTimecard_select_payPeriod("0");
		
		emp_yourTimecard_editTimePair(Integer.parseInt(monthDate.get(YourTimecard.data.date.toString())));

		List<String> timePunchs = emp_youtTimecard_GetPunchTime();

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);
		}
		if(punchType.equals(YourTimecard.data.clockIn.toString())) {
		    emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockInTime); // punch time should be update
		}else if(punchType.equals(YourTimecard.data.clockOut))
		{
			 emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockOutTime); // punch time should be update
		}else if(punchType.equals(YourTimecard.data.takeAMeal.toString()))
		{
			emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.mealOutTime); // punch time should be update
		}else {
			emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.mealReturnTime); // punch time should be update
		}
   }
	
	
	/**
	 *  your timecard ---verify-- time punch existence on timecard -- clock employee
	 * @param Day  ---0 , 1 , -1
	 * @param punchType  --- ClockIn, ClockOut, TakeAMeal, MealReturn
	 */
	@Step
	public void emp_yourTimecard_verify_punch_clockEmp(String Day , String punchType)
   {
	   
		HashMap<String, String> monthDate = new HashMap<String, String>();
		
		monthDate = emp_yourTimecard_select_payPeriod("0");
		
		//emp_yourTimecard_editTimePair(Integer.parseInt(monthDate.get(YourTimecard.data.date.toString())));

		
		emp_yourTimecard_enable_showDetails(true);
			
			List<String> timePunchs = emp_yourTimecard_timecardGrid_GetPunchTime(Integer.parseInt(monthDate.get(YourTimecard.data.date.toString())));

			for (String timePunch : timePunchs) {
				System.out.println("time card punches : " + timePunch);
			}
		
		
		
		if(punchType.equals(YourTimecard.data.clockIn.toString())) {
		    emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockInTime); // punch time should be update
		}else if(punchType.equals(YourTimecard.data.clockOut))
		{
			 emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockOutTime); // punch time should be update
		}else if(punchType.equals(YourTimecard.data.takeAMeal.toString()))
		{
			emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.mealOutTime); // punch time should be update
		}else {
			emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.mealReturnTime); // punch time should be update
		}
		
		
   }
	
	
	
	
	
	/** employee -- yourtimecard -- select pay period 
	 * 
	 * @param day   day like as 1 , 3 , -3
	 * @return
	 */
	
@Step
public HashMap<String, String> emp_yourTimecard_select_payPeriod(String day)
{
	HashMap<String,String> monthDate  =new HashMap<String,String>();    
	
	String monthName = yourTimePortletsSteps.get_date(day, "todayMonth").toLowerCase();

	System.out.println("month is :" + monthName);

	monthDate.put(YourTimecard.data.monthName.toString(),monthName); 
	
	String date = yourTimePortletsSteps.get_date(day, "date");
	
	monthDate.put(YourTimecard.data.date.toString(), date);

	System.out.println("date is :" + date);

	String timePeriod = emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
			Integer.parseInt(date));

	System.out.println("time period is :" + date);
	
	monthDate.put("timePeriod",timePeriod);
	
	emp_YourTimcard_Navigation();

	emp_yourTimecard_select_timePeriod(timePeriod);

	emp_yourTimecard_Verify_PageLoading();
	
	return monthDate;
	
}
 

/** employee --- your timecard -- verify note presence
 * 
 * @param noteExistanceFlag   - true -- should be presence 
 */

@Step
public void emp_yourTimecard_verify_note_presence(boolean noteExistanceFlag)
{
		List<String> noteList =  emp_yourTimecard_get_allNotes();
	
		emp_yourTimecard_verify_note_existence(noteList,YourTimePortletsStepDefinition.note,noteExistanceFlag);
	
}


/** employee --- your timecard -- verify note presence
 * 
 * @param noteExistanceFlag   - true -- should be presence 
 */

@Step
public void emp_yourTimecard_verify_note_presence_clockEmp(String day, boolean noteExistanceFlag)
{
	   String date = yourTimePortletsSteps.get_date(day, "date");
	
	       emp_yourTimecard_editTimePair_note(Integer.parseInt(date));
	        
	     List<String> noteList =  emp_yourTimecard_get_allNotes();
	
		emp_yourTimecard_verify_note_existence(noteList,YourTimePortletsStepDefinition.note,noteExistanceFlag);
}


/**  your timecard --- verify total hours 
 * 
 * @param day    day we need to select 
 * @param hours   total hours 
 */

@Step
public void emp_yourTimecard_Verify_totalHours(String day , String hours)
{
	List<String> HoursList = new ArrayList<String>();
	
	
	//emp_yourTimecard_select_payPeriod(day);
	
	HoursList = emp_yourTimecard_getTotalHours();
	
	boolean status = HoursList.contains(hours);
	
	assertTrue("verify time pairs total hours ",status);
	
}

@Step
public void emp_yourTimecard_clickOn_element(String elementName)
{
	

	if(elementName.equalsIgnoreCase("Approve Timecard"))
	{
	  emp_yourTimecard_clickOn_approveTimecard();
	}
	 
}

@Step
public void emp_yourTimecard_verify_element_existence(String elementName)
{
	if (elementName.equalsIgnoreCase("timecard approved message")) {
		 emp_verify_element_existence(YourTimecard.data.timecardApproved, true);
	} else if (elementName.equalsIgnoreCase("pending for manager approval message")) {
		emp_verify_element_existence(YourTimecard.data.pendingForManagerApproval, true);
	}
	else {
		assertTrue("time card approval message invalid", false);
	}
}










	
	//---------------- end common functions-------------------------------------------------------------------//
	

}
