package com.adp.tempus.steps;

import com.adp.tempus.pages.HireRehire;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class HireRehireSteps extends ScenarioSteps {

	HireRehire hireRehire;
	
	@Step
	public void selectHireTemplate(String templateName) {
		hireRehire.selectHireTemplate(templateName);
	}
	@Step
	public void enterBasicDetailsOnPersonalStep(String fName, String lName, String taxIdType, String taxId,
			String hDate,String hireReason) {
		hireRehire.enterBasicDetailsOnPersonalStep(fName,lName,taxIdType,taxId,hDate,hireReason);
	}
	@Step
	public void enterAddressDetailsOnPersonalStep(String country,String addrLine1,String city,String state,String zip) {
		hireRehire.enterAddressDetailsOnPersonalStep(country,addrLine1,city,state,zip);
	}
	@Step
	public void enterEmploymentDetailsOnEmploymentStep(String payGroup, String positionId, String legalEntity,
			String supervisor) {
		hireRehire.enterEmploymentDetailsOnEmploymentStep(payGroup,positionId,legalEntity,supervisor);
	}
	@Step
	public void enterDetailsOnPayrollStep(String regPayRateType, String payRate, String overtime) {
		hireRehire.enterDetailsOnPayrollStep(regPayRateType,payRate,overtime);
	}
	@Step
	public void enterDetailsOnTaxJurisdictionsStep(String worskState, String residenceState) {
		hireRehire.enterDetailsOnTaxJurisdictionsStep(worskState,residenceState);
	}
	@Step
	public void enterDetailsOnTimeAttendanceStep(String timeEntry, String badge, String timeZone) {
		hireRehire.enterDetailsOnTimeAttendanceStep(timeEntry,badge,timeZone);
	}
	@Step
	public void clickNextButtonOnStep(String stepName) {
		hireRehire.clickNextButtonOnStep(stepName);
	}
	@Step
	public void clickButtonOnHireRehire(String btnName) {
		hireRehire.clickButtonOnHireRehire(btnName);
	}
}
