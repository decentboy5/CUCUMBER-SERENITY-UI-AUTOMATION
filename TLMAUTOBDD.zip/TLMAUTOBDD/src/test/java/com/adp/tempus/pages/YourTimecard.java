package com.adp.tempus.pages;

import static org.junit.Assert.assertTrue;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.tlmbdd.pages.GenericPageObject;
import com.adp.tlmbdd.pages.Navigation;
import com.adp.tlmbdd.steps.TimecardAccumulatorSteps;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class YourTimecard extends GenericPageObject {

	@FindBy(xpath = "//*[@id='timeCard_root']/descendant::div[contains(@class,'panel timecard')]")
	private WebElementFacade tbl_Timecard;

	@FindBy(xpath = "//span[text()='APPROVE TIMECARD']/..")
	private WebElementFacade btn_approveTimecard;

	@FindBy(xpath = "//span[text()='Yes']/..")
	private WebElementFacade btn_Yes_popup;

	@FindBy(xpath = "//div[contains(@class,'time-entry-row')][last()]/descendant::input[1]")
	private WebElementFacade tbx_inTime;

	@FindBy(xpath = "//div[contains(@class,'time-entry-row')][last()]/descendant::input[2]")
	private WebElementFacade tbx_outTime;

	@FindBy(xpath = "//span[text()='Save']/..")
	private WebElementFacade btn_save_timePair;

	@FindBy(xpath = "//div[contains(text(),'Successfully saved')]")
	private WebElementFacade lbl_successfully_saved;

	@FindBy(xpath = "//div[@id='timeCard_root']/descendant::span[text()='DELETE TIME'][1]")
	private WebElementFacade lnk_deleteTime;

	@FindBy(xpath = "//div[contains(text(),'Deletion successful')]")
	private WebElementFacade lbl_deleteSuccessful;

	@FindBy(xpath = "(//div[contains(text(),'You have approved your timecard') or contains(text(),'Waiting For Manager Approval') or contains(text(),'Timecard Approved') or contains(text(),'approved by your manager')])[1]")
	private WebElementFacade lbl_approvedYourTimecard;

	@FindBy(xpath = "//div[contains(text(),'Your timecard is pending approval from your manager')]")
	private WebElementFacade lbl_pendingApprovalFromYourManager;

	@FindBy(xpath = "//div[contains(text(),'must reapprove your timecard')]")
	private WebElementFacade lbl_reapproveTimecard;

	@FindBy(xpath = "//div[contains(text(),'have approved this timecard')]")
	private WebElementFacade lbl_approvedThisTimecard;

	@FindBy(xpath = "//div[contains(text(),'approved by your manager')]")
	private WebElementFacade lbl_approvedByYourManager;

	@FindBy(xpath = "//div[contains(text(),'you must reapprove')]")
	private WebElementFacade lbl_mustReapprove;

	@FindBy(xpath = "//*[@id='timeCard_root']/descendant::span[contains(@class,'left-arrow-icon')]")
	private WebElementFacade imgIcon_leftArrow_backToTimecard;

	@FindBy(xpath = "//div[@id='tc-time-period-list-row']/descendant::div[contains(@class,'dropdown-indicator')]")
	private WebElementFacade imgIcon_downArrow_timePeriod;

	@FindBy(xpath = "//div[@id='tc-time-period-list-row']/descendant::div[contains(@class,'menu-list')]/div[1]")
	private WebElementFacade ddlOption_previous_payPeriod;

	@FindBy(xpath = "//div[@id='tc-time-period-list-row']/descendant::div[contains(@class,'menu-list')]/div[2]")
	private WebElementFacade ddlOption_current_payPeriod;

	@FindBy(xpath = "//div[@id='tc-time-period-list-row']/descendant::div[contains(@class,'menu-list')]/div[3]")
	private WebElementFacade ddlOption_Next_payPeriod;

	@FindBy(xpath = "//div[contains(@class,'ug-day')]/../../descendant::span[@class='fa fa-plus-circle' or contains(@class,'fa fa-pencil')]")
	private WebElementFacade imgIcon_plus_or_editPencil;

	@FindBy(xpath = "//*[contains(@id,'ToggleSwitch') and contains(@class,'checked')]")
	private WebElementFacade btnSwitch_showDetails_checked;

	@FindBy(xpath = "//div[@class='vdl-toggle-switch__knob']")
	private WebElementFacade btnSwitch_showDetails;

	@FindBy(xpath = "//span[text()='ADD TIME']")
	private WebElementFacade lnk_addTIme;

	@FindBy(xpath = "//div[contains(@class,'time-entry-row')][1]")
	private WebElementFacade element_timePairRow;

	By lnk_deleteTimes_list = By.xpath("//div[@id='timeCard_root']/descendant::span[text()='DELETE TIME']");
	By imgIcon_editPencil_list = By
			.xpath("//span[contains(@class,'fa fa-pencil')]/ancestor::div[contains(@class,'cell-header')]/div[1]");
	By lbl_totalHours_timepair_list = By
			.xpath("//*[@id='timeCard_root']/descendant::div[contains(@class,'total-time-entry')]");
	By tbx_timePairds_list = By.xpath("//div[@id='timeCard_root']/descendant::input");
	By txtArea_note_list = By.xpath("//*[@id='timeCard_root']/descendant::div[contains(@class,'read-only-text user-comment')] | //*[@id='timeCard_root']/descendant::textarea");

	YourTimePortlets yourTimePortlets;

	public void yourTimePortletsObject() {
		if (yourTimePortlets == null) {
			yourTimePortlets = new YourTimePortlets();
		}
	}

	public enum e_timePeriod {
		previous, current, feature;
	}

	/**
	 * Verify your timecard page loading
	 */
	public void emp_yourTimecard_Verify_PageLoading() {
		// YourTimePortlets timePortlets = new YourTimePortlets();
		yourTimePortletsObject();
		waitForElementToLoad(tbl_Timecard);
		assertTrue("verify your timecard page loading", checkElementVisible(tbl_Timecard));
		yourTimePortlets.waitForPageLoad(6);
	}

	/**
	 * your timecard page -- get all punches based particular day prerequisite :
	 * employee should be on your timecard edit time pair page
	 * 
	 * @return list of all time pairs on that day
	 */
	public List<String> emp_yourTimecard_GetPunchTime() {
		yourTimePortletsObject();
		List<String> timepairData = new ArrayList<String>();
		waitForWebElementToLoad(getDriver().findElement(tbx_timePairds_list));
		yourTimePortlets.waitForPageLoad(2);
		List<WebElement> timePairs = getDriver().findElements(tbx_timePairds_list); // tbx_timePairs
		for (WebElement element : timePairs) {
			String punchData = element.getAttribute("value");
			System.out.println("Punch data " + punchData);
			timepairData.add(punchData);
		}

		return timepairData;
	}

	/**
	 * employee --yourTimecard --timecard grid -- get all punch time pairs
	 * Precondition: enable show details for timecard grid
	 * 
	 * @param day -- day--- we need to get all punches
	 * @return --- list of time pairs on based in the day
	 */

	public List<String> emp_yourTimecard_timecardGrid_GetPunchTime(int day) {
		yourTimePortletsObject();
		List<String> timepairData = new ArrayList<String>();
		yourTimePortlets.waitForPageLoad(3);
		List<WebElement> timePairs = getDriver().findElements(By.xpath("//div[contains(@class,'ug-day') and text()='"
				+ day
				+ "']/../../descendant::div[contains(@class,'in-time') or contains(@class,'start') or contains(@class,'end') and not(contains(@class,'skip-end '))]")); // tbx_timePairs
		for (WebElement element : timePairs) {
			String punchData = element.getText().trim();
			System.out.println("Punch data " + punchData);
			if (yourTimePortlets.isNullOrEmpty(punchData)) {
				continue;
			}
			timepairData.add(punchData);
		}

		return timepairData;
	}

	/**
	 * Compare timepair list with time card
	 * 
	 * @param timePairList ---- list of time pairs
	 * @param timePair     --- time pair to be validate
	 * @return -- retun boolean value
	 */
	public Boolean emp_yourTimecard_CheckTimePair_Existence(List<String> timePairList, String timePair) {
		return timePairList.contains(timePair);
	}

	/**
	 * Employee your time card navigation
	 */
	public void emp_YourTimcard_Navigation() {
		yourTimePortletsObject();
		// Navigation nav = new Navigation();
		// nav.wfnmainShellPageNavigation("Myself", "Time & Attendance", "Your
		// Timecard");
		yourTimePortlets.tempus_MenuNavigation("Myself", "Time & Attendance", "Your Timecard", "Your Timecard");
		emp_yourTimecard_Verify_PageLoading();
		yourTimePortlets.waitForPageLoad(4);
	}

	/**
	 * your time card ----- add time pair------
	 * 
	 * @param inTime  ---- in Time of time pair
	 * @param outTime ---- out time of time pair
	 */
	public void emp_yourTimecard_addTimepair(String inTime, String outTime, int rowNo) {
		yourTimePortletsObject();
		yourTimePortlets.waitForPageLoad(2);

		if (rowNo == 0) {
			if (!yourTimePortlets.isNullOrEmpty(inTime)) {
				tbx_inTime.waitUntilClickable().typeAndTab(inTime);// tbx_outTime
			}
			if (!yourTimePortlets.isNullOrEmpty(outTime)) {
				tbx_outTime.waitUntilClickable().typeAndTab(outTime); // tbx_inTime
			}
		} else if (rowNo == -1) {

			emp_yourTimecard_clicOn_addTime();

			if (!yourTimePortlets.isNullOrEmpty(inTime)) {
				tbx_inTime.waitUntilClickable().typeAndTab(inTime);// tbx_outTime
			}
			if (!yourTimePortlets.isNullOrEmpty(outTime)) {
				tbx_outTime.waitUntilClickable().typeAndTab(outTime); // tbx_inTime
			}
		} else {

			if (!checkElementVisible("//div[contains(@class,'time-entry-row')][" + rowNo + "]/descendant::input[1]")) {
				emp_yourTimecard_clicOn_addTime();
			}

			if (!yourTimePortlets.isNullOrEmpty(inTime)) {
				$("//div[contains(@class,'time-entry-row')][" + rowNo + "]/descendant::input[1]").waitUntilClickable()
						.typeAndTab(inTime);// tbx_outTime
			}
			if (!yourTimePortlets.isNullOrEmpty(outTime)) {
				$("//div[contains(@class,'time-entry-row')][" + rowNo + "]/descendant::input[2]").waitUntilClickable()
						.typeAndTab(outTime); // tbx_inTime
			}
		}

	}

	/**
	 * your timecard --- edit time pair
	 * 
	 * @param day -- day we need to edit time pair ex ; 5, 12
	 */
	public void emp_yourTimecard_editTimePair(int day) {
		try {
			yourTimePortletsObject();
			waitForElementToLoad($("//div[contains(@class,'ug-day') and text()='" + day
					+ "']/../../descendant::span[@class='fa fa-plus-circle' or contains(@class,'fa fa-pencil')]")); // Img_plus_pencil_edit
			yourTimePortlets.waitForPageLoad(2);

			$("//div[contains(@class,'ug-day') and text()='" + day
					+ "']/../../descendant::span[@class='fa fa-plus-circle' or contains(@class,'fa fa-pencil')]") // Img_plus_pencil_edit
							.click();// imgBtn_addTimepair
		} catch (Exception e) {
			$("(//div[contains(@class,'ug-day') and contains(text(),'" + day
					+ "')])[last()]/../../descendant::span[@class='fa fa-plus-circle' or contains(@class,'fa fa-pencil')]")
							.waitUntilClickable().click();
		}
		waitForElementToLoad(tbx_inTime);
		yourTimePortlets.waitForPageLoad(3);
		assertTrue("verify edit timepair page loading", checkElementVisible(tbx_inTime));
	}

	/**
	 * your timecard --- edit time pair note
	 * 
	 * @param day -- day we need to edit time pair ex ; 5, 12
	 */
	public void emp_yourTimecard_editTimePair_note(int day) {
		try {
			yourTimePortletsObject();
			waitForElementToLoad($("//div[contains(@class,'ug-day') and text()='" + day
					+ "']/../../descendant::span[contains(@class,'fa-comment')]")); // Img_plus_pencil_edit
			yourTimePortlets.waitForPageLoad(2);

			$("//div[contains(@class,'ug-day') and text()='\" + day\r\n"
					+ "					+ \"']/../../descendant::span[contains(@class,'fa-comment')]") // Img_plus_pencil_edit
							.click();// imgBtn_addTimepair
		} catch (Exception e) {
			$("(//div[contains(@class,'ug-day') and contains(text(),'" + day
					+ "')])[1]/../../descendant::span[contains(@class,'fa-comment')]").waitUntilClickable().click();
		}
		waitForElementToLoad(element_timePairRow);
		yourTimePortlets.waitForPageLoad(3);
		assertTrue("verify edit timepair page loading", checkElementVisible(element_timePairRow));

	}

	/**
	 * your time card --- save your time pair precondition: should be on edit time
	 * pair page
	 * 
	 * @param successFlag ---true -- should be success , false -- should be fail
	 */
	public void emp_youTimecard_saveTimePair(Boolean successFlag) {
		waitForElementToLoad(btn_save_timePair); // btn_Save
		btn_save_timePair.waitUntilClickable().click(); // btn_Save
		if (successFlag) {
			lbl_successfully_saved.waitUntilPresent();
			assertTrue("verify save time pair successfull", checkElementVisible(lbl_successfully_saved));
		} else {
			assertTrue("function not implemented", false);
		}
	}

	/**
	 * your timeTimecard ----delete timepairs
	 * 
	 * @param deleteMultipleFalg --- True -- delete all time pairs , false ----
	 *                           delete singel timepair
	 */
	public void emp_yourTimecard_deleteTimePair(boolean deleteMultipleFalg) {

		yourTimePortletsObject();
		if (!deleteMultipleFalg) {
			lnk_deleteTime.waitUntilVisible();
			lnk_deleteTime.click();
			yourTimePortlets.waitForPageLoad(3);
			if (checkElementVisible(btn_Yes_popup)) {
				btn_Yes_popup.waitUntilClickable().click();// btn_yes
				lbl_deleteSuccessful.waitUntilPresent();
				assertTrue("verify deletion successful message", checkElementVisible(lbl_deleteSuccessful));
			}
		} else {
			List<WebElement> timePairs = getDriver().findElements(lnk_deleteTimes_list); // tbx_timePairs
			for (WebElement element : timePairs) {
				waitForWebElementToLoad(element);
				// yourTimePortlets.waitForPageLoad(1);
				lnk_deleteTime.waitUntilPresent();// link_deleteMe
				lnk_deleteTime.click();
				if (checkElementVisible(btn_Yes_popup)) {
					btn_Yes_popup.waitUntilPresent().click();// btn_yes
					lbl_deleteSuccessful.waitUntilPresent();
					assertTrue("verify deletion successful message", lbl_deleteSuccessful.isPresent());

				}

			}

		}
	}

	/**
	 * employee -- your timecard -- approve timecard
	 */
	public void emp_yourTimecard_clickOn_approveTimecard() {
		waitForElementToLoad(btn_approveTimecard);
		btn_approveTimecard.click();
		waitForElementToLoad(lbl_approvedYourTimecard);
		assertTrue("verify timecard approval message", lbl_approvedYourTimecard.isPresent());

	}

	/**
	 * employee -- your timecard --verify approved timecard
	 */
	public void emp_yourTimecard_verify_approvedTimecard() {
		waitForElementToLoad(lbl_approvedYourTimecard);
		// lbl_approvedYourTimecard.waitUntilPresent();// lbl_approvedYourTimecard
		assertTrue("verify timecard approval message", lbl_approvedYourTimecard.isPresent());
	}

	/**
	 * employee -- yourTimecard ---- get dates which have time pairs
	 * 
	 * @return list<String> -- return list of dates
	 */
	public List<String> emp_getListOfDates_withTimePairs() {
		// yourTimePortletsObject();
		List<String> timePairDates = new ArrayList<String>();
		yourTimePortlets.waitForPageLoad(2);
		List<WebElement> dateElements = getDriver().findElements(imgIcon_editPencil_list); // lbl_timePairEditIconCount
		for (WebElement element : dateElements) {
			String date = element.getText().trim();
			if (date.length() > 4) {
				date = date.split(" ")[1]; // handling date start with month name
			}
			timePairDates.add(date);
		}
		return timePairDates;
	}

	/**
	 * employee ---your timecard page -- click on back to timecard
	 */
	public void emp_yourTimecard_clickOn_backToTimecard() {
		yourTimePortletsObject();
		waitForElementToLoad(imgIcon_leftArrow_backToTimecard);
		yourTimePortlets.waitForPageLoad(2);
		imgIcon_leftArrow_backToTimecard.waitUntilClickable().click();
		emp_yourTimecard_Verify_PageLoading();

	}

	/**
	 * employee -- yourTimecard--- select time period
	 * 
	 * @param timePeriod --- time period should be previous or current or next
	 */
	public void emp_yourTimecard_select_timePeriod(String timePeriod) {
		yourTimePortletsObject();
		waitForElementToLoad(imgIcon_downArrow_timePeriod);
		yourTimePortlets.waitForPageLoad(2);
		imgIcon_downArrow_timePeriod.waitUntilVisible().click();

		if (timePeriod.equalsIgnoreCase("previous")) {
			ddlOption_previous_payPeriod.waitUntilClickable().click();
		} else if (timePeriod.equalsIgnoreCase("current")) {
			ddlOption_current_payPeriod.waitUntilClickable().click();
		} else {

			ddlOption_Next_payPeriod.waitUntilClickable().click();
		}

	}

	/**
	 * employee - yourTimecard -- get time period -- date list
	 * 
	 * @param timePeriod
	 * @return
	 */

	public List<Integer> emp_yourTimecard_get_timePeriod_dateList(String timePeriod) {
		List<Integer> dateList = new ArrayList<Integer>();
		String period = "";

		imgIcon_downArrow_timePeriod.waitUntilVisible().click();// ddlArrow_timePeriod
		if (timePeriod.equalsIgnoreCase("previous")) {
			period = ddlOption_previous_payPeriod.waitUntilVisible().getText();// ddlOption_firstOption_previous
		} else if (timePeriod.equalsIgnoreCase("current")) {
			period = ddlOption_current_payPeriod.waitUntilVisible().getText(); // ddlOption_firstOption_current
		} else {

			period = ddlOption_Next_payPeriod.waitUntilVisible().getText(); //// ddlOption_firstOption_next
		}

		String[] periodList = period.split(" ");

		dateList.add(Integer.parseInt(periodList[1]));
		dateList.add(Integer.parseInt(periodList[4]));

		return dateList;

	}

	/**
	 * Employee ---yourTimecard -- get time pairs total hours list precondition:
	 * should be edit time pair page
	 * 
	 * @return total hours list
	 */

	public List<String> emp_yourTimecard_getTotalHours() {
		// *[@id='timeCard_root']/descendant::div[contains(@class,'total-time-entry')]

		List<String> totalHours = new ArrayList<String>();
		List<WebElement> totalHourElements = getDriver().findElements(lbl_totalHours_timepair_list); // lbl_timePairTotalHours
		for (WebElement element : totalHourElements) {
			String hours = element.getText().trim();
			hours = hours.split(" ")[1].trim(); // handling date start with month name
			System.out.println("time pair date :" + hours);
			totalHours.add(hours);
		}
		return totalHours;
	}

	/**
	 * employee -- yourTimecard -- get all time pairs list -- in and out consider as
	 * one time pair precondition: should be on edit timepair page
	 * 
	 * @return -- list of time pairs Ex : 10:30 AM 3:00 PM
	 */

	public List<String> emp_yourTimecard_getTimePairs() {

		System.out.println("time   pair date   :");
		List<String> timePairs = new ArrayList<String>();
		int timePairRows = getDriver().findElements(lbl_totalHours_timepair_list).size(); // lbl_timePairRows

		for (int i = 1; i <= timePairRows; i++) {

			String inTime = $("//*[@id='timeCard_root']/descendant::div[contains(@class,'time-entry-row')][" + i
					+ "]/descendant::div[contains(@class,'in-time-entry')]//input").getValue();// tbx_inTime

			String outTime = $("//*[@id='timeCard_root']/descendant::div[contains(@class,'time-entry-row')][" + i
					+ "]/descendant::div[contains(@class,'out-time-entry')]//input").getValue();// tbx_outTime

			String totalHours = $("//*[@id='timeCard_root']/descendant::div[contains(@class,'time-entry-row')][" + i
					+ "]/descendant::div[contains(@class,'total-time-entry')]").getText();// tbx_outTime

			String row_timePair = inTime + "-" + outTime + "-" + totalHours;

			System.out.println("time pair date :" + row_timePair);

			timePairs.add(row_timePair);
		}

		return timePairs;

	}

	/**
	 * employee -- your timecard -- verify timecard read and edit status
	 * 
	 * @param readonlyFlag -- true ---- read only , false -- read and edit status
	 */

	public void emp_yourTimecard_verify_readOnlyStatus(boolean readonlyFlag) {
		yourTimePortletsObject();
		yourTimePortlets.waitForPageLoad(2);
		if (readonlyFlag) {
			imgIcon_plus_or_editPencil.waitUntilNotVisible();
			assertTrue("Verify timecard read only status", !imgIcon_plus_or_editPencil.isPresent());

		} else {
			waitForElementToLoad(imgIcon_plus_or_editPencil);
			assertTrue("Verify timecard read and edit status", imgIcon_plus_or_editPencil.isPresent());
		}

	}

	/**
	 * employee ---- yourTimecard -- enable and disable show details switch
	 * 
	 * @param showDetailsFlag -- true-- enable , false --- disable
	 */
	public void emp_yourTimecard_enable_showDetails(boolean showDetailsFlag) {
		System.out.println(" ");
		yourTimePortletsObject();
		yourTimePortlets.waitForPageLoad(2);
		if (showDetailsFlag) {
			if (!checkElementVisible(btnSwitch_showDetails_checked)) // btnSwitch_showDetails_checked
			{
				btnSwitch_showDetails.waitUntilClickable().click(); // btnSwitch_showDetails
				btnSwitch_showDetails_checked.waitUntilPresent();
				assertTrue("verify show details enable status", btnSwitch_showDetails_checked.isPresent());
				yourTimePortlets.waitForPageLoad(3);
			}
		} else {
			if (checkElementVisible(btnSwitch_showDetails_checked)) // btnSwitch_showDetails_checked
			{
				btnSwitch_showDetails.waitUntilClickable().click(); // btnSwitch_showDetails
				assertTrue("verify show details unchecked status", !btnSwitch_showDetails_checked.isPresent());
				yourTimePortlets.waitForPageLoad(3);
			}
		}
	}

	/**
	 * employee -- your timecard -- verify approve timecard buton
	 */
	public void emp_youTime_verify_approveTimecard_pageLoading() {
		emp_yourTimecard_Verify_PageLoading();
		btn_approveTimecard.waitUntilPresent().shouldBePresent();
	}

	/**
	 * wait for invisibility of element
	 * 
	 * @param element
	 */
	public void waitForInVisibility(WebElementFacade element) {
		for (int i = 1; i <= 15; i++) {
			try {

				element.waitUntilNotVisible();
				Thread.sleep(1000);

			} catch (Exception e) {
				break;
			}

		}

	}

	/**
	 * employee -- yourTimecard --- get time period based on month and date
	 * 
	 * @param monthName --enter month name
	 * @param day       -- day need to pass
	 * @return ---return time period based on month and date ex : current , previous
	 *         and next
	 */

	public String emp_yourTimecard_Select_currentPayPeriod(String monthName, int day) {

		String result = "";
		String period = "";
		int actualDay;
		yourTimePortletsObject();
		waitForElementToLoad(imgIcon_downArrow_timePeriod);
		yourTimePortlets.waitForPageLoad(2);
		imgIcon_downArrow_timePeriod.waitUntilVisible().click();// ddlArrow_timePeriod
		period = ddlOption_previous_payPeriod.waitUntilClickable().getText();// ddlOption_firstOption_previous

		String[] periodList = period.split(" ");
		if (monthName.contains(periodList[0].trim().toLowerCase())) {

			actualDay = Integer.parseInt(periodList[1]);
			if (day >= actualDay) {
				actualDay = Integer.parseInt(periodList[4]);
				if (!monthName.contains(periodList[3].trim().toLowerCase())) {
					result = e_timePeriod.previous.toString();
				} else {
					if (day <= actualDay) {
						result = e_timePeriod.previous.toString();
					}
				}

			}

		} else if (monthName.contains(periodList[3].trim().toLowerCase())) {

			actualDay = Integer.parseInt(periodList[4]);
			if (day <= actualDay) {
				result = e_timePeriod.previous.toString();
			}

		}

		period = ddlOption_current_payPeriod.waitUntilClickable().getText(); // ddlOption_firstOption_current

		periodList = period.split(" ");
		if (monthName.contains(periodList[0].trim().toLowerCase())) {

			actualDay = Integer.parseInt(periodList[1]);
			if (day >= actualDay) {
				actualDay = Integer.parseInt(periodList[4]);
				if (!monthName.contains(periodList[3].trim().toLowerCase())) {
					result = e_timePeriod.current.toString();
				} else {
					if (day <= actualDay) {
						result = e_timePeriod.current.toString();
					}
				}

			}

		} else if (monthName.contains(periodList[3].trim().toLowerCase())) {

			actualDay = Integer.parseInt(periodList[4]);
			if (day <= actualDay) {
				result = e_timePeriod.current.toString();
			}

		}

		if (ddlOption_Next_payPeriod.isPresent()) {

			period = ddlOption_Next_payPeriod.waitUntilClickable().getText(); //// ddlOption_firstOption_next

			periodList = period.split(" ");
			if (monthName.contains(periodList[0].trim().toLowerCase())) {

				actualDay = Integer.parseInt(periodList[1]);
				if (day >= actualDay) {
					actualDay = Integer.parseInt(periodList[4]);
					if (!monthName.contains(periodList[3].trim().toLowerCase())) {
						result = e_timePeriod.feature.toString();
					} else {
						if (day <= actualDay) {
							result = e_timePeriod.feature.toString();
						}
					}

				}

			} else if (monthName.contains(periodList[3].trim().toLowerCase())) {

				actualDay = Integer.parseInt(periodList[4]);
				if (day <= actualDay) {
					result = e_timePeriod.feature.toString();
				}

			}
		}

		return result;

	}

	/**
	 * employee -- yourTimecard ----- click on add time Prerequisite: should be on
	 * edit time card page
	 */

	public void emp_yourTimecard_clicOn_addTime() {
		lnk_addTIme.waitUntilClickable().click();
		yourTimePortletsObject();
		yourTimePortlets.waitForPageLoad(3);
	}

	/**
	 * employee -- yourtimecard ----get all notes list
	 * 
	 * @return
	 */
	public List<String> emp_yourTimecard_get_allNotes() {

		List<String> noteList = new ArrayList<String>();
		waitForWebElementToLoad(getDriver().findElement(txtArea_note_list));
		yourTimePortlets.waitForPageLoad(2);
		List<WebElement> notes = getDriver().findElements(txtArea_note_list); // tbx_timePairs
		for (WebElement element : notes) {
			String noteMessage = element.getText();
			System.out.println("note message " + noteMessage);
			noteList.add(noteMessage);
		}

		return noteList;

	}

	/**
	 * verify note message existence
	 * 
	 * @param notesList         -- need to pass list of notes
	 * @param note              --- expected note
	 * @param noteExistenceFlag -- true -- not should be available , false ---
	 *                          should not be available
	 */

	public void emp_yourTimecard_verify_note_existence(List<String> notesList, String note, boolean noteExistenceFlag) {
		if (noteExistenceFlag) {
			assertTrue("Verify that note message should be presence", notesList.contains(note));
		} else {
			assertTrue("Verify that note message should be presence", !notesList.contains(note));
		}
	}

	/**
	 * employee -- your time card - check element availability
	 * 
	 * @param element             --- webElementFacade element need to pass
	 * @param elementPresenceFlag true-- should be presence, false --should not be
	 *                            presence
	 */

	public void emp_yourTime_verify_element_existence(WebElementFacade element, boolean elementPresenceFlag) {
		if (elementPresenceFlag) {
			waitForElementToLoad(element);
			assertTrue("verify that element should be display", element.isPresent());
		} else {
			element.waitUntilNotVisible();
			assertTrue("verify that element should not be display", !element.isPresent());
		}

	}

	/**
	 * employee -- your timecard ---- verify element availability
	 * 
	 * @param existenceFalg -- true -- should be available , false --- should not be
	 *                      available
	 */
	public void emp_verify_element_existence(YourTimecard.data elementName, boolean existenceFalg) {

		switch (elementName) {
		case pendingForManagerApproval:
			if (existenceFalg) {
				emp_yourTime_verify_element_existence(lbl_pendingApprovalFromYourManager, true);
			} else {
				emp_yourTime_verify_element_existence(lbl_pendingApprovalFromYourManager, false);
			}
			break;

		case timecardApproved:
			if (existenceFalg) {
				emp_yourTime_verify_element_existence(lbl_approvedByYourManager, true);
			} else {
				emp_yourTime_verify_element_existence(lbl_approvedByYourManager, false);
			}
			break;

		default:
			throw new IllegalArgumentException("please provide right button name");

		}

	}

	public static enum data {
		monthName, date, clockIn, clockOut, takeAMeal, mealReturn, clockIn_carousel, clockOut_carousel,
		takeAMeal_carousel, mealReturn_carousel, viewMoreOptions, hideMoreOptons, smartButtons, carouselButtons, toDay,
		timePairOverlaps, resolvedSomePunches, fixedAllPunches, noteMessage, pendingForManagerApproval,
		timecardApproved;

	}

	/**
	 * employee -- yourtimecard --- update note
	 * 
	 * @param noteMessage --- meessafe need to update
	 * @param rowNo       -- row number -- 1 ,2 ,3
	 */

	public void emp_yourTimecard_updateNote(String noteMessage, int rowNo) {
		yourTimePortletsObject();
        
		yourTimePortlets.waitForPageLoad(3);
		
		WebElementFacade noteEditPencilIcon =  $("//*[@id='timeCard_root']/descendant::span[contains(@class,'toggle-notes-icon')]["+rowNo+"]");
		WebElementFacade noteTextArea = $("//*[@id='timeCard_root']/descendant::textarea[" + rowNo + "]");
		if(!checkElementVisible(noteTextArea))
		{
			noteEditPencilIcon.click();
		}
		waitForElementToLoad($("//*[@id='timeCard_root']/descendant::textarea[" + rowNo + "]"));

		$("//*[@id='timeCard_root']/descendant::textarea[" + rowNo + "]").typeAndTab(noteMessage);

		yourTimePortlets.waitForPageLoad(3);

	}

	public String calculate_hours(String time1, String time2) {
		String calculatedHours="";
				
		try {

			String[] timeArray1 = time1.split("[ \\:]");
			String[] timeArray2 = time2.split("[ \\:]");

			Calendar cal = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

			Date date1 = sdf.parse(timeArray1[0] + ":" + timeArray1[1]);
			cal.setTime(date1);

			int mins1 = cal.get(Calendar.HOUR) * 60 + cal.get(Calendar.MINUTE);
			System.out.println("the result is " + mins1);

			Date date2 = sdf.parse(timeArray2[0] + ":" + timeArray2[1]);
			cal.setTime(date2);

			int mins2 = cal.get(Calendar.HOUR) * 60 + cal.get(Calendar.MINUTE);

			System.out.println("the result is " + mins2);

			int result = mins2 - mins1;

			sdf = new SimpleDateFormat("mm");

			Date dt = sdf.parse(Integer.toString(result));
			sdf = new SimpleDateFormat("HH:mm");
			calculatedHours = sdf.format(dt);
			System.out.println("final date is " + calculatedHours);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return calculatedHours;
		

	}

}
