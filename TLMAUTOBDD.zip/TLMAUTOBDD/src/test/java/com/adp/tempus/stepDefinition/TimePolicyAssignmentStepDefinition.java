package com.adp.tempus.stepDefinition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.adp.tempus.steps.TimePolicyAssignmentSteps;
//import com.adp.tlmbdd.stepDefinition.TeamDashboardStepDefinition;
import com.adp.tlmbdd.common.DateUtils;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class TimePolicyAssignmentStepDefinition {
	
	@Steps
	TimePolicyAssignmentSteps timePolicyAssignmentStep;
	
	@Then("^I verify employment profile is loaded properly$")
	public void i_verify_employment_profile_is_loaded_properly() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verifyEmployeeProfilePageLoading();
	}

	@Then("^I verify time title is displayed$")
	public void i_verify_time_title_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verifyTimeTitleDisplayed();
	}
	
	@Then("^I verify clock icon is displayed$")
	public void i_verify_clock_icon_is_displayed() throws Throwable {
		timePolicyAssignmentStep.verifyClockiconIsDisplayed();
	}

	@Then("^I verify Time & Attendence text is displayed$")
	public void i_verify_Time_Attendence_text_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verify_Time_Attendence_text_is_displayed();
	}

	@Then("^I verify NAME label is displayed$")
	public void i_verify_NAME_label_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verify_NAME_label_is_displayed();
	}

	@Then("^I verify CATEGORY label is displayed$")
	public void i_verify_CATEGORY_label_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verify_CATEGORY_label_is_displayed();
	}

	@Then("^I verify Time Settings Link is displayed$")
	public void i_verify_Time_Settings_Link_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verify_Time_Settings_Link_is_displayed();
	}

	@Then("^I verify History Link is displayed$")
	public void i_verify_History_Link_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verify_History_Link_is_displayed();
	}

	@Then("^I verify Edit button is displayed$")
	public void i_verify_Edit_button_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verify_Edit_button_is_displayed();
	}

	@When("^I select edit button$")
	public void i_select_edit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.select_edit_button();
	}

	@Then("^I should navigate to Time Policy Assignment page$")
	public void i_should_navigate_to_Time_Policy_Assignment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.should_navigate_to_Time_Policy_Assignment_page();
	}

	@Then("^I select Back button$")
	public void i_select_Back_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.select_Back_button();
	}

	@Then("^I should navigate to employee profile page$")
	public void i_should_navigate_to_employee_profile_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.should_navigate_to_employee_profile_page();
	}

	@When("^I select Time & Attendance History link$")
	public void i_select_Time_Attendance_History_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.select_Time_Attendance_History_link();
	}

	@Then("^I navigate to Time & Attendance History page$")
	public void i_navigate_to_Time_Attendance_History_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.navigate_to_Time_Attendance_History_page();
	}

	@When("^I select Other Time & Attendance Settings link$")
	public void i_select_Other_Time_Attendance_Settings_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.select_Other_Time_Attendance_Settings_link();
	}

	@Then("^I navigate to Other Time & Attendance Settings page$")
	public void i_navigate_to_Other_Time_Attendance_Settings_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.navigate_to_Other_Time_Attendance_Settings_page();
	}

	@Then("^I validate HISTORY link is displayed$")
	public void i_validate_HISTORY_link_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.validate_HISTORY_link_is_displayed();
	}

	@Then("^I select HISTORY link$")
	public void i_select_HISTORY_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.select_HISTORY_link_Time_Policy_Assignment_Page();
	}

	
	/*@Then("^I navigate to Time & Attendance Settings page$")
	public void i_navigate_to_Time_Attendance_Settings_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}*/

	@Then("^I verify i can pick effective date as \"([^\"]*)\"$")
	public void i_verify_i_can_pick_effective_date_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.pick_effective_date(arg1);
		
	}

	@Then("^Rounding Options and Time Entry and Meal & Breaks and Time Holiday$")
	public void rounding_Options_and_Time_Entry_and_Meal_Breaks_and_Time_Holiday() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.select_rounding_Options_and_Time_Entry_and_Meal_Breaks_and_Time_Holiday();
	}

	@Then("^i validate new time line is created$")
	public void i_validate_new_time_line_is_created() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.validate_new_time_line_is_created();
	}

	@Then("^i select new time line$")
	public void i_select_new_time_line() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I verify Time & Attendence displayed as per new time line secected$")
	public void i_verify_Time_Attendence_displayed_as_per_new_time_line_secected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I verify Rounding Option is not displayed on time tile$")
	public void i_verify_Rounding_Option_is_not_displayed_on_time_tile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I verify Time Entry is not displayed on time tile$")
	public void i_verify_Time_Entry_is_not_displayed_on_time_tile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I verify Meal is not displayed on time tile$")
	public void i_verify_Meal_is_not_displayed_on_time_tile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I verify Time Holiday is not displayed on time tile$")
	public void i_verify_Time_Holiday_is_not_displayed_on_time_tile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	@Then("^I verify pay profile is loaded properly$")
	public void i_verify_pay_profile_is_loaded_properly() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verifyEmployeeProfilePageLoading();
	}

	@Then("^I verify time title is displayed on Pay Profile$")
	public void i_verify_time_title_is_displayed_on_Pay_Profile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verifyTimeTileDisplayedPayProfile();
	}
	
	@Then("^I verify Time and Attendance link is displayed$")
	public void i_verify_Time_and_Attendance_link_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.verifyTimeandAttendenceLinkDisplayed();
	}
	
	@When("^I select Time and Attendence link$")
	public void i_select_Time_Attendance_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.selectTimeandAttendanceLink();
	}
	
	@Then("^I should navigate to pay profile page$")
	public void i_should_navigate_to_pay_profile_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.should_navigate_to_pay_profile_page();
	}
	
	@And("^I select Back button on history$")
	public void i_select_Back_button_on_history() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		timePolicyAssignmentStep.select_Back_button_on_history();
	}
	
	@And("^I verify time tile is not displayed$")
	public void verify_time_tile_is_not_displayed() {
		timePolicyAssignmentStep.verifyTimeTitleNotDisplayed();
	}
	
	
}
