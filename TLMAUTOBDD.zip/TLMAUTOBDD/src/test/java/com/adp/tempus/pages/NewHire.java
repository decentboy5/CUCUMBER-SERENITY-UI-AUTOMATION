package com.adp.tempus.pages;

import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class NewHire extends GenericPageObject{
	
public static Logger log = Logger.getLogger(NewHire.class);

 @FindBy (xpath = "//i[@class='fa fa-user-plus fa-3x hronly-icon-css']")
 private WebElementFacade hrOnlyTemplate;
 
 @FindBy (xpath = "//div[contains(text(),'HR Only')]")
 private WebElementFacade hrTemplatepage;
 
 @FindBy (xpath = "//div[@class='step-line-item']//div[contains(text(),'Time')]")
 private WebElementFacade stepLineTimeItem;
 
 @FindBy (xpath = "//span[contains(text(),'Cancel')]")
 private WebElementFacade templateCancelBtn;
 
 @FindBy (xpath = "//span[contains(text(),'Yes')]")
 private WebElementFacade confirmCancelBtn;
 
 @FindBy (xpath = "//span[contains(text(),'Hire/Rehire')]")
 private WebElementFacade hireRehirePageTitle;
 
 @FindBy (xpath = "//div[contains(text(),'Paid Contractor (Individual)')]")
 private WebElementFacade paidContractorTemplate;

 @FindBy (xpath = "//div[contains(text(),'Template Name')]")
 private WebElementFacade templateNameHeader;
 
 @FindBy (xpath = "//div[contains(text(),'Paid Employee (W2)')]")
 private WebElementFacade paidEmployeeTemplate;
	
	public void verify_HireRehire_page_is_loaded_properly() {
		WaitForPageLoad();
		waitABit(5000);
	}
	
	public void validate_HR_Only_Template_is_displayed() {
		
		Assert.assertTrue("validate HR Only Template is displayed", checkElementVisible(hrOnlyTemplate));
	}
	
	public void navigate_to_HR_Only_Template() {
		hrOnlyTemplate.click();
		if(!checkElementVisible(templateNameHeader)) waitABit(3000);
		Assert.assertTrue("validate Paid Contractor page is displayed", checkElementVisible(templateNameHeader));
		Assert.assertTrue("validate HR Only page is displayed", checkElementVisible(hrTemplatepage));
	}
	
	public void verify_time_section_is_not_displayed() {
		Assert.assertFalse("verify time section is not displayed", checkElementVisible(stepLineTimeItem));
	}
	
	public void Cancel_the_New_Hire_creation() {
		Assert.assertTrue("validate cancel button is displayed", checkElementVisible(templateCancelBtn));
		templateCancelBtn.click();
		waitABit(2000);
		Assert.assertTrue("validate confirm cancel popup is displayed", checkElementVisible(confirmCancelBtn));
		confirmCancelBtn.click();
		System.out.println("confirm cancel clicked");
		waitABit(5000);
	}
	
	public void verify_navigate_back_to_HireRehire_page() {
		Assert.assertTrue("validate HireRehire page is displayed", checkElementVisible(hireRehirePageTitle));
	}
	
	public void validate_Paid_Contractor_Template_is_displayed() {
		Assert.assertTrue("validate Paid Contractor template is displayed", checkElementVisible(paidContractorTemplate));
	}
	
	public void navigate_to_Paid_Contractor_Template() {
		paidContractorTemplate.click();
		if(!checkElementVisible(templateNameHeader)) waitABit(3000);
		Assert.assertTrue("validate Paid Contractor page is displayed", checkElementVisible(templateNameHeader));
		Assert.assertTrue("validate Paid Contractor page is displayed", checkElementVisible(paidContractorTemplate));
	}
	
	public void validate_Paid_Employee_Template_is_displayed() {
		Assert.assertTrue("validate Paid Employee template is displayed", checkElementVisible(paidEmployeeTemplate));
	}
	
	public void navigate_to_Paid_Employee_Template() {
		paidEmployeeTemplate.click();
		if(!checkElementVisible(templateNameHeader)) waitABit(3000);
		Assert.assertTrue("validate Paid Employee page is displayed", checkElementVisible(templateNameHeader));
		Assert.assertTrue("validate Paid Employee page is displayed", checkElementVisible(paidEmployeeTemplate));
	}
	
	public void verify_time_section_is_displayed() {
		Assert.assertTrue("verify time section is displayed", checkElementVisible(stepLineTimeItem));
	}
	
}

