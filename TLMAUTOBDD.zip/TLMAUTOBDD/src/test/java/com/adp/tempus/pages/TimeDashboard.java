package com.adp.tempus.pages;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.adp.tlmbdd.pages.GenericPageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class TimeDashboard extends GenericPageObject {

	@FindBy(xpath = "//div[contains(@class,'dashBoard-thingsTodo-tile-todoListViewName')][text()='Timecard Approvals']")
	public WebElementFacade lbl_TimecardApprovalsSubTile;

	@FindBy(xpath = "//div[contains(@class,'dashBoard-thingsTodo-tile-todoListViewName')][text()='Timecard Approvals']/following-sibling::div")
	public WebElementFacade lbl_TACountSubTile;

	@FindBy(xpath = "//div[contains(@class,'timecard-Approvals-ListViewName')]")
	public WebElementFacade lbl_TimecardApprovalsSummaryTile;

	@FindBy(xpath = "//div[contains(@class,'timecard-Approvals-ListViewName')]/following-sibling::div")
	public WebElementFacade lbl_TACountSummaryTile;

	@FindBy(xpath = "//button[.='REMIND EMPLOYEE TO APPROVE']")
	public WebElementFacade btn_RemindEmployeeToApprove;

	@FindBy(xpath = "//button[.='APPROVE']")
	public WebElementFacade btn_Approve;

	@FindBy(xpath = "//button/span[text()='Save']")
	public WebElementFacade btn_Save;

	@FindBy(xpath = "//button[.='Back']")
	public WebElementFacade btn_Back;

	@FindBy(xpath = "//button[.='Cancel']")
	public WebElementFacade btn_Cancel;

	@FindBy(xpath = "//button[.='Timecard Approval']")
	public WebElementFacade btn_TimecardApproval;

	@FindBy(xpath = "//div[contains(@class,'vdl-row mdf-grid-header')]//input")
	public WebElementFacade chkBox_ApproveAll;

	@FindBy(xpath = "//div[contains(@class,'dashBoard-datacoin-name')][text()='APPROVED']/preceding-sibling::div")
	public WebElementFacade lblVal_Approved;

	@FindBy(xpath = "//div[contains(@class,'dashBoard-datacoin-name')][text()='READY FOR APPROVAL']/preceding-sibling::div")
	public WebElementFacade lblVal_ReadyForApproval;

	@FindBy(xpath = "//div[contains(@class,'dashBoard-datacoin-name')][text()='PENDING ACTIONS']/preceding-sibling::div")
	public WebElementFacade lblVal_pendingActions;

	@FindBy(xpath = "//div[contains(@class,'dashBoard-datacoin-name')][text()='PENDING ACTIONS']/preceding-sibling::div")
	public WebElementFacade title_TimecardApprovalStatus;

	@FindBy(xpath = "//div[text()='Missed Punches']/../div[2]")
	private WebElementFacade txt_missedPunchesAndEmployeeCount;

	@FindBy(xpath = "//*[@class='missedPunches-notification-header']/../text")
	private WebElementFacade txt_missedPunchesAndEmployeeCountOnMissedPunchesPage;

	@FindBy(xpath = "//*[@id='timeCard_root']")
	private WebElementFacade timecardroot;

	@FindBy(xpath = "//button[@aria-label='Back']")
	private WebElementFacade btn_timecardBack;

	@FindBy(xpath = "//*[@class='notes-padding-username']")
	private WebElementFacade txt_notesUsername;

	String lbl_EmpAprvStatus = ".//span[contains(@class,'fa fa-times isEmployeeApprovals')]";
	String lbl_EmpTotalHrs = ".//div[contains(@class,'column-3')]/div";
	String chkBox_EmpTimecardApprovalGrid = ".//div[contains(@class,'moreOptionsGridEntry-groupBy vdl-checkbox')]";
	String btn_ViewTimecardApprovalGrid = ".//div[contains(@class,'timecard-approval-chevron')]";

	public static String employeecount, missedpunchescount, employeecountonslider, missedpunchescountonslider;

	public void clickOnTTDTile(String tilename) {
		WaitForPageLoad();
		getDriver().findElement(By.xpath("//div[text()='" + tilename + "']")).click();
		WaitForPageLoad();
		waitABit(5000);
	}

	public void resolveMultipleMissedPunch(String employeename, String date, List<String> timepairs) {

		List<String> missedPunchesList = new ArrayList<String>();
		List<WebElement> missedPunchesweblist = getDriver().findElements(By.xpath("//text[text()='" + employeename
				+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
				+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//*[@class='vdl-row missedPunches-padding-bottom']"));

		for (int i = 0; i < missedPunchesweblist.size(); i++) {

			missedPunchesList.add(missedPunchesweblist.get(i).getText().trim());
		}

		System.out.println("MissedPunchesListis " + missedPunchesList);

		for (int i = 0; i < timepairs.size(); i++) {

			for (int j = 0; j < missedPunchesList.size(); j++) {

				String dataInPunch = timepairs.get(i).split("-")[0].trim();
				String dataOutPunch = timepairs.get(i).split("-")[1].trim();
				String missedInPunch = missedPunchesList.get(j).split("-")[0].trim();

				if (dataInPunch.equals(missedInPunch)) {
					WaitForPageLoad();
					getDriver().findElement(By.xpath("(//text[text()='" + employeename
							+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
							+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//input)[1]")).click();
					waitABit(2000);
					getDriver()
							.findElement(By.xpath("(//text[text()='" + employeename
									+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
									+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//input)[" + (i + 1) + "]"))
							.sendKeys(dataOutPunch);
					waitABit(2000);
					getDriver()
							.findElement(By.xpath("(//text[text()='" + employeename
									+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
									+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//input)[" + (i + 1) + "]"))
							.sendKeys(Keys.TAB);
					;
					break;
				}
			}

		}
	}

	public void resolveMissedPunch(String employeename, String outPunch, String date) {
		WaitForPageLoad();
		getDriver().findElement(
				By.xpath("//text[text()='" + employeename + "']/ancestor::div[@data-grid-index]//text[contains(text(),'"
						+ date + "')]/ancestor::div[@class='vdl-row mdf-grid-row']//input"))
				.click();
		waitABit(2000);
		getDriver().findElement(
				By.xpath("//text[text()='" + employeename + "']/ancestor::div[@data-grid-index]//text[contains(text(),'"
						+ date + "')]/ancestor::div[@class='vdl-row mdf-grid-row']//input"))
				.sendKeys(outPunch);
		waitABit(2000);
		getDriver().findElement(
				By.xpath("//text[text()='" + employeename + "']/ancestor::div[@data-grid-index]//text[contains(text(),'"
						+ date + "')]/ancestor::div[@class='vdl-row mdf-grid-row']//input"))
				.sendKeys(Keys.TAB);
		;
	}

	public void clickButtonOnSlider(String buttonName) {
		WaitForPageLoad();
		switch (buttonName.toUpperCase()) {
		case "SAVE":
			btn_Save.waitUntilClickable().click();
			break;
		case "BACK":
			btn_Back.waitUntilClickable().click();
			break;
		case "CANCEL":
			btn_Cancel.waitUntilClickable().click();
			break;
		case "REMIND EMPLOYEE TO APPROVE":
			btn_RemindEmployeeToApprove.waitUntilClickable().click();
			break;
		case "APPROVE":
			btn_Approve.waitUntilClickable().click();
			waitABit(2000);
			break;
		case "TIMECARD APPROVAL":
			btn_TimecardApproval.waitUntilClickable().click();
			break;
		}
	}

	public WebElement getEmployeeRowTimecardApprovalGrid(String empName, String positionId) {

		if (empName.contentEquals("") && positionId.contentEquals(""))
			return null;
		List<WebElement> empRow = null;
		try {
			if (!empName.contentEquals("") && !positionId.contentEquals(""))
				empRow = getDriver()
						.findElements(By.xpath(".//div[@class='timeCard-Approvals-Employee-Names-Class'][contains(.,'"
								+ empName.trim() + "')][contains(.,'" + positionId.trim()
								+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']"));
			else if (!empName.contentEquals("") && positionId.contentEquals(""))
				empRow = getDriver()
						.findElements(By.xpath(".//div[@class='timeCard-Approvals-Employee-Names-Class'][contains(.,'"
								+ empName.trim() + "')]/ancestor::div[@class='vdl-row mdf-grid-row']"));
			else if (empName.contentEquals("") && !positionId.contentEquals(""))
				empRow = getDriver()
						.findElements(By.xpath(".//div[@class='timeCard-Approvals-Employee-Names-Class'][contains(.,'"
								+ positionId.trim() + "')]/ancestor::div[@class='vdl-row mdf-grid-row']"));
			if (empRow.isEmpty()) {
				// Assert.assertTrue("No Rows/More than one Rows Available with
				// given criteria", false);
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return empRow.get(0);
	}

	public void verifyEmployeeDetailsTimecardApprovalGrid(String empName, String positionId, String empApproval,
			String totalHours) {
		if (empName.contentEquals("") && positionId.contentEquals(""))
			return;
		WebElement empRecord = getEmployeeRowTimecardApprovalGrid(empName, positionId);
		// verify Employee Approval
		if (!empApproval.contentEquals("")) {
			WebElement objEmpAppr = empRecord.findElement(By.xpath(lbl_EmpAprvStatus));
			String empStatus = objEmpAppr.getAttribute("class");
			switch (empApproval.toUpperCase()) {
			case "APPROVED":
				Assert.assertTrue("Verification of Timecard Employee Approval Status", !empStatus.contains("Red"));
				break;
			case "NOT APPROVED":
				Assert.assertTrue("Verification of Timecard Employee Approval Status", empStatus.contains("Red"));
				break;
			}
		}
		// verify Total Hours
		if (!totalHours.contentEquals("")) {
			WebElement objEmpTotalHrs = empRecord.findElement(By.xpath(lbl_EmpTotalHrs));
			Assert.assertTrue("Verification of Total Hours", objEmpTotalHrs.getText().contentEquals(totalHours));
		}
	}

	public void verifyTmecardApprovalSubTile(String count) {
		lbl_TimecardApprovalsSummaryTile.waitUntilVisible().shouldBeVisible();
		Assert.assertTrue("Verification of Count on Timcard Approvals Sub Tile under TTD",
				lbl_TACountSubTile.getText().contains(count)
						&& lbl_TACountSummaryTile.getText().contains("timecards ready for approval"));
	}

	public void verifySummaryTimecardsApprovalSlider(String count) {
		lbl_TimecardApprovalsSummaryTile.waitUntilVisible().shouldBeVisible();
		Assert.assertTrue("Verification of Count on Summary Tile", lbl_TACountSummaryTile.getText().contains(count)
				&& lbl_TACountSummaryTile.getText().contains("timecards ready for approval"));
	}

	public void selectEmployeeTimecardApprovalGrid(String empName, String positionId, String value) {
		if (empName.contentEquals("") && positionId.contentEquals(""))
			return;
		WebElement empRecord = getEmployeeRowTimecardApprovalGrid(empName, positionId);
		WebElement empCheckBox = empRecord.findElement(By.xpath(chkBox_EmpTimecardApprovalGrid));
		selectWebCheckBox(empCheckBox, value);
	}

	public void navigateToEmployeeTimecardFromTimecardApprovalGrid(String empName, String positionId) {
		if (empName.contentEquals("") && positionId.contentEquals(""))
			return;
		WebElement empRecord = getEmployeeRowTimecardApprovalGrid(empName, positionId);
		empRecord.findElement(By.xpath(btn_ViewTimecardApprovalGrid)).click();
	}

	public void selectAllEmployeeTimecardFromTimecardApprovalGrid(String value) {
		if (value.contentEquals(""))
			return;
		selectWebCheckBox(chkBox_ApproveAll, value);
	}

	public void verifyEmployeeRecordTimecardApprovalGrid(String empName, String positionId, String status) {
		if (empName.contentEquals("") && positionId.contentEquals("") && status.contentEquals(""))
			return;
		WebElement empRecord = getEmployeeRowTimecardApprovalGrid(empName, positionId);
		switch (status.toUpperCase()) {
		case "EXISTS":
			Assert.assertTrue("Verification of Employee Record Existance on Timecard Approval Grid", empRecord != null);
			break;
		case "DOESNOTEXIST":
			Assert.assertTrue("Verification of Employee Record Existance on Timecard Approval Grid", empRecord == null);
			break;
		}
	}

	public void verifyTimecardCountTimecardApprovalStatusTile(String approved, String readyForApproval,
			String pendingActions) {
		if (!approved.contentEquals(""))
			Assert.assertTrue("Verification of Timecard Count - Approved",
					approved.contentEquals(lblVal_Approved.getText().trim()));
		if (!readyForApproval.contentEquals(""))
			Assert.assertTrue("Verification of Timecard Count - Ready For Approval",
					readyForApproval.contentEquals(lblVal_ReadyForApproval.getText().trim()));
		if (!pendingActions.contentEquals(""))
			Assert.assertTrue("Verification of Timecard Count - Pending Actions",
					pendingActions.contentEquals(lblVal_pendingActions.getText().trim()));
	}

	public void clickOnTimecardApprovalStatusTile(String buttonName) {
		if (buttonName.contentEquals(""))
			return;
		switch (buttonName.toUpperCase()) {
		case "APPROVED":
			lblVal_Approved.waitUntilClickable().click();
			break;
		case "READY FOR APPROVAL":
			lblVal_ReadyForApproval.waitUntilClickable().click();
			break;
		case "PENDING ACTIONS":
			lblVal_pendingActions.waitUntilClickable().click();
			break;
		case "TIMECARD APPROVAL STATUS":
			title_TimecardApprovalStatus.waitUntilClickable().click();
			break;
		}
	}

	public void verifybuttonStatusOnSlider(String btnName, String status) {
		if (status.contentEquals(""))
			return;
		switch (btnName.toUpperCase()) {
		case "APPROVE":
			verifyObjectStatus(btn_Approve);
			break;
		}
	}

	public void saveMissedPunchesAndEmployeeCountOnTTDTile() {
		String employeecountandmissedpunches = txt_missedPunchesAndEmployeeCount.getText();
		employeecount = employeecountandmissedpunches.split(",")[0].trim().split(" ")[0].trim();
		missedpunchescount = employeecountandmissedpunches.split(",")[1].trim().split(" ")[0].trim();

	}

	public void saveMissedPunchesAndEmployeeCountOnSlider() {
		String employeecountandmissedpunches = txt_missedPunchesAndEmployeeCountOnMissedPunchesPage.getText();
		employeecountonslider = employeecountandmissedpunches.split(",")[0].trim().split(" ")[0].trim();
		missedpunchescountonslider = employeecountandmissedpunches.split(",")[1].trim().split(" ")[0].trim();

	}

	public void verifyMissedPunchesAndEmployeeOnTTDTile(String employeedifference, String missedpunchesdifference) {
		WaitForPageLoad();
		waitABit(5000);
		String employeecountandmissedpunches = txt_missedPunchesAndEmployeeCount.getText();
		String actualemployeecount = employeecountandmissedpunches.split(",")[0].trim().split(" ")[0].trim();
		String actualmissedpunchescount = employeecountandmissedpunches.split(",")[1].trim().split(" ")[0].trim();
		Assert.assertEquals(employeedifference,
				String.valueOf(Integer.valueOf(employeecount) - Integer.valueOf(actualemployeecount)));
		Assert.assertEquals(missedpunchesdifference,
				String.valueOf(Integer.valueOf(missedpunchescount) - Integer.valueOf(actualmissedpunchescount)));
	}

	public void verifyMissedPunchesAndEmployeeOnSlider(String employeedifference, String missedpunchesdifference) {
		WaitForPageLoad();
		waitABit(5000);
		String employeecountandmissedpunches = txt_missedPunchesAndEmployeeCountOnMissedPunchesPage.getText();
		String actualemployeecount = employeecountandmissedpunches.split(",")[0].trim().split(" ")[0].trim();
		String actualmissedpunchescount = employeecountandmissedpunches.split(",")[1].trim().split(" ")[0].trim();
		Assert.assertEquals(employeedifference,
				String.valueOf(Integer.valueOf(employeecountonslider) - Integer.valueOf(actualemployeecount)));
		Assert.assertEquals(missedpunchesdifference, String
				.valueOf(Integer.valueOf(missedpunchescountonslider) - Integer.valueOf(actualmissedpunchescount)));
	}

	public void verifyTileInVisibilityOnTTDTIle(String TileName) {
		WaitForPageLoad();
		Assert.assertFalse(checkElementVisible("//div[text()='" + TileName + "']"));
	}

	public void clickTimeCardLinkAndVerifyLoading(String employeename) {
		WaitForPageLoad();
		getDriver()
				.findElement(By.xpath("//*[text()='" + employeename
						+ "']/ancestor::div[@class='missedPunches-employee-subheader']//*[text()='VIEW TIMECARD']"))
				.click();
		waitABit(5000);
		Assert.assertTrue(checkElementVisible(timecardroot));
		btn_timecardBack.click();
		waitABit(2000);
	}

	public void verifyColorOfNote(String color, String employeename, String date) {

		if (color.equals("blue")) {
			String attributevalue = getDriver()
					.findElement(By.xpath("//text[text()='" + employeename
							+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
							+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//span[contains(@class,'missedPunches-notes-icon')]"))
					.getAttribute("class");
			Assert.assertEquals("fa fa-comment missedPunches-notes-icon", attributevalue);
		} else if (color.equals("white")) {
			String attributevalue = getDriver()
					.findElement(By.xpath("//text[text()='" + employeename
							+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
							+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//span[contains(@class,'missedPunches-notes-icon')]"))
					.getAttribute("class");
			Assert.assertEquals("fa fa-comment-o missedPunches-notes-icon", attributevalue);
		} else if (color.equals("read"))
			Assert.assertEquals(false, checkElementVisible("//text[text()='" + employeename
					+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
					+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//*[contains(@class,'alert-number-indicator')]"));
		else if (color.equals("unread"))
			Assert.assertEquals(true, checkElementVisible("//text[text()='" + employeename
					+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
					+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//*[contains(@class,'alert-number-indicator')]"));
	}

	public void clickOnSpecificNote(String employeename, String date) {
		WaitForPageLoad();
		waitABit(3000);
		getDriver()
				.findElement(By.xpath("//text[text()='" + employeename
						+ "']/ancestor::div[@data-grid-index]//text[contains(text(),'" + date
						+ "')]/ancestor::div[@class='vdl-row mdf-grid-row']//span[contains(@class,'missedPunches-notes-icon')]/.."))
				.click();
		waitABit(3000);
	}

	public void verifyEmployeeNote(String note, String employeename) {
		Assert.assertTrue(txt_notesUsername.getText().contains(employeename.split(",")[0]));
		Assert.assertTrue(checkElementVisible("//*[text()='" + note + "']"));
	}

}
