package com.adp.tempus.steps;

import com.adp.tempus.pages.PolicyManager;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class PolicyManagerSteps extends ScenarioSteps {
	
	
	PolicyManager policyManager;
	
	@Step
	public void verifyPolicyManagerPageLoading()
	{
		policyManager.verifyPolicyManagerPageLoading();
	}
	
	@Step
	public void verifyTimeAndAttendanceOptionUnderSetupNew()
	{
		policyManager.verifyTimeAndAttendanceOptionUnderSetupNew();
	}
	
	@Step
	public void createTimeAndAttendanceRoundingPolicy(String policyType,String policyname,String roundingtype,String date)
	{
		policyManager.createTimeAndAttendanceRoundingPolicy(policyType, policyname, roundingtype, date);
	}
	
	@Step
	public void createTimeAndAttendanceTimeEntryPolicy(String policyType,String policyname,String timeEntryType,String date,String sourceType, String actionType) {
		policyManager.createTimeAndAttendanceTimeEntryPolicy(policyType, policyname, timeEntryType, date,sourceType,actionType);
		
	}
	
	@Step
	public void deletePolicy(String policyname)
	{
		policyManager.deletePolicy(policyname);
	}

	public void navigateBackPolicyList() {
		policyManager.navigateBackPolicyList();		
	}
}
