package com.adp.tempus.pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.adp.tlmbdd.common.DateUtils;
import com.adp.tlmbdd.pages.GenericPageObject;
import com.adp.tlmbdd.stepDefinition.TeamDashboardStepDefinition;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class PolicyManager extends GenericPageObject {
	public static Logger log = Logger.getLogger(PolicyManager.class);

	@FindBy(xpath = "//div[@id='policyManager']")
	public WebElementFacade policyManagerPageLoad;

	@FindBy(xpath = "//button[@id='setupNewPolicyButton']")
	public WebElementFacade setupNewPolicyButton;

	@FindBy(xpath = "//div[contains(@class,'payroll-item-setupcard')]//*[text()='Time & Attendance']")
	public WebElementFacade timeandattendanceUnderSetup;

	@FindBy(xpath = "//div[contains(@class,'payroll-item-setupcard')]//input[@value='Time & Attendance']/..")
	public WebElementFacade timeandattendanceOption;

	@FindBy(xpath = "//button[@name='selectedPolicyType'][@value='Time & Attendance']")
	public WebElementFacade timeandattendanceOptionNew;
	

	@FindBy(xpath = "//i[@class='icon-close-thin']")
	public WebElementFacade closeSetupNew;

	@FindBy(xpath = "//span[text()='CONTINUE']")
	public WebElementFacade continueButton;

	@FindBy(xpath = "//span[text()='Continue']")
	public WebElementFacade policyBasicscontinueButton;

	@FindBy(xpath = "//input[@value='Rounding']/..")
	public WebElementFacade roundingCheckBox;

	@FindBy(xpath = "//span[contains(text(),'get started') or contains(text(),'GET Started')]")
	public WebElementFacade iamReadyLetsGetStarted;

	// @FindBy(xpath = "(//*[@name='createPolicySelectedOptionType']/..)[3]")
	@FindBy(xpath = "//label[contains(text(),'Create new Rounding policy from scratch')]")
	public WebElementFacade createNewRoundingPolicy;

	@FindBy(xpath = "//input[@name='effectiveDate']")
	public WebElementFacade effectiveDate;

	@FindBy(xpath = "//input[@name='name']")
	public WebElementFacade policyName;

	@FindBy(xpath = "//input[@name='en_US']")
	public WebElementFacade shortName;

	@FindBy(xpath = "//*[@name='sameRoundingConfigOn'][@value='Yes']/..")
	public WebElementFacade sameRoundingRule;

	@FindBy(xpath = "//span[text()='Save']")
	public WebElementFacade saveButton;

	public WebElementFacade payrollWorksheetLink;

	@FindBy(xpath = "//span[text()='Back to Policy List']")
	public WebElementFacade backToPolicyListButton;

	@FindBy(xpath = "//span[text()='Add Another Policy']")
	public WebElementFacade addAnotherPolicyButton;
	
	@FindBy(xpath = "//button[@class='move-all-right']")
	public WebElementFacade btn_MoveAll;	
	
	public final String[] sourceTypeValues = new String[] {"clock","web","mobile","ivr"};//{"Physical Time Clocks","Workforce Now My Time Entry","ADP Mobile App (phone/tablet)","Interactive Voice Response (IVR) Phone"}; 
	public final String[] actionTypeValues =  new String[] {"In","TakeMeal","Transfer"};
	
	public static String CurrentTimeStamp = DateUtils.getCurrentTimeStamp();

	public void verifyPolicyManagerPageLoading() {
		try {
			waitABit(5000);
			WaitForPageLoad();
			// Assert.assertEquals("Verifying policy manager page load", true,
			// checkElementVisible(policyManagerPageLoad));
		} catch (Exception ex) {
		}
	}

	// This method is to select setupNew and to load Time & Attendance policies
	public void verifyTimeAndAttendanceOptionUnderSetupNew() {
		try {
			setupNewPolicyButton.click();
			WaitForPageLoad();
			Assert.assertEquals("Verifying time and attendance option under setup new", true,
					checkElementVisible(timeandattendanceUnderSetup));
			closeSetupNew.click();
		} catch (Exception ex) {
		}
	}

	// This method is to select Time & Attendance policy Type(Example: Rounding,TimeEntry, Overtime etc ..)
	public void selectTimeAndAttendancePolicyType(String policyType) {
		try {
			setupNewPolicyButton.waitUntilClickable();
			setupNewPolicyButton.click();
			WaitForPageLoad();
			waitABit(2000);
			//PReDIT and FIT are not in sync, to avoid script failure added below condition
			if (checkElementVisible(timeandattendanceOptionNew)) {
				timeandattendanceOptionNew.click();
			}
			WaitForPageLoad();
			waitABit(2000);
			// dynamically passing the policyType, xpath is defined in
			// policymanager_dynamicelements.properties file
			WebElementFacade policyTypeCheckbox = getElementByDynamicValues("xpath", "policyTypeCheckBox", policyType);
			scrollIntoView(policyTypeCheckbox);
			policyTypeCheckbox.click();
			waitABit(2000);
			continueButton.click();
			WaitForPageLoad();
			waitABit(2000);
		} catch (Exception ex) {
		}
	}

	/* This method is to select the mode of creating a policy,copy existing policy 
	  * or create from scratch*/
	public void copyOrCreatePolicy(String policyType) {
		try {
			if (checkElementVisible(iamReadyLetsGetStarted)) {
				iamReadyLetsGetStarted.click();
				waitABit(2000);
			}
			WebElementFacade createNewPolicy = getElementByDynamicValues("xpath", "createNewPolicy", policyType);
			if (checkElementVisible(createNewPolicy)) {
				createNewPolicy.click();
				waitABit(1000);
				continueButton.click();
				WaitForPageLoad();
			}
		} catch (Exception ex) {
		}
	}

	// This method is to select Rounding/Policy policy methods
	public void selectpolicyMethod(String policyType, String policyMethodType) {

		/*
		 * dynamically passing the roundingType, xpath is defined in
		 * policymanager_dynamicelements.properties file
		 */
		WebElementFacade policyMethodTypeCheckbox = null ;
		if(policyType.contains("Rounding")){
			policyMethodTypeCheckbox = getElementByDynamicValues("xpath", "roundingTypeCheckbox",
				policyMethodType);
		}
		else if(policyType.contains("TimeEntry")) {
			policyMethodTypeCheckbox = getElementByDynamicValues("xpath", "timeEntryTypeCheckbox",
					policyMethodType);
		}
		//Assert.assertEquals("Verifying" + policyType + policyMethodType+ "  Method", true,
				//(policyMethodTypeCheckbox));
		waitFor(policyMethodTypeCheckbox);
		policyMethodTypeCheckbox.click();
		waitABit(1000);
		continueButton.click();
		WaitForPageLoad();
	}

	// This method is to enter policy basic details(name, date etc ..)
	public void enterpolicyBasics(String policyname, String date) {
		effectiveDate.clear();
		effectiveDate.sendKeys(date);
		policyName.clear();
		policyName.sendKeys("BVT" + policyname);
		shortName.clear();
		shortName.sendKeys(policyname);
		waitABit(2000);
		shortName.sendKeys(Keys.TAB);
		scrollIntoView(btn_MoveAll);
		btn_MoveAll.waitUntilClickable();
		clickUsingJavaScript(btn_MoveAll);
		// btn_MoveAll.click();
		continueButton.click();
		waitABit(2000);
		WaitForPageLoad();

	}

	// This method is to select Clocking Rules: clock web mobile ivr and actions In TakeMeal Transfer
	public void selectClockingSource(String clockingRule, String[] Rules) {
		try {
			if (clockingRule.equals("all")) {
				for (int i = 0; i < Rules.length; i++) {
					selectTimeEntrySoureAction(Rules[i]);
				}
			}
				else
				{
					selectTimeEntrySoureAction(clockingRule);
				}			
		} catch (Exception ex) {
		}
	}
	
	/*public void selectClockingAction(String clockingRule) {
		try {
			if (clockingRule.equals("all")) {
				for (int i = 0; i < actionType.length; i++) {
					selectTimeEntrySoureAction(actionType[i]);
				}
			}
				else
				{
					selectTimeEntrySoureAction(clockingRule);
				}			
		} catch (Exception ex) {
		}
	}*/
	
	//This method is used to select clocking actions :In TakeMeal Transfer
	public void selectTimeEntrySoureAction (String timeEntrySourceAction) {
		try {						
			WebElementFacade timeEntryCLockingActionsCheckbox = getElementByDynamicValues("xpath", "timeEntryClockingActionsCheckbox",
					timeEntrySourceAction);
			timeEntryCLockingActionsCheckbox.click();	
			waitABit(1000);
		    } catch (Exception ex) {	
	     }
		
	}
	
	// This method is to create Rounding Policy by Rounding method
	public void createTimeAndAttendanceRoundingPolicy(String policyType, String policyname, String roundingtype,
			String date) {
		try {
			selectTimeAndAttendancePolicyType(policyType);
			copyOrCreatePolicy(policyType);
			enterpolicyBasics(policyname,date);
			selectpolicyMethod(policyType,roundingtype);
			// Select Rounding Rule: Same Rounding configuration if the Rounding type is Round Each Time Entry Type
			if (roundingtype.equals("Round Each Time Entry")) {
				sameRoundingRule.click();
				waitABit(2000);
			}
			continueButton.click();
			waitABit(2000);
			saveButton.click();
			WaitForPageLoad();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// This method is create TimeEntry Policy by timeEntry method
	// (clocking,Timesheets Entry)
	public void createTimeAndAttendanceTimeEntryPolicy(String policyType, String policyname, String timeEntrytype,
			String date,String sourceType, String actionType) {
		try {
			selectTimeAndAttendancePolicyType(policyType);
			copyOrCreatePolicy(policyType);
			if(timeEntrytype.contains("Clocking") && timeEntrytype.contains("Timesheets") ){
			selectpolicyMethod(policyType,"Clocking");
			selectpolicyMethod(policyType,"Timesheets Entry");
			}
			selectpolicyMethod(policyType,timeEntrytype);
			enterpolicyBasics(policyname,date);
			if(timeEntrytype.contains("Clocking")){
			selectClockingSource(sourceType,sourceTypeValues);
			selectClockingSource(actionType,actionTypeValues);
			policyBasicscontinueButton.click();
			}	       
	        WaitForPageLoad();
	        policyBasicscontinueButton.click();
	        waitABit(2000);
			saveButton.click();
			WaitForPageLoad();

		} catch (Exception ex) {
		}
	}

	// This method is to delete the policy
	public void deletePolicy(String policyname) {
		String policyName = "BVT" + policyname;
//		if (checkElementVisible(backToPolicyListButton))
//			backToPolicyListButton.click();
//		waitABit(5000);
		List<WebElement> findPolicy = getDriver()
				.findElements(By.xpath(".//span[text()='" + policyName + "']/../../..//button/span/div"));
		if (!findPolicy.isEmpty()) {
			findPolicy.get(0).click();
			waitABit(2000);
			getDriver().findElement(By.xpath("//*[@title='Delete']")).click();
			waitABit(2000);
			getDriver().findElement(By.xpath("//span[text()='Close']")).click();
		}
	}
	
	//This method to click on Back to Policy List button
	public void navigateBackPolicyList() {
		if (checkElementVisible(backToPolicyListButton))
			backToPolicyListButton.click();
		waitABit(5000);
		setupNewPolicyButton.waitUntilClickable();
		Assert.assertTrue("Verification of Navigate Back to Policy List Page", checkElementVisible(setupNewPolicyButton));
	}
}
