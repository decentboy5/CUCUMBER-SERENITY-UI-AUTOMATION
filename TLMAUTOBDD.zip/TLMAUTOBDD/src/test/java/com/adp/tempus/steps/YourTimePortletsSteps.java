package com.adp.tempus.steps;

import java.text.ParseException;
import java.util.List;

import com.adp.tempus.pages.YourTimePortlets;
import com.adp.tempus.pages.YourTimecard;
import com.adp.tlmbdd.pages.Logins;

import net.thucydides.core.annotations.Step;

public class YourTimePortletsSteps {

	YourTimePortlets yourTimePortletsBase;
	Logins login;

	@Step
	public void tempus_EmployeeLogin(String userId, String password) {
		login.empUserLogin(userId, password);
		// yourTimePortletsBase.tempus_EmployeeLogin(userId, password);
	}

	@Step
	public void tempus_MenuNavigation(String mianMenu, String subMenu, String subMenuOption, String pageHeader) {
		yourTimePortletsBase.tempus_MenuNavigation(mianMenu, subMenu, subMenuOption, pageHeader);
	}

	@Step
	public void emp_HomePage_Verify_YourTime_loading() {
		yourTimePortletsBase.emp_HomePage_Verify_YourTime_loading();
	}

	@Step
	public String convert_toTime_addingMinutes(String time, int minuts, boolean addMinutesFlag) throws ParseException {
		return yourTimePortletsBase.convert_toTime_addingMinutes(time, minuts, addMinutesFlag);
	}

	@Step
	public String get_date(String addToDay, String dateType) {
		return yourTimePortletsBase.get_date(addToDay, dateType);
	}

	@Step
	public void emp_Homepage_Verify_ClockINImgIcon_Existance(boolean clockInIconPresenceFlag) {
		yourTimePortletsBase.emp_Homepage_Verify_ClockINImgIcon_Existance(clockInIconPresenceFlag);
	}

	@Step
	public void emp_Homepage_Verify_ClockOutImgIcon_Existance(boolean clockOutIconPresenceFlag) {
		yourTimePortletsBase.emp_Homepage_Verify_ClockOutImgIcon_Existance(clockOutIconPresenceFlag);
	}

	@Step
	public void emp_Homepage_Verify_MealOutImgIcon_Existance(boolean mealOutIconPresenceFlag) {
		yourTimePortletsBase.emp_Homepage_Verify_MealOutImgIcon_Existance(mealOutIconPresenceFlag);
	}

	@Step
	public void emp_Homepage_Verify_TransferImgIcon_Existance(boolean transferIconPresenceFlag) {
		yourTimePortletsBase.emp_Homepage_Verify_TransferImgIcon_Existance(transferIconPresenceFlag);
	}

	@Step
	public void emp_yourTimecard_Navigation_FromYourTime() {
		yourTimePortletsBase.emp_yourTimecard_Navigation_FromYourTime();
	}

	@Step
	public String emp_yourTime_GetPunchTime() {
		return yourTimePortletsBase.emp_yourTime_GetPunchTime();
	}

	@Step
	public void emp_HomePage_Naviagation() {
		yourTimePortletsBase.emp_HomePage_Naviagation();
	}

	@Step
	public void emp_HomePage_YourTime_Verify_ClockInToStartYourShift_Msg(boolean startYourShiftFlag) {
		yourTimePortletsBase.emp_HomePage_YourTime_Verify_ClockInToStartYourShift_Msg(startYourShiftFlag);
	}

	@Step
	public void emp_HomePage_YourTime_ClickOn_ClockIn() {
		yourTimePortletsBase.emp_HomePage_YourTime_ClickOn_ClockIn();
	}

	@Step
	public void emp_yourTime_clickOn_mealOut() {
		yourTimePortletsBase.emp_yourTime_clickOn_mealOut();
	}

	@Step
	public void emp_yourTime_clickOn_mealReturn() {
		yourTimePortletsBase.emp_yourTime_clickOn_mealReturn();
	}

	@Step
	public void emp_Homepage_Verify_mealReturnImgIcon_Existance(boolean mealReturnIconPresenceFlag) {
		yourTimePortletsBase.emp_Homepage_Verify_mealReturnImgIcon_Existance(mealReturnIconPresenceFlag);
	}

	@Step
	public void emp_youTime_approveTimecard_navigation() {
		yourTimePortletsBase.emp_youTime_approveTimecard_navigation();
	}

	@Step
	public void emp_yourTime_missedPunches_navigation() {
		yourTimePortletsBase.emp_yourTime_missedPunches_navigation();
	}

	@Step
	public void emp_yourTime_verify_missedPunches_pageloading() {
		yourTimePortletsBase.emp_yourTime_verify_missedPunches_pageloading();
	}

	@Step
	public void emp_homePage_close_missedPunches_slider() {
		yourTimePortletsBase.emp_homePage_close_missedPunches_slider();
	}
	
	@Step
	public void emp_yourTime_missedPunches_close_notePopup() {
		yourTimePortletsBase.emp_yourTime_missedPunches_close_notePopup();
	}

	@Step
	public void wait_For_ThreeMinutes() {
		yourTimePortletsBase.wait_For_ThreeMinutes();
	}

	@Step
	public void emp_yourTime_verify_missedPunches_existance(boolean missedPunchesPresenceFlag) {
		yourTimePortletsBase.emp_yourTime_verify_missedPunches_existance(missedPunchesPresenceFlag);
	}

	@Step
	public void emp_homePage_enter_missedPunchData(String date, String outTime) {
		yourTimePortletsBase.emp_homePage_enter_missedPunchData(date, outTime);
	}
	
	@Step
	public void emp_homePage_enter_missedPunchData(String date,String inTime, String outTime, int rowNo) {
		yourTimePortletsBase.emp_homePage_enter_missedPunchData(date,inTime, outTime, rowNo);
	}

	@Step
	public List<String> emp_homePage_get_missedPunchesDates() {
		return yourTimePortletsBase.emp_homePage_get_missedPunchesDates();
	}

	@Step
	public void emp_homepage_save_missedPunchesData() {
		yourTimePortletsBase.emp_homepage_save_missedPunchesData();
	}

	@Step
	public void emp_yourTime_verify_approveTimecard_existance(boolean approveTimecardPresenceFlag) {
		yourTimePortletsBase.emp_yourTime_verify_approveTimecard_existance(approveTimecardPresenceFlag);
	}

	@Step
	public void emp_HomePage_YourTime_verify_ClockIn_successful() {
		yourTimePortletsBase.emp_HomePage_YourTime_verify_ClockIn_successful();
	}

	@Step
	public void emp_yourTime_waitFor_threeMinutes() throws InterruptedException {
		yourTimePortletsBase.emp_yourTime_waitFor_threeMinutes();
	}

	@Step
	public Boolean emp_yourTime_verify_webElement_presence(String imgIconName) {
		return yourTimePortletsBase.emp_yourTime_verify_webElement_presence(imgIconName);
	}

	@Step
	public void emp_yourTimecard_clockOn_clockOut() {
		yourTimePortletsBase.emp_yourTimecard_clockOn_clockOut();
	}

	@Step
	public void emp_yourTime_verify_clockOut_successful() {
		yourTimePortletsBase.emp_yourTime_verify_clockOut_successful();
	}

	@Step
	public void emp_yourTimecard_verify_donotHaveAccess_msg(boolean accessMsgPresenceFlag) {
		yourTimePortletsBase.emp_yourTimecard_verify_donotHaveAccess_msg(accessMsgPresenceFlag);
	}

	@Step
	public String emp_yourTime_get_currentTime() {
		return yourTimePortletsBase.emp_yourTime_get_currentTime();
	}
	
	@Step
	public void emp_yourTime_clickOn_viewMoreOptions() {
		yourTimePortletsBase.emp_yourTime_clickOn_viewMoreOptions();
	}
	
	@Step
	public void emp_yourTime_clickOn_hideMoreOptions() {
		yourTimePortletsBase.emp_yourTime_clickOn_hideMoreOptions();
	}

	@Step
	public void emp_yourTime_carousel_verify_clockInIcon_presence(boolean clockInIconPresence) {
		yourTimePortletsBase.emp_yourTime_carousel_verify_clockInIcon_presence(clockInIconPresence);
	}
	
	@Step
	public void emp_yourTime_carousel_verify_clockOutIcon_presence(boolean clockOutIconPresence) {
		yourTimePortletsBase.emp_yourTime_carousel_verify_clockOutIcon_presence(clockOutIconPresence);
	}
	
	
	
	@Step
	public void emp_yourTime_clickOn_clockIn_notesIcon() {
		yourTimePortletsBase.emp_yourTime_clickOn_clockIn_notesIcon();
	}
	
	@Step
	public void emp_yourTime_clickOn_clockOut_notesIcon() {
		yourTimePortletsBase.emp_yourTime_clickOn_clockOut_notesIcon();
	}
	
	
	@Step
	public void emp_yourTime_clickOn_takeMeal_notesIcon() {
		yourTimePortletsBase.emp_yourTime_clickOn_takeMeal_notesIcon();
	}
	
	@Step
	public void emp_yourTime_clickOn_mealReturn_notesIcon() {
		yourTimePortletsBase.emp_yourTime_clickOn_mealReturn_notesIcon();
	}
	
	@Step
	public void emp_yourTime_enterNotes_from_notesSlider(String noteMessage) {
		yourTimePortletsBase.emp_yourTime_enterNotes_from_notesSlider(noteMessage);
	}
	
	@Step
	public void emp_yourTime_verify_viewMoreOptions_existance(boolean viewMoreOptionsFlag) {
		yourTimePortletsBase.emp_yourTime_verify_viewMoreOptions_existance(viewMoreOptionsFlag);
	}
	
	@Step
	public void emp_yourTime_verify_carousel_existence(boolean carouselPresenceFlag) {
		yourTimePortletsBase.emp_yourTime_verify_carousel_existence(carouselPresenceFlag);
	}
	
	@Step
	public void emp_yourTime_verify_smartbutton_existence(boolean smartButtonPresenceFlag) {
		yourTimePortletsBase.emp_yourTime_verify_smartbutton_existence(smartButtonPresenceFlag);
	}
	
	@Step
	public void emp_yourTime_verify_hideMoreOptins_existence(boolean hideMoreOptionsPresenceFlag) {
		yourTimePortletsBase.emp_yourTime_verify_hideMoreOptins_existence(hideMoreOptionsPresenceFlag);
	}
	
	@Step
	public void emp_verify_element_existence(YourTimecard.data elementName,boolean existenceFalg)
	{
		yourTimePortletsBase.emp_verify_element_existence(elementName, existenceFalg);
	}
	
	@Step
	public void emp_yourtime_clickOn_clockIn_carousel() {
		yourTimePortletsBase.emp_yourtime_clickOn_clockIn_carousel();
	}
	
	@Step
	public void emp_yourTime_clickOn_takeAMeal_carousel() {
		yourTimePortletsBase.emp_yourTime_clickOn_takeAMeal_carousel();
	}
	
	@Step
	public void emp_yourTime_clickOn_mealReturn_carousel() {
		yourTimePortletsBase.emp_yourTime_clickOn_mealReturn_carousel();
	}
	
	@Step
	public void emp_yourTime_clickOn_clockOut_carousel() {
		yourTimePortletsBase.emp_yourTime_clickOn_clockOut_carousel();
	}
	
	@Step
	public void emp_yourTime_clickOn_clockIn_noteIcon_carousel() {
		yourTimePortletsBase.emp_yourTime_clickOn_clockIn_noteIcon_carousel();
	}
	
	@Step
	public void emp_yourTime_clickOn_clockOut_notesIcon_carousel() {
		yourTimePortletsBase.emp_yourTime_clickOn_clockOut_notesIcon_carousel();
	}
	
	@Step
	public void emp_yourTime_clickOn_takeMeal_notesIcon_carousel() {
		yourTimePortletsBase.emp_yourTime_clickOn_takeMeal_notesIcon_carousel();
	}
	
	
	@Step
	public void emp_yourTime_clickOn_mealReturn_notesIcon_carousel() {
		yourTimePortletsBase.emp_yourTime_clickOn_mealReturn_notesIcon_carousel();
	}
	
	@Step
	public void emp_yourTime_verify_errorMessage_existence(YourTimecard.data buttonName, boolean existenceFalg) {
		yourTimePortletsBase.emp_yourTime_verify_errorMessage_existence(buttonName, existenceFalg);
	}
	@Step
	public void emp_yourTime_clickOn_element(YourTimecard.data buttonName) {
		yourTimePortletsBase.emp_yourTime_clickOn_element(buttonName);
	}
	
	@Step
	public void emp_homepage_save_missedPunches() {
		yourTimePortletsBase.emp_homepage_save_missedPunches();
	}
	
	@Step
	public void emp_yourTime_missedPunchesSlider_clickOn_addNote(String date, int rowNo) {
		
         String actual_date = "";
		
		List<String> missPunchDates = emp_homePage_get_missedPunchesDates();
		
		for(String t_date : missPunchDates)
		{
			String temp_date = (t_date.split("/"))[1].trim();
			if(temp_date.contains(date.trim()))
			{
				actual_date = t_date;
				break;
			}
			
		}
		yourTimePortletsBase.emp_yourTime_missedPunchesSlider_clickOn_addNote(actual_date,rowNo);
	}
	
	
	@Step
	public void emp_yourTime_missedPunchesSlider_enter_noteMessage(String noteMessage) {
		yourTimePortletsBase.emp_yourTime_missedPunchesSlider_enter_noteMessage(noteMessage);
	}
	
	
	@Step
	public void em_yourTime_missedPunches_verify_noteMessage(String expectedNoteMessage,boolean noteExistenceFlg) {
		yourTimePortletsBase.em_yourTime_missedPunches_verify_noteMessage(expectedNoteMessage,noteExistenceFlg);
	}
	
	//---------- common function -----------------------------------------------------//
	
	
	@Step
	public void emp_yourTime_missedPunchesSlider_addTimePair(List<String> timePairs, boolean submitFlag)
	{
		String actual_date = "  ";
		
		List<String> missPunchDates = emp_homePage_get_missedPunchesDates();
		
		for(String t_timePairs : timePairs)
		{
			String[] t_time = t_timePairs.split("-");
			
			for(String t_date : missPunchDates)
			{
				String temp_date = (t_date.split("/"))[1].trim();
				if(temp_date.contains(t_time[3].trim()))
				{
					actual_date = t_date;
					break;
				}
				
			}
			
			
			emp_homePage_enter_missedPunchData(actual_date,t_time[0].trim(), t_time[1].trim(), Integer.parseInt(t_time[2].trim()));
		
		}
		
		  if(submitFlag)
		  {
		  emp_homepage_save_missedPunches();
		  }
		
    }
	
	
	@Step
	public void emp_yourTime_missedPunchesSlider_add_note(String day, String noteMessage)
	{
		
		emp_yourTime_missedPunchesSlider_clickOn_addNote(day,1);
		
		emp_yourTime_missedPunchesSlider_enter_noteMessage(noteMessage);
		
	}
	
	@Step
	public void emp_yourTime_verify_element_shouldBe_display(String elementName)
	{
		
	}
	
	@Step
	public void emp_yourTime_clickOn_element(String elementName)
	{
		
		
		
	}
	
	
	
	

	
	//-------------end common function -----------------------------------------------//
	
	
	
	
	
	
	
	
	
	
}
