package com.adp.tempus.pages;

import com.adp.tlmbdd.pages.objects.ReportObjectsGen;

import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.chrome.ChromeDriver;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.remote.server.handler.GetElementDisplayed;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.util.Assert;

public class TempusReport extends ReportObjectsGen {


	public void runAsExcel() {

		runAsExcelButton.waitUntilClickable();
		runAsExcelButton.click();
		waitABit(1000);
	}

	public void runAsPDF() {

		runAsPDFButton.waitUntilClickable();
		runAsPDFButton.click();
		waitABit(1000);
	}

	public void runAsCSV() {

		runAsCSV.waitUntilClickable();
		runAsCSV.click();
		waitABit(1000);
	}

	public void navigateToWhoAppearsOnTheReport() {
		whoAppearsSection.waitUntilClickable();
		whoAppearsSection.click();
	}

	public void navigateToWhatIsDisplayedSection() {
		whatsDisplayedSection.waitUntilClickable();
		whatsDisplayedSection.click();
	}

	public void navigateToAppearanceSection() {
		appearanceSection.waitUntilClickable();
		appearanceSection.click();
	}

	public void runAs(String runFormat) {

		if (runFormat.equalsIgnoreCase("PDF")) {
			runAsPDFButton.waitUntilClickable();
			runAsPDFButton.click();
			waitABit(1000);
		} else if (runFormat.equalsIgnoreCase("CSV")) {
			runAsCSV.waitUntilClickable();
			runAsCSV.click();
			waitABit(1000);
		} else if (runFormat.equalsIgnoreCase("Excel")) {
			runAsExcelButton.waitUntilClickable();
			runAsExcelButton.click();
			waitABit(1000);
		}
	}

	public void employeeList() {
		waitABit(1000);
		employeeList.waitUntilClickable();
		employeeList.click();
	}

	public void companyCode() {
		waitABit(1000);
		companyCode.waitUntilClickable();
		companyCode.click();
	}

	public void selectOneCompany() {
		waitABit(1000);
		selectOneCompany.click();
	}

	public void selectEmployeeType(String employeeType) {
		if (employeeType.equalsIgnoreCase("archived")) {
			includeArchivedEmployees.click();
		} else if (employeeType.equalsIgnoreCase("terminated")) {
			includeTerminatedEmployees.click();
			waitABit(1000);
		} else if (employeeType.equalsIgnoreCase("inactive")) {
			includeInactiveEmployees.click();
			waitABit(1000);
		}
	}

	public void selectEmployeeType(String employeeType, String employeeType1) {
		if (employeeType.equalsIgnoreCase("archived") && employeeType1.equalsIgnoreCase("inactive")) {
			includeArchivedEmployees.click();
			waitABit(1000);
			includeTerminatedEmployees.click();
			waitABit(1000);
		} else if (employeeType.equalsIgnoreCase("archived") && employeeType1.equalsIgnoreCase("terminated")) {
			includeTerminatedEmployees.click();
			waitABit(1000);
		} else if (employeeType.equalsIgnoreCase("inactive") && employeeType1.equalsIgnoreCase("terminated")) {
			includeInactiveEmployees.click();
			waitABit(1000);
		}
	}

	public void selectAllTypesOfEmployees() {
		includeArchivedEmployees.click();
		waitABit(1000);
		includeTerminatedEmployees.click();
		waitABit(1000);
		includeInactiveEmployees.click();
	}

	public void verifySaveMySettings() {
		saveMySettings.shouldBeVisible();
		waitABit(1000);
	}

	public void verifyAllOptionsDisplayed() {
		runAsPDFButton.shouldBeVisible();
		runAsCSV.shouldBeVisible();
		runAsExcelButton.shouldBeVisible();
		waitABit(1000);
		saveMySettings.shouldBeVisible();
		waitABit(1000);

	}

	public void verifyAllComponentsAreDisplayed() {
		whoAppearsSection.shouldBeVisible();
		waitABit(1000);
		whatsDisplayedSection.shouldBeVisible();
		waitABit(1000);
		appearanceSection.shouldBeVisible();
		waitABit(1000);
	}

	public void department() {
		waitABit(1000);
		department.click();
	}

	public void selectOneDepartment() {
		waitABit(1000);
		selectOneDepartment.waitUntilClickable();
		selectOneDepartment.click();
	}

	public void selectAllDepartment() {
		waitABit(1000);
		selectAllDepartment.waitUntilClickable();
		selectAllDepartment.click();
	}

	public void selectTimeFrame(String timeFrame) {

		WebElementFacade currentPay = getElementByDynamicValues("xpath", "timeFrameDropdownValue", timeFrame);
		currentPay.click();
		// span[@class='vdl-dropdown-list__picker']//..//div[contains(.,'Current Pay
		// Period')]

	}

	public void enterDatesForTimeFrame(String date) {
		// DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDateTime now = LocalDateTime.now();
		fromDate.waitUntilClickable();
		fromDate.click();
		fromDate.typeAndTab(date);
		toDate.waitUntilClickable();
		toDate.click();
		toDate.type(now.toString());
		waitABit(1000);

	}


	public void searchForReport(String reportName) {
		System.out.println("The reportname is:::::::" + reportName);
		
		waitABit(1000);
		
		searchReports.waitUntilClickable();
		searchReports.click();
		searchReports.typeAndEnter(reportName);
		waitABit(2000);
	//	filterDiv.click();
		filterButton.click();
		waitABit(2000);
		
	}

	public void selectSpecificEmployee() {

		selectSpecificEmployees.waitUntilClickable();
		selectSpecificEmployees.click();
		waitABit(1000);
		selectEmployee1.click();

	}

	public void selectFiveEmployees() {
		selectSpecificEmployees.waitUntilClickable();
		selectSpecificEmployees.click();
		waitABit(1000);
		selectEmployee1.click();
		selectEmployee2.click();
		selectEmployee3.click();
		selectEmployee4.click();
		selectEmployee5.click();
		waitABit(1000);

	}

	public void selectAllFields() {
		waitABit(1000);
		archived.click();
		badge.click();
		companycode.click();
		status.click();
		fileNumber.click();
		override.click();
		payClass.click();
		supervisor.click();
		payrollID.click();
		adjustTranDate.click();
		clockInID.click();
		clockOutId.click();
		payDate.click();
		rateModifier.click();
		supervisorApproved.click();
		timePairActualGap.click();
		timePairRoundedGap.click();

	}

	public void selectSomeFields() {
		waitABit(1000);
		archived.click();
		badge.click();
		companycode.click();
		status.click();
		supervisor.click();
		payrollID.click();
		adjustTranDate.click();
		clockInID.click();
		clockOutId.click();
		payDate.click();

	}

	public void selectSomeOtherFields() {
		waitABit(1000);
		payDate.click();
		rateModifier.click();
		supervisorApproved.click();
		timePairActualGap.click();
		timePairRoundedGap.click();

	}

	public void clickOnTimeframe() {
		waitABit(1000);
		timeFrame.waitUntilClickable();
		timeFrame.click();

	}

	public void includeNotes() {
		waitABit(1000);
		includeNotes.waitUntilClickable();
		includeNotes.click();
	}

	public void includePendingTimeOff() {
		waitABit(1000);
		includePendingTimeOff.waitUntilClickable();
		includePendingTimeOff.click();
	}

	public void includePayrollAdjustment(int i) {
		waitABit(1000);
		includePayRollAdjustment.waitUntilClickable();
		includePayRollAdjustment.click();
		if (i == 0) {
			payDateinPayrollAdjustment.click();
		} else {
			adjustedTransactionDate.click();
		}

	}

	public void includePayrollAdjustmentHours() {
		waitABit(1000);
		displayPayrollAdjustment.waitUntilClickable();
		displayPayrollAdjustment.click();

	}

	public void includePrintOption() {
		waitABit(1000);
		printRuntimeSetting.waitUntilClickable();
		printRuntimeSetting.click();

	}

	public void selectAllOptionsInAppearance() {
		waitABit(1000);
		includeNotes.click();
		includePendingTimeOff.click();
		includePayRollAdjustment.click();
		displayPayrollAdjustment.click();
		printRuntimeSetting.click();
	}

	public void selectAllOptionsInWhoApppears() {
		waitABit(1000);
		companyCode.click();
		selectAllCompanies.click();
		employeeList.click();
		includeArchivedEmployees.click();
		includeInactiveEmployees.click();
		includeTerminatedEmployees.click();
		timeFrame.click();
		selectTimeFrame("Company Code");
		department.click();
		selectAllDepartment.click();
		waitABit(1000);

	}

	public void selectAllOptionsInWhatIsDisplayedSection() {
		includeNotes.click();
		includePendingTimeOff.click();
		includePayRollAdjustment.click();
		displayPayrollAdjustment.click();
		printRuntimeSetting.click();

	}

	public void selectOnlyCompanyCode() {
		companycode.click();
		waitABit(1000);
	}

	public void cancelButton() {
		cancelButton.click();
		waitABit(1000);
	}

	public void addNotes() {
		addNote.click();
		notesTextArea.click();
		notesTextArea.type("This is a sample note");
	}

	public void saveSettingsWithDEfaultOptions() {
		saveMySettings.waitUntilClickable();
		saveMySettings.click();
		reportName.waitUntilClickable();
		reportName.click();
		reportName.type("- Report with default options");
		saveMySettingsInDialog.waitUntilClickable();
		saveMySettingsInDialog.click();

	}

	// validation for non-default is left
	public void saveSettingsWithNonDefaultOptions() {
		saveMySettings.waitUntilClickable();
		saveMySettings.click();
		reportName.waitUntilClickable();
		reportName.click();
		reportName.type("- Report with non-default options");
		saveMySettingsInDialog.waitUntilClickable();
		saveMySettingsInDialog.click();
	}

	public void validateReport() {
		String textLabel = checkReportShows.getTextValue();
		Assert.isTrue(textLabel.equalsIgnoreCase("Copy of Timecard- Report with default options"),
				"The report name does not match");
	}

	public void saveSettingsAsCSV() {
		saveMySettings.waitUntilClickable();
		saveMySettings.click();
		reportName.waitUntilClickable();
		reportName.type("- CSV Report with default options");
		saveAsCSV.waitUntilClickable();
		saveAsCSV.click();
		saveMySettingsInDialog.waitUntilClickable();
		saveMySettingsInDialog.click();
	}

	public void saveSettingsAsCSVWithNonDefaultOptions() {
		saveMySettings.waitUntilClickable();
		saveMySettings.click();
		reportName.waitUntilClickable();
		reportName.type("- CSV Report with non-default options");
		saveAsCSV.waitUntilClickable();
		saveAsCSV.click();
		saveMySettingsInDialog.waitUntilClickable();
		saveMySettingsInDialog.click();
	}

	public void validateReportAsCSV() {
		String textLabel = checkReportShows.getTextValue();
		Assert.isTrue(textLabel.equalsIgnoreCase("Copy of Timecard- CSV Report with default options"),
				"The report does not exist");
	}

	public void saveSettingsAsExcel() {
		saveMySettings.waitUntilClickable();
		saveMySettings.click();
		reportName.waitUntilClickable();
		reportName.type("- Excel Report with default options");
		saveAsExcel.waitUntilClickable();
		saveAsExcel.click();
		saveMySettingsInDialog.waitUntilClickable();
		saveMySettingsInDialog.click();
	}

	public void saveSettingsAsExcelWithNonDefaultOptions() {
		saveMySettings.waitUntilClickable();
		saveMySettings.click();
		reportName.waitUntilClickable();
		reportName.type("- Excel Report with non-default options");
		saveAsExcel.waitUntilClickable();
		saveAsExcel.click();
		saveMySettingsInDialog.waitUntilClickable();
		saveMySettingsInDialog.click();
	}

	public void validateReportAsExcel() {
		String textLabel = checkReportShows.getTextValue();
		Assert.isTrue(textLabel.equalsIgnoreCase("Copy of Timecard- Excel Report with default options"),
				"The report does not exist");

	}

	public void clickOnReport(String reportname) {
	//	selectFrame(iframeMain);
		System.out.println("I am here");
		waitABit(3000);
		WebElementFacade searchedReportName = getElementByDynamicValues("xpath", "reportName", reportname);
		waitABit(1000);
		searchedReportName.click();
		waitABit(5000);
	}

	public void saveSettingAndCancel() {
		saveMySettings.click();
		saveMySettings.click();
		cancelButton.waitUntilClickable();
		cancelButton.click();
	}

	public void gotoStandardTab() {
		selectFrame(iframeMain);
		standardTab.waitUntilClickable();
		standardTab.click();
	}

	public void gotoOutputTab() {
		selectFrame(iframeMain);
		outputTab.waitUntilClickable();
		outputTab.click();
	}

	public void runAsExcelAndOpenReport() {
		// write code here.
	}

	public void runAsPDFAndOpenReport() {
		// write code here.
	}

	public void runAsCSVAndOpenReport() {
		// write code here.
	}

	public void gotoReportsTab() {
		selectFrame(iframeMain);
		myReportsTab.waitUntilClickable();
		myReportsTab.click();
	}

	public void clickOnThreeDots() {
		threeDots.click();
		waitABit(1000);
	}

	public void verifyHeaders() {
		// Write logic here
	}

	public void navigateToReportsTab() { // completely tentative
		WebDriver driver = new ChromeDriver();
		String windowHandle = driver.getWindowHandle();
		String originalHandle = driver.getWindowHandle();

		// Do something to open new tabs

		for (String handle : driver.getWindowHandles()) {
			if (!handle.equals(originalHandle)) {
				driver.switchTo().window(handle);
				driver.close();
			}
		}

		driver.switchTo().window(originalHandle);

	}

	public void apply() {
		waitABit(1000);
		apply.waitUntilClickable();
		apply.click();
	}

}
