package com.adp.tempus.stepDefinition;

import com.adp.tempus.steps.HireRehireSteps;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class HireRehireStepDefinition {

	@Steps
	HireRehireSteps HireRehireSteps;

	@When("^I Select Hire Template \"([^\"]*)\" on Hire Rehire Page$")
	public void i_select_Hire_Template(String templateName) throws Throwable {
		HireRehireSteps.selectHireTemplate(templateName);
	}

	@When("^I Enter Basic Details on Personal Step \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Basic_Details_on_Personal_Step(String fName, String lName,String taxIdType,String taxId, String hDate,String hireReason) throws Throwable {
		HireRehireSteps.enterBasicDetailsOnPersonalStep(fName,lName,taxIdType,taxId,hDate,hireReason);
	}
	
	@When("^I Enter Address Details on Personal Step \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Address_Details_on_Personal_Step(String country,String addrLine1,String city,String state,String zip) throws Throwable {
		HireRehireSteps.enterAddressDetailsOnPersonalStep(country,addrLine1,city,state,zip);
	}

	@When("^I Enter Details on Employment Step \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Details_on_Employment_Step(String payGroup, String positionId, String legalEntity,
			String supervisor) throws Throwable {
		HireRehireSteps.enterEmploymentDetailsOnEmploymentStep(payGroup,positionId,legalEntity,supervisor);
	}

	@When("^I Enter Details on Payroll Step \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Details_on_Payroll_Step(String regPayRateType, String payRate, String overtime) throws Throwable {
		HireRehireSteps.enterDetailsOnPayrollStep(regPayRateType,payRate,overtime);
	}
	
	@When("^I Enter Details on Tax Jurisdictions Step \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Details_on_TaxJurisdiction_Step(String worskState, String residenceState) throws Throwable {
		HireRehireSteps.enterDetailsOnTaxJurisdictionsStep(worskState,residenceState);
	}

	@When("^I Enter Details on Time Attendance Step \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Details_on_TimeAttendance_Step(String timeEntry,String badge, String timeZone) throws Throwable {
		HireRehireSteps.enterDetailsOnTimeAttendanceStep(timeEntry,badge,timeZone);
	}

	@When("^I Click Next Button on \"([^\"]*)\" Step$")
	public void i_click_Next_Button_on(String stepName) throws Throwable {
		HireRehireSteps.clickNextButtonOnStep(stepName);
	}

	@When("^I Click \"([^\"]*)\" Button on Hire Rehire Page$")
	public void i_click_Button_on_HireRehire_Page(String stepName) throws Throwable {
		HireRehireSteps.clickButtonOnHireRehire(stepName);
	}
}
