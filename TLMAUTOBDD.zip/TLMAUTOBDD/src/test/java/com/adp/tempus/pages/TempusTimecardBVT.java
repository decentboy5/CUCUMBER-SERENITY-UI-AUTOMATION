package com.adp.tempus.pages;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.adp.tlmbdd.pages.GenericPageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
public class TempusTimecardBVT extends GenericPageObject{

	public static Logger log = Logger.getLogger(TempusTimecardBVT.class);
	SoftAssertions sa=new SoftAssertions();
	@FindBy(xpath="//div[@id='wfnnav_top_item_home']")
	public WebElementFacade lnk_menuHome;
	
	@FindBy(xpath="//span[@class='view-timecard']")
	public WebElementFacade btn_viewYourTimecard;

	@FindBy(xpath="//div[contains(@class,'mytime-actions')]/descendant::div[contains(@class,'mytime-actions')]")
	public WebElementFacade btn_myTimeAtions;

	@FindBy(xpath="//div[@class='mytime-header-things-to-do'][.='Things to Do']")
	public WebElementFacade lbl_thingsToDoSection;
	
	@FindBy(xpath="//span[text()='Your Timecard']")
	public WebElementFacade lbl_yourTimecard;
	
	@FindBy(xpath="//div[@class='tc-total-period-hour']")
	public WebElementFacade lbl_totalPeriodHour;
	
	@FindBy(xpath="(//div[contains(@class,'week-summary')]//div[contains(@class,'tc-weekly-total-row')])[1]")
	public WebElementFacade lblVal_timeSummaryWeek1Regular;
	
	@FindBy(xpath="(//div[contains(@class,'week-summary')]//div[contains(@class,'tc-weekly-total-row')])[2]")
	public WebElementFacade lblVal_timeSummaryWeek1Overtime;
	
	@FindBy(xpath="//span[@class='tc-week-header'][text()='WEEK 2']/ancestor::div[@class='vdl-col-lg-12'][2]/descendant::div[text()='Regular']/following-sibling::div[contains(@class,'tc-currency-total')]")
	public WebElementFacade lblVal_timeSummaryWeek2Regular;
	
	@FindBy(xpath="//span[@class='tc-week-header'][text()='WEEK 2']/ancestor::div[@class='vdl-col-lg-12'][2]/descendant::div[text()='Overtime']/following-sibling::div[contains(@class,'tc-currency-total')]")
	public WebElementFacade lblVal_timeSummaryWeek2Overtime;

	@FindBy(xpath="//div[text()='Regular']/following-sibling::div[contains(@class,'tc-currency-total')]")
	public WebElementFacade lblVal_timeSummaryRegular;
	
	@FindBy(xpath="//div[text()='Overtime']/following-sibling::div[contains(@class,'tc-currency-total')]")
	public WebElementFacade lblVal_timeSummaryOvertime;	

	@FindBy(xpath="//div[text()='Gross Pay']")
	public WebElementFacade lbl_paySummaryGrossPay;
	
	@FindBy(xpath="//span[contains(@class,'tc-timecard-pie-chart-icon')]")
	public WebElementFacade imgIcon_paySummaryPieChart;
	
	@FindBy(xpath="//span[contains(@class,'fa fa-table tc-timecard-pay-summary-icon')]")
	public WebElementFacade imgIcon_paySummaryGrid;
	
	@FindBy(xpath="//*[contains(@class,'highcharts-pie-series')][@style='cursor:pointer;']")
	public WebElementFacade paySummaryPieChart;

	@FindBy(xpath="//div[text()='Gross Pay']/following-sibling::div/span")
	public WebElementFacade lblVal_paySummaryGrossPay;
	
	@FindBy(xpath="//div[text()='Deductions']/following-sibling::div/span")
	public WebElementFacade lblVal_paySummaryDeductions;	

	@FindBy(xpath="//div[text()='Taxes']/following-sibling::div/span")
	public WebElementFacade lblVal_paySummaryTaxes;
	
	@FindBy(xpath="//div[text()='Net Pay']/following-sibling::div/span")
	public WebElementFacade lblVal_paySummaryNetPay;	
	
	@FindBy(xpath="//div[@class='ug-day ug-day-highlight']")
	public WebElementFacade lbl_timecardCurrentDay;

	@FindBy(xpath="//span[@class='tc-add-punch-label'][text()='ADD TIME']")
	public WebElementFacade btn_enterTimePairAddPunch;

	@FindBy(xpath="//div[@class='tc-add-punch-icon-text']/span[text()='ADD HOURS']")
	public WebElementFacade btn_enterTimePairAddHours;
	
	@FindBy(xpath="//button[.='Save'][@aria-disabled='false'][contains(@class,'tc-time-pair-Save')]")
	public WebElementFacade btn_enterTimePairSave;
	
	@FindBy(xpath="//button[.='Save'][@aria-disabled='true']")
	public WebElementFacade btn_enterTimePairSaveDisabled;
	
	@FindBy(xpath="//button[.='Cancel'][contains(@class,'tc-time-pair-cancel')]")
	public WebElementFacade btn_addTimePairCancel;
	
	@FindBy(xpath = "//div[text()='Missed Punches']")
	public WebElementFacade lbl_missedPunches;
	
	@FindBy(xpath = "//div[text()='Shift Swap Requests']")
	public WebElementFacade lbl_shiftSwapRequests;
	
	@FindBy(xpath = "//div[text()='Timecard Approvals']")
	public WebElementFacade lbl_timecardApprovals;
	
	@FindBy(xpath="//div[@title='Notes'][contains(@class,'missedPunches-Grid-header')]")
	public WebElementFacade lbl_notesHeaderMissedPunches;
	
	@FindBy(xpath = "//span[text()='Pending Approval']")
	public WebElementFacade btn_shiftSwapRequestsPendingApproval;

	@FindBy(xpath="//h3[contains(text(),'Which timecards would you like to resolve today')]")
	public WebElementFacade lbl_timecardApprovalWelcomeText;
	
	@FindBy(xpath = "//div[text()='WORKING NOW']")
	public WebElementFacade lbl_whoisin;

	@FindBy(xpath = "//div[text()='HIT OVERTIME']")
	public WebElementFacade lbl_hitOvertime;

	@FindBy(xpath = "//div[text()='APPROVED']")
	public WebElementFacade lbl_approved;

	@FindBy(xpath = "//div[text()='Time Off This Week']")
	public WebElementFacade lbl_timeOffThisWeek;

	@FindBy(xpath="//div[contains(@class,'dashboardTileTitleClass')]/div[text()='Time Off This Week']")
	public WebElementFacade lbl_timeOffThisWeekTitle;
	
	@FindBy(xpath="//button[.='Request Pay']")
	public WebElementFacade btn_requestPay;
	
	@FindBy(xpath="//button[.='Request Pay']")
	public WebElementFacade btn_payRequested;	
	
	@FindBy(xpath="//div[contains(@class,'tc-early-pay-title')][.='Pay Request Submitted']")
	public WebElementFacade lbl_payRequestSubmitted;

	@FindBy(xpath="//div[@id='PiProcessPayrollSchedule_root']")
	public WebElementFacade lbl_payrollSchedulePageLoad;
	
	@FindBy(xpath="//div[@id='payrolldashboard_root']")
	public WebElementFacade lbl_payrollDashboardPageLoad;
	
	@FindBy(xpath="//div[@id='payData_root']")
	public WebElementFacade lbl_payrollWorksheetPageLoad;
	
	@FindBy(xpath="//div[@id='policyManager']")
	public WebElementFacade lbl_policyManagerPageLoad;
	
	@FindBy(xpath="//button[@id='setupNewPolicyButton']")
	public WebElementFacade btn_setupNewPolicy;
	
	@FindBy(xpath="//div[contains(@class,'payroll-item-setupcard')]//*[text()='Time & Attendance']")
	public WebElementFacade btn_timeandattendanceUnderSetup;
	
	@FindBy(xpath="//div[contains(@class,'payroll-item-setupcard')]//input[@value='Time & Attendance']/..")
	public WebElementFacade btn_timeandattendanceOption;
	
	@FindBy(xpath="//i[@class='icon-close-thin']")
	public WebElementFacade imgIcon_closeSetupNew;
	
	@FindBy(xpath="//span[text()='CONTINUE']")
	public WebElementFacade btn_continueButton;
	
	@FindBy(xpath="//span[text()='Continue']")
	public WebElementFacade btn_roundingPolicycontinueButton;
	
	@FindBy(xpath="//input[@value='Rounding']/..")
	public WebElementFacade chkBox_roundingCheckBox;
	
	@FindBy(xpath="//span[contains(text(),'GET Started')]")
	public WebElementFacade btn_iamReadyLetsGetStarted;
	
	@FindBy(xpath="(//*[@name='createPolicySelectedOptionType']/..)[3]")
	public WebElementFacade btn_createNewRoundingPolicy;

	@FindBy(xpath="//input[@name='effectiveDate']")
	public WebElementFacade txtBox_effectiveDate;
	
	@FindBy(xpath="//input[@name='name']")
	public WebElementFacade txtBox_policyName;
	
	@FindBy(xpath="//input[@name='en_US']")
	public WebElementFacade txtBox_shortName;
	
	@FindBy(xpath="//*[@name='sameRoundingConfigOn'][@value='Yes']/..")
	public WebElementFacade radioBtn_sameRoundingRule;
	
	@FindBy(xpath="//span[text()='Save']")
	public WebElementFacade btn_saveButton;
	
	@FindBy(xpath="(//img[@class='mytime-action-img'])[1]")
	public WebElementFacade btn_clockIN;
	
	
	@FindBy(xpath ="//div[@class='timecard-total-period tc-red-flag ']")
	public WebElementFacade btn_MissingOutPunch;
	
	@FindBy(xpath="(//img[@class='mytime-action-img'])[2]")
	public WebElementFacade btn_transfer;
	
	@FindBy(xpath="//*[contains(@id,'payrolldashboard')]//span[text()='MENU']")
	public WebElementFacade lnk_menuLinkInPayrollDashboard;
	
	@FindBy(xpath="//span[text()='Payroll Worksheet']")
	public WebElementFacade lnk_payrollWorksheet;
	
	@FindBy(xpath="//span[text()='Back to Policy List']")
	public WebElementFacade btn_backToPolicyList;
	
	@FindBy(xpath="//div[contains(@class,'tc-time-pair-back')]")
	public WebElementFacade lnk_backToTimecard;
	
	@FindBy(xpath="//button[@type='button']/span[text()='Back']")
	public WebElementFacade btn_backTTDSliders;

	@FindBy(xpath="//button[.='SCHEDULES'][contains(@class,'dasboard-other-actions')]")
	public WebElementFacade lnk_otherActionsSchedules;

	@FindBy(xpath="//button[.='INDIVIDUAL TIMECARD'][contains(@class,'dasboard-other-actions')]")
	public WebElementFacade lnk_otherActionsindividualTimecard;
	
	@FindBy(xpath="//button[.='TIMECARD EXCEPTIONS'][contains(@class,'dasboard-other-actions')]")
	public WebElementFacade lnk_otherActionsTimecardExceptions;
	
	@FindBy(xpath="//button[.='REPORTS'][contains(@class,'dasboard-other-actions')]")
	public WebElementFacade lnk_otherActionsReports;
	
	@FindBy(xpath="//button[.='Publish']")
	public WebElementFacade btn_schedulesPublish;
	
	@FindBy(xpath="//div[@id='map']")
	public WebElementFacade migIcon_whoIsInMap;

	@FindBy(xpath="//div[text()='Start Work']/preceding-sibling::div//img")
	public WebElementFacade btn_ClockIn;
	
	@FindBy(xpath="//div[text()='End Work']/preceding-sibling::div//img")
	public WebElementFacade btn_ClockOut;
	
	@FindBy(xpath="//div[text()='Meal Out']/preceding-sibling::div//img")
	public WebElementFacade btn_MealOut;
	
	@FindBy(xpath="//div[text()='Meal Return']/preceding-sibling::div//img")
	public WebElementFacade btn_MealReturn;

	@FindBy(xpath="//button[.='Timecard'][@id='thingsToDoLinks']")
	public WebElementFacade btn_ttdTimecard;
	
	@FindBy(xpath="//div[text()='Missed Punches'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]")
	public WebElementFacade lbl_ttdMissedPunches;
	
	@FindBy(xpath="//div[text()='Missed Punches'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]/following-sibling::div")
	public WebElementFacade lbl_ttdMissedPunchesCount;

	@FindBy(xpath="//div[text()='Approve Timecard'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]")
	public WebElementFacade lbl_ttdApproveTimecard;
	
	@FindBy(xpath="//div[text()='Approve Timecard'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]/following-sibling::div")
	public WebElementFacade lbl_ttdApproveTimecardCount;
	
	@FindBy(xpath="//div[text()='Transfer']/preceding-sibling::div//img")
	public WebElementFacade btn_ClockTransfer;
	
	@FindBy(xpath="//div[contains(text(),'Hello,')][contains(@class,'mytime-name')]")
	public WebElementFacade lbl_homePortletHello;

	@FindBy(xpath="//span[@id='currentdate_id']")
	public WebElementFacade lbl_homePortletCrntDate;
	
	@FindBy(xpath="//span[@id='currenttime_id']")
	public WebElementFacade lbl_homePortletCrntTime;
	
	@FindBy(xpath="//div[contains(@class,'mytime-status mytime-')]")
	public WebElementFacade lbl_homePortletClockStatus;
	
	@FindBy(xpath="//div[@class='tc-add-punch-link']")
	public WebElementFacade btn_addTimePairAddTime;	
	
	@FindBy(xpath="//label[@id='ToggleSwitch']")
	public WebElementFacade showDetails;

	@FindBy(xpath="//div[text()='Timecard Approved!']")
	public WebElementFacade lbl_timecardApprovedMsg;

	@FindBy(xpath = "//button[.='APPROVE TIMECARD'][@type='button']")
	public WebElementFacade btn_approveTimecard;
		
	@FindBy(xpath = "//button[.='Yes'][@type='button']")
	public WebElementFacade btn_deleteYes;
		
	@FindBy(xpath=".//button[@type='button'][@aria-disabled='false'][.='Request Pay']")
	public WebElementFacade enabledRequestPay;
	
	@FindBy(xpath = "//span[text()='WEEK 1']/parent::div")
	public WebElementFacade lbl_week1TimeSummary;
	
	@FindBy(xpath = "//span[text()='WEEK 2']/parent::div")
	public WebElementFacade lbl_week2TimeSummary;
	
	@FindBy(xpath="//div[contains(@class,'MDFSelectBox__single-value')]")
	public WebElementFacade txtBox_selectedPayPeriod;
	
	@FindBy(xpath="//div[text()='Time Period']")
	public WebElementFacade lbl_timePeriod;
	
	@FindBy(xpath="//button[@id='timeAndAttendancePiPolicyAssignment_btn']")
	public WebElementFacade btn_timeAttendanceEdit;
	
	@FindBy(xpath="//div[@class='sub-header'][text()='Failed to delete.']")
	public WebElementFacade msg_FailedToDelete;
	
	@FindBy(xpath="//div[@class='tc-navigation-previous']")
	public WebElementFacade lnk_previousDay;
	
	@FindBy(xpath="//div[@class='tc-navigation-next']")
	public WebElementFacade lnk_nextDay;
		
	By addTimecardGrid=By.xpath(".//span[@class='fa fa-plus-circle']");
	By editTimecardGrid=By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']");
	By noteTimecardGrid=By.xpath(".//span[contains(@class,'fa tc-day-entry-icon fa-comment')]");	
	By clockStatus=By.xpath(".//div[@class='timecard-clocked-in-label']");
	By clockInTime=By.xpath(".//div[@class='timecard-clocked-in-time']");
	By addNote = By.xpath("//div[@class='tc-add-new-note-icon-text']");
	By enterNote = By.xpath(".//div[contains(@class,'tc-add-notes-text-box')]/textarea");
	By payPeriodComboBox=By.xpath("//div[@class='vdl-col-lg-12 tc-time-period-list']");
	String tcGridDate=".//div[contains(@class,'ug-day ')]";
	String hoursTextBox=".//div[contains(@class,'tc-time-entry-hours')]/input";
	String inPunchTextBox = ".//div[contains(@class,'tc-in-time-entry-text-box')]/descendant::input";
	String outPunchTextBox = ".//div[contains(@class,'tc-out-time-entry-text-box')]/descendant::input";
	String deletePair = ".//span[@class='tc-delete-time-pair-label']";
	String inPunchBox = ".//div[contains(@class,'tc-in-time-entry-text-box')]/descendant::div[contains(@class,'tc-time-entry-box-error')]";
	String outPunchBox = ".//div[contains(@class,'tc-out-time-entry-text-box')]/descendant::div[contains(@class,'tc-time-entry-box-error')]";
	String unreadNote = "//span[@class='fa tc-day-entry-icon fa-comment non-read']";
	
	String txt_supUsername = "(//span[@class='tc-comments-by-name-text'])[1]";
	String txt_supNote = "//textarea[contains(@class,'tc-add-notes-text-area')]";
	String lbl_mealDeductionHours = "//div[@class='meal-entry']";
	
	public void verifyHomePortlet(){
		try{
			if(!checkElementVisible(lbl_homePortletHello)) waitABit(5000);
			Assert.assertTrue(checkElementVisible(lbl_homePortletCrntDate));
			Assert.assertTrue(checkElementVisible(lbl_homePortletCrntTime));
			Assert.assertTrue(checkElementVisible(btn_myTimeAtions));
		}catch(Exception e){
			e.printStackTrace();
		}
	}	

	public void verifyContentHomePortlet(String strDate,String strTime,String empName,String strClockStatus){
		try{
			waitABit(2000);
			if(!checkElementVisible(lbl_homePortletHello)) waitABit(5000);
			Assert.assertTrue(lbl_homePortletCrntDate.getText().contentEquals(strDate));
			//Assert.assertTrue(homePortletCrntTime.getText().contentEquals(strTime));
			Assert.assertTrue(lbl_homePortletClockStatus.getText().contains(strClockStatus));
			Assert.assertTrue(lbl_homePortletHello.getText().contains(empName));
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void verifyClockInHomePortlet(String strDate,String strTime,String empName,String strClockStatus){
		try{
			waitABit(2000);
			if(!checkElementVisible(lbl_homePortletHello)) waitABit(5000);
			Assert.assertTrue(lbl_homePortletCrntDate.getText().contentEquals(strDate));
			Assert.assertTrue(lbl_homePortletCrntTime.getText().contentEquals(strTime));
			Assert.assertTrue(lbl_homePortletClockStatus.getText().contentEquals(strClockStatus));
			Assert.assertTrue(lbl_homePortletHello.getText().contains(empName));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void clickButtonHomePortlet(String btnName) {
		try {
			switch (btnName.toUpperCase()) {
			case "CLOCK IN":
				waitABit(2000);
				btn_ClockIn.click();
				break;
			case "CLOCK OUT":
				waitABit(2000);
				btn_ClockOut.click();
				break;
			case "MEAL OUT":
				waitABit(2000);
				btn_MealOut.click();
				break;
			case "MEAL RETURN":
				waitABit(2000);
				btn_MealReturn.click();
				break;
			case "APPROVE TIMECARD":
				waitABit(2000);
				lbl_ttdApproveTimecard.click();
				break;
			case "MISSED PUNCHES":
				waitABit(2000);
				lbl_ttdMissedPunches.click();
				break;			
			case "TIMECARD":
				waitABit(2000);
				btn_ttdTimecard.click();
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	
	
	public void verifySmartButtonsHomePortlet(String clockIn, String clockOut, String mealOut, String mealReturn,
			String thingsToDo) {
		if (!checkElementVisible(lbl_homePortletHello))
			waitABit(5000);
		if (mealOut.equalsIgnoreCase("EXISTS")) {
			btn_MealOut.waitUntilVisible().shouldBeVisible();
		} else if (mealOut.equalsIgnoreCase("DOESNOTEXIST"))
			btn_MealOut.waitUntilNotVisible().shouldNotBeVisible();
		if (clockIn.equalsIgnoreCase("EXISTS")) {
			waitABit(2000);
			btn_ClockIn.shouldBeVisible();
			// Assert.assertTrue(checkElementVisible(btn_ClockIn));
		} else if (clockIn.equalsIgnoreCase("DOESNOTEXIST"))
			// Assert.assertTrue(!checkElementVisible(btn_ClockIn));
			btn_ClockIn.waitUntilNotVisible().shouldNotBeVisible();
		if (clockOut.equalsIgnoreCase("EXISTS")) {
			// Assert.assertTrue(checkElementVisible(btn_ClockOut));
			btn_ClockOut.waitUntilVisible().shouldBeVisible();
		} else if (clockOut.equalsIgnoreCase("DOESNOTEXIST"))
			// Assert.assertTrue(!checkElementVisible(btn_ClockOut));
			btn_ClockOut.waitUntilNotVisible().shouldNotBeVisible();
		if (thingsToDo.equalsIgnoreCase("EXISTS")) {
			// Assert.assertTrue(checkElementVisible(lbl_thingsToDoSection));
			lbl_thingsToDoSection.waitUntilVisible().shouldBeVisible();
		} else if (thingsToDo.equalsIgnoreCase("DOESNOTEXIST"))
			lbl_thingsToDoSection.waitUntilNotVisible().shouldNotBeVisible();
		// Assert.assertTrue(!checkElementVisible(lbl_thingsToDoSection));
		if (mealReturn.equalsIgnoreCase("EXISTS")) {
			// Assert.assertTrue(checkElementVisible(btn_MealReturn));
			btn_MealReturn.waitUntilVisible().shouldBeVisible();
		} else if (mealReturn.equalsIgnoreCase("DOESNOTEXIST"))
			// Assert.assertTrue(!checkElementVisible(btn_MealReturn));
			btn_MealReturn.waitUntilNotVisible().shouldNotBeVisible();
	}
	
	public void verifyTimecardButtonHomePortlet(String timecardButton) {
		switch (timecardButton.toUpperCase()) {
		case "EXISTS":
			btn_ttdTimecard.waitUntilVisible().shouldBeVisible();
			// Assert.assertTrue("Verification of Timecard Button",
			// checkElementVisible(btn_ttdTimecard));
			break;
		case "DOESNOTEXIST":
			btn_ttdTimecard.waitUntilNotVisible().shouldNotBeVisible();
			// Assert.assertTrue("Verification of Timecard Button",
			// !checkElementVisible(btn_ttdTimecard));
			break;
		}
	}
	
	public void verifyContentApproveTimecardHomePortlet(String approveTimecardCount) {
		try{
			if(approveTimecardCount.contentEquals("")) return;
			Assert.assertTrue("Verification of Approve Timecard Tile", checkElementVisible(lbl_ttdApproveTimecard));
			Assert.assertTrue("Verification of Pending Timecards count", lbl_ttdApproveTimecardCount.getText().contentEquals(approveTimecardCount+" pending approval"));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void verifyContentMissedPunchesHomePortlet(String missedPunchesCount) {
		try{
			if(missedPunchesCount.contentEquals("")) return;
			Assert.assertTrue("Verification of Approve Timecard Tile", checkElementVisible(lbl_ttdMissedPunches));
			Assert.assertTrue("Verification of Pending Timecards count", lbl_ttdMissedPunchesCount.getText().contentEquals(missedPunchesCount+" pending approval"));
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	
	public List<WebElement> getTimePairCards(){
		List<WebElement> timePairCards = null;
		try {
			timePairCards = getDriver().findElements(
					By.xpath(".//div[@class='wfnx-small-card tc-time-entry-card']"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return timePairCards;
	}

	public void clickButtonTimecardGrid(String strDate, String strButton) {
		if (!strDate.contentEquals("")) {
			waitABit(2000);
			WebElement tcDayBlock = findTimecardBlock(strDate);
			switch (strButton.toUpperCase()) {
			case "ADD":
				//tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-plus-circle']")).click();
				scrollIntoView(tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-plus-circle']")));
				tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-plus-circle']")).click();
				break;
			case "EDIT":
				//tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']")).click();
				scrollIntoView(tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']")));
				tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']")).click();
				break;
			case "NOTE":
				//tcDayBlock.findElement(By.xpath(".//span[contains(@class,'fa tc-day-entry-icon fa-comment')]")).click();
				scrollIntoView(tcDayBlock.findElement(By.xpath(".//span[contains(@class,'fa tc-day-entry-icon fa-comment')]")));
				tcDayBlock.findElement(By.xpath(".//span[contains(@class,'fa tc-day-entry-icon fa-comment')]")).click();
				break;
			}
		}
	}

//	public void 
	
	public void verifyTimePairsExistanceTimecardGrid(String strDate,String timePairs){
		try{
			WebElement tcDayBlock = findTimecardBlock(strDate);
			List<WebElement> objTimePairContainer=tcDayBlock.findElements(By.xpath(".//div[@class='timepair-container']"));
			if(timePairs.toUpperCase().contentEquals("EXISTS")){
				Assert.assertTrue("Verification of Display of Time Pairs on Timecard Grid", objTimePairContainer.size()==1);
			}else if(timePairs.toUpperCase().contentEquals("DOESNOTEXIST")){
				Assert.assertTrue("Verification of Display of Time Pairs on Timecard Grid", !objTimePairContainer.get(0).isDisplayed());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void verifyTimePairsTimecardGrid(String strDate,String timePair){
		try{
			List<String> objTimePairs=getTimepairsOfDayOnTimecard(strDate);
			Assert.assertTrue("Verification of Time Pair '"+timePair+"' on Timecard Grid", objTimePairs.contains(timePair));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void selectShowDetailButton(String btnValue){
		try{
			selectToggleButton(showDetails,btnValue);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}


	public void selectPayPeriodTimecardPage(String payPeriod) {
		try {
			List<WebElement> values = getValuesOfComboBox(payPeriodComboBox);
			//to close drop down
			lbl_timePeriod.click();
			switch (payPeriod.toUpperCase()) {
			case "PREVIOUS":
				if (values.size() == 2) {
					Assert.assertTrue("Previous Pay Period is not available", false);
				} else {
					selectValueFromComboBox(payPeriodComboBox, 0);
				}
				break;
			case "CURRENT":
				selectValueFromComboBox(payPeriodComboBox, 1);
				break;
			case "NEXT":
				selectValueFromComboBox(payPeriodComboBox, 2);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	public void verifyPayPeriodDropdown(){
		try{
			//verify drop down size
			List<WebElement> values=getValuesOfComboBox(payPeriodComboBox);
			if(values.size()==3){
				Assert.assertTrue("Verification of Pay Periods in Drop Down", true);
				Assert.assertTrue("Verification of Default Selection of Pay Period - Current"+values.get(1).getText(),values.get(1).getText().contentEquals(txtBox_selectedPayPeriod.getText()));
			}else if(values.size()==2){
				
			}else{
				Assert.assertTrue("Verification of Pay Periods in Drop Down", false);
			}
			values.get(1).click();			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void verifyPayPeriodDates(){
		try{
			//Verify pay period dates
			waitABit(3000);
			String tempTcDate="";
			String tcDate="";
			String selectedPeriod=txtBox_selectedPayPeriod.getText();
			String[] spltPayPeriod=selectedPeriod.split(" ");
			List<WebElement> tcDayBlocks=getTimecardBlocks();
			tempTcDate=tcDayBlocks.get(0).findElement(By.xpath(tcGridDate)).getText().trim();
			if(tempTcDate.length()>2){
				tcDate=tempTcDate.substring(4);
			}else{
				tcDate=tempTcDate;
			}
			System.out.println(spltPayPeriod[1].trim());
			Assert.assertTrue("Verification of Pay Period Start Date "+tcDate, tcDate.contentEquals(spltPayPeriod[1].trim()));
			tempTcDate=tcDayBlocks.get(tcDayBlocks.size()-1).findElement(By.xpath(tcGridDate)).getText().trim();
			if(tempTcDate.trim().length()>2){
				tcDate=tempTcDate.substring(4).trim();
			}else{
				tcDate=tempTcDate.trim();
			}
			Assert.assertTrue("Verification of Pay Period End Date "+tcDate, tcDate.contentEquals(spltPayPeriod[spltPayPeriod.length-1].trim()));
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void verifyPayPeriodDatesTimeSummaryTile(String payPeriodType) {
		try{
		if (payPeriodType.contentEquals(""))
			return;
		String selectedPeriod = txtBox_selectedPayPeriod.getText();
		String tempActPayPeriod = "";
		switch (payPeriodType.toUpperCase()) {
		case "WEEKLY":
			tempActPayPeriod = lbl_week1TimeSummary.getText().trim();
			tempActPayPeriod = tempActPayPeriod.replace("WEEK 1", "").trim();
			tempActPayPeriod = tempActPayPeriod.replace("(", "");
			tempActPayPeriod = tempActPayPeriod.replace(")", "").trim();
			Assert.assertTrue("Verification of Pay Period on Time Summary - Actual:" + tempActPayPeriod + ", Expected: "
					+ selectedPeriod, selectedPeriod.contentEquals(tempActPayPeriod));
			break;
		case "BIWEEKLY":
			String wk1PayPeriod=lbl_week1TimeSummary.getText().trim();
			wk1PayPeriod=wk1PayPeriod.replace("WEEK 1", "").trim();
			wk1PayPeriod=wk1PayPeriod.replace(")", "").trim();
			wk1PayPeriod=wk1PayPeriod.replace("(", "");
			String wk2PayPeriod=lbl_week2TimeSummary.getText().trim();
			wk2PayPeriod=wk2PayPeriod.replace("WEEK 2", "").trim();
			wk2PayPeriod=wk2PayPeriod.replace(")", "").trim();
			wk2PayPeriod=wk2PayPeriod.replace("(", "");
			System.out.println(wk1PayPeriod.split("-")[0]+"-"+wk2PayPeriod.split("-")[1]);
			tempActPayPeriod =wk1PayPeriod.split("-")[0]+"-"+wk2PayPeriod.split("-")[1]; 
			Assert.assertTrue("Verification of Pay Period on Time Summary - Actual:" + tempActPayPeriod + ", Expected: "
					+ selectedPeriod, selectedPeriod.contentEquals(tempActPayPeriod));
			break;
		case "SEMIMONTHLY":
			break;
		case "MONTHLY":
			break;
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		}

	public List<String> getTimepairsOfDayOnTimecard(String strDate) {
		List<String> tPairs = new ArrayList<String>();
		WebElement tcDayBlock = findTimecardBlock(strDate);
		List<WebElement> timePairsStartTime = tcDayBlock.findElements(By.xpath(".//div[contains(@class,'timecard-time-entries')]/div[@class='start ']"));
		List<WebElement> timePairsEndTime = tcDayBlock.findElements(By.xpath(".//div[contains(@class,'timecard-time-entries')]/div[@class='end ']"));
		for (int i = 0; i < timePairsStartTime.size(); i++) {
			System.out.println(timePairsStartTime.get(i).getText().trim().replace("\r\n", " ").replace("\n", " "));
			scrollIntoView(timePairsStartTime.get(i));
			tPairs.add((timePairsStartTime.get(i).getText().trim()).toString()+" - "+(timePairsEndTime.get(i).getText().trim()).toString());
		}

		return tPairs;
	}	
	
//	public List<WebElement> navigateToEnterTimePair(String strDate) {
//		List<WebElement> timePairCards = null;
//		try {
//			if (!strDate.contentEquals("")) {
//				waitForElementToLoad(timecardCurrentDay);
//				WebElement tcDayBlock = findTimecardBlock(strDate);
//
//				if (tcDayBlock.findElements(By.xpath(".//span[@class='fa fa-plus-circle']")).size() != 0) {
//					tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-plus-circle']")).click();
//					timePairCards = getTimePairCards();
//					Assert.assertTrue((timePairCards.size() == 1));
//				} else if (tcDayBlock.findElements(By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']"))
//						.size() != 0) {
//					tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']")).click();
//					timePairCards = getTimePairCards();
//					Assert.assertTrue((timePairCards.size() >= 1));
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return timePairCards;
//	}
	
	public void clickButtonAddTimePair(String btnName) {
		if (btnName.contentEquals(""))
			return;
		switch (btnName.toUpperCase().trim()) {
		case "SAVE":
			waitABit(5000);
			scrollIntoView(btn_enterTimePairSave);
			btn_enterTimePairSave.click();
			waitABit(5000);
			break;
		case "CANCEL":
			btn_addTimePairCancel.click();
			waitABit(5000);
			break;
		case "BACK TO TIMECARD":
			lnk_backToTimecard.click();
			waitABit(5000);
			break;
		case "ADD TIME":
			btn_addTimePairAddTime.click();
			waitABit(5000);
			break;
		case "PREVIOUS DAY":
			lnk_nextDay.waitUntilClickable();
			lnk_previousDay.click();
			waitABit(3000);
			break;
		case "NEXT DAY":
			lnk_nextDay.waitUntilClickable();
			lnk_nextDay.click();
			waitABit(3000);
			break;
		}
	}
	
	public void submitTimePair(String punchType, String findInPunch, String inPunch, String outPunch) {
		if (punchType.contentEquals(""))
			return;
		switch (punchType.toUpperCase().trim()) {
		case "ADD PUNCH":
			enterTimePunches(inPunchTextBox, inPunch);
			enterTimePunches(outPunchTextBox, outPunch);
			break;
		case "RESOLVE PUNCH":
			resolveMissedPunch(inPunchTextBox, outPunchTextBox, inPunch, outPunch);
			break;
		case "DELETE PUNCH":
			employeeDeletesTimePair(inPunch, outPunch);
			break;
		case "EDIT PUNCH":
			employeeEditsTimePair(findInPunch, inPunch, outPunch);
		}
	}

	public void employeeSubmitHours(String addType, String findHours, String hours) {
		if (addType.contentEquals(""))
			return;
		switch (addType.toUpperCase().trim()) {
		case "ADD HOURS":
			enterHours(hoursTextBox, hours);
			break;
		case "DELETE HOURS":
			employeeDeletesHours(findHours);
			break;
		case "EDIT HOURS":
			employeeEditsHours(findHours, hours);
			break;
		}
	}
	
	public void enterHours(String by, String hours) {
		if (hours.contentEquals(""))
			return;
		boolean found = false;
		List<WebElement> objPunch = getDriver().findElements(By.xpath(by));
		for (WebElement objP : objPunch) {
			System.out.println(objP.getAttribute("value"));
			if (objP.getAttribute("value").contentEquals("")) {
				objP.sendKeys(hours, Keys.TAB);
				found = true;
				break;
			}
		}
		if (!found) {
			btn_enterTimePairAddHours.click();
			objPunch = getDriver().findElements(By.xpath(by));
			for (WebElement objIn : objPunch) {
				if (objIn.getAttribute("value").contentEquals("")) {
					objIn.sendKeys(hours, Keys.TAB);
					found = true;
					break;
				}
			}
		}
	}
	
	public void employeeDeletesHours(String findHours) {
		if (findHours.contentEquals(""))
			return;
		List<WebElement> timePairCards = getTimePairCards();
		WebElement objHours = null;
		for (WebElement timePair : timePairCards) {
			objHours = timePair.findElement(By.xpath(hoursTextBox));
			System.out.println(objHours.getAttribute("value").trim());
			if (objHours.getAttribute("value").trim().contentEquals(findHours)) {
				timePair.findElement(By.xpath(deletePair)).click();
				clickButtonOnPopup("Yes");
				Assert.assertTrue("Verification of Hours deletion is Successful", true);
				break;
			}
		}
	}
	
	public void employeeEditsHours(String findHours, String hours) {
		if (findHours.contentEquals(""))
			return;
		WaitForPageLoad();
		boolean inFound = false;
		List<WebElement> timePairCards = getTimePairCards();
		WebElement objHours = null;
		for (WebElement timePair : timePairCards) {
			objHours = timePair.findElement(By.xpath(hoursTextBox));
			System.out.println(objHours.getAttribute("value").trim());
			if (objHours.getAttribute("value").trim().contentEquals(findHours)) {
				inFound = true;
				if (!hours.contentEquals("")) {
					String selctAll = Keys.chord(Keys.CONTROL, "a");
					objHours.sendKeys(selctAll);
					objHours.sendKeys(Keys.BACK_SPACE);
					objHours.sendKeys(hours, Keys.TAB);
				}
				break;
			}
		}
		if (!inFound) {
			Assert.assertTrue("No Time Entry found with Hours-" + findHours, false);
		}
	}
	
	public void employeeEditsTimePair(String findInPunch, String inPunch, String outPunch) {
		if (findInPunch.contentEquals(""))
			return;
		WaitForPageLoad();
		boolean inFound = false;
		int index = 0;
		List<WebElement> objInPunch = getDriver().findElements(By.xpath(inPunchTextBox));
		for (WebElement objP : objInPunch) {
			System.out.println(objP.getAttribute("value"));
			if (objP.getAttribute("value").contentEquals(findInPunch)) {
				index = objInPunch.indexOf(objP);
				inFound = true;
				if (!inPunch.contentEquals("")) {
					waitForWebElementToLoad(objP);
					String selctAll = Keys.chord(Keys.CONTROL, "a");
					objP.sendKeys(selctAll);
					objP.sendKeys(Keys.BACK_SPACE);
					objP.sendKeys(inPunch, Keys.ENTER);
				}
				break;
			}
		}
		if (!inFound) {
			Assert.fail("No Time Entry found with In Punch-" + inPunch);
		}
		if (outPunch.contentEquals(""))
			return;
		List<WebElement> objOutPunch = getDriver().findElements(By.xpath(outPunchTextBox));
		String selctAll = Keys.chord(Keys.CONTROL, "a");
		objOutPunch.get(index).sendKeys(selctAll);
		objOutPunch.get(index).sendKeys(Keys.BACK_SPACE);
		objOutPunch.get(index).sendKeys(outPunch, Keys.TAB);
		waitABit(3000);
	}

	public void employeeDeletesTimePair(String inPunch, String outPunch) {
		if (inPunch.contentEquals(""))
			return;
		List<WebElement> timePairCards = getTimePairCards();
		WebElement objInPunch = null;
		WebElement objOutPunch = null;
		for (WebElement timePair : timePairCards) {
			objInPunch = timePair.findElement(By.xpath(inPunchTextBox));
			objOutPunch = timePair.findElement(By.xpath(outPunchTextBox));
			System.out.println(objInPunch.getAttribute("value").trim());
			System.out.println(objOutPunch.getAttribute("value").trim());
			if (objInPunch.getAttribute("value").trim().contentEquals(inPunch)
					&& objOutPunch.getAttribute("value").trim().contentEquals(outPunch)) {
				scrollIntoView(timePair.findElement(By.xpath(deletePair)));
				timePair.findElement(By.xpath(deletePair)).click();
				//clickButtonOnPopup("Yes");
				btn_deleteYes.click();
				break;
			}
		}
	}
	
	public void resolveMissedPunch(String inPunchBy, String outPunchBy, String inPunch, String outPunch) {
		if (outPunch.contentEquals(""))
			return;
		boolean inFound = true;
		List<WebElement> pairCards = getTimePairCards();
		for (WebElement pairCard : pairCards) {
			WebElement objInPunch = pairCard.findElement(By.xpath(inPunchBy));
			System.out.println(objInPunch.getAttribute("value"));
			if (objInPunch.getAttribute("value").contentEquals(inPunch)) {
				inFound = true;
				WebElement objOutPunch = pairCard.findElement(By.xpath(outPunchBy));
				if (objOutPunch.isDisplayed()) {
					objOutPunch.sendKeys(outPunch, Keys.TAB);
					break;
				}
			}
		}
		if (!inFound) {
			Assert.fail("No Time Entry found with In Punch-" + inPunch);
		}
	}	
	
	public void AddEditNotesToHours(String findHours, String noteType, String noteText) {
		if (findHours.contentEquals("") && noteType.contentEquals(""))
			return;

		WebElement timePairCard = findTimePairCard(findHours);
		switch (noteType.toUpperCase()) {
		case "ADD":
			WebElement objAddNote = timePairCard.findElement(addNote);
			objAddNote.click();
			WebElement objenterNote = timePairCard.findElement(enterNote);
			enterNoteTextToTimePair(objenterNote, noteText);
			break;
		case "EDIT":
			WebElement objEnterNote = timePairCard.findElement(enterNote);
			enterNoteTextToTimePair(objEnterNote, noteText);
			break;
		// case "REMOVE NOTE":
		// WebElement objEnterNote = timePairCard.findElement(enterNote);
		// enterNoteTextToTimePair(objEnterNote, NoteText);
		// break;
		}
	}
	
	public void AddEditNotesToTimePair(String inPunch, String outPunch, String instance, String noteType,
			String NoteText) {
		if (inPunch.contentEquals("") && noteType.contentEquals(""))
			return;
		WebElement timePairCard = findTimePairCard(inPunch, outPunch, instance);
		switch (noteType.toUpperCase()) {
		case "ADD NOTE":
			WebElement objAddNote = timePairCard.findElement(addNote);
			objAddNote.click();
			WebElement objenterNote = timePairCard.findElement(enterNote);
			enterNoteTextToTimePair(objenterNote, NoteText);
			break;
		case "EDIT NOTE":
			WebElement objEnterNote = timePairCard.findElement(enterNote);
			enterNoteTextToTimePair(objEnterNote, NoteText);
			break;
		// case "REMOVE NOTE":
		// WebElement objEnterNote = timePairCard.findElement(enterNote);
		// enterNoteTextToTimePair(objEnterNote, NoteText);
		// break;
		}

	}
	
	public void enterNoteTextToTimePair(WebElement objNoteText, String noteText) {
		waitABit(2000);
		objNoteText.clear();
		waitABit(2000);
		objNoteText.sendKeys(noteText);
	}
	
	public WebElement findTimePairCard(String findHours) {
		WebElement objCard = null;
		if (findHours.contentEquals(""))
			return null;
		boolean hFound = false;
		List<WebElement> timePairs = getTimePairCards();
		WebElement objHours = null;
		for (WebElement timePair : timePairs) {
			objHours = timePair.findElement(By.xpath(hoursTextBox));
			System.out.println(objHours.getAttribute("value").trim());
			if (objHours.getAttribute("value").trim().contentEquals(findHours)) {
				objCard = timePair;
				hFound = true;
				break;
			}
		}
		if (!hFound) {
			Assert.assertTrue("No Entry found with Hours-" + findHours, false);
		}
		return objCard;
	}
	
	public WebElement findTimePairCard(String inPunch, String outPunch, String instance) {
		WebElement objCard = null;
		if (inPunch.contentEquals("") && instance.contentEquals(""))
			return null;
		List<WebElement> timePairs = getTimePairCards();
		WebElement objInPunch = null;
		WebElement objOutPunch = null;
		if (!instance.contentEquals("")) {
			int cardInstance = Integer.parseInt(instance);
			objCard = timePairs.get(cardInstance);
			if (objCard == null) {
				Assert.assertTrue("Time Pair not found with given instance", false);
			}
		} else {
			for (WebElement timePair : timePairs) {
				objInPunch = timePair.findElement(By.xpath(inPunchTextBox));
				objOutPunch = timePair.findElement(By.xpath(outPunchTextBox));
				System.out.println(objInPunch.getAttribute("value").trim());
				System.out.println(objOutPunch.getAttribute("value").trim());
				if (objInPunch.getAttribute("value").trim().contentEquals(inPunch)
						&& objOutPunch.getAttribute("value").trim().contentEquals(outPunch)) {
					objCard = timePair;
					break;
				}
			}
		}
		return objCard;
	}

	String dayTimecardGrid=".//div[contains(@class,'ug-day')]";
By timePeriodComboBox=By.xpath("//div[contains(@class,'tc-time-period-list')]/div[contains(@class,'-container')]");

	public WebElement getCrntPrevDayTimecardGrid(String strDate) {
		WebElement objDay = null;
		if (strDate.contentEquals(""))
			return null;
		boolean dFound = false;

		List<WebElement> lsDays = getTimecardBlocks();
		if (!lsDays.isEmpty()) {
			for (int i = 0; i < lsDays.size(); i++) {
				if (lsDays.get(i).findElement(By.xpath(dayTimecardGrid)).getText().contentEquals(strDate)) {
					dFound = true;
					objDay = lsDays.get(i);
					break;
				}
			}
			if (!dFound) {
				selectValueFromComboBox(timePeriodComboBox, 0);
				lsDays = getTimecardBlocks();
				if (!lsDays.isEmpty()) {
					for (int i = 0; i < lsDays.size(); i++) {
						if (lsDays.get(i).findElement(By.xpath(dayTimecardGrid)).getText().contentEquals(strDate)) {
							dFound = true;
							objDay = lsDays.get(i).findElement(By.xpath(dayTimecardGrid));
							break;
						}
					}
				}
			}
		}

		return objDay;
	}

	public void verifyExceptionIndicatorsTimecardGrid(String strDate,String status) {
		List<WebElement> objHighlight = null;
		boolean statusFlag=true;
		WebElement objDay = getCrntPrevDayTimecardGrid(strDate);
		if(status.toUpperCase().contentEquals("EXISTS"))statusFlag=false;
		else if(status.toUpperCase().contentEquals("DOESNOTEXIST"))statusFlag=true;
		// Verify hours - red color
		objHighlight = objDay.findElements(
				By.xpath(".//div[contains(@class,'timecard-total-period') and contains(@class,'tc-red-flag')]"));
		if (objHighlight.isEmpty()) {
			Assert.assertTrue("Verification of Missed Punch Excpetion on Timecard - Highlight of Hours", statusFlag);
		}
		objHighlight = objDay.findElements(
				By.xpath(".//span[contains(@class,'fa-exclamation-circle') and contains(@class,'tc-red-flag')]"));
		if (objHighlight.isEmpty()) {
			Assert.assertTrue("Verification of Missed Punch Excpetion on Timecard - Red Exclamatory Mark", statusFlag);
		}
	}
	
	public void verifyExceptionIndicatorTimePair(String inPunch, String outPunch, String strField, String instance,String status) {
		if (strField.contentEquals(""))
			return;
		boolean tcFound=false;
		if(status.toUpperCase().contentEquals("EXISTS"))tcFound=false;
		else if(status.toUpperCase().contentEquals("DOESNOTEXIST"))tcFound=true;
		List<WebElement> objHighlight = null;
		WebElement timePair = findTimePairCard(inPunch, outPunch, instance);
		switch (strField.toUpperCase()) {
		case "IN PUNCH":
			objHighlight = timePair.findElements(By.xpath(inPunchBox));
			Assert.assertTrue("Missed In Punch field Indicator Verification", objHighlight.isEmpty()==tcFound);
			break;
		case "OUT PUNCH":
			objHighlight = timePair.findElements(By.xpath(outPunchBox));
			Assert.assertTrue("Missed Out Punch field Indicator Verification", objHighlight.isEmpty()==tcFound);
			break;
		}
	}
	
	public void enterTimePunches(String by, String Punch) {
		// if(Punch.contentEquals("")) return;
		boolean found = false;
		List<WebElement> objPunch = getDriver().findElements(By.xpath(by));
		for (WebElement objP : objPunch) {
			System.out.println(objP.getAttribute("value"));
			if (objP.getAttribute("value").contentEquals("")) {
				objP.sendKeys(Punch, Keys.TAB);
				found = true;
				break;
			}
		}
		if (!found) {
			scrollIntoView(btn_enterTimePairAddPunch);
			btn_enterTimePairAddPunch.click();
			objPunch = getDriver().findElements(By.xpath(by));
			for (WebElement objIn : objPunch) {
				if (objIn.getAttribute("value").contentEquals("")) {
					objIn.sendKeys(Punch, Keys.TAB);
					found = true;
					break;
				}
			}
		}
	}
	
	public List<WebElement> getTimecardBlocks() {
		List<WebElement> tcDayCards = null;
		tcDayCards = getDriver().findElements(By.xpath("//div[contains(@class,'ug-cell ug-cell--4')]"));
		if (tcDayCards.isEmpty()) {
			Assert.assertTrue("No Timecard displayed on Your Timecard Page", false);
		}
		return tcDayCards;
	}
	
	public void verifyDaysYourTimecardPage(String noOfDays) {
		List<WebElement> tcDays = getTimecardBlocks();
		Assert.assertTrue("Verification of Time Period on Timecard", tcDays.size() == Integer.parseInt(noOfDays));

	}
	
	public void verifyNoteAvailabilityOnTimecardGrid(String strDate, String noteStatus) {
		WaitForPageLoad();
		List<WebElement> objWithNotes = null;
		WebElement tcDay = findTimecardBlock(strDate);
		if (noteStatus.toUpperCase().contentEquals("NO")) {
			objWithNotes = tcDay.findElements(By.xpath(".//span[@class='fa tc-day-entry-icon fa-comment-o']"));
			Assert.assertTrue("Verification of Notes not exists on Timecard Grid", !objWithNotes.isEmpty());
		} else if (noteStatus.toUpperCase().contentEquals("YES")) {
			objWithNotes = tcDay.findElements(By.xpath(".//span[contains(@class,'fa tc-day-entry-icon fa-comment')]"));
			Assert.assertTrue("Verification of Notes exists on Timecard Grid", !objWithNotes.isEmpty());
		}
	}
	
	public void verifyTotalHrsOnTimecardGrid(String strDate, String totalHrs) {
	WaitForPageLoad();
		WebElement tcDay = findTimecardBlock(strDate);
		if (totalHrs.contentEquals(""))
			return;
		//scrollIntoView(tcDay.findElement(By.xpath(".//div[contains(@class,'timecard-total-period')]")));
		String actHrs = tcDay.findElement(By.xpath(".//div[contains(@class,'timecard-total-period')]")).getText();
		Assert.assertTrue("Verification of Total Hours on Timecard Grid", actHrs.contentEquals(totalHrs));
	}
	
	public void verifyPunchTextOnTimecardGrid(String timePairDate, String Punch) {
		WaitForPageLoad();
			WebElement tcDay = findTimecardBlock(timePairDate);
			String text = null;
			if (Punch.contentEquals(""))
				return;
			//scrollIntoView(tcDay.findElement(By.xpath(".//div[contains(@class,'timecard-total-period')]")));
			if(Punch.contentEquals("Clocked In"))
			{			
			text = tcDay.findElement(By.xpath(".//div[contains(@class,'timecard-clocked-in-label')]")).getText();
			Assert.assertTrue("Verification of Clocked In text on Timecard Grid", text.contentEquals(Punch));
			}
			else if (Punch.contentEquals("Clocked Out"))
			{
				Assert.assertEquals("Verifying clock out", true, checkElementVisible(btn_MissingOutPunch));
			}
			
		}

	public void verifyTimecardPermissions(String timecardStatus) {
		WaitForPageLoad();
		List<WebElement> objAddEdit = getDriver().findElements(By.xpath(
				".//span[contains(@class,'fa fa-pencil tc-day-entry-icon') or contains(@class,'fa fa-plus-circle')]"));
		switch (timecardStatus.toUpperCase()) {
		case "EDIT":
			Assert.assertTrue("Verification of Timecard Status - View/Edit", !objAddEdit.isEmpty());
			break;
		case "VIEW":
			Assert.assertTrue("Verification of Timecard Status - View/Edit", objAddEdit.isEmpty());
			break;
		}
	}
	
	public void verifyStatusofSaveButton(String buttonStatus) {
		if (buttonStatus.contentEquals(""))
			return;
		if (buttonStatus.toUpperCase().contentEquals("ENABLED")) {
			Assert.assertTrue("Verification of Save button status - Enabled", btn_enterTimePairSave.isDisplayed());
		} else if (buttonStatus.toUpperCase().contentEquals("DISABLED")) {
			Assert.assertTrue("Verification of Save button status - Disabled",
					btn_enterTimePairSaveDisabled.isDisplayed());
		}
	}
	
	public String calculateTotalHours() {
		int Hr = 0;
		String calTotalHr = "";
		List<WebElement> timeDays = getDriver()
				.findElements(By.xpath(".//div[contains(@class,'timecard-total-period')]"));
		if (!timeDays.isEmpty()) {
			for (WebElement time : timeDays) {
				String[] arr = time.getText().trim().split(":");
				Hr += 60 * Integer.parseInt(arr[0]);
				Hr += Integer.parseInt(arr[1]);
			}
			long hh = Hr / 60;
			Hr %= 60;
			calTotalHr = hh + ":" + format(Hr);
		} else {
			calTotalHr = "0:00";
		}
		return calTotalHr;
	}
	
	public void verifyHoursTotalTime() {
		String actTotalHr = lbl_totalPeriodHour.getText().trim();
		String calTotalHr = calculateTotalHours();
		Assert.assertTrue(
				"Verification of Total Hours on Total Time Tile-Actual: " + actTotalHr + " Expected: " + calTotalHr,
				actTotalHr.contentEquals(calTotalHr));
	}
	
	private static String format(long s) {
		if (s < 10)
			return "0" + s;
		else
			return "" + s;
	}

	public WebElement findTimecardBlock(String strDate) {
		WebElement timcardDayBlock = null;
		int actDate;
		String crntActDate = "";
		String newStr = "";
		boolean tcFound=false;
		List<WebElement> tcDayCards = getTimecardBlocks();
		if (!tcDayCards.isEmpty()) {
			for (WebElement tcDay : tcDayCards) {
				crntActDate = tcDay.findElement(By.xpath(tcGridDate)).getText();
				if (crntActDate.length() > 2) {
					newStr = crntActDate.substring(4, crntActDate.length()).trim();
					actDate = Integer.parseInt(newStr);
				} else {
					actDate = Integer.parseInt(tcDay.findElement(By.xpath(tcGridDate)).getText());
				}
				if (actDate == Integer.parseInt(strDate)) {
					timcardDayBlock = tcDay;
					tcFound=true;
					break;
				}
			}
			if(!tcFound){
				Assert.assertTrue("Given Timepair/Hour Date not found on Timecard",false);
			}
		}
		return timcardDayBlock;
	}

	public void verifyClockStatusTimecardGrid(String strDate, String inTime, String ClockStatus) {
		WebElement objDay = findTimecardBlock(strDate);
		List<WebElement> lsClockStatus = objDay.findElements(clockStatus);
		Assert.assertTrue("Verification of Clocked In label on Timecard Grid", lsClockStatus.size() == 1);
		lsClockStatus.clear();
		if (!inTime.contentEquals(""))
			Assert.assertTrue("Verification of Clocked In time on Timecard Grid",
					objDay.findElement(clockInTime).getText().trim().contentEquals(inTime));
	}
	
	public void verifyViewYourTimecard() {
		try {
			if(!checkElementVisible(btn_viewYourTimecard)) waitABit(3000);
			Assert.assertTrue("View Your Timecard Link is displayed", checkElementVisible(btn_viewYourTimecard));
			btn_viewYourTimecard.click();
			if(!checkElementVisible(lbl_yourTimecard)) waitABit(3000);
			Assert.assertTrue("Your Timecard page is displayed", checkElementVisible(lbl_yourTimecard));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyTilesonTimecardPage(String tileName) {
		if (tileName.contentEquals(""))
			return;
		switch (tileName.toUpperCase().trim()) {
		case "TOTAL TIME":
			verifyTotalTime();
			break;
		case "TIME SUMMARY":
			verifyTimeSummary();
			break;
		case "PAY SUMMARY":
			verifyPaySummary();
			break;
		case "TIMECARD GRID":
			verifyTimecard();
			break;
		}
	}

	public void verifyTotalTime() {
		if (!checkElementVisible(lbl_totalPeriodHour))
			waitABit(3000);
		lbl_totalPeriodHour.shouldBeVisible();
	}

	public void verifyContentsTimeSummary(String regular, String overtime) {
		// waitForElementToLoad(timeSummaryRegular);
		if (checkElementVisible(lblVal_timeSummaryWeek2Regular)) {
			Assert.assertTrue("Verification of Regular Hours",
					lblVal_timeSummaryWeek1Regular.getText().contains(regular)
							|| lblVal_timeSummaryWeek2Regular.getText().contains(regular));
			Assert.assertTrue("Verification of Overtime Hours",
					lblVal_timeSummaryWeek1Overtime.getText().contains(overtime)
							|| lblVal_timeSummaryWeek2Overtime.getText().contains(overtime));
		} else if (checkElementVisible(lblVal_timeSummaryRegular)) {
			Assert.assertTrue("Verification of Regular Hours",
					lblVal_timeSummaryWeek1Regular.getText().contentEquals(regular));
			Assert.assertTrue("Verification of Regular Hours",
					lblVal_timeSummaryWeek1Overtime.getText().contentEquals(overtime));
		}
	}
	
	public void verifyContentPaySummary(String grossPay, String deductions, String taxes, String netPay) {
		if (!checkElementVisible(enabledRequestPay))
			waitABit(10000);
		waitForLoadingSpinnerToComplete();
		if (!grossPay.contentEquals(""))
			Assert.assertTrue("Verification of Gross Pay on Pay Summary Tile",
					lblVal_paySummaryGrossPay.getText().contentEquals(grossPay));
		if (!deductions.contentEquals(""))
			Assert.assertTrue("Verification of Deductions on Pay Summary Tile",
					lblVal_paySummaryDeductions.getText().contentEquals(deductions));
		if (!taxes.contentEquals(""))
			Assert.assertTrue("Verification of Taxes on Pay Summary Tile",
					lblVal_paySummaryTaxes.getText().contentEquals(taxes));
		if (!netPay.contentEquals(""))
			Assert.assertTrue("Verification of Net Pay on Pay Summary Tile",
					lblVal_paySummaryNetPay.getText().contentEquals(netPay));
	}
	
	public void verifyTimeSummary() {
		if (!checkElementVisible(lblVal_timeSummaryWeek1Regular))
			waitABit(5000);
			lblVal_timeSummaryWeek1Regular.waitUntilVisible().shouldBeVisible();
	}

	public void verifyPaySummary() {
		try {
			waitForLoadingSpinnerToComplete();
//			if(!checkElementVisible(enabledRequestPay))
//			waitABit(5000);
//			sft.assertThat(checkElementVisible(lblVal_paySummaryGrossPay)).as("Verification of Grid").isEqualTo(true);
			//sft.assertEquals("Sample", "Failed");
			Assert.assertTrue("Pay Summary Tile - Grid is displayed", checkElementVisible(lblVal_paySummaryGrossPay));
			imgIcon_paySummaryPieChart.click();
			if(!checkElementVisible(paySummaryPieChart))
			waitABit(5000);
/*			sft.assertThat(checkElementVisible(paySummaryPieChart)).as("Verification of Pie Chart").isEqualTo(true);
*/			
			Assert.assertTrue("Pay Summary Tile - Pie Chart is displayed", checkElementVisible(paySummaryPieChart));
			imgIcon_paySummaryGrid.click();
/*			sft.assertThat(checkElementVisible(paySummaryGrossPay)).as("Verification of Grid").isEqualTo(true);
 * 
 */
			Assert.assertTrue("Pay Summary Tile - Grid is displayed", checkElementVisible(lblVal_paySummaryGrossPay));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyTimecard() {
		try {
			if(!checkElementVisible(lbl_timecardCurrentDay))
			waitABit(5000);			
			Assert.assertTrue("Timecard Grid is displayed", checkElementVisible(lbl_timecardCurrentDay));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyteamdashboardpage() {
		try {
			WaitForPageLoad();
			Assert.assertTrue(checkElementVisible(lbl_missedPunches));
			Assert.assertTrue(checkElementVisible(lbl_whoisin));
			Assert.assertTrue(checkElementVisible(lbl_hitOvertime));
			Assert.assertTrue(checkElementVisible(lbl_approved));
			Assert.assertTrue(checkElementVisible(lbl_timeOffThisWeekTitle));
			Assert.assertTrue(checkElementVisible(migIcon_whoIsInMap));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void verifyNavigationMissedPunchesSlider() {
		try {
			WaitForPageLoad();
			if(checkElementVisible(lbl_missedPunches)){
				lbl_missedPunches.click();
				Assert.assertTrue("Verify Page Loading of - Missed Punches",checkElementVisible(lbl_notesHeaderMissedPunches));
				waitABit(3000);
				btn_backTTDSliders.click();
				if(!checkElementVisible(lnk_otherActionsSchedules))waitABit(3000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void verifyNavigationShiftSwapRequestSlider() {
		try {
			WaitForPageLoad();
			if(checkElementVisible(lbl_shiftSwapRequests)){
				lbl_shiftSwapRequests.click();
				Assert.assertTrue("Verify Page Loading of - Shift Swap Requests",checkElementVisible(btn_shiftSwapRequestsPendingApproval));
				if(!checkElementVisible(btn_backTTDSliders))waitABit(3000);
				waitABit(3000);
				btn_backTTDSliders.click();
				if(!checkElementVisible(lnk_otherActionsSchedules))waitABit(3000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void verifyNavigationTimecardApprovalSlider() {
		try {
			WaitForPageLoad();
			if(checkElementVisible(lbl_timecardApprovals)){
				lbl_timecardApprovals.click();
				Assert.assertTrue("Verify Page Loading of - Missed Punches",checkElementVisible(lbl_timecardApprovalWelcomeText));
				if(!checkElementVisible(btn_backTTDSliders))waitABit(3000);
				waitABit(3000);
				btn_backTTDSliders.click();
				if(!checkElementVisible(lnk_otherActionsSchedules))waitABit(3000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	By scheudleFrame=By.xpath("//iframe[@class]");
	public void clickOtherActionsLink(String linkName) {
		try {
			if(linkName.contentEquals("")) return;
			WaitForPageLoad();
			switch(linkName.toUpperCase().trim()){
			case "SCHEDULES":
				lnk_menuHome.click();
				waitForElementToLoad(lnk_otherActionsSchedules);
				Assert.assertTrue("Verify Other Action Link - Schedules", checkElementVisible(lnk_otherActionsSchedules));
				lnk_otherActionsSchedules.click();
				waitABit(3000);
				selectFrame(getDriver().findElement(By.xpath("//iframe[@class]")));
				waitForElementToLoad(btn_schedulesPublish);
				Assert.assertTrue("Verify Navigation to Schedules Page", checkElementVisible(btn_schedulesPublish));
				switchToDefaultContent();
				break;
			case "INDIVIDUAL TIMECARD":	
				lnk_menuHome.click();
				waitForElementToLoad(lnk_otherActionsindividualTimecard);
				Assert.assertTrue("Verify Other Action Link - Individual Timecard", checkElementVisible(lnk_otherActionsindividualTimecard));
				lnk_otherActionsindividualTimecard.click();
				break;
			case "TIMECARD EXCEPTIONS":	
				lnk_menuHome.click();
				waitForElementToLoad(lnk_otherActionsTimecardExceptions);
				Assert.assertTrue("Verify Other Action Link - Timecard Exceptions", checkElementVisible(lnk_otherActionsTimecardExceptions));
				lnk_otherActionsTimecardExceptions.click();
				break;
			case "REPORTS":	
				lnk_menuHome.click();
				waitForElementToLoad(lnk_otherActionsReports);
				Assert.assertTrue("Verify Other Action Link - Reports", checkElementVisible(lnk_otherActionsReports));
				lnk_otherActionsReports.click();
				break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void submitRequestPay() {
		try {
			waitForElementToLoad(btn_requestPay);
			Assert.assertTrue(checkElementVisible(btn_requestPay));
			btn_requestPay.click();
			waitForElementToLoad(btn_payRequested);
			Assert.assertTrue(checkElementVisible(btn_payRequested));
			Assert.assertTrue(checkElementVisible(lbl_payRequestSubmitted));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public void verifyHomePagePortlets() {
		waitABit(5000);
		WaitForPageLoad();
		Assert.assertEquals("Verifying clockin", true, checkElementVisible(btn_clockIN));
		Assert.assertEquals("Verifying transfer", true, checkElementVisible(btn_transfer));
	}

	public void verifyPayrollSchedulePageLoading() {
		waitABit(10000);
		lbl_payrollSchedulePageLoad.waitUntilPresent().shouldBeCurrentlyVisible();
		WaitForPageLoad();
		Assert.assertEquals("Verifying payroll schedule page load", true, checkElementVisible(lbl_payrollSchedulePageLoad));
	}

	public void verifyPayrollDashboardPageLoading() {
		waitABit(5000);
		WaitForPageLoad();
		Assert.assertEquals("Verifying payroll dashboard page load", true,
				checkElementVisible(lbl_payrollDashboardPageLoad));
	}

	public void verifyPayrollWorksheetFromDashboard() {
		lnk_menuLinkInPayrollDashboard.click();
		waitABit(2000);
		lnk_payrollWorksheet.click();
		waitABit(5000);
		WaitForPageLoad();
		Assert.assertEquals("Verifying payroll worksheet page load", true,
				checkElementVisible(lbl_payrollWorksheetPageLoad));
	}

	public void verifyPayrollWorksheetPageLoading() {
		waitABit(5000);
		WaitForPageLoad();
		Assert.assertEquals("Verifying payroll worksheet page load", true,
				checkElementVisible(lbl_payrollWorksheetPageLoad));
	}

	public void verifyPolicyManagerPageLoading() {
		waitABit(5000);
		WaitForPageLoad();
		Assert.assertEquals("Verifying policy manager page load", true, checkElementVisible(lbl_policyManagerPageLoad));
	}

	public void verifyEmploymentProfilePageLoading() {
		waitABit(5000);
		btn_timeAttendanceEdit.waitUntilClickable();
		WaitForPageLoad();
		Assert.assertEquals("Verifying policy manager page load", true, checkElementVisible(btn_timeAttendanceEdit));
		//btn_timeAttendanceEdit.click();
		
	}
	
	public void verifyTimeAndAttendanceOptionUnderSetupNew() {
		btn_setupNewPolicy.click();
		WaitForPageLoad();
		Assert.assertEquals("Verifying time and attendance option under setup new", true,
				checkElementVisible(btn_timeandattendanceUnderSetup));
		imgIcon_closeSetupNew.click();
	}

	public void createTimeAndAttendanceRoundingPolicy(String policyname, String roundingtype, String date) {
		btn_setupNewPolicy.click();
		WaitForPageLoad();
		waitABit(2000);
		btn_timeandattendanceOption.click();
		waitABit(2000);
		btn_continueButton.click();
		WaitForPageLoad();
		waitABit(2000);
		chkBox_roundingCheckBox.click();
		waitABit(2000);
		btn_continueButton.click();
		WaitForPageLoad();
		waitABit(2000);
		if(checkElementVisible(btn_iamReadyLetsGetStarted))
		{
			btn_iamReadyLetsGetStarted.click();
		waitABit(2000);
		}
		if(checkElementVisible(btn_createNewRoundingPolicy))
		{
		btn_createNewRoundingPolicy.click();
		waitABit(1000);
		btn_continueButton.click();
		WaitForPageLoad();
		}
		getDriver().findElement(By.xpath("//div[text()='" + roundingtype + "']/..//div[1]")).click();
		btn_roundingPolicycontinueButton.click();
		WaitForPageLoad();
		txtBox_effectiveDate.clear();
		txtBox_effectiveDate.sendKeys(date);
		txtBox_policyName.clear();
		txtBox_policyName.sendKeys(policyname);
		txtBox_shortName.clear();
		txtBox_shortName.sendKeys(policyname);
		waitABit(2000);
		txtBox_shortName.sendKeys(Keys.TAB);
		btn_roundingPolicycontinueButton.click();
		waitABit(2000);
		radioBtn_sameRoundingRule.click();
		waitABit(2000);
		btn_roundingPolicycontinueButton.click();
		waitABit(2000);
		btn_saveButton.click();
		WaitForPageLoad();

	}

	public void deletePolicy(String policyname) {
		if (checkElementVisible(btn_backToPolicyList))
			btn_backToPolicyList.click();
		waitABit(2000);
		getDriver().findElement(By.xpath("//span[text()='" + policyname + "']/../../..//button/span/div")).click();
		getDriver().findElement(By.xpath("//*[@title='Delete']")).click();
		waitABit(2000);
		getDriver().findElement(By.xpath("//span[text()='Close']")).click();
	}

	public void navigateBackToYourTimecard() {
		
		waitABit(2000);
		WaitForPageLoad();
		waitForElementToLoad(lnk_backToTimecard);
		if (checkElementVisible(lnk_backToTimecard))
			lnk_backToTimecard.click();
		waitABit(2000);
	}
	
	public void deleteTimepairsTimecards() {
		// get days with time pair or hours
		waitABit(3000);
		if (!checkElementVisible(lbl_totalPeriodHour))
			waitABit(3000);
		List<WebElement> objDays = getDriver().findElements(By.xpath(
				".//span[@class='fa fa-pencil tc-day-entry-icon']/ancestor::div[contains(@class,'ug-cell ug-cell--4')]"));
		List<WebElement> objDelete = null;
		if (objDays.isEmpty())
			return;
		for (int i = 0;;) {
			objDays = getDriver().findElements(By.xpath(
					".//span[@class='fa fa-pencil tc-day-entry-icon']/ancestor::div[contains(@class,'ug-cell ug-cell--4')]"));
			if (objDays.isEmpty())
				break;
			scrollIntoView(objDays.get(i).findElement(By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']")));
			objDays.get(i).findElement(By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']")).click();
			objDelete = getDriver().findElements(By.xpath(".//span[@class='tc-delete-time-pair-label']"));
			deleteTimePairHour(objDelete);
			waitABit(2000);
			scrollIntoView(lnk_backToTimecard);
			lnk_backToTimecard.click();
			if (!checkElementVisible(imgIcon_paySummaryPieChart))
				waitABit(2000);

		}
	}

	public void deleteTimePairHour(List<WebElement> objDelete) {
		for (int i = objDelete.size() - 1; i >= 0; i--) {
			objDelete.get(0).click();
			if (checkElementVisible(btn_deleteYes)) {
				btn_deleteYes.click();
				waitABit(1000);
				msg_FailedToDelete.shouldNotBeVisible();
			}
		}
	}

	public void verifyTimecardApprovalStatus(String status) {
		boolean taMsgFlag = false, taBtnFlag = false;
		waitABit(3000);
		if (checkElementVisible(lbl_timecardApprovedMsg)) {
			taMsgFlag = true;
		}
		if (checkElementVisible(btn_approveTimecard)) {
			taBtnFlag = true;
		}
		if (status.toUpperCase().contentEquals("APPROVED")) {
			Assert.assertTrue("Verification of Timecard Approval Status" + status, taMsgFlag && !taBtnFlag);
		} else if (status.toUpperCase().contentEquals("NOT APPROVED")) {
			Assert.assertTrue("Verification of Timecard Approval Status" + status, taBtnFlag && !taMsgFlag);
		}
	}

	public void verifyButtonStatusTimecardPage(String btnName, String btnStatus) {
		if (btnName.contentEquals("") || btnStatus.contentEquals(""))
			return;
		switch (btnName.toUpperCase()) {
		case "APPROVE TIMECARD":
			if (btnStatus.toUpperCase().contentEquals("EXISTS")) {
				Assert.assertTrue("Verification of '" + btnName + "' Status", checkElementVisible(btn_approveTimecard));
			} else if (btnStatus.toUpperCase().contentEquals("DOESNOTEXIST")) {
				waitABit(3000);
				Assert.assertTrue("Verification of '" + btnName + "' Status", !checkElementVisible(btn_approveTimecard));
			}
			break;
		}
	}

	public void clickButtonYourTimecard(String btnName) {
		if (btnName.contentEquals(""))
			return;
		switch (btnName.toUpperCase()) {
		case "APPROVE TIMECARD":
			if (!checkElementVisible(btn_approveTimecard)) {
				if (!checkElementVisible(lbl_timecardApprovedMsg)) {
					btn_approveTimecard.click();
				}
			} else {
				btn_approveTimecard.click();
			}
			break;
		}
	}

	public void pauseForSomeTime(String mnts) {
		waitABit(Integer.parseInt(mnts) * 60000);
	}

	public void verifyMealPolicyDeductionOnTimecardGrid(String strDate, String mealdeductionhours) {
		WaitForPageLoad();
		WebElement tcDay = findTimecardBlock(strDate);
		if (!mealdeductionhours.contentEquals("")) {
			scrollIntoView(tcDay.findElement(By.xpath(lbl_mealDeductionHours)));
			String actTxt = tcDay.findElement(By.xpath(lbl_mealDeductionHours)).getText();
			String actualMealDeductionText = actTxt.split("-")[0].trim();
			String actualMealDeductionhours = actTxt.split("-")[1].trim();
			Assert.assertTrue("Verification of meal deduction text", actualMealDeductionText.equals("Meal Deduction"));
			Assert.assertTrue("Verification of meal deduction hours",
					actualMealDeductionhours.equals(mealdeductionhours));
		} else {
			Assert.assertFalse("Meal deduction visibility verification", checkElementVisible(lbl_mealDeductionHours));

		}
	}

	public void verifyTimePairsOnTimecardGrid(String strDate, List<String> timepairs) {

		WaitForPageLoad();
		List<String> objTimePairs = getTimepairsOfDayOnTimecard(strDate);
		Assert.assertTrue("Verification of Time Pairs on Timecard Grid",objTimePairs.equals(timepairs));
	}

	public void selectDayOnTimecardGrid(String strDate, String action) {
		WaitForPageLoad();
		waitABit(3000);
		if (!strDate.contentEquals("")) {
			waitABit(2000);
			WebElement tcDayBlock = getCrntPrevDayTimecardGrid(strDate);
			//tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-plus-circle']")).click();
			scrollIntoView(tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-plus-circle']")));			
			tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-plus-circle']")).click();
		}
	}
	
	public void verifyDataOnAddTimecardPage(String inPunch,String outPunch,String empNote,String supusername,String SupNote) {
		try{
		WebElement timePairCard = findTimePairCard(inPunch, outPunch, "");
		
		String actualInPunch = timePairCard.findElement(By.xpath(inPunchTextBox)).getAttribute("value");
		String actualOutPunch = timePairCard.findElement(By.xpath(outPunchTextBox)).getAttribute("value");
		String actualNote = timePairCard.findElement(enterNote).getText();
		
		Assert.assertEquals("Comparision of in punch ",actualInPunch,inPunch);
		Assert.assertEquals("Comparision of out punch ",actualOutPunch,outPunch);
		Assert.assertEquals("Comparision of note ",actualNote,empNote);
		
		if(checkElementVisible(timePairCard.findElement(By.xpath("(//span[@class='tc-comments-by-name-text'])[1]"))))
		{
			String actualSupUsername =  timePairCard.findElement(By.xpath(txt_supUsername)).getText().trim();
			String actualSupNote = timePairCard.findElement(By.xpath(txt_supNote)).getText().trim();
			if(!supusername.contentEquals(""))
			Assert.assertEquals("Comparision of sup username",actualSupUsername,supusername);
			if(!SupNote.contentEquals(""))
			Assert.assertEquals("Comparision of out punch ",actualSupNote,SupNote);
			
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void verifyExistanceOfTimePairOnAddTimePairPage(String inPunch,String outPunch,String existanceValue)
	{
		WebElement timePairCard = findTimePairCard(inPunch, outPunch, "");
		if(existanceValue.equals("EXISTS"))
		{
			Assert.assertTrue(timePairCard!=null);
		}
		else if(existanceValue.equals("DOESNOTEXISTS"))
		{
			Assert.assertTrue(timePairCard==null);
		}
	}
	
	public void verifyNoteStatusOnTimecard(String strDate,String notestatus) {
		
		WebElement tcDayBlock = findTimecardBlock(strDate);
		if(notestatus.equals("READ"))
		{
			boolean flag = checkElementVisible(tcDayBlock.findElement(By.xpath(unreadNote)));
			Assert.assertFalse(flag);
		}
		else if(notestatus.equals("UNREAD"))
		{
			boolean flag = checkElementVisible(tcDayBlock.findElement(By.xpath(unreadNote)));
			Assert.assertTrue(flag);
		}
		else if(notestatus.equals("EXISTS"))
			Assert.assertTrue(checkElementVisible(tcDayBlock.findElement(By.xpath("//span[contains(@class,'fa tc-day-entry-icon fa-comment')]"))));
		else if(notestatus.equals("DOESNOTEXISTS"))
			Assert.assertTrue(checkElementVisible(tcDayBlock.findElement(By.xpath("//span[contains(@class,'fa tc-day-entry-icon fa-comment-o')]"))));
	}
	
	public void verifyPTOAvailabilityOnTimecardGrid(String strDate, String PTOPayCode, String Hours) {
		WaitForPageLoad();
		List<WebElement> objWithNotes = null;
		WebElement tcDay = findTimecardBlock(strDate);
		//objWithNotes = tcDay.findElements(By.xpath("//div[contains(text(),'" + PTOPayCode + "')]"));
		objWithNotes = tcDay.findElements(By.xpath("//div[contains(text(),'"+ Hours +":00 HRS  "+ PTOPayCode +"')]"));
		
		Assert.assertTrue("Verification of PTO exists on Timecard Grid", !objWithNotes.isEmpty());

	}


	
}
