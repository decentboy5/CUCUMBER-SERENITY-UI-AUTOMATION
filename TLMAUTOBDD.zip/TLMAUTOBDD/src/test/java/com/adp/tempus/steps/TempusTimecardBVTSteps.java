package com.adp.tempus.steps;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.adp.tempus.pages.TempusTimecardBVT;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class TempusTimecardBVTSteps extends ScenarioSteps {

	TempusTimecardBVT tempusTimecardBVT;

	@Step
	public void verifyViewYourTimecard() {
		tempusTimecardBVT.verifyViewYourTimecard();
	}

	@Step
	public void verifyTilesonTimecardPage(String tileName) {
		tempusTimecardBVT.verifyTilesonTimecardPage(tileName);
	}

	@Step
	public void employeesubmitTimePair(String strPunchType, String findInPunch, String inPunch, String outPunch) {
		tempusTimecardBVT.submitTimePair(strPunchType, findInPunch, inPunch, outPunch);
	}

	@Step
	public void verifyteamdashboardpage() {
		tempusTimecardBVT.verifyteamdashboardpage();
	}

	@Step
	public void verifyHomePagePortlets() {
		tempusTimecardBVT.verifyHomePagePortlets();
	}

	@Step
	public void verifyHomePortlet() {
		tempusTimecardBVT.verifyHomePortlet();

	}

	@Step
	public void verifyContentHomePortlet(String strDate, String strTime, String empName, String clockStatus) {
		tempusTimecardBVT.verifyContentHomePortlet(strDate, strTime, empName, clockStatus);
	}

	@Step
	public void submitRequestPay() {
		tempusTimecardBVT.submitRequestPay();
	}

	@Step
	public void verifyPayrollSchedulePageLoading() {
		tempusTimecardBVT.verifyPayrollSchedulePageLoading();
	}

	@Step
	public void verifyPayrollDashboardPageLoading() {
		tempusTimecardBVT.verifyPayrollDashboardPageLoading();
	}

	@Step
	public void verifyPayrollWorksheetPageLoading() {
		tempusTimecardBVT.verifyPayrollWorksheetPageLoading();
	}

	/*
	 * @Step public void verifyPolicyManagerPageLoading() {
	 * tempusTimecardBVT.verifyPolicyManagerPageLoading(); }
	 * 
	 * @Step public void verifyTimeAndAttendanceOptionUnderSetupNew() {
	 * tempusTimecardBVT.verifyTimeAndAttendanceOptionUnderSetupNew(); }
	 * 
	 * @Step public void createTimeAndAttendanceRoundingPolicy(String
	 * policyname,String roundingtype,String date) {
	 * tempusTimecardBVT.createTimeAndAttendanceRoundingPolicy(policyname,
	 * roundingtype, date); }
	 * 
	 * @Step public void deletePolicy(String policyname) {
	 * tempusTimecardBVT.deletePolicy(policyname); }
	 */
	@Step
	public void verifyPayrollWorksheetFromDashboard() {
		tempusTimecardBVT.verifyPayrollWorksheetFromDashboard();
	}

	@Step
	public void navigateBackToYourTimecard() {
		tempusTimecardBVT.navigateBackToYourTimecard();
	}

	// @Step
	// public void employeeEditsTimePair(String strDate, String findInPut,
	// String inPunch, String outPunch) {
	// tempusTimecardBVT.employeeEditsTimePair(strDate,findInPut,inPunch,outPunch);
	// }

	@Step
	public void verifyNavigationMissedPunchesSlider() {
		tempusTimecardBVT.verifyNavigationMissedPunchesSlider();
	}

	@Step
	public void verifyNavigationShiftSwapRequestSlider() {
		tempusTimecardBVT.verifyNavigationShiftSwapRequestSlider();
	}

	@Step
	public void verifyNavigationTimecardApprovalSlider() {
		tempusTimecardBVT.verifyNavigationTimecardApprovalSlider();
	}

	@Step
	public void clickOtherActionsLink(String linkName) {
		tempusTimecardBVT.clickOtherActionsLink(linkName);
	}

	@Step
	public void verifySmartButtonsHomePortlet(String clockIn, String clockOut, String mealOut, String mealReturn,
			String thingsToDo) {
		tempusTimecardBVT.verifySmartButtonsHomePortlet(clockIn, clockOut, mealOut, mealReturn, thingsToDo);
	}

	@Step
	public void clickButtonHomePortlet(String smartButton) {
		tempusTimecardBVT.clickButtonHomePortlet(smartButton);
	}

	@Step
	public void clickButtonAddTimePair(String btnName) {
		tempusTimecardBVT.clickButtonAddTimePair(btnName);
	}

	@Step
	public void verifyExceptionIndicatorTimePair(String inPunch, String outPunch, String strField, String instance,
			String status) {
		tempusTimecardBVT.verifyExceptionIndicatorTimePair(inPunch, outPunch, strField, instance, status);
	}

	@Step
	public void verifyDaysYourTimecardPage(String noOfDays) {
		tempusTimecardBVT.verifyDaysYourTimecardPage(noOfDays);
	}

	@Step
	public void verifyTimecardPermissions(String accessPermission) {
		tempusTimecardBVT.verifyTimecardPermissions(accessPermission);
	}

	@Step
	public void verifyStatusofSaveButton(String btnStatus) {
		tempusTimecardBVT.verifyStatusofSaveButton(btnStatus);
	}

	@Step
	public void AddEditNotesToTimePair(String inPunch, String outPunch, String instance, String noteType,
			String noteText) {
		tempusTimecardBVT.AddEditNotesToTimePair(inPunch, outPunch, instance, noteType, noteText);
	}

	@Step
	public void verifyClockStatusTimecardGrid(String strDate, String inTime, String clockStatus) {
		tempusTimecardBVT.verifyClockStatusTimecardGrid(strDate, inTime, clockStatus);
	}

	@Step
	public void clickButtonTimecardGrid(String strDate, String strButton) {
		tempusTimecardBVT.clickButtonTimecardGrid(strDate, strButton);
	}

	@Step
	public void verifyNoteAvailabilityOnTimecardGrid(String strDate, String noteStatus) {
		tempusTimecardBVT.verifyNoteAvailabilityOnTimecardGrid(strDate, noteStatus);
	}

	@Step
	public void verifyTotalHrsOnTimecardGrid(String strDate, String totalHrs) {
		tempusTimecardBVT.verifyTotalHrsOnTimecardGrid(strDate, totalHrs);
	}

	@Step
	public void verifyPunchTextOnTimecardGrid(String TimePairDate, String Punch) {
		tempusTimecardBVT.verifyPunchTextOnTimecardGrid(TimePairDate, Punch);
	}

	
	@Step
	public void verifyHoursTotalTime() {
		tempusTimecardBVT.verifyHoursTotalTime();
	}

	@Step
	public void verifyContentsTimeSummary(String regular, String overtime) {
		tempusTimecardBVT.verifyContentsTimeSummary(regular, overtime);
	}

	@Step
	public void selectShowDetailButton(String strValue) {
		tempusTimecardBVT.selectShowDetailButton(strValue);
	}

	@Step
	public void verifyTimePairsExistanceTimecardGrid(String timePairDate, String timePairExistance) {
		tempusTimecardBVT.verifyTimePairsExistanceTimecardGrid(timePairDate, timePairExistance);
	}

	@Step
	public void verifyTimePairsTimecardGrid(String timePairDate, String timePairs) {
		tempusTimecardBVT.verifyTimePairsTimecardGrid(timePairDate, timePairs);
	}

	@Step
	public void verifyTimecardButtonHomePortlet(String timecardButton) {
		tempusTimecardBVT.verifyTimecardButtonHomePortlet(timecardButton);
	}

	@Step
	public void verifyContentApproveTimecardHomePortlet(String timecardsCount) {
		tempusTimecardBVT.verifyContentApproveTimecardHomePortlet(timecardsCount);
	}

	@Step
	public void employeesubmitHours(String addType, String findHours, String hours) {
		tempusTimecardBVT.employeeSubmitHours(addType, findHours, hours);
	}

	@Step
	public void verifyContentPaySummary(String grossPay, String deductions, String taxes, String netPay) {
		tempusTimecardBVT.verifyContentPaySummary(grossPay, deductions, taxes, netPay);
	}

	@Step
	public void AddEditNotesToHours(String findHours, String noteType, String noteText) {
		tempusTimecardBVT.AddEditNotesToHours(findHours, noteType, noteText);
	}

	@Step
	public void verifyExceptionIndicatorTimecardGrid(String strDate, String status) {
		tempusTimecardBVT.verifyExceptionIndicatorsTimecardGrid(strDate, status);
	}

	@Step
	public void deleteTimepairsTimecards() {
		tempusTimecardBVT.deleteTimepairsTimecards();
	}

	@Step
	public void verifyButtonStatusTimecardPage(String btnName, String btnStatus) {
		tempusTimecardBVT.verifyButtonStatusTimecardPage(btnName, btnStatus);
	}

	@Step
	public void clickButtonYourTimecard(String btnName) {
		tempusTimecardBVT.clickButtonYourTimecard(btnName);
	}

	@Step
	public void verifyTimecardApprovalStatus(String btnStatus) {
		tempusTimecardBVT.verifyTimecardApprovalStatus(btnStatus);
	}

	@Step
	public void pauseForSomeTime(String mnts) {
		tempusTimecardBVT.pauseForSomeTime(mnts);
	}

	@Step
	public void verifyPayPeriodDates() {
		tempusTimecardBVT.verifyPayPeriodDates();
	}

	@Step
	public void selectPayPeriodTimecardPage(String payPeriod) {
		tempusTimecardBVT.selectPayPeriodTimecardPage(payPeriod);
	}

	@Step
	public void verifyPayPeriodDropdown() {
		tempusTimecardBVT.verifyPayPeriodDropdown();
	}

	@Step
	public void verifyPayPeriodDatesTimeSummaryTile(String payPeriodType) {
		tempusTimecardBVT.verifyPayPeriodDatesTimeSummaryTile(payPeriodType);
	}

	@Step
	public void verifyMealPolicyDeductionOnTimecardGrid(String strDate, String mealdeductionhours) {
		tempusTimecardBVT.verifyMealPolicyDeductionOnTimecardGrid(strDate, mealdeductionhours);
	}

	@Step
	public void verifyTimePairsOnTimecardGrid(String strDate, List<String> timepairs) {
		tempusTimecardBVT.verifyTimePairsOnTimecardGrid(strDate, timepairs);
	}

	@Step
	public void verifyEmploymentProfilePageLoading() {
		tempusTimecardBVT.verifyEmploymentProfilePageLoading();
	}

	@Step
	public void selectDayOnTimecardGrid(String strDate, String action) {
		tempusTimecardBVT.selectDayOnTimecardGrid(strDate, action);
	}

	@Step
	public void verifyDataOnAddTimecardPage(String inPunch, String outPunch, String empNote, String supusername , String supnote) {

		tempusTimecardBVT.verifyDataOnAddTimecardPage(inPunch, outPunch, empNote,supusername,supnote);
	}

	@Step
	public void verifyExistanceOfTimePairOnAddTimePairPage(String inPunch, String outPunch, String existanceValue) {
		tempusTimecardBVT.verifyExistanceOfTimePairOnAddTimePairPage(inPunch, outPunch, existanceValue);
	}
	
	@Step
	public void verifyNoteStatusOnTimecard(String strDate, String notestatus) {
		tempusTimecardBVT.verifyNoteStatusOnTimecard(strDate, notestatus);
	
	}
	
	@Step
	public void verifyPTOAvailabilityOnTimecardGrid(String strDate, String PTOPayCode, String Hours) {
		tempusTimecardBVT.verifyPTOAvailabilityOnTimecardGrid(strDate, PTOPayCode, Hours);
	}

}
