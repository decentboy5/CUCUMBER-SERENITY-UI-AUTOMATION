package com.adp.tempus.stepDefinition;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import com.adp.tempus.steps.TempusTimecardBVTSteps;
import com.adp.tlmbdd.stepDefinition.TeamDashboardStepDefinition;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class TempusTimecardBVTStepDefinition {

	@Steps
	TempusTimecardBVTSteps tempusTimecardBVTSteps;

	@Then("^I Verify View Your Timecard Link on Portlet Page$")
	public void i_Verify_View_Your_Timecard_Link_on_Portlet_Page() throws Throwable {
		tempusTimecardBVTSteps.verifyViewYourTimecard();
	}

	@Then("^I Verify Home Portlet Page$")
	public void i_Verify_Home_Portlet_Page() throws Throwable {
		tempusTimecardBVTSteps.verifyHomePortlet();
	}

	@Then("^I Verify Content on Home Portlet Page \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Content_Home_Portlet_Page(String empName, String clockStatus) throws Throwable {
		DateTimeFormatter dt = DateTimeFormatter.ofPattern("EEE, MMMM dd");
		String strDate = TeamDashboardStepDefinition.getRequiredDate("TODAYDATE").format(dt).toString();
		System.out.println(strDate);
		String strTime = "";
		tempusTimecardBVTSteps.verifyContentHomePortlet(strDate, strTime, empName, clockStatus);
	}

	@Then("^I Verify Buttons on Home Portlet Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Buttons_on_Home_Portlet_Page(String clockIn, String clockOut, String mealOut,
			String mealReturn, String thingsToDo) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		tempusTimecardBVTSteps.verifySmartButtonsHomePortlet(clockIn, clockOut, mealOut, mealReturn, thingsToDo);
	}

	@When("^I Verify Tmecard Button of Things To Do section on Home Portlet \"([^\"]*)\"$")
	public void i_Verify_TmecardButton_ThingsToDo_HomePortlet(String timecardButton) throws Throwable {
		tempusTimecardBVTSteps.verifyTimecardButtonHomePortlet(timecardButton);
	}

	@When("^I Verify Content Approve Timecard Tile of Things To Do section on Home Portlet \"([^\"]*)\"$")
	public void i_Verify_Content_ApproveTimecard_ThingsToDo_HomePortlet(String timecardsCount) throws Throwable {
		tempusTimecardBVTSteps.verifyContentApproveTimecardHomePortlet(timecardsCount);
	}

	@When("^I Verify Content Missed Punches Tile of Things To Do section on Home Portlet \"([^\"]*)\"$")
	public void i_Verify_Content_MissedPunches_ThingsToDo_HomePortlet(String timecardsCount) throws Throwable {
		tempusTimecardBVTSteps.verifyContentApproveTimecardHomePortlet(timecardsCount);
	}

	@When("^I Click Button on Home Portlet Page \"([^\"]*)\"$")
	public void i_Click_Button_on_Home_Portlet_Page(String smartButton) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		tempusTimecardBVTSteps.clickButtonHomePortlet(smartButton);
	}

	@Then("^I verify home page portlets$")
	public void i_verify_home_page_portlets() throws Throwable {
		tempusTimecardBVTSteps.verifyHomePagePortlets();
	}

	@Then("^I Verify \"([^\"]*)\" Tile loaded on Your Timecard Page$")
	public void i_Verify_Tile_loaded_on_Your_Timecard_Page(String tileName) throws Throwable {
		tempusTimecardBVTSteps.verifyTilesonTimecardPage(tileName);
	}

	@When("^I Verify Content on Pay Summary Tile \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Content_on_PaySummary_Tile(String grossPay, String deductions, String taxes, String netPay)
			throws Throwable {
		tempusTimecardBVTSteps.verifyContentPaySummary(grossPay, deductions, taxes, netPay);
	}

	@When("^I Employee Enters Time Pair on Your Timecard Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Employee_Submits_Time_Pair_on_Your_Timecard_Page(String strPunchType, String findInPunch,
			String inPunch, String outPunch) throws Throwable {
		// DateTimeFormatter formatters = DateTimeFormatter.ofPattern("dd");
		// strDate =
		// TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.employeesubmitTimePair(strPunchType, findInPunch, inPunch, outPunch);
	}

	@When("^I Employee Enters Hours on Your Timecard Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Employee_Enters_Hours_on_Your_Timecard_Page(String addType, String findHours, String hours)
			throws Throwable {
		tempusTimecardBVTSteps.employeesubmitHours(addType, findHours, hours);
	}

	@When("^I Click Button on Add Time Pair Page \"([^\"]*)\"$")
	public void i_Click_Button_on_Add_Time_Pair_Page(String btnName) throws Throwable {
		tempusTimecardBVTSteps.clickButtonAddTimePair(btnName);
	}

	@When("^I Verify Exception Indidcators on Add Time Pair Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Exception_Add_Time_Pair_Page(String inPunch, String outPunch, String strField, String instance,
			String status) throws Throwable {
		tempusTimecardBVTSteps.verifyExceptionIndicatorTimePair(inPunch, outPunch, strField, instance, status);
	}

	@When("^I Verify Exception Indidcators on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Exception_Indicators_TimecardGrid(String strDate, String status) throws Throwable {
		DateTimeFormatter dt = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(dt).toString();
		tempusTimecardBVTSteps.verifyExceptionIndicatorTimecardGrid(strDate, status);
	}

	// @When("^I Employee Edits Time Pair on Your Timecard Page
	// \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
//	public void i_Employee_Edits_Time_Pair_on_Your_Timecard_Page(String strDate,String findInPut, String inPunch, String outPunch) throws Throwable {
//		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("dd");
//		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
//		tempusTimecardBVTSteps.employeeEditsTimePair(strDate,findInPut,inPunch,outPunch);
//	}

	@When("^I Navigate back to Your Timecard page$")
	public void i_Navigate_Back_To_Your_Timecard() throws Throwable {
		tempusTimecardBVTSteps.navigateBackToYourTimecard();
	}

	@Then("^I Verify Days on Timecard on Your Timecard Page \"([^\"]*)\"$")
	public void i_Verify_Days_of_Timecard_on_YourTimecard_Page(String noOfDays) throws Throwable {
		tempusTimecardBVTSteps.verifyDaysYourTimecardPage(noOfDays);
	}

	@Then("^I Verify Timecard Access Permission on Your Timecard Page \"([^\"]*)\"$")
	public void i_Verify_Timecard_AccessPermission_YourTimecard_Page(String AccessPermission) throws Throwable {
		tempusTimecardBVTSteps.verifyTimecardPermissions(AccessPermission);
	}

	@Then("^I Verify Status of the Save Button on Add Time Pair Page \"([^\"]*)\"$")
	public void i_Verify_Status_Save_AddTimePair_Page(String btnStatus) throws Throwable {
		tempusTimecardBVTSteps.verifyStatusofSaveButton(btnStatus);
	}

	@When("^I Enter Notes to Time Pair on Add Time Pair Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Notes_To_TimePair_AddTimePair_Page(String inPunch, String outPunch, String instance,
			String noteType, String noteText) throws Throwable {
		tempusTimecardBVTSteps.AddEditNotesToTimePair(inPunch, outPunch, instance, noteType, noteText);
	}

	@When("^I Enter Notes to Hours on Add Time Pair Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Enter_Notes_To_Hours_AddTimePair_Page(String findHours, String noteType, String noteText)
			throws Throwable {
		tempusTimecardBVTSteps.AddEditNotesToHours(findHours, noteType, noteText);
	}

	@Then("^I Verify Clock Status on Timecard Grid \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Clock_Status_Timecard_Grid(String strDate, String inTime, String clockStatus)
			throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("dd");
		// DateTimeFormatter timeformatters = DateTimeFormatter.ofPattern("h:m a");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyClockStatusTimecardGrid(strDate, inTime, clockStatus);
	}

	@When("^I Click Button on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Click_Button_Timecard_Grid(String strDate, String strButton) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.clickButtonTimecardGrid(strDate, strButton);
	}

	@When("^I Select Show Details toggle button on Yor Timecard Page \"([^\"]*)\"$")
	public void i_Select_ShowDetails_togglebutton_on_YorTimecardPage(String strValue) throws Throwable {
		tempusTimecardBVTSteps.selectShowDetailButton(strValue);
	}

	@When("^I Verify Existance of Time Pair Container on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Existance_TimePairContainer_on_YorTimecardPage(String timePairDate, String timePairExistance)
			throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		timePairDate = TeamDashboardStepDefinition.getRequiredDate(timePairDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyTimePairsExistanceTimecardGrid(timePairDate, timePairExistance);
	}

	@When("^I Verify Time Pairs on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_TimePair_on_YorTimecardPage(String timePairDate, String timePairs) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		timePairDate = TeamDashboardStepDefinition.getRequiredDate(timePairDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyTimePairsTimecardGrid(timePairDate, timePairs);
	}

	@Then("^I Verify Notes Availability on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Notes_Availability_Timecard_Grid(String strDate, String noteStatus) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyNoteAvailabilityOnTimecardGrid(strDate, noteStatus);
	}

	@Then("^I Verify Hours on Time Summary Tile \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Hours_on_TimeSummary_Tile(String regular, String overtime) throws Throwable {
		tempusTimecardBVTSteps.verifyContentsTimeSummary(regular, overtime);
	}

	@Then("^I Verify Total Hours on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Total_Hours_Timecard_Grid(String strDate, String totalHrs) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyTotalHrsOnTimecardGrid(strDate, totalHrs);
	}

	@Then("^I verify \"([^\"]*)\" text on the Timecard Grid \"([^\"]*)\"$")
	public void iVerifyTextOnTheTimecardGrid(String Punch, String timePairDate) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		timePairDate = TeamDashboardStepDefinition.getRequiredDate(timePairDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyPunchTextOnTimecardGrid(timePairDate, Punch);
	}

	@Then("^I Verify Hours on Total Time Tile$")
	public void i_Verify_Hours_TotalTime_Tile() throws Throwable {
		tempusTimecardBVTSteps.verifyHoursTotalTime();
	}

	@When("^I Verify Tiles displayed on Team Dashboard$")
	public void i_Verify_Tile_displayed_on_Team_Dashboard() throws Throwable {
		tempusTimecardBVTSteps.verifyteamdashboardpage();
	}

	@Then("^I Verify Navigation to Missed Punches Slider$")
	public void i_Verify_Navigation_To_MissedPunches_Slider() throws Throwable {
		tempusTimecardBVTSteps.verifyNavigationMissedPunchesSlider();
	}

	@Then("^I Verify Navigation to Shift Swap Requests Slider$")
	public void i_Verify_Navigation_To_ShiftSwapRequests_Slider() throws Throwable {
		tempusTimecardBVTSteps.verifyNavigationShiftSwapRequestSlider();
	}

	@Then("^I Verify Navigation to Timecard Approval Slider$")
	public void i_Verify_Navigation_To_TimecardApproval_Slider() throws Throwable {
		tempusTimecardBVTSteps.verifyNavigationTimecardApprovalSlider();
	}

	@When("^I Submit Request Pay Request from Your Timecard page$")
	public void i_Submit_Request_Pay_Request_from_Your_Timecard_page() throws Throwable {
		tempusTimecardBVTSteps.submitRequestPay();
	}

	@Then("^I verify payroll schedule page is loaded properly$")
	public void i_verify_payroll_schedule_page_is_loaded_properly() throws Throwable {
		tempusTimecardBVTSteps.verifyPayrollSchedulePageLoading();
	}

	@Then("^I verify payroll dashboard page is loaded properly$")
	public void i_verify_payroll_dashboard_page_is_loaded_properly() throws Throwable {
		tempusTimecardBVTSteps.verifyPayrollDashboardPageLoading();

	}

	@Then("^I verify payroll worksheet page is loaded properly$")
	public void i_verify_payroll_worksheet_page_is_loaded_properly() throws Throwable {
		tempusTimecardBVTSteps.verifyPayrollWorksheetPageLoading();
	}

	@Then("^I verify Employment Profile page is loaded properly$")
	public void i_verify_Employment_Profile_page_is_loaded_properly() throws Throwable {
		tempusTimecardBVTSteps.verifyEmploymentProfilePageLoading();
	}

	/*
	 * @Then("^I verify policy manager is loaded properly$") public void
	 * i_verify_policy_manager_page_is_loaded_properly() throws Throwable {
	 * tempusTimecardBVTSteps.verifyPolicyManagerPageLoading(); }
	 * 
	 * @Then("^I verify time and attendance under setup new$") public void
	 * i_verify_time_and_attendance_under_setup_new() throws Throwable {
	 * tempusTimecardBVTSteps.verifyTimeAndAttendanceOptionUnderSetupNew(); }
	 * 
	 * @Then("^I create a rounding policy with name \"([^\"]*)\" rounding type \"([^\"]*)\" and date \"([^\"]*)\"$"
	 * ) public void
	 * i_create_a_rounding_policy_with_name_rounding_type_and_date(String
	 * policyname, String roundingtype, String dateformat) throws Throwable {
	 * DateTimeFormatter formatters = DateTimeFormatter.ofPattern("M/dd/yyyy");
	 * LocalDate requireddate =
	 * TeamDashboardStepDefinition.getRequiredDate(dateformat); String requireddate1
	 * = requireddate.format(formatters).toString();
	 * tempusTimecardBVTSteps.createTimeAndAttendanceRoundingPolicy(policyname,
	 * roundingtype, requireddate1); }
	 */

	@Then("^I Verify Status of \"([^\"]*)\" on Your Timecard Page \"([^\"]*)\"$")
	public void i_Verify_Status_Button_YourTimecard(String btnName, String btnStatus) throws Throwable {
		tempusTimecardBVTSteps.verifyButtonStatusTimecardPage(btnName, btnStatus);
	}

	@Then("^I Verify Approval Status of Timecard \"([^\"]*)\"$")
	public void i_Verify_Approval_Status_YourTimecard(String btnStatus) throws Throwable {
		tempusTimecardBVTSteps.verifyTimecardApprovalStatus(btnStatus);
	}

	@When("^I Click Button on Your Timecard Page \"([^\"]*)\"$")
	public void i_Click_Button_YourTimecard(String btnName) throws Throwable {
		tempusTimecardBVTSteps.clickButtonYourTimecard(btnName);
	}

	@When("^I Click on Other Actions link on Team Dashboard \"([^\"]*)\"$")
	public void i_Click_OtherActions_TeamDashboard(String linkName) throws Throwable {
		tempusTimecardBVTSteps.clickOtherActionsLink(linkName);
	}

	@Then("^I verify payroll worksheet is loaded from payroll dashboard page$")
	public void i_verify_payroll_worksheet_loaded_from_payroll_dashboard() throws Throwable {
		tempusTimecardBVTSteps.verifyPayrollWorksheetFromDashboard();
	}

	@When("^I Clear all Timepairs or Hours on Timecard$")
	public void i_Clear_Hours_Timecard() throws Throwable {
		tempusTimecardBVTSteps.deleteTimepairsTimecards();
	}

	@When("^I Make Execution Pause for \"([^\"]*)\" Minutes$")
	public void i_make_execution_pause_for_minutes(String mnts) throws Throwable {
		tempusTimecardBVTSteps.pauseForSomeTime(mnts);
	}

	@Then("^I Verify Pay Periods on Your Timecard Page$")
	public void i_verify_pay_periods_timecard_page() throws Throwable {
		tempusTimecardBVTSteps.verifyPayPeriodDropdown();
	}

	@Then("^I Verify Pay Period Dates on Timecard Grid$")
	public void i_verify_pay_period_Dates_timecard_grid() throws Throwable {
		tempusTimecardBVTSteps.verifyPayPeriodDates();
	}

	@Then("^I Verify Pay Period Dates on Time Summary Tile \"([^\"]*)\"$")
	public void i_verify_pay_period_Dates_timesummary_tile(String payPeriodType) throws Throwable {
		tempusTimecardBVTSteps.verifyPayPeriodDatesTimeSummaryTile(payPeriodType);
	}

	@When("^I Select Pay Period on Your Timecard Page \"([^\"]*)\"$")
	public void i_select_pay_period_timecard_page(String payPeriod) throws Throwable {
		tempusTimecardBVTSteps.selectPayPeriodTimecardPage(payPeriod);
	}
	// @Then("^I Verify Clock Status on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
//	public void i_verify_clock_status_timecard_grid(String strDate,String status) throws Throwable {
//	    tempusTimecardBVTSteps.verifyClockStatusTimecardGrid(strDate,status);
//	}	

	@Then("^I verify meal deduction details on Timecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_verify_meal_deduction_details_on_Timecard_Grid(String strDate, String mealDeductionHrs)
			throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyMealPolicyDeductionOnTimecardGrid(strDate, mealDeductionHrs);
	}

	@Then("^I Verify Time Pairs on Timecard Grid on \"([^\"]*)\"$")
	public void i_Verify_Time_Pairs_on_Timecard_Grid_on(String strDate, List<String> timepairlist) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyTimePairsOnTimecardGrid(strDate, timepairlist);
	}

	@When("^I Select Day on Timecard Grid to Enter Missed Punch \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Select_Day_Timecard_Grid_to_Enter_Missed_punch(String strDate, String action) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.selectDayOnTimecardGrid(strDate, action);
	}

	@Then("^I Verify Details on Add Time Pair Page as \"([^\"]*)\", \"([^\"]*)\" and note \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Details_On_Add_Time_Pair_Page(String inPunch, String outPunch, String empNote,
			String SupUsername, String supNote) throws Throwable {

		tempusTimecardBVTSteps.verifyDataOnAddTimecardPage(inPunch, outPunch, empNote, SupUsername, supNote);
	}

	@Then("^I Verify Time Pair Existance on Add Time Pair Page as \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_TimePair_Existance_On_Add_Time_Pair_Page(String inPunch, String outPunch,
			String existanceValue) throws Throwable {

		tempusTimecardBVTSteps.verifyExistanceOfTimePairOnAddTimePairPage(inPunch, outPunch, existanceValue);
	}

	@Then("^I Verify Note Details on \"([^\"]*)\" as \"([^\"]*)\" on Timecard$")
	public void i_Verify_Note_Details_On_Timecard(String date, String notestatus) throws Throwable {

		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		String strDate = TeamDashboardStepDefinition.getRequiredDate(date).format(formatters).toString();
		tempusTimecardBVTSteps.verifyNoteStatusOnTimecard(strDate, notestatus);
	}

	@Then("^I Verify PTO Availability on Timecard Grid \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void iVerifyPTOAvailabilityOnTimecardGrid(String strDate, String PTOPayCode, String Hours) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		tempusTimecardBVTSteps.verifyPTOAvailabilityOnTimecardGrid(strDate, PTOPayCode, Hours);
	}

}
