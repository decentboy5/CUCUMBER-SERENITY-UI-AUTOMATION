package com.adp.tempus.stepDefinition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.adp.tempus.steps.TimeDashboardSteps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class TimeDashboardStepDefinition {

	@Steps
	TimeDashboardSteps timeDashboardSteps;

	public static LocalDate getRequiredDate(String dateformat) {
		int intendeddate;
		LocalDate dateUsed;

		LocalDate localDate = LocalDate.now();
		System.out.println(localDate);

		// set date and in punch values
		if (dateformat.contains("MINUS")) {
			intendeddate = Integer.valueOf(dateformat.split("MINUS")[1].trim());
			dateUsed = localDate.minusDays(intendeddate);
		} else if (dateformat.contains("PLUS")) {
			intendeddate = Integer.valueOf(dateformat.split("PLUS")[1].trim());
			dateUsed = localDate.plusDays(intendeddate);
		} else {
			dateUsed = localDate;
		}
		System.out.println("Modified Date" + dateUsed);
		return dateUsed;
	}

	@When("^I click on a tile on things to do \"([^\"]*)\"$")
	public void i_click_on_a_tile_on_things_to_do(String tilename) throws Throwable {

		timeDashboardSteps.clickOnTTDTile(tilename);
	}

	@When("^I resolve missed punch of employee \"([^\"]*)\"with time \"([^\"]*)\" for date \"([^\"]*)\"$")
	public void i_resolve_missed_punch_of_employee_with_time_for_date(String employeename, String outPunch, String date)
			throws Throwable {

		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = getRequiredDate(date).format(formatters).toString();
		timeDashboardSteps.resolveMissedPunch(employeename, outPunch, requireddate);

	}

	@When("^I Click on \"([^\"]*)\" Button on Slider$")
	public void i_click_on_Button_slider(String buttonName) throws Throwable {
		timeDashboardSteps.clickButtonOnSlider(buttonName);
	}

	@When("^I Select Employee to Approve on Timecard Approval Grid \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Select_Employee_Approve_TimecardApprovalGrid(String empName, String positionId, String value)
			throws Throwable {
		timeDashboardSteps.selectEmployeeTimecardApprovalGrid(empName, positionId, value);
	}

	@Then("^I Verify Employee Record on Timecard Approval Grid \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Employee_Record_TimecardApprovalGrid(String empName, String positionId, String status)
			throws Throwable {
		timeDashboardSteps.verifyEmployeeRecordTimecardApprovalGrid(empName, positionId, status);
	}

	@Then("^I Verify Timecard Count on Timecard Approval Status Tile \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Timecard_Count_TimecardApprovalStatusTile(String approved, String readyForApproval,
			String pendingActions) throws Throwable {
		timeDashboardSteps.verifyTimecardCountTimecardApprovalStatusTile(approved, readyForApproval, pendingActions);
	}

	@Then("^I Verify Timecard Details on Timecard Approval Grid \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_Employee_Record_TimecardApprovalGrid(String empName, String positionId, String status,
			String totalHrs) throws Throwable {
		timeDashboardSteps.verifyEmployeeDetailsTimecardApprovalGrid(empName, positionId, status, totalHrs);
	}

	@When("^I Click on Timecard Approval Status Tile \"([^\"]*)\"$")
	public void i_click_on_Timecard_Approval_Status_Tile(String buttonName) throws Throwable {
		timeDashboardSteps.clickOnTimecardApprovalStatusTile(buttonName);
	}

	@Then("^I Verify Status of \"([^\"]*)\" Button on Slider \"([^\"]*)\"$")
	public void i_Verify_Status_of_Button_on_Slider(String btnName, String status) throws Throwable {
		timeDashboardSteps.verifybuttonStatusOnSlider(btnName, status);
	}

	@Then("^I Verify Timecard Approvals Tile under Things To Do \"([^\"]*)\"$")
	public void i_Verify_Timecard_Approvals_Tile_Things_To_Do(String tcCount) throws Throwable {
		timeDashboardSteps.verifyTmecardApprovalSubTile(tcCount);
	}

	@When("^I Select Employee on Team Timecard Page \"([^\"]*)\"$")
	public void i_select_employee_TeamTimecard_Page(String empName) throws Throwable {
		timeDashboardSteps.selectEmployee(empName);
	}

	@When("^I resolve multiple missed punches of employee \"([^\"]*)\" for date \"([^\"]*)\"$")
	public void i_resolve_multiple_missed_punches_of_employee_for_date(String employeename, String date,
			List<String> timepairlist) throws Throwable {
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = getRequiredDate(date).format(formatters).toString();
		timeDashboardSteps.resolveMultipleMissedPunch(employeename, requireddate, timepairlist);
	}

	@When("^I get the count of employee and missed punches on TTD Tile$")
	public void i_get_the_count_of_employee_and_missed_punches_on_TTD_Tile() throws Throwable {

		timeDashboardSteps.saveMissedPunchesAndEmployeeCountOnTTDTile();
	}

	@When("^I get the count of employee and missed punches on missed punches slider$")
	public void i_get_the_count_of_employee_and_missed_punches_on_missed_punches_slider() throws Throwable {

		timeDashboardSteps.saveMissedPunchesAndEmployeeCountOnSlider();
	}

	@Then("^I verify the count difference of employee as \"([^\"]*)\" and missed punches as \"([^\"]*)\" on slider$")
	public void i_verify_the_count_difference_of_employee_as_and_missed_punches_as_on_slider(String employeedifference,
			String missedpunchesdifference) throws Throwable {

		timeDashboardSteps.verifyMissedPunchesAndEmployeeOnSlider(employeedifference, missedpunchesdifference);
	}

	@Then("^I verify the count difference of employee as \"([^\"]*)\" and missed punches as \"([^\"]*)\" on TTD Tile$")
	public void i_verify_the_count_difference_of_employee_as_and_missed_punches_as_on_TTD_Tile(
			String employeedifference, String missedpunchesdifference) throws Throwable {

		timeDashboardSteps.verifyMissedPunchesAndEmployeeOnTTDTile(employeedifference, missedpunchesdifference);
	}

	@Then("^I verify \"([^\"]*)\" is not visible$")
	public void i_Verify_Message_on_Screen(String tilename) throws Throwable {

		timeDashboardSteps.verifyTileInVisibilityOnTTDTIle(tilename);
	}

	@Then("^I click on time card link for \"([^\"]*)\" employee and verify timecard loading$")
	public void i_click_on_time_card_link_for_employee(String employeename) throws Throwable {
		timeDashboardSteps.clickTimeCardLinkAndVerifyLoading(employeename);
	}
	
	@Then("^I verify employee note color as \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\"$")
	public void i_verify_employee_note_color_as_for_on(String color, String employeename, String date) throws Throwable {
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = getRequiredDate(date).format(formatters).toString();
		timeDashboardSteps.verifyColorOfNote(color, employeename, requireddate);
	}
	
	@When("^I click notes icon for \"([^\"]*)\" employee for date \"([^\"]*)\"$")
	public void i_click_notes_icon_for_employee_for_date(String employeename, String date) throws Throwable {
		String requireddate;
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd");
		requireddate = getRequiredDate(date).format(formatters).toString();
		timeDashboardSteps.clickOnSpecificNote(employeename, requireddate);
	}

	@Then("^I verify note as \"([^\"]*)\" for employee \"([^\"]*)\"$")
	public void i_verify_note_as_for_employee(String note, String employeename) throws Throwable {
	    timeDashboardSteps.verifyEmployeeNote(note, employeename);
	}
	
}
