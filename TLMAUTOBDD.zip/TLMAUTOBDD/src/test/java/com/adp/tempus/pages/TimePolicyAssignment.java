package com.adp.tempus.pages;

import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class TimePolicyAssignment extends GenericPageObject{
	
public static Logger log = Logger.getLogger(TimePolicyAssignment.class);
	
	@FindBy(xpath = "(//*[@class='portletCard-title' and contains(text(),'Time & Attendance')])")
	private WebElementFacade timeTitle;
	
	@FindBy(xpath = "//div[@class='portletCard-wrapper portletCard-wrapper-timeAndAttendance']")
	private WebElementFacade timeTitlePayProfile;
	
	@FindBy(css = "span.fa.fa-clock-o")
	private WebElementFacade clockIcon;
	
	@FindBy(xpath ="//div[@class='vdl-col-xs mdf-grid-headerCell column-0 time-card-name-grid-column'] | //div[@class='vdl-col-xs mdf-grid-headerCell column-0 policy-data-grid policy-name']")
	private WebElementFacade nameLabel;
	
	@FindBy(xpath="//div[@class='vdl-col-xs mdf-grid-headerCell column-1 policy-data-grid policy-category'] | //div[@class='vdl-col-xs mdf-grid-headerCell column-1 time-card-category-grid-column']")
	private WebElementFacade categoryLabel;
	
	@FindBy(xpath = "//span[contains(text(),'Other Time & Attendance Setting')]")
	private WebElementFacade timeSettingslnk;
	
	@FindBy(xpath = "//button[@id='empProfileTimeAttendanceHistoryBtn'] | //div[@class='portletCard-wrapper portletCard-wrapper-timeAndAttendance']//span[@class='fa fa-history']")
	private WebElementFacade timeHistorylnk;
	
	@FindBy(xpath = "//a[contains(text(),'History')]")
	private WebElementFacade historylnk_EditTandA;	
	
	
	@FindBy(xpath = "//button[@id='timeAndAttendancePiPolicyAssignment_btn']//span[@class='vdl-button__container'][contains(text(),'Edit')]")
	private WebElementFacade timeEditBtn;
	
	@FindBy(xpath ="//span[@class='vdl-slide-in-title']")
	private WebElementFacade timeandAttendenceTab;
	
	@FindBy(xpath ="//label[contains(text(),'Rounding Options')]")
	private WebElementFacade txtRoundingOption;
	
	@FindBy(xpath ="//span[@class='vdl-button__container'][contains(text(),'Back')]")
	private WebElementFacade backBtn;
	
	@FindBy(xpath ="//div[@class='time-assignment-history-slideIn fade in vdl-slide-in']//span[@class='vdl-button__container'][contains(text(),'Back')]")
	private WebElementFacade backBtnHstry;
	
	@FindBy (xpath = "(//span[@class='vdl-slide-in-title' and contains(text(),'Time & Attendance History')])")
	private WebElementFacade timeHistoryTitle;
	
	@FindBy (xpath = "(//span[@class='vdl-slide-in-title' and contains(text(),'Other Time & Attendance Setting')])")
	private WebElementFacade otherTimeSettingTitle;
	
	@FindBy (xpath = "//input[@id='effectiveDate']")
	private WebElementFacade txtEffDate;	
	
	@FindBy (xpath = "//div[@name='selectedRoundingPolicy']")
	private WebElementFacade roundingDropdown;
	
	@FindBy (xpath = "//div[@name='selectedTimeEntryPolicy']")
	private WebElementFacade timeEntryDropdown;	
	
	@FindBy (xpath = "//div[@name='selectedMealPolicy']")
	private WebElementFacade mealDropdown;	
	
	@FindBy (xpath = "//div[@name='selectedHolidayPolicy']")
	private WebElementFacade holidayDropdown;	
	
	@FindBy (xpath = "//span[text()='Done']")
	private WebElementFacade btnDone;
	
	@FindBy (xpath = "//span[text()='Time & Attendance']")
	private WebElementFacade lnkTimeandAttendence;
	
	@FindBy (xpath = "//div[@class='mdf-time-frame__point-label']")
	private WebElementFacade timeLine;
	
	@FindBy (xpath = "//div[@class='mdf-time-frame__timeline-point']")
	private WebElementFacade timeLineRdBtn;
	
	@FindBy (xpath = "//div[@class='mdf-time-frame__dates']")
	private WebElementFacade timeLineDates;
	
	String strRounding;
	String strTimeEntry;
	String strMeal;
	String strTimeHoliday;
	String strDate;
	String effDateVal;
		
	public void verifyEmployeeProfilePageLoading()
	{
		WaitForPageLoad();
		waitABit(5000);
	}
	
	public void verifyTimeTitleDisplayed() {
		
		Assert.assertTrue("Verification of Time Title Displayed", checkElementVisible(timeTitle));
		
	}
	
public void verifyTimeTitleNotDisplayed() {
		
		Assert.assertFalse("Verification of Time Title Not Displayed", checkElementVisible(timeTitle));
		
	}
	
	public void verifyTimeTileDisplayedPayProfile()
	{
		Assert.assertTrue("Verification of Time Title Displayed", checkElementVisible(timeTitlePayProfile));
	}
	
	public void verifyClockiconIsDisplayed() {
		
		Assert.assertTrue("Verification of Clock icon Is Displayed", checkElementVisible(clockIcon));
	}
	
	public void verify_Time_Attendence_text_is_displayed() {
		Assert.assertTrue("Verification of Time and Attendence text is displayed", checkElementVisible(timeTitle));
	}
	
	public void verify_NAME_label_is_displayed() {
		Assert.assertTrue("Verification of NAME label is displayed", checkElementVisible(nameLabel));
	}

	public void verify_CATEGORY_label_is_displayed() {
		Assert.assertTrue("Verification of CATEGORY label is displayed", checkElementVisible(categoryLabel));
	}
	
	public void verify_Time_Settings_Link_is_displayed() {
		Assert.assertTrue("Verification of Other Time and Attendence link is displayed", checkElementVisible(timeSettingslnk));
	}
	
	public void verify_History_Link_is_displayed() {
		Assert.assertTrue("Verification of Time & Attendance History link is displayed", checkElementVisible(timeHistorylnk));
	}
	
	public void verify_Edit_button_is_displayed() {
		Assert.assertTrue("Verification of Time & Attendance EDIT button is displayed", checkElementVisible(timeEditBtn));
	}
	
	public void select_edit_button(){
		timeEditBtn.click();
		if(!checkElementVisible(timeandAttendenceTab)) waitABit(3000);
	}
	
	public void should_navigate_to_Time_Policy_Assignment_page() {
		Assert.assertTrue("Verification of Time & Attendance TAB button is displayed", checkElementVisible(txtRoundingOption));
	}
	
	public void select_Back_button() {
		backBtn.click();
		waitABit(2000);
	}
	
	
	public void select_Back_button_on_history() {
		backBtnHstry.click();
		waitABit(2000);
	}
	
	public void should_navigate_to_employee_profile_page() {
		Assert.assertTrue("Verification of Time Title Displayed", checkElementVisible(timeTitle));
	}
	
	public void select_Time_Attendance_History_link() {
		timeHistorylnk.click();
		waitABit(2000);
	}
	
	public void navigate_to_Time_Attendance_History_page() {
		Assert.assertTrue("Verification of Time and Attendence history Title Displayed", checkElementVisible(timeHistoryTitle));
	}
	
	public void select_Other_Time_Attendance_Settings_link() {
		timeSettingslnk.click();
		waitABit(2000);
	}
	
	public void navigate_to_Other_Time_Attendance_Settings_page() {
		Assert.assertTrue("Verification of Other Time & Attendance Settings Title Displayed", checkElementVisible(otherTimeSettingTitle));
	}
	
	public void validate_HISTORY_link_is_displayed() {
		Assert.assertTrue("Verification of Other Time & Attendance Settings Title Displayed", checkElementVisible(historylnk_EditTandA));
	}
	
	public void select_HISTORY_link_Time_Policy_Assignment_Page() {
		historylnk_EditTandA.click();
		waitABit(2000);		
	}
	
	public void pick_effective_date(String effDate) {
		//effDateVal= effDate;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		//String currDate = sdf.format(cal.getTime());
		if(effDate.equals("futureDate")) {
			cal.add(Calendar.DAY_OF_MONTH, 7); 
		}else if(effDate.equals("pastDate")) {
			cal.add(Calendar.DAY_OF_MONTH, -2); 
		}	
			strDate = sdf.format(cal.getTime());
			txtEffDate.sendKeys(strDate);
			waitABit(2000);
			txtEffDate.sendKeys(Keys.TAB);
			waitABit(2000);
		
	}
	
	public void select_rounding_Options_and_Time_Entry_and_Meal_Breaks_and_Time_Holiday() {
		
		roundingDropdown.click();
		
		List<WebElement> roundingList=roundingDropdown.findElements(By.tagName("li"));
		
		roundingList.get(1).click();
		waitABit(2000);
		//strRounding = roundingDropdown.getAttribute("value");
		
		//System.out.println("value is "+roundingDropdown.getAttribute("value"));
		strRounding = roundingDropdown.getText();
		System.out.println("text is "+roundingDropdown.getText());
		
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", timeEntryDropdown);
		waitABit(2000);
		timeEntryDropdown.click();
		
		List<WebElement> timeEntryList=timeEntryDropdown.findElements(By.tagName("li"));
		
		timeEntryList.get(1).click();
		waitABit(2000);
		
		strTimeEntry = timeEntryDropdown.getText();
		
		System.out.println("text is "+timeEntryDropdown.getText());
		
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", mealDropdown);
		waitABit(2000);
		mealDropdown.click();
		
		List<WebElement> mealList=mealDropdown.findElements(By.tagName("li"));
		
		mealList.get(1).click();
		waitABit(2000);
		strMeal = mealDropdown.getText();
		
		System.out.println("text is "+mealDropdown.getText());
		
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", holidayDropdown);
		waitABit(2000);
		holidayDropdown.click();
		
		List<WebElement> holidayList=holidayDropdown.findElements(By.tagName("li"));
		
		holidayList.get(1).click();
		waitABit(2000);
		
		strTimeHoliday = holidayDropdown.getText();
		System.out.println("text is "+holidayDropdown.getText());
		
		btnDone.click();
		waitABit(2000);
	}
	
	public void verifyTimeandAttendenceLinkDisplayed() {
		
		Assert.assertTrue("Verification of Time Title Displayed", checkElementVisible(lnkTimeandAttendence));
		
	}
	
	public void selectTimeandAttendanceLink() {
		verifyTimeandAttendenceLinkDisplayed();
		lnkTimeandAttendence.click();
		waitABit(2000);
	}
	
	public void validate_new_time_line_is_created() {
		selectTimeandAttendanceLink();
				
		txtEffDate.sendKeys(strDate);
		waitABit(2000);
		txtEffDate.sendKeys(Keys.TAB);
		waitABit(2000);
		
		List<WebElement> dateList=timeLine.findElements(By.xpath("//div[@class='mdf-time-frame__dates']"));
		Assert.assertTrue("Verification time policy with future date is created", dateList.get(0).getText().contains(strDate));
		
		Assert.assertTrue("Rounding value is correct",roundingDropdown.getText().contains(strRounding));
		Assert.assertTrue("timeEntryDropdown value is correct",timeEntryDropdown.getText().contains(strTimeEntry));
		Assert.assertTrue("Rounding value is correct",mealDropdown.getText().contains(strMeal));
		Assert.assertTrue("Rounding value is correct",holidayDropdown.getText().contains(strTimeHoliday));
		
		btnDone.click();
		waitABit(2000);
	}
	
	
}
