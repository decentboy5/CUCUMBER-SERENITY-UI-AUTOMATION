package com.adp.tempus.stepDefinition;

import com.adp.tempus.steps.YourTimecardSteps;
import com.adp.tempus.pages.YourTimecard;
import com.adp.tempus.steps.YourTimePortletsSteps;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class YourTimecardStepDefinition {

	@Steps
	YourTimePortletsSteps yourTimePortletsSteps;

	@Steps 
	YourTimecardSteps timecardSteps;

	@When("^I navigate to your timecard page$")
	public void i_navigate_to_your_timecard_page() throws Throwable {
		timecardSteps.emp_YourTimcard_Navigation();
	}

	@Then("^I validate that timecard should be on read only$")
	public void i_validate_that_timecard_should_be_on_read_only() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_readOnlyStatus(true);
	}

	@When("^I naviate to your time card page$")
	public void i_naviate_to_your_time_card_page() throws Throwable {
		timecardSteps.emp_YourTimcard_Navigation();
		timecardSteps.emp_yourTimecard_Verify_PageLoading();
	}

	@When("^I delete all time pairs in timecard current pay period$")
	public void i_delete_all_time_pairs_in_timecard_current_pay_period() throws Throwable {

		timecardSteps.emp_yourTimecard_select_timePeriod("current");
		timecardSteps.emp_yourTimecard_Verify_PageLoading();
		List<String> dates = timecardSteps.emp_getListOfDates_withTimePairs();
		for (String date : dates) {
			System.out.println(" date is " + date);
			timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));
			timecardSteps.emp_yourTimecard_deleteTimePair(true);
			timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
		}
	}

	@When("^I delete all time pairs in timecard previous pay period$")
	public void i_delete_all_time_pairs_in_timecard_previous_pay_period() throws Throwable {

		timecardSteps.emp_yourTimecard_select_timePeriod("previous");
		timecardSteps.emp_yourTimecard_Verify_PageLoading();
		List<String> dates = timecardSteps.emp_getListOfDates_withTimePairs();
		for (String date : dates) {
			timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));
			timecardSteps.emp_yourTimecard_deleteTimePair(true);
			timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
		}

	}

	@Then("^I verify that your timecard page should be display$")
	public void i_verify_that_your_timecard_page_should_be_display() throws Throwable {
		timecardSteps.emp_youTime_verify_approveTimecard_pageLoading();
	}

	@When("^I add In time and out time on previous pay period date from timecard \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_add_In_time_and_out_time_for_previous_pay_period_date_from_timecard(String inTime, String outTime)
			throws Throwable {
		timecardSteps.emp_yourTimecard_select_timePeriod("previous");
		timecardSteps.emp_yourTimecard_Verify_PageLoading();
		List<Integer> dateList2 = timecardSteps.emp_yourTimecard_get_timePeriod_dateList("previous");
		timecardSteps.emp_yourTimecard_editTimePair(dateList2.get(0));
		timecardSteps.emp_yourTimecard_addTimepair(inTime, outTime, 0);
		timecardSteps.emp_youTimecard_saveTimePair(true);
		timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
	}

	@When("^I add In time punch for feature date from timecard$")
	public void i_add_In_time_punch_for_feature_date_from_timecard() throws Throwable {

		List<Integer> dateList3 = timecardSteps.emp_yourTimecard_get_timePeriod_dateList("current");

		timecardSteps.emp_yourTimecard_editTimePair(dateList3.get(0));
		timecardSteps.emp_yourTimecard_addTimepair("08:00 AM", "", 0);
		timecardSteps.emp_youTimecard_saveTimePair(true);
	}

	@And("^I validare clock employe clocked in punch on timecard$")
	public void iValidareClockEmployeClockedInPunchOnTimecard() throws Throwable {
		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		timecardSteps.emp_yourTimecard_enable_showDetails(true);

		List<String> timePunchs = timecardSteps.emp_yourTimecard_timecardGrid_GetPunchTime(Integer.parseInt(date));

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);
		}

		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockInTime); // punch
																														// time
																														// should
																														// be
																														// update

	}

	@Then("^I validare Clocked in punch on timecard$")
	public void i_validare_Clocked_in_punch_on_timecard() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));

		List<String> timePunchs = timecardSteps.emp_youtTimecard_GetPunchTime();

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);

		}
		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockInTime); // punch
																														// time
																														// should
																														// be
																														// update
	}

	@And("^I validare that meal entry should be displayed on timecard for clock employee$")
	public void iValidareThatMealEntryShouldBeDisplayedOnTimecardForClockEmployee() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		System.out.println(" time period is :" + timePeriod);

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		List<String> timePunchs = timecardSteps.emp_yourTimecard_timecardGrid_GetPunchTime(Integer.parseInt(date));

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);
		}

		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.mealOutTime); // punch
																														// time
																														// should
																														// be
																														// update

	}

	@And("^I validare that meal return should be displayed on timecard for clock employee$")
	public void iValidareThatMealReturnShouldBeDisplayedOnTimecardForClockEmployee() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		List<String> timePunchs = timecardSteps.emp_yourTimecard_timecardGrid_GetPunchTime(Integer.parseInt(date));

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);
		}

		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs,
				YourTimePortletsStepDefinition.mealReturnTime); // punch time should be update

	}

	@Then("^I validare that meal entry should be displayed on timecard$")
	public void i_validare_that_meal_entry_should_be_displayed_on_timecard() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		timecardSteps.emp_YourTimcard_Navigation();

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		System.out.println("pay period :" + timePeriod);

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));

		List<String> timePunchs = timecardSteps.emp_youtTimecard_GetPunchTime();

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);

		}
		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.mealOutTime); // punch
																														// time
																														// should
																														// be
																														// update

	}

	@Then("^I validare that meal return should be displayed on timecard$")
	public void i_validare_that_meal_return_should_be_displayed_on_timecard() throws Throwable {

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println("today date is : " + date);

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println("today month is : " + monthName);

		timecardSteps.emp_YourTimcard_Navigation();

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));

		List<String> timePunchs = timecardSteps.emp_youtTimecard_GetPunchTime();

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);

		}
		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs,
				YourTimePortletsStepDefinition.mealReturnTime); // punch time should be
		// update

	}

	@Then("^I validate that clock out entry should be display on timecard$")
	public void i_validare_that_clock_out_should_be_displayed_on_timecard() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_punch("0", YourTimecard.data.clockOut.toString());

//		String date = yourTimePortletsSteps.get_date("0", "date");
//
//		System.out.println("today date is : " + date);
//
//		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();
//
//		System.out.println("today month is : " + monthName);
//
//		timecardSteps.emp_YourTimcard_Navigation();
//		
//		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
//				Integer.parseInt(date));
//		
//		timecardSteps.emp_YourTimcard_Navigation();
//
//		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);
//		
//		timecardSteps.emp_yourTimecard_Verify_PageLoading();
//
//		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));
//
//		List<String> timePunchs = timecardSteps.emp_youtTimecard_GetPunchTime();
//
//		for (String timePunch : timePunchs) {
//			System.out.println("time card punches : " + timePunch);
//
//		}
//		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockOutTime); // punch time should be
//																							// update

	}

	@Then("^I validate that out entry should be display on timecard for clock employee$")
	public void i_validate_that_out_entry_should_be_display_on_timecard() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(date));

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		List<String> timePunchs = timecardSteps.emp_yourTimecard_timecardGrid_GetPunchTime(Integer.parseInt(date));

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);
		}

		timecardSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs, YourTimePortletsStepDefinition.clockOutTime); // punch
																															// time
																															// should
																															// be
																															// update
	}

	@When("^I adding IN time pair from timecard for current date$")
	public void i_adding_IN_time_pair_from_timecard_for_current_date() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String day = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + day);

		// String inTime = timecardSteps.get_date("0", "ESTHourAndTime");

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(day));

		System.out.println("time period " + timePeriod);

		yourTimePortletsSteps.emp_HomePage_Naviagation();

		String inTime = yourTimePortletsSteps.emp_yourTime_get_currentTime();

		System.out.println(" Time is :" + inTime);

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));

		timecardSteps.emp_yourTimecard_deleteTimePair(true);

		timecardSteps.emp_yourTimecard_clickOn_backToTimecard();

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));

		timecardSteps.emp_yourTimecard_addTimepair(inTime, "", 0);

		timecardSteps.emp_youTimecard_saveTimePair(true);
	}

	@When("^I adding Clock out time pair from time card for current date$")
	public void i_adding_Clock_out_time_pair_from_time_card_for_current_date() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String day = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + day);

		// String inTime = timecardSteps.get_date("0", "ESTHourAndTime");

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(day));

		System.out.println("time period " + timePeriod);

		yourTimePortletsSteps.emp_HomePage_Naviagation();

		String time = yourTimePortletsSteps.emp_yourTime_get_currentTime();

		System.out.println(" Time is :" + time);

		String data = time.split(":|\\ ")[2];

		String inTime = yourTimePortletsSteps.convert_toTime_addingMinutes(time, 10, false);

		inTime = inTime + " " + data;

		System.out.println(" intime is :" + inTime);

		String outTime = yourTimePortletsSteps.convert_toTime_addingMinutes(time, 5, false);

		outTime = outTime + " " + data;

		System.out.println(" Time is :" + outTime);

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));

		timecardSteps.emp_yourTimecard_deleteTimePair(true);

		timecardSteps.emp_yourTimecard_clickOn_backToTimecard();

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));

		timecardSteps.emp_yourTimecard_addTimepair(inTime, outTime, 0);

		timecardSteps.emp_youTimecard_saveTimePair(true);

	}

	@When("^I adding In time pair from timecard for feature date$")
	public void i_adding_In_time_pair_from_timecard_for_feature_date() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String day = yourTimePortletsSteps.get_date("1", "date");

		System.out.println(" date is :" + day);

		// String inTime = timecardSteps.get_date("0", "ESTHourAndTime");

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(day));

		System.out.println("time period " + timePeriod);

		yourTimePortletsSteps.emp_HomePage_Naviagation();

		String inTime = yourTimePortletsSteps.emp_yourTime_get_currentTime();

		System.out.println(" Time is :" + inTime);

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		List<String> dates = timecardSteps.emp_getListOfDates_withTimePairs();
		for (String l_day : dates) {
			timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(l_day));
			timecardSteps.emp_yourTimecard_deleteTimePair(true);
			timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
		}

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));

		timecardSteps.emp_yourTimecard_addTimepair(inTime, "", 0);

		timecardSteps.emp_youTimecard_saveTimePair(true);
	}

	@When("^I adding Clock out time pair from time card for feature date$")
	public void i_adding_Clock_out_time_pair_from_time_card_for_feature_date() throws Throwable {

		String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String day = yourTimePortletsSteps.get_date("1", "date");

		System.out.println(" date is :" + day);

		// String inTime = timecardSteps.get_date("0", "ESTHourAndTime");

		String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
				Integer.parseInt(day));

		System.out.println("time period " + timePeriod);

		yourTimePortletsSteps.emp_HomePage_Naviagation();

		String time = yourTimePortletsSteps.emp_yourTime_get_currentTime();

		System.out.println(" Time is :" + time);

		String data = time.split(":|\\ ")[2];

		String inTime = yourTimePortletsSteps.convert_toTime_addingMinutes(time, 10, false);

		inTime = inTime + " " + data;

		System.out.println(" intime is :" + inTime);

		String outTime = yourTimePortletsSteps.convert_toTime_addingMinutes(time, 5, false);

		outTime = outTime + " " + data;

		System.out.println(" Time is :" + outTime);

		timecardSteps.emp_YourTimcard_Navigation();

		timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

		timecardSteps.emp_yourTimecard_Verify_PageLoading();

		List<String> dates = timecardSteps.emp_getListOfDates_withTimePairs();
		for (String l_day : dates) {
			timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(l_day));
			timecardSteps.emp_yourTimecard_deleteTimePair(true);
			timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
		}

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));

		timecardSteps.emp_yourTimecard_addTimepair(inTime, outTime, 0);

		timecardSteps.emp_youTimecard_saveTimePair(true);

	}

	@Then("^I verify your timecard page loading$")
	public void i_verify_your_timecard_page_loading() throws Throwable {
		timecardSteps.emp_yourTimecard_Verify_PageLoading();
	}

	@Then("^I verify that time pairs rows created \"([^\"]*)\" and \"([^\"]*)\" $")
	public void i_verify_that_two_time_pairs_row_created(String arg1, String arg2) throws Throwable {

	}

	@When("^I update time pair total hours to more than five hours$")
	public void i_update_time_pair_total_hours_to_more_than_five_hours() throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		timePairs.add("08:00 AM-10:00 AM-02:00 HRS");
		timePairs.add("11:00 AM-01:00 PM-02:00 HRS");

		timecardSteps.emp_yourTimecard_add_timePairs(timePairs, "0", false);

	}

	@Then("^I verify that (\\d+) minutes deducted from time pair total hours$")
	public void i_verify_that_minutes_deducted_from_time_pair_total_hours(int arg1) throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		timePairs.add("08:00 AM-10:00 AM-02:00 HRS");
		timePairs.add("11:00 AM-01:00 PM-02:00 HRS");

		timecardSteps.emp_yourTimecard_verify_timepairs_and_totalHours(timePairs, "0");

	}

	@Then("^I delete all time pairs \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_delete_all_time_pairs(String arg1, String arg2) throws Throwable {

		timecardSteps.emp_yourTimecard_delete_timePairs(arg1, Boolean.parseBoolean(arg2));
	}

	@Then("^I validate that timecard should be editable$")
	public void i_validate_that_timecard_should_be_editable() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_readOnlyStatus(false);
	}

	@Then("^I click on backToTimecard link$")
	public void i_click_on_backToTimecard_link() throws Throwable {
		timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
	}

	@Then("^I validate that clock in entry should be display on timecard$")
	public void i_validate_that_clock_in_entry_should_be_display_on_timecard() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_punch("0", YourTimecard.data.clockIn.toString());
	}

	@Then("^I validate that clock in entry note should be display on timecard$")
	public void i_validate_that_clock_in_entry_note_should_be_display_on_timecard() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence(true);

	}

	@Then("^I validate that take a meal entry should be displayed on timecard$")
	public void i_validate_that_take_a_meal_entry_should_be_displayed_on_timecard() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_punch("0", YourTimecard.data.takeAMeal.toString());

	}

	@Then("^I validate that take a meal entry note should be display on timecard$")
	public void i_validate_that_take_entry_note_should_be_display_on_timecard() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence(true);
	}

	@Then("^I validate that meal return entry should be displayed on timecard$")
	public void i_validate_that_meal_return_entry_should_be_displayed_on_timecard() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_punch("0", YourTimecard.data.mealReturn.toString());

	}

	@Then("^I validate that meal return entry note should be displayed on timecard$")
	public void i_validate_that_meal_return_entry_note_should_be_displayed_on_timecard() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence(true);
	}

	@Then("^I validate that clock out entry with note should  be display on timecard$")
	public void i_validate_that_clock_out_entry_with_note_should_be_display_on_timecard() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence(true);
	}

	@Then("^I validate that time pair row created with In entry and out entry is blank and total hours is \"([^\"]*)\"$")
	public void i_validate_that_time_pair_row_created_with_In_entry_and_out_entry_is_blank_and_total_hours_is(
			String arg1) throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		String clockIN = YourTimePortletsStepDefinition.clockInTime;

		timePairs.add(clockIN + "-" + "" + "-00:00 HRS");

		for (String pair : timePairs) {
			System.out.println("time pair :  " + pair);
		}

		timecardSteps.emp_yourTimecard_verify_timepairs_and_totalHours(timePairs, "0");

		// timecardSteps.emp_yourTimecard_Verify_totalHours("0",arg1);

	}

	@When("^I validate that closed time pairs should be generated and total hours calculated$")
	public void i_validate_that_closed_time_pairs_should_be_generated_and_total_hours_calculated() throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		String clockIN = YourTimePortletsStepDefinition.clockInTime;
		String takeaMeal = YourTimePortletsStepDefinition.mealOutTime;
         
		String calculatedHours =  timecardSteps.calculate_hours(clockIN,takeaMeal);
	   
		timePairs.add(clockIN + "-" + takeaMeal + "-"+calculatedHours+" HRS");
		

		for (String pair : timePairs) {
			System.out.println("time pair :  " + pair);
		}

		timecardSteps.emp_yourTimecard_verify_timepairs_and_totalHours(timePairs, "0");

	}

	@When("^I validate that two closed time pair rows should be presence$")
	public void i_validate_that_two_closed_time_pair_rows_should_be_presence() throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		String date = yourTimePortletsSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));

		timePairs = timecardSteps.emp_yourTimecard_getTimePairs();

		assertTrue("verify time pair rows count ", timePairs.size() == 2);

	}

	@When("^I validate that two closed time pair should be generated and total hours calculated$")
	public void i_validate_that_closed_time_pair_should_be_generated_and_total_hours_calculated() throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		String clockIN = YourTimePortletsStepDefinition.clockInTime;
		String takeaMeal = YourTimePortletsStepDefinition.mealOutTime;
		String mealReturn = YourTimePortletsStepDefinition.mealReturnTime;
		String clockOut = YourTimePortletsStepDefinition.clockOutTime;

		
		String calculatedHours1 =  timecardSteps.calculate_hours(clockIN,takeaMeal);
		   
		timePairs.add(clockIN + "-" + takeaMeal + "-"+calculatedHours1+" HRS");
		
		
		String calculatedHours2 =  timecardSteps.calculate_hours(mealReturn,clockOut);
		   
		timePairs.add(mealReturn + "-" + clockOut + "-"+calculatedHours2+" HRS");
		
		for (String pair : timePairs) {
			System.out.println("time pair :  " + pair);
		}

		timecardSteps.emp_yourTimecard_verify_timepairs_and_totalHours(timePairs, "0");
	}

	@Then("^I validate that new time pair row created with in entry and out entry should be blank and total hours is \"([^\"]*)\"$")
	public void i_validate_that_new_time_pair_row_created_with_in_entry_and_out_entry_should_be_blank_an_total_hours_is(
			String arg1) throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		String clockIN = YourTimePortletsStepDefinition.clockInTime;
		String takeaMeal = YourTimePortletsStepDefinition.mealOutTime;
		String mealReturn = YourTimePortletsStepDefinition.mealReturnTime;

		String calculatedHours =  timecardSteps.calculate_hours(clockIN,takeaMeal);
		
		timePairs.add(clockIN + "-" + takeaMeal + "-"+calculatedHours+" HRS");
		
		
		timePairs.add(mealReturn + "-" + "" + "-00:00 HRS");


		for (String pair : timePairs) {
			System.out.println("time pair :  " + pair);
		}
		timecardSteps.emp_yourTimecard_verify_timepairs_and_totalHours(timePairs, "0");

	}

	@When("^I Navigate to your timecard$")
	public void i_Navigate_to_your_timecard() throws Throwable {
		timecardSteps.emp_YourTimcard_Navigation();
	}

	@When("^I delete all  time pairs in current payperiod$")
	public void i_delete_all_time_pairs_in_current_payperiod() throws Throwable {

		timecardSteps.emp_yourTimecard_delete_timePairs(YourTimecard.data.toDay.toString(), true);

	}

	@When("^I add time pair to previous day as in time \"([^\"]*)\" and out time \"([^\"]*)\"$")
	public void i_add_time_pair_to_previous_day_as_in_time_and_out_time(String arg1, String arg2) throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		timePairs.add(arg1 + "-" + arg2);

		timecardSteps.emp_yourTimecard_add_timePairs(timePairs, "-1", false);
	}

	@When("^I add new row and time pair to previous day as in time \"([^\"]*)\" and out time \"([^\"]*)\"$")
	public void i_add_new_row_and_time_pair_to_previous_day_as_in_time_and_out_time(String arg1, String arg2)
			throws Throwable {

		List<String> timePairs = new ArrayList<String>();

		timePairs.add(arg1 + "-" + arg2);

		timecardSteps.emp_yourTimecard_add_timePairs(timePairs, "-1", true);
	}

	@Then("^I have observed that missed punch note should be display for previous day$")
	public void i_have_observed_that_missed_punch_note_should_be_display() throws Throwable {

		HashMap<String, String> monthDate = new HashMap<String, String>();

		monthDate = timecardSteps.emp_yourTimecard_select_payPeriod("-1");

		timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(monthDate.get(YourTimecard.data.date.toString())));

		timecardSteps.emp_yourTimecard_verify_note_presence(true);

	}

	@When("^I have updated missed punch note from timecard$")
	public void i_have_updated_missed_punch_note_from_timecard() throws Throwable {

		YourTimePortletsStepDefinition.note = "updated note";

		timecardSteps.emp_yourTimecard_updateNote(YourTimePortletsStepDefinition.note, 1);

		timecardSteps.emp_youTimecard_saveTimePair(true);

	}

	@Then("^I validate that clock in entry should be display on timecard for clock employe$")
	public void i_validate_that_clock_in_entry_should_be_display_on_timecard_for_clock_employe() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_punch_clockEmp("0", YourTimecard.data.clockIn.toString());
	}

	@Then("^I validate that clock in entry note should be display on timecard for clock employe$")
	public void i_validate_that_clock_in_entry_note_should_be_display_on_timecard_for_clock_employe() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence_clockEmp("0", true);

	}

	@Then("^I validate that take a meal entry should be displayed on timecard for clock employe$")
	public void i_validate_that_take_a_meal_entry_should_be_displayed_on_timecard_for_clock_employe() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_punch_clockEmp("0", YourTimecard.data.takeAMeal.toString());
	}

	@Then("^I validate that take a meal entry note should be display on timecard for clock employe$")
	public void i_validate_that_take_a_meal_entry_note_should_be_display_on_timecard_for_clock_employe()
			throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence_clockEmp("0", true);
	}

	@Then("^I validate that meal return entry should be displayed on timecard for clock employe$")
	public void i_validate_that_meal_return_entry_should_be_displayed_on_timecard_for_clock_employe() throws Throwable {

		timecardSteps.emp_yourTimecard_verify_punch_clockEmp("0", YourTimecard.data.mealReturn.toString());
	}

	@Then("^I validate that meal return entry note should be displayed on timecard for clock employe$")
	public void i_validate_that_meal_return_entry_note_should_be_displayed_on_timecard_for_clock_employe()
			throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence_clockEmp("0", true);
	}

	@Then("^I validate that clock out entry should be display on timecard for clock employe$")
	public void i_validate_that_clock_out_entry_should_be_display_on_timecard_for_clock_employe() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_punch_clockEmp("0", YourTimecard.data.clockOut.toString());
	}

	@Then("^I validate that clock out entry with note should  be display on timecard for clock employe$")
	public void i_validate_that_clock_out_entry_with_note_should_be_display_on_timecard_for_clock_employe()
			throws Throwable {

		timecardSteps.emp_yourTimecard_verify_note_presence_clockEmp("0", true);
	}

	@Then("^I verify that pending for manager approval message should be display$")
	public void i_verify_that_pending_for_manager_approval_message_should_be_display() throws Throwable {
		timecardSteps.emp_verify_element_existence(YourTimecard.data.pendingForManagerApproval, true);
	}

	@Then("^I Verify that \"([^\"]*)\" should be display$")
	public void i_Verify_that_message_should_be_display(String arg1) throws Throwable {
		
		timecardSteps.emp_yourTimecard_verify_element_existence(arg1);
	}
	
	@When("^I click on \"([^\"]*)\" button$")
	public void i_click_on_button(String arg1) throws Throwable {
	    
		timecardSteps.emp_yourTimecard_clickOn_element(arg1);
	}
	
	

}
