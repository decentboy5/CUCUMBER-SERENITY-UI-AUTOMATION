package com.adp.tempus.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class ReviewTimecardRUN extends GenericPageObject {

	@FindBy(xpath = "//span[contains(.,'Review Timecards')]/preceding-sibling::span")
	public WebElementFacade btn_ReviewTimecard;

	@FindBy(xpath = "//span[contains(.,'Run Payroll')]")
	public WebElementFacade btn_RunPayroll;

	@FindBy(xpath = "//span[contains(.,'Time Management')]")
	public WebElementFacade btn_TimeManagement;

	// @FindBy(xpath = "//input[@id='ddEmployee_input']")
	// public WebElementFacade ddl_Employee;

	@FindBy(xpath = "//div[@class='dvEmpMain']")
	public WebElementFacade btn_EmpIDBar;

	@FindBy(xpath = "//i[@class='fa fa-trash-o']")
	public WebElementFacade btn_deleteMyADP;
	
	@FindBy(xpath = "//i[@class='fa fa-comment']")
	public WebElementFacade btn_commentMyADP;
	

	@FindBy(xpath = "(//span[@class='vdl-date-time-picker__select']/button)[1]")
	public WebElementFacade img_InTime;

	@FindBy(xpath = "(//span[@class='vdl-date-time-picker__select']/button)[2]")
	public WebElementFacade img_OutTime;

	@FindBy(xpath = "(*//div[@class='vdl-timelist-popup vdl-popup vdl-popup--animate']/div/div/ul/li[1])[1]")
	public WebElementFacade popup_InTime;

	@FindBy(xpath = "(*//div[@class='vdl-timelist-popup vdl-popup vdl-popup--animate']/div/div/ul/li[2])[2]")
	public WebElementFacade popup_OutTime;

	By empnamedropdown = By.xpath("//input[@id='ddEmployee_input']");

	@FindBy(xpath = "//div[contains(@class,'label--unchecked')]")
	public WebElementFacade btn_Toggle;

	@FindBy(xpath = "//div[@class='arrow right arrowActive']")
	public WebElementFacade btn_rightarrow;

	@FindBy(xpath = "//div[@class='hours-total ng-binding']")
	public WebElementFacade lbl_totalhours;

	@FindBy(xpath = "//a[contains(.,'Time')]")
	public WebElementFacade btn_Time;
	
	@FindBy(xpath = "//a[contains(.,'Dashboard')]")
	public WebElementFacade btn_Dashboard;

	String tcMyADPGridDate = "//div[contains(@class,'cell-date ng-binding')]";

	@FindBy(xpath = "//div[@class='hours-total ng-binding']")
	public WebElementFacade lbl_totalPeriodHourMyADP;

	@FindBy(xpath = "//i[@class='fa adp-fa-icon-ellipses-vertical only-icon']")
	public WebElementFacade btn_ellipses;

	@FindBy(xpath = "//span[contains(text(),'Save and Close')]")
	public WebElementFacade btn_SaveandCloseMyADP;

	@FindBy(xpath = "//i[@class='fa adp-fa-icon-close-x only-icon']")
	public WebElementFacade btn_CancelMyADP;

	@FindBy(xpath = "//span[contains(.,'Home')]")
	public WebElementFacade btn_ClickonHome;

	@FindBy(xpath = "//a[@class='enterpayroll arrow button button-green']")
	public WebElementFacade btn_EnterPayroll;

	@FindBy(xpath = "//a[@id='btnADPTimekeepingResolveException']")
	public WebElementFacade btn_ResolveException;

	@FindBy(xpath = "//button[@id='btnback']")
	public WebElementFacade btn_Sliderback;

	String txt_MyADPIn = "//input[@name='In']";
	String txt_MyADPOut = "//input[@name='Out']";
	
	@FindBy(xpath = "//textarea[@class='espresso-input-element']")
	public WebElementFacade txt_Notes;

	//String txt_MyADPNotes = "//textarea[@class='espresso-input-element']";
	
	@FindBy(xpath = "//input[@id='txtSearch']")
	private WebElementFacade txt_ClientSearch;

	@FindBy(xpath = "//button[@id='btnFilter']")
	private WebElementFacade btn_Find;

	@FindBy(xpath = "//a[@class='GridStaticLinkText CwcHyperLink']")
	private WebElementFacade lnk_ClientName;

	@FindBy(xpath = "//span[@class='dropdown']")
	private WebElementFacade btn_dropdown;

	@FindBy(xpath = "//img[contains(@src,'timecardmngr.png')]")
	private WebElementFacade img_Timecard;

	@FindBy(xpath = "//table[@id='TcGrid']")
	private WebElementFacade tbl_TimecardGrid;

	@FindBy(xpath = "//table[@id='TcGrid']/descendant::div[@class='StatusColBkgdImage']")
	public List<WebElementFacade> rows_Timecard;
	
	@FindBy(xpath = "(//td[text()='Delete Row'])")
	public List<WebElementFacade> rows_Delete;
	
	@FindBy(xpath = "(//*[text()='OK']/ancestor::span[1])")
	public List<WebElementFacade> btn_OK;
	
	@FindBy(xpath = "//div[text()='Operation Successful.']")
	public WebElementFacade lbl_OperationSuccessful;
	
	@FindBy(xpath = "//a[contains(.,'Resolve Exceptions')]")
	public WebElementFacade btn_ResolveExceptions;
	
	@FindBy(id = "iFramebtnClose")
	public WebElementFacade btn_iFrameSliderClose;
	
	@FindBy(xpath = "//span[@class='fa fa-plus-circle']")
	public List<WebElementFacade> btn_AddTimePair;

	@FindBy(xpath = "//input[@id='employeeSearch']")
	public WebElementFacade txt_EmployeeSearch;
	
	@FindBy(xpath = "//input[@id='dtTermDate_input']")
	public WebElementFacade ddl_TermDate;
	
	@FindBy(xpath = "//input[@id='dtHireDate_input']")
	public WebElementFacade ddl_HireDate;
	
	@FindBy(xpath = "//a[@id='TERMINATE_EMPLOYEE']")
	public WebElementFacade lnk_TerminateEmployee;
	
	@FindBy(xpath = "//button[text()='Terminate Employee']")
	public WebElementFacade btn_TerminateEmployee;
	
	@FindBy(xpath = "//a[text()='Employee Info']")
	public WebElementFacade lnk_EmployeeInfo;
	
	@FindBy(xpath = "//button[@id='btnRehire']")
	public WebElementFacade btn_Rehire;
	
	@FindBy(xpath = "//span[@class='fa fa-print']")
	public WebElementFacade btn_Print;
	
	@FindBy(xpath = "//input[@name='hours']")
	public WebElementFacade txt_MyADPHours;
	
	@FindBy(xpath = "//span[contains(.,'Submit Time Off')]")
	public WebElementFacade btn_SubmitTimeOff;
	
	@FindBy(xpath = "//span[contains(.,'Save')]")
	public WebElementFacade btn_SavePTO;

	@FindBy(xpath = "//span[text()='Clock In']")
	public WebElementFacade btn_ClockIn;

	@FindBy(xpath = "//span[text()='Clock Out']")
	public WebElementFacade btn_ClockOut;
	
	@FindBy(xpath = "//div[text()='Clocked In']")
	public WebElementFacade lbl_ClockIn;
	
	@FindBy(xpath = "//div[text()='Clocked Out']")
	public WebElementFacade lbl_ClockOut;

	@FindBy(xpath = "//input[@id='timeoff-edittimeoff-hours']")
	public WebElementFacade txt_PTOHours;
	
	@FindBy(xpath = "//span[contains(.,'EDIT TIMEOFF')]")
	public WebElementFacade btn_EditTimeOff;
	
	By addTimecardGrid=By.xpath(".//span[@class='fa fa-plus-circle']");
	By editTimecardGrid=By.xpath(".//span[@class='fa fa-pencil tc-day-entry-icon']");
	By noteTimecardGrid=By.xpath(".//span[contains(@class,'fa tc-day-entry-icon fa-comment')]");	
	By clockStatus=By.xpath(".//div[@class='timecard-clocked-in-label']");
	By clockInTime=By.xpath(".//div[@class='timecard-clocked-in-time']");
	By addNote = By.xpath("//div[@class='tc-add-new-note-icon-text']");
	By enterNote = By.xpath(".//div[contains(@class,'tc-add-notes-text-box')]/textarea");
	By payPeriodComboBox=By.xpath("//div[@class='vdl-col-lg-12 tc-time-period-list']");

	String inPunchTextBox = ".//div[contains(@class,'tc-in-time-entry-text-box')]/descendant::input";
	String outPunchTextBox = ".//div[contains(@class,'tc-out-time-entry-text-box')]/descendant::input";
	By ddl_SelectStatus = By.xpath(".//select[@id='employeeStatus']");
	
	
	
	
	public void reviewTimecard() {

		
		// selectFrame(getDriver().findElement(By.xpath("//iframe[@id='taxFormIFrame']")));
		btn_ClickonHome.click();
		scrollIntoView(btn_ReviewTimecard);		
		btn_ReviewTimecard.waitUntilVisible();
		btn_ReviewTimecard.click();
		btn_EmpIDBar.waitUntilVisible();
	}

	public void SelectEmpDropDown(String EmpName, String Visibility) {
		
		if(Visibility.equals("ON"))
		{
		waitABit(1000);
		// ddl_Employee.sendKeys(EmpName);
		while (!getDriver().findElement(By.xpath("//div[@title='" + EmpName + "']")).isDisplayed()) {
			btn_rightarrow.click();
		}
		getDriver().findElement(By.xpath("//div[@title='" + EmpName + "']")).click();
		waitABit(4000);
		selectFrame(getDriver().findElement(By.xpath("//iframe[@id='iframeTempus']")));
		waitABit(1000);
		btn_Toggle.waitUntilVisible();
		// }
		}
		else
		{
	    if(Visibility.equals("OFF"))
	    {
			waitABit(2000);
			boolean found = true;
			try
			{
			while (!getDriver().findElement(By.xpath("//div[@title='" + EmpName + "']")).isDisplayed())
			{
				btn_rightarrow.click();
			}
			}
			catch(Exception e)
			{
				
			}
			found = false;
			
			Assert.assertNotEquals(true, found);			
		}
		}
		
	}

	public void SelectToggleButton() {
		waitABit(3000);
		btn_Toggle.click();
		waitABit(4000);

	}

	public void SelectTimePickerIcon(String intime, String outtime) {
		img_InTime.click();
		waitABit(1500);
		getDriver().findElement(By.xpath("(//*[contains(@id,'_time_listbox__option')][.='" + intime + "'])[1]"))
				.click();
		waitABit(1500);
		img_OutTime.click();
		waitABit(1500);
		getDriver().findElement(By.xpath("(//*[contains(@id,'_time_listbox__option')][.='" + outtime + "'])[2]"))
				.click();

	}

	public void VerifyPayCodeSummary(String PayCodeSummaryHours) {
		
		
		Assert.assertEquals("Verifying hours on pay code summary", true,
				checkElementVisible("//div[@class='tc-pay-summary']/div[@class='vdl-card']/div/div[@class='tc-pay-summary-content vdl-card-content']/div[@class='vdl-row tc-week-header-row']/div/div[2]/div/div/div[contains(text(),'"+ PayCodeSummaryHours +"')]"));
		
		
		/*Assert.assertEquals("Verifying hours on pay code summary", true,
				checkElementVisible("//span[contains(text(),'Hours')]/../div/div[2]//span[contains(text(),'"
						+ PayCodeSummaryHours + "')]"));*/

	}

	public void VerifyHourDistType(String HourDistType) {

		Assert.assertEquals("Verifying hour dist type on pay code summary", true,
				checkElementVisible("//div[@class='tc-pay-summary']//div[contains(text(),'" + HourDistType + "')]"));

	}

	public void validateExceptions(String ExceptionType) {
		if (ExceptionType.contentEquals(""))
			return;
		switch (ExceptionType.toUpperCase().trim()) {
		case "OVERNIGHT":
			
			Assert.assertEquals("Verifying overnight error", true,
					checkElementVisible("//span[contains(text(),'Overnight')]"));
			break;
		case "OVERLAP":
			/*Assert.assertEquals("Verifying overlap error", true,
					checkElementVisible("//div[contains(text(),'The time pair overlaps with another time pair')]"));*/
			Assert.assertEquals("Verifying overlap error", true,
					checkElementVisible("(//div[@class='tc-time-entry-header-total-time tc-total-time-div error'])[1]"));
			break;
		case "MISSING INPUNCH":

			break;
		case "MISSING OUTPUNCH":
			Assert.assertEquals("Verifying missing outpunch error", true,
					checkElementVisible("//div[contains(text(),'Missing Punch')]"));
			
		
			break;

		}
	}

	public void ClickTimeIcon() {
		
		waitABit(10000);
		btn_Time.waitUntilVisible();
		btn_Time.click();
		waitABit(2000);
		lbl_totalhours.waitUntilVisible();

	}
	
    public void ClickDashboardIcon() {
		
		waitABit(10000);
		btn_Dashboard.waitUntilVisible();
		btn_Dashboard.click();
		waitABit(2000);
		lbl_ClockIn.waitUntilVisible();

	}

	public List<WebElement> getMyADPTimecardBlocks() {
		List<WebElement> tcDayCards = null;
		tcDayCards = getDriver().findElements(By.xpath("//div[@class='timecard-day-summary']"));
		if (tcDayCards.isEmpty()) {
			Assert.assertTrue("No Timecard displayed on My ADP Timecard Page", false);
		}
		return tcDayCards;
	}

	public WebElement findMyADPTimecardBlock(String strDate) {
		WebElement timcardDayBlock = null;
		try{
			
		int actDate;
		String crntActDate = "";
		String newStr = "";
		boolean tcFound = false;
		List<WebElement> tcDayCards = getDriver().findElements(By.xpath(".//div[contains(@class,'time-calendar-table-cell timecard-day')]"));
		if (!tcDayCards.isEmpty()) {
			//for (WebElement tcDay : tcDayCards) {
			for(int i=0;i<=tcDayCards.size();i++) {	
			crntActDate = tcDayCards.get(i).getAttribute("id");
			int trimActDate=Integer.parseInt(crntActDate.replace("day",""));
			int trimActDate1 = Integer.parseInt(crntActDate.substring(4));
//				if (crntActDate.length() > 2) {
//					newStr = crntActDate.substring(4, crntActDate.length()).trim();
//					actDate = Integer.parseInt(newStr);
//				} else {
//					actDate = Integer.parseInt(crntActDate);
//					//Integer.parseInt(tcDay.findElement(By.xpath(tcMyADPGridDate)).getText());
//				}
				if (trimActDate1 == Integer.parseInt(strDate)) {
					timcardDayBlock = tcDayCards.get(i);
					tcFound = true;
					break;
				}
//
//				timcardDayBlock = tcDay;
//				tcFound = true;
//				break;
			}
			if (!tcFound) {
				Assert.assertTrue("Given Timepair/Hour Date not found on Timecard", false);
			}
		}
		}catch(Exception e) {
			
		}
		return timcardDayBlock;
	}

	public void clickButtonMyADPTimecardGrid(String strDate, String strButton) {
		if (!strDate.contentEquals("")) {
			waitABit(2000);
			WebElement tcDayBlock = findMyADPTimecardBlock(strDate);
			switch (strButton.toUpperCase()) {
			case "ADD":
				// tcDayBlock.findElement(By.xpath(".//span[@class='fa
				// fa-plus-circle']")).click();
				scrollIntoView(tcDayBlock.findElement(By.xpath("//i[@class='fa adp-fa-icon-plus']")));
				tcDayBlock.findElement(By.xpath(".//i[@class='fa adp-fa-icon-plus']")).click();
				break;
			case "EDIT":
				// tcDayBlock.findElement(By.xpath(".//span[@class='fa fa-pencil
				// tc-day-entry-icon']")).click();
				scrollIntoView(tcDayBlock.findElement(By.xpath("//i[@class='fa fa-pencil only-icon']")));
				tcDayBlock.findElement(By.xpath("//i[@class='fa fa-pencil only-icon']")).click();
				break;
			case "NOTE":
				// tcDayBlock.findElement(By.xpath(".//span[contains(@class,'fa
				// tc-day-entry-icon fa-comment')]")).click();
				scrollIntoView(tcDayBlock.findElement(By.xpath("//i[@class='fa fa-comment primary-link']")));
				tcDayBlock.findElement(By.xpath("//i[@class='fa fa-comment primary-link']")).click();
				break;
			}
		}
	}

	public void deleteTimePairHourMyADP(List<WebElement> objDelete) {
		for (int i = objDelete.size() - 1; i >= 0; i--) {
			objDelete.get(0).click();
			waitABit(2000);
			if (checkElementVisible(btn_deleteMyADP)) {
				btn_deleteMyADP.click();
				waitABit(2000);
				btn_SaveandCloseMyADP.click();
				// msg_FailedToDelete.shouldNotBeVisible();
			}
		}
	}

	public void submitTimePairMyADP(String punchType, String findInPunch, String inPunch, String outPunch) {
		if (punchType.contentEquals(""))
			return;
		switch (punchType.toUpperCase().trim()) {
		case "ADD PUNCH":
			enterTimePunchesMyADP(txt_MyADPIn, inPunch);
			enterTimePunchesMyADP(txt_MyADPOut, outPunch);
			enterNotesMyADP("Notes entered");
			break;
		/*
		 * case "RESOLVE PUNCH": resolveMissedPunch(txt_MyADPIn, txt_MyADPOut, inPunch,
		 * outPunch); break; case "DELETE PUNCH": employeeDeletesTimePair(inPunch,
		 * outPunch); break; case "EDIT PUNCH": employeeEditsTimePair(findInPunch,
		 * inPunch, outPunch);
		 */
		}
	}

	public void enterTimePunchesMyADP(String by, String Punch) {
		// if(Punch.contentEquals("")) return;
		boolean found = false;
		List<WebElement> objPunch = getDriver().findElements(By.xpath(by));
		for (WebElement objP : objPunch) {
			System.out.println(objP.getAttribute("value"));
			if (objP.getAttribute("value").contentEquals("")) {
				objP.sendKeys(Punch, Keys.TAB);
				found = true;
				break;
			}
		}

	}
	
	public void enterNotesMyADP(String Notes) {
		
		getDriver().findElement(By.xpath("//i[@class='fa adp-fa-icon-ellipses-vertical only-icon']")).click();
		waitABit(1000);
		btn_commentMyADP.click();
		waitABit(1000);
		txt_Notes.sendKeys(Notes);

	}

	public void enterHoursMyADP(String PTOPayCode, String Hours)
	{
	//	getDriver().findElement(By.xpath("//i[@class='fa adp-fa-icon-ellipses-vertical only-icon']")).click();
		waitABit(1000);
		getDriver().findElement(By.xpath("//a[contains(.,'Optional Optional')]")).click();
		waitABit(1000);
		getDriver().findElement(By.xpath("(//input[@type='search'])[2]")).sendKeys(PTOPayCode);
		getDriver().findElement(By.xpath("(//input[@type='search'])[2]")).sendKeys(Keys.TAB);
		txt_MyADPHours.sendKeys(Hours);		
	}	
	
	
	public void enterPTOTimecard(String PTOPayCode, String Hours)
	{
		btn_SubmitTimeOff.waitUntilClickable();
		btn_SubmitTimeOff.click();
		waitABit(5000);
		scrollIntoView(getDriver().findElement(By.xpath("//span[contains(.,'Save')]/..")));
		Actions actions = new Actions(getDriver());
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
		getDriver().findElement(By.xpath("//span[contains(.,'Save')]/..")).click();
		scrollIntoView(getDriver().findElement(By.xpath("//li[contains(text(),'Time Off has been created ')]")));		
		Assert.assertEquals("Verifying PTO", true,
				checkElementVisible("//li[contains(text(),'Time Off has been created ')]"));
	
		//Actions actions = new Actions(getDriver());
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();

		//scrollIntoView(getDriver().findElement(By.xpath("//span[contains(text(),'Cancel')]/..")));
		//((JavascriptExecutor)getDriver()).executeScript("window.scrollTo(document.body.scrollHeight,0)");	
		
		getDriver().findElement(By.xpath("//div[@id='timeoff-snackbar-back']")).click();
		
		
	}
	
	public void editPTOTimecard(String updatedhours)
	{
		btn_EditTimeOff.click();
		scrollIntoView(txt_PTOHours);
		txt_PTOHours.clear();
		txt_PTOHours.clear();
		txt_PTOHours.sendKeys(updatedhours);
		txt_PTOHours.sendKeys(Keys.TAB);
		scrollIntoView(getDriver().findElement(By.xpath("//span[contains(.,'Save')]/..")));
		Actions actions = new Actions(getDriver());
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();

		getDriver().findElement(By.xpath("//span[contains(.,'Save')]/..")).click();
		scrollIntoView(getDriver().findElement(By.xpath("//li[contains(text(),'Time Off has been updated ')]")));		
		Assert.assertEquals("Verifying PTO", true,
				checkElementVisible("//li[contains(text(),'Time Off has been updated ')]"));
		//Actions actions = new Actions(getDriver());
		scrollIntoView(getDriver().findElement(By.xpath("//span[contains(.,'Save')]/..")));

		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();

		//scrollIntoView(getDriver().findElement(By.xpath("//span[contains(text(),'Cancel')]/..")));
		//((JavascriptExecutor)getDriver()).executeScript("window.scrollTo(document.body.scrollHeight,0)");	
		
		getDriver().findElement(By.xpath("//div[@id='timeoff-snackbar-back']")).click();
		
	}
	
	public void PunchOperation(String PunchType)
	{
		switch(PunchType.toUpperCase().trim())
		{
		case "CLOCKIN":
			btn_ClockIn.click();
			waitABit(2000);		
			lbl_ClockIn.waitUntilVisible();
			break;
		case "CLOCKOUT":
			btn_ClockOut.click();
			waitABit(2000);
			lbl_ClockOut.waitUntilVisible();
			break;
		
		}
	}
	
	
	public void clickButtonMyADPAddTimePair(String btnName) {
		if (btnName.contentEquals(""))
			return;
		switch (btnName.toUpperCase().trim()) {
		case "SAVE":
			btn_SaveandCloseMyADP.click();
			waitABit(2000);
			break;
		case "CANCEL":
			btn_CancelMyADP.click();
			waitABit(2000);
			break;

		}
	}
	
	public void AddEditNotesToTimePairRUN(String inPunch, String outPunch, String instance, String noteType,
			String NoteText) {
		if (inPunch.contentEquals("") && noteType.contentEquals(""))
			return;
		WebElement timePairCard = findTimePairCardRUN(inPunch, outPunch, instance);
		switch (noteType.toUpperCase()) {
		case "ADD NOTE":
			WebElement objAddNote = timePairCard.findElement(addNote);
			objAddNote.click();
			WebElement objenterNote = timePairCard.findElement(enterNote);
			enterNoteTextToTimePairRUN(objenterNote, NoteText);
			break;
		case "EDIT NOTE":
			WebElement objEnterNote = timePairCard.findElement(enterNote);
			enterNoteTextToTimePairRUN(objEnterNote, NoteText);
			break;
		// case "REMOVE NOTE":
		// WebElement objEnterNote = timePairCard.findElement(enterNote);
		// enterNoteTextToTimePair(objEnterNote, NoteText);
		// break;
		}

	}
	
	
	public void enterNoteTextToTimePairRUN(WebElement objNoteText, String noteText) {
		objNoteText.clear();
		objNoteText.sendKeys(noteText);
	}
	
	public WebElement findTimePairCardRUN(String inPunch, String outPunch, String instance) {
		WebElement objCard = null;
		if (inPunch.contentEquals("") && instance.contentEquals(""))
			return null;
		List<WebElement> timePairs = getTimePairCardsRUN();
		WebElement objInPunch = null;
		WebElement objOutPunch = null;
		if (!instance.contentEquals("")) {
			int cardInstance = Integer.parseInt(instance);
			objCard = timePairs.get(cardInstance);
			if (objCard == null) {
				Assert.assertTrue("Time Pair not found with given instance", false);
			}
		} else {
			for (WebElement timePair : timePairs) {
				objInPunch = timePair.findElement(By.xpath(inPunchTextBox));
				objOutPunch = timePair.findElement(By.xpath(outPunchTextBox));
				System.out.println(objInPunch.getAttribute("value").trim());
				System.out.println(objOutPunch.getAttribute("value").trim());
				if (objInPunch.getAttribute("value").trim().contentEquals(inPunch)
						&& objOutPunch.getAttribute("value").trim().contentEquals(outPunch)) {
					objCard = timePair;
					break;
				}
			}
		}
		return objCard;
	}

	public List<WebElement> getTimePairCardsRUN(){
		List<WebElement> timePairCards = null;
		try {
			timePairCards = getDriver().findElements(
					By.xpath(".//div[@class='wfnx-small-card tc-time-entry-card']"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return timePairCards;
	}
	
	
	public void clickonHomeandRunPayrollTempus() {

		getDriver().switchTo().defaultContent();
		btn_ClickonHome.waitUntilClickable();
		btn_ClickonHome.click();
		/*if (getDriver().findElement(By.xpath("//span[text()='Something you should be aware of']")).isDisplayed()) {
			getDriver().findElement(By.xpath("//button[text()='OK']")).click();
		}*/
		waitABit(2000);
		btn_RunPayroll.waitUntilVisible();
		btn_RunPayroll.click();
		btn_EnterPayroll.waitUntilVisible();
		getDriver().findElement(By.xpath("(//span[@class='ui-button-icon-primary ui-icon ui-icon-triangle-1-s'])[3]")).click();
		waitABit(1000);
		getDriver().findElement(By.xpath("//a[contains(.,'Monthly')]")).click();
		waitABit(1000);
		getDriver().findElement(By.xpath("//a[@class='enterpayroll arrow button button-green']")).click();
		btn_ResolveException.waitUntilVisible();
		btn_ResolveException.click();
		btn_Sliderback.waitUntilVisible();
	}

	public void deleteTimepairsMyADPTimecards() {
		// get days with time pair or hours
		waitABit(3000);
		if (!checkElementVisible(lbl_totalPeriodHourMyADP))
			waitABit(3000);
		List<WebElement> objDays = getDriver()
				.findElements(By.xpath("//button[@class='timecard-day-edit btn btn-direct']/../.."));
		List<WebElement> objDelete = null;
		if (objDays.isEmpty())
			return;
		for (int i = 0;;) {
			objDays = getDriver().findElements(By.xpath("//button[@class='timecard-day-edit btn btn-direct']/../.."));
			if (objDays.isEmpty())
				break;
			scrollIntoView(objDays.get(i).findElement(By.xpath("//i[@class='fa fa-pencil only-icon']")));
			objDays.get(i).findElement(By.xpath("//i[@class='fa fa-pencil only-icon']")).click();
			waitABit(2000);
			objDelete = getDriver().findElements(By.xpath("//i[@class='fa adp-fa-icon-ellipses-vertical only-icon']"));
			deleteTimePairHourMyADP(objDelete);
			waitABit(10000);
			lbl_totalhours.waitUntilVisible();
			// lnk_backToTimecard.click();
			// if (!checkElementVisible(imgIcon_paySummaryPieChart))
			// waitABit(2000);

		}
	}

	public void SearchRUNClient(String TLMClientID) {
		selectFrame(getDriver().findElement(By.id("iPDetail")));

		// getDriver().switchTo().frame(frame_IPDetail);
		txt_ClientSearch.waitUntilVisible();
		txt_ClientSearch.clear();
		txt_ClientSearch.sendKeys(TLMClientID);
		waitABit(1000);
		btn_Find.click();
		waitABit(1000);
		lnk_ClientName.click();
		getDriver().switchTo().defaultContent();
	}

	public void SearchRUNNonTLM(String NonTLMClientID) {
		getDriver().switchTo().defaultContent();
		btn_dropdown.click();
		waitABit(5000);		
		getDriver().findElement(By.xpath("//a[@rel='" + NonTLMClientID + "']")).click();
		btn_TimeManagement.waitUntilVisible();
		btn_TimeManagement.click();

		/*
		 * String windowHandle = getDriver().getWindowHandle();
		 * getDriver().switchTo().window(windowHandle);
		 * System.out.println("Title of the new window:" + getDriver().getTitle());
		 * getDriver().switchTo().window("RUN powered by ADP");
		 * img_Timecard.waitUntilVisible(); img_Timecard.click();
		 */

		String cHandle = getDriver().getWindowHandle();
		String newWindowHandle = null;
		Set<String> allWindowHandles = getDriver().getWindowHandles();

		// Wait for 20 seconds for the new window and throw exception if not found
		for (int i = 0; i < 20; i++) {
			if (allWindowHandles.size() > 1) {
				for (String allHandlers : allWindowHandles) {
					if (!allHandlers.equals(cHandle))
						newWindowHandle = allHandlers;
				}
				getDriver().switchTo().window(newWindowHandle);
				break;
			} else {
				waitABit(5000);
			}
		}
		if (cHandle == newWindowHandle) {
			throw new RuntimeException("Time out - No window found");
		}

		WaitForAjax();
		img_Timecard.waitUntilVisible();
		img_Timecard.click();
		WaitForAjax();
		waitABit(30000);
		tbl_TimecardGrid.waitUntilVisible();

	}

	public void AddTimePairTLM() 
	{
		CleanupTimecardTLM();
		MissedOutPunchTLM();
			
	}

	public void CleanupTimecardTLM() {
		int rowcount = rows_Timecard.size();

		for (int j = 1; j <= rowcount; j++)
		{
			
			
			if(checkElementVisible("//div[@id='r_" + j + "_e_" + j + "_InTime']")||checkElementVisible("//div[@id='r_" + j + "_e_" + j + "_OutTime']"))
			{
				getDriver().findElement(By.xpath("//div[@id='r_" + j + "_e_" + j + "_InTime']")).click();
				waitABit(1000);
				getDriver().findElement(By.xpath("//div[@id='r_" + j + "_e_" + j + "_OutTime']")).click();
				waitABit(1000);
				String InTime = getDriver().findElement(By.xpath("//div[@id='r_" + j + "_e_" + j + "_InTime']")).getText();
				String OutTime = getDriver().findElement(By.xpath("//div[@id='r_" + j + "_e_" + j + "_OutTime']")).getText();
				
				if(!InTime.equals("") || !OutTime.equals(""))
				{
			
				if (getDriver().findElement(By.xpath("//div[@id='r_" + j + "_e_" + j + "_Value']/preceding::a[@class='menuIcon'][1]")).isDisplayed()) 
				{
					getDriver().findElement(By.xpath("//div[@id='r_" + j + "_e_" + j + "_Value']/preceding::a[@class='menuIcon'][1]")).click();
				} 
				else if (getDriver().findElement(By.xpath("//*[@id='r_" + j + "_c_" + j + "_Status']/descendant::a[1]")).isDisplayed())
				{
					getDriver().findElement(By.xpath("//*[@id='r_" + j + "_c_" + j + "_Status']/descendant::a[1]")).click();
				}
				waitABit(3000);
                int count = rows_Delete.size();
                for (int a = 1; a<=count; a++)
                {
                	if(getDriver().findElement(By.xpath("(//td[text()='Delete Row'])[" + a + "]")).isDisplayed())
                	{
                    getDriver().findElement(By.xpath("(//td[text()='Delete Row'])[" + a + "]")).click();
                    break;
                	}
                }
		     }			
				
			break;	
		}
		
	}
			getDriver().findElement(By.xpath("//*[@id='btnSubmit']")).click();
			
			if(checkElementVisible("//span[text()='OK']/.."))
			{
				getDriver().findElement(By.xpath("//span[text()='OK']/..")).click();
			}
			if(checkElementVisible(lbl_OperationSuccessful))
			{
				lbl_OperationSuccessful.waitUntilVisible();
			}
		
	}

	public void MissedOutPunchTLM()

	{
		int rowcount = rows_Timecard.size();

		for(int k=0;k<rowcount;k++)
		{
		if(checkElementVisible("//div[@id='r_" + k + "_e_" + k + "_InTime']"))
		{
	    getDriver().findElement(By.xpath("//div[@id='r_" + k + "_e_" + k + "_InTime']")).click();
		waitABit(2000);
		getDriver().findElement(By.xpath("//input[starts-with(@id, 'TLMWidgets_app_form_TcTimeTextBox_')]")).clear();
		getDriver().findElement(By.xpath("//input[starts-with(@id, 'TLMWidgets_app_form_TcTimeTextBox_')]")).sendKeys("8a");		
		waitABit(1000);
		getDriver().findElement(By.xpath("//*[@id='btnSubmit']")).click();
		if(checkElementVisible("//span[text()='OK']/.."))
		{
			getDriver().findElement(By.xpath("//span[text()='OK']/..")).click();
		}
		if(checkElementVisible(lbl_OperationSuccessful))
		{
			lbl_OperationSuccessful.waitUntilVisible();
		}
		break;
		}
		}

	}
	
	public void ResolveExceptionsTLM()
	{
		//selectFrame(getDriver().findElement(By.id("iframeTLMSSOContentBannerBIWKLY")));
		btn_ResolveExceptions.waitUntilVisible();
		btn_ResolveExceptions.click();
		btn_iFrameSliderClose.waitUntilVisible();
		btn_iFrameSliderClose.click();
		
	}
	
	public void SearchClientNonTLM(String NonTLMClientID)
	{
		getDriver().switchTo().defaultContent();
		btn_dropdown.click();
		waitABit(1000);
		getDriver().findElement(By.xpath("//a[@rel='" + NonTLMClientID + "']")).click();
	}
	
	public void ValidateTCGridGrayed()
	{
		getDriver().findElement(By.xpath("//div[@class='css-16pqwjk-indicatorContainer MDFSelectBox__indicator MDFSelectBox__dropdown-indicator']")).click();
		waitABit(1000);
		if(checkElementVisible("//div[contains(@id,'react-select-2-option-0')]"))
		{
		getDriver().findElement(By.xpath("//div[contains(@id,'react-select-2-option-0')]")).click();	
		waitABit(2000);
		int plusiconrows = btn_AddTimePair.size();
		if(plusiconrows>=1)
		{
			Assert.fail("Timecard Grid not grayed out");
		}
		}
	}
	
	public void SearchEmployee(String Employee)
	{
		getDriver().findElement(By.xpath("(//span[contains(.,'Employees')])[1]")).click();
		waitABit(10000);
		getDriver().findElement(By.xpath("//span[@class='ui-button-icon-primary ui-icon ui-icon-triangle-1-s']/..")).click();
		waitABit(2000);
		//selectValueFromDropDownByVisibleText(ddl_SelectStatus,"All");
		//getDriver().findElement(By.xpath("//select[@id='employeeStatus']")).click();
		//Select select = new Select(getDriver().findElement(By.xpath("//select[@id='employeeStatus']")));
		//select.selectByValue("ONB_All");
		getDriver().findElement(By.xpath("(//a[contains(.,'All')])[2]")).click();
		waitABit(1000);
		txt_EmployeeSearch.clear();
		txt_EmployeeSearch.sendKeys(Employee);		
		getDriver().findElement(By.xpath("//div[contains(text(),'" + Employee + "')]")).click();
		lnk_EmployeeInfo.waitUntilVisible();
		
	}
	
	public void TerminateEmployee(String Employee)
	{
		waitABit(1000);
		lnk_TerminateEmployee.waitUntilVisible();
		getDriver().findElement(By.xpath("//a[@id='TERMINATE_EMPLOYEE']")).click();
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String termdate = formatter.format(date);
		selectFrame(getDriver().findElement(By.id("iPDetail")));
		ddl_TermDate.clear();
		ddl_TermDate.sendKeys(termdate);
		waitABit(1000);
		getDriver().findElement(By.xpath("//input[@id='cboTermReason_input']//following-sibling::a")).click();
		waitABit(2000);
		getDriver().findElement(By.xpath("//a[contains(.,'Discharge Issues (No Misconduct Involved)')]")).click();
		waitABit(2000);
		getDriver().switchTo().defaultContent();
		selectFrame(getDriver().findElement(By.id("iPButtons")));		
		scrollIntoView(btn_TerminateEmployee);
		btn_TerminateEmployee.click();	
		waitABit(1000);
		getDriver().switchTo().defaultContent();
		if (getDriver().findElement(By.xpath("//span[text()='Something you should be aware of']")).isDisplayed()) {
			getDriver().findElement(By.xpath("//div[@class='dlg-buttons dlg-warning']//button[text()='OK']")).click();
		}		
	}
	
	public void RehireEmployee(String Employee)
	{
		waitABit(1000);
		lnk_TerminateEmployee.waitUntilVisible();
		getDriver().findElement(By.xpath("//a[@id='EMPLOYEE_EMPLOYMENT']")).click();
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String rehiredate = formatter.format(date);
		selectFrame(getDriver().findElement(By.id("iPDetail")));
		ddl_TermDate.clear();
		ddl_TermDate.sendKeys(rehiredate);
		getDriver().findElement(By.xpath("//input[@id='cboTermReason_input']//following-sibling::a")).click();
		waitABit(2000);
		getDriver().findElement(By.xpath("//input[@placeholder='Select a value']")).click();
		//getDriver().switchTo().defaultContent();
		//selectFrame(getDriver().findElement(By.id("iPButtons")));
		scrollIntoView(btn_Rehire);
		btn_Rehire.click();
		waitABit(1000);
		getDriver().switchTo().defaultContent();
		if (getDriver().findElement(By.xpath("//span[text()='Something you should be aware of']")).isDisplayed()) {
			getDriver().findElement(By.xpath("//div[@class='dlg-buttons dlg-warning']//button[text()='OK']")).click();
		}		
		selectFrame(getDriver().findElement(By.id("iPDetail")));
		scrollIntoView(ddl_HireDate);
		ddl_HireDate.clear();
		ddl_HireDate.sendKeys(rehiredate);		
		getDriver().findElement(By.xpath("//input[@id='cboTermReason_input']//following-sibling::a")).click();
		waitABit(2000);
		//getDriver().findElement(By.xpath("//select[@id='cboTermReason']/following-sibling::span//input[@placeholder='Select a value']")).click();
		getDriver().findElement(By.xpath("(//a[contains(.,'Discharge Issues')]/../../li/a)[1]")).click();
		getDriver().switchTo().defaultContent();
		selectFrame(getDriver().findElement(By.id("iPButtons")));				
		scrollIntoView(getDriver().findElement(By.xpath("//td[@id='buttonContainerRight']//button[text()='Save']")));
		getDriver().findElement(By.xpath("//td[@id='buttonContainerRight']//button[text()='Save']")).click();
		waitABit(1500);
		getDriver().switchTo().defaultContent();

	}
	
	public void PrintTimecard()
	{
		waitABit(1000);
		btn_Print.click();
		String cHandle = getDriver().getWindowHandle();
		String newWindowHandle = null;
		Set<String> allWindowHandles = getDriver().getWindowHandles();

		// Wait for 20 seconds for the new window and throw exception if not found
		for (int i = 0; i < 20; i++)
		{
			if (allWindowHandles.size() > 1) {
				for (String allHandlers : allWindowHandles) {
					if (!allHandlers.equals(cHandle))
						newWindowHandle = allHandlers;
				}
				getDriver().close();

				//getDriver().switchTo().window(newWindowHandle);
				break;
			} 
			else 
			{
				waitABit(5000);
				getDriver().close();
			}
		}
		if (cHandle == newWindowHandle)
		{
			throw new RuntimeException("Time out - No window found");

		}
		
	}	
	
	
}
