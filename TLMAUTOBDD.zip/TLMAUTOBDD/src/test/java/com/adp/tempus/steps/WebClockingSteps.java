package com.adp.tempus.steps;

import java.util.List;

import com.adp.tempus.pages.WebClockingHomePage;
import com.adp.tempus.pages.WebClockingTimecardPage;
import com.adp.tlmbdd.pages.Logins;

import net.thucydides.core.annotations.Step;

public class WebClockingSteps {

	WebClockingHomePage webclockingHomePage;

	WebClockingTimecardPage webclockingTimecardPage;

	Logins login;
	
	public static String payperiod;

	@Step
	public void WebClocking_EmployeeLogin(String userId, String password, String URL) {
		// login.empUserLogin(userId, password);
		login.TempusWebClockingLogin(userId, password, "https://clock-fit.nj.adp.com/");
		// webclockingHomePage.WebClocking_EmployeeLogin(userId,
		// password,"https://clock-fit.nj.adp.com/");
	}

	@Step
	public void emp_HomePage_Verify_Webclocking_Homepage_loading() {
		webclockingHomePage.emp_HomePage_Verify_Webclocking_Homepage_loading();
	}

	@Step
	public String get_date(String addToDay, String dateType) {
		return webclockingHomePage.get_date(addToDay, dateType);
	}

	@Step
	public String emp_yourTime_GetPunchTime() {
		return webclockingHomePage.emp_yourTime_GetPunchTime();
	}

	@Step
	public void emp_yourTime_missedPunches_navigation() {
		webclockingHomePage.emp_yourTime_missedPunches_navigation();
	}

	@Step
	public String emp_yourTime_get_currentTime() {
		return webclockingHomePage.emp_yourTime_get_currentTime();
	}

	@Step
	public void emp_HomePage_WebclockingPopup(String message) {

		webclockingHomePage.emp_HomePage_WebclockingPopup(message);
	}

	@Step
	public void emp_HomePage_WebclockingPopup_clickon_KeepmeLoggedin() {

		webclockingHomePage.emp_HomePage_WebclockingPopup_clickon_KeepmeLoggedin();
	}

	@Step
	public void emp_Screen_is_Navigated_to_webclocking_homescreen() {

		webclockingHomePage.emp_Screen_is_Navigated_to_webclocking_homescreen();
	}

	@Step
	public void i_validate_that_timecard_should_be_loaded_successfully_in_web_clocking() {

		webclockingTimecardPage.i_validate_that_timecard_should_be_loaded_successfully_in_web_clocking();

	}

	@Step
	public void i_validate_that_Web_clocking_is_in_offline() {
		webclockingHomePage.i_validate_that_Web_clocking_is_in_offline();

	}

	@Step
	public void emp_yourTimecard_Select_ActualPayPeriod(String monthName, int date) {

		payperiod=webclockingTimecardPage.emp_yourTimecard_Select_currentPayPeriod(monthName, date);
	}

	public void emp_yourTimecard_select_timePeriod(String timePeriod) {

		webclockingTimecardPage.emp_yourTimecard_select_timePeriod(timePeriod);
	}

	@Step
	public void emp_yourTimecard_Verify_PageLoading() {

		webclockingTimecardPage.emp_yourTimecard_Verify_PageLoading();

	}

	@Step
	public void emp_yourTimecard_editTimePair(int day) {

		webclockingTimecardPage.emp_yourTimecard_editTimePair(day);
	}

	@Step
	public List<String> emp_youtTimecard_GetPunchTime() {
		return webclockingTimecardPage.emp_yourTimecard_GetPunchTime();
	}

	@Step
	public Boolean emp_yourTimecard_CheckTimePair_Existence(List<String> timePairList, String timePair) {

		return webclockingTimecardPage.emp_yourTimecard_CheckTimePair_Existence(timePairList, timePair);
	}

	@Step
	public void selectPayPeriodTimecardPage(String payPeriod) {

		webclockingTimecardPage.selectPayPeriodTimecardPage(payPeriod);
	}

	@Step
	public void i_Click_Button_on_Web_Clocking_Page(String smartButton) {

		webclockingHomePage.clickButtonWebClocking(smartButton);

	}

	@Step
	public void i_Click_Button_under_on_carousel_Web_Clocking_Page(String smartButton) {

		webclockingHomePage.i_Click_Button_under_on_carousel_Web_Clocking_Page(smartButton);
	}

	@Step
	public void i_Click_Button_with_notes_under_on_carousel_Web_Clocking_Page(String smartButton) {

		webclockingHomePage.i_Click_Button_with_notes_under_on_carousel_Web_Clocking_Page(smartButton);
	}

	@Step
	public void i_Click_on_Back_button_in_Time_card_screen_in_web_clocking() {

		webclockingTimecardPage.i_Click_on_Back_button_in_Time_card_screen_in_web_clocking();
	}

	@Step
	public void i_Click_Button_on_Add_Time_Pair_Page_in_Web_Clocking(String button) {

		webclockingTimecardPage.clickButtonAddTimePair(button);

	}

	@Step
	public void i_validate_smart_button_displayed_in_webclocking_Home_screen(String smartbutton) {

		webclockingHomePage.i_validate_smart_button_displayed_in_webclocking_Home_screen(smartbutton);
	}

	@Step
	public void i_Validate_User_successfully_logged_Out_in_WebClocking() {

		webclockingHomePage.i_Validate_User_successfully_logged_Out_in_WebClocking();

	}

	@Step
	public void i_Verify_Timer_in_Web_clocking_screen() {
		webclockingHomePage.i_Verify_Timer_in_Web_clocking_screen();

	}

	@Step
	public void i_Click_Button_with_notes_on_Web_Clocking_Page(String smartButton) {

		webclockingHomePage.i_Click_Button_with_notes_on_Web_Clocking_Page(smartButton);
	}

	@Step
	public void i_validate_Add_a_Note_slider_is_opened() {

		webclockingHomePage.i_validate_Add_a_Note_slider_is_opened();
	}

	@Step
	public void i_enter_in_Add_a_Note_slider_and_click_on(String notes, String btnName) {

		webclockingHomePage.i_enter_in_Add_a_Note_slider_and_click_on(notes, btnName);

	}

	@Step
	public void emp_HomePage_verify_mytime_status(String message) {
		
		webclockingHomePage.emp_HomePage_verify_mytime_status(message);
		
	}

	@Step
	public void i_validate_that_view_more_actions_link_displayed_in_webclocking_Home_screen() {
		
		webclockingHomePage.i_validate_that_view_more_actions_link_displayed_in_webclocking_Home_screen();
	}

	@Step
	public void i_validate_that_carousel_should_not_be_display_in_webclocking_Home_screen(boolean status) {
		webclockingHomePage.i_validate_that_carousel_should_not_be_display_in_webclocking_Home_screen(status);
		
	}

}