package com.adp.tempus.pages;

import static org.junit.Assert.assertTrue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class WebClockingHomePage extends GenericPageObject {

	// start --- WFN login page elements
	@FindBy(xpath = "//input[@id='user_id']")
	private WebElementFacade tbx_UserID;

	@FindBy(xpath = "//input[@id='password']")
	private WebElementFacade tbx_Password;

	@FindBy(xpath = "//button[@id='subBtn']")
	private WebElementFacade btn_Submit;

	@FindBy(xpath = "//i[contains(@title,'Log Out')]")
	private WebElementFacade imgIcon_LogOut;

	// --end ------WFN login page -----

	/*-- Smart Buttons ---*/
	@FindBy(xpath = "//div[text()='Start Work']/preceding-sibling::div//img")
	public WebElementFacade btn_StartWork;

	@FindBy(xpath = "//div[text()='End Work']/preceding-sibling::div//img")
	public WebElementFacade btn_EndWork;

	@FindBy(xpath = "//div[text()='Take Meal']/preceding-sibling::div//img")
	public WebElementFacade btn_TakeMeal;

	@FindBy(xpath = "//div[text()='End Meal']/preceding-sibling::div//img")
	public WebElementFacade btn_EndMeal;

	@FindBy(xpath = "//div[contains(@class,'popover')]//span[contains(text(),'with notes')]")
	public WebElementFacade popover_smart_btns;

	@FindBy(xpath = "//*[text()='Add a note']")
	public WebElementFacade lbl_add_aNote_slider;

	@FindBy(xpath = "//div[text()='Note']/following::textarea")
	public WebElementFacade tbx_notes_textArea;

	By dots_in_smartBtn = By.xpath(".//..//..//preceding-sibling::div//text[contains(@class,'notes-icon-ellipsis')]");
	
	
	By dots_in_smartBtn_takeMeal = By.xpath("(//..//..//preceding-sibling::div//text[contains(@class,'notes-icon-ellipsis')])[2]");

	@FindBy(xpath = "//div[text()='Missed Punches'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]")
	public WebElementFacade lbl_ttdMissedPunches;

	@FindBy(xpath = "//div[text()='Missed Punches'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]/following-sibling::div")
	public WebElementFacade lbl_ttdMissedPunchesCount;

	@FindBy(xpath = "//div[text()='Approve Timecard'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]")
	public WebElementFacade lbl_ttdApproveTimecard;

	@FindBy(xpath = "//div[text()='Approve Timecard'][contains(@class,'dashboard-thingstodo-tile-todolistviewname')]/following-sibling::div")
	public WebElementFacade lbl_ttdApproveTimecardCount;

	@FindBy(xpath = "//*[@class='row welcome-title'][contains(.,'Web Clock')]")
	public WebElementFacade lbl_webclocking_loginPage_loaded_confirmation;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Start Work')]/..")
	private WebElementFacade imgIcon_startWork_carousel;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'End Work')]/..")
	private WebElementFacade imgIcon_endWork_carousel;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Take Meal')]/..")
	private WebElementFacade imgIcon_takeMeal_carousel;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'End Meal')]/..")
	private WebElementFacade imgIcon_endMeal_carousel;

	@FindBy(xpath = "//div[text()='Transfer' and contains(@class,'mytime-action-label')]")
	private WebElementFacade imgIcon_Transfer_portlets;

	@FindBy(xpath = "//div[contains(text(),'Click the button to start your shift') and contains(@class,'mytime-status mytime-grey')]")
	private WebElementFacade lbl_startYourShift;

	@FindBy(xpath = "//*[@id='lastPunchTimeDuration']/span")
	private WebElementFacade lbl_timer;

	@FindBy(xpath = "//div[contains(@class,'mytime-status mytime')]")
	private WebElementFacade lbl_mytimestatus_message;

	@FindBy(xpath = "//div[contains(text(),'Things to Do') and contains(@class,'mytime-header-things-to-do')]")
	private WebElementFacade lbl_ThingsToDo;

	@FindBy(xpath = "//*[@id='thingsToDoLinks']/descendant::span[text()='Timecard']/..")
	private WebElementFacade btn_Timecard;

	@FindBy(xpath = "//*[@class='vdl-button__container' and text()='Log Out']")
	private WebElementFacade btn_logOut_rightPanel;

	@FindBy(xpath = "//div[text()='Approve Timecard' and contains(@class,'thingstodo-tile-todolistviewname')]")
	private WebElementFacade lnk_ApproveTimecard;

	@FindBy(xpath = "//div[text()='pending approval']")
	private WebElementFacade lbl_PendingApproval;

	@FindBy(xpath = "//div[contains(@class,'mytime-status-time')]")
	private WebElementFacade lbl_lastPunchTime;

	@FindBy(xpath = "//div[text()='Approve Timecard']")
	private WebElementFacade btn_approveTimecard;

	@FindBy(xpath = "//span[text()='APPROVE TIMECARD']/..")
	private WebElementFacade btn_approveTimecard_timecard;

	@FindBy(xpath = "//div[text()='Missed Punches' and contains(@class,'todolistviewname')]")
	private WebElementFacade lnk_missedPunches;

	@FindBy(xpath = "//div[contains(@class,'missed-punch-grid')]/descendant::div[@class='msdpunchesdata'][1]")
	private WebElementFacade tblrow_missedPunch;

	@FindBy(xpath = "//span[text()='Back']/parent::button[contains(@class,'slide-in-close')]")
	private WebElementFacade btn_back_missedPunchSlider;

	@FindBy(xpath = "//span[text()='SUBMIT']/..")
	private WebElementFacade btn_submit_missedPunchesSlide;

	@FindBy(xpath = "//div[contains(text(),'You fixed all your missed punches') or contains(text(),'Great job') ]")
	private WebElementFacade lbl_success_awesome_message;

	@FindBy(xpath = "//*[@id='lastPunchTimeDuration']/span[1]")
	private WebElementFacade lbl_time_lastPunchSession;

	@FindBy(xpath = "//span[text()='SUBMIT']/..")
	private WebElementFacade btn_submit_notesSlider;

	@FindBy(xpath = "//span[text()='SAVE']/..")
	private WebElementFacade btn_save_notesSlider;

	@FindBy(xpath = "//*[@id='timeCard_root']/descendant::div[contains(@class,'panel timecard')]")
	private WebElementFacade tbl_Timecard;

	@FindBy(xpath = "//span[contains(text(),'VIEW MORE ACTIONS')]/..")
	private WebElementFacade lnk_viewMoreActions;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Take Meal') or contains(text(),'End Work')]")
	private WebElementFacade imgIcon_carousel;

	@FindBy(xpath = "//*[@id='currenttime_id']/span")
	private WebElementFacade lbl_time_onYourTimePage;

	@FindBy(xpath = "//div[contains(text(),'not have access to view this section')]")
	private WebElementFacade lbl_youDoNotHaveAccess_message;

	@FindBy(xpath = "//div[contains(text(),'Start Work') or contains(text(),'End Meal') or contains(text(),'End Work') or contains(text(),'not have access to view this section')]")
	private WebElementFacade imgIcon_startWork_or_endWork_endMeal;

	@FindBy(xpath = "//span[contains(text(),'HIDE MORE OPTIONS')]/..")
	private WebElementFacade lnk_hideMoreOptions;

	@FindBy(xpath = "//div[contains(text(),'Out Punch can\'t be less than or equal to In Punch')]")
	private WebElementFacade lbl_lessThan_or_equal_to_error_message;

	@FindBy(xpath = "//div[contains(text(),'Out Punch can't be greater than or equal to next In Punch')]")
	private WebElementFacade lbl_greaterThan_or_equal_to_error_message;

	@FindBy(xpath = "//div[contains(text(),'Take Meal') or contains(text(),'Start Work') or contains(text(),'End Meal')]/parent::div/../../*[not(@class='carouselClass')]")
	private WebElementFacade imgIcon_smartButton;

	@FindBy(xpath = "//div[contains(text(),'The time pair overlaps with another time pair') or contains(text(),'The time pair overlaps with other time pair')]")
	private WebElementFacade lbl_timePairOverlaps;

	@FindBy(xpath = "//div[contains(text(),'resolved some missed punches')]")
	private WebElementFacade lbl_resolvedSomePunches;

	@FindBy(xpath = "//div[contains(text(),'fixed all your missed punches')]")
	private WebElementFacade lbl_fixedAllPunches;

	@FindBy(xpath = "//div[contains(@class,'dialog md')]//div[text()='Would like to do something else?']")
	private WebElementFacade lbl_popup_confirmation;

	@FindBy(xpath = "//*[@class='modal-show-action']")
	private WebElementFacade lbl_success_popup;

	@FindBy(xpath = "//div[contains(@class,'dialog md')]//button[.='KEEP ME LOGGED IN']")
	private WebElementFacade btn_KeepMeloggedin;

	@FindBy(xpath = "//div[@class='webclocking-section']")
	private WebElementFacade webclocking_homescreen;

	@FindBy(xpath = "//*[contains(@class,'thingstodo-empty-content') and contains(text(),'connect to retrieve your status')]")
	private WebElementFacade webclocking_offline_confirmation;

	By tbx_missedOutpunch_list = By
			.xpath("//div[@class='missed-punch-detail']/../../descendant::div[@class='msdpunchesdata'][1]");
	By lbl_time_lastPunch = By
			.xpath("//div[@class='missed-punch-detail']/../../descendant::div[@class='msdpunchesdata'][1]");

	public static boolean access_carousel_buttons = false;

	/**
	 * Tempus -- Employee login
	 * 
	 * @param user     id -- Employee login Id
	 * @param password -- Employee password
	 */
	public void WebClocking_EmployeeLogin(String userid, String password, String URL) {

		browserLaunchbyURL(URL);
		tbx_UserID.waitUntilVisible();
		tbx_UserID.type(userid);
		tbx_Password.type(password);
		btn_Submit.click();
		imgIcon_LogOut.waitUntilVisible();
		imgIcon_LogOut.shouldBePresent();
		WaitForPageLoad();
		WaitForAjax();

	}

	/**
	 * Get date and time
	 * 
	 * @param addToDay -- number of dates to be add
	 * @param dateType -- date type will be date
	 * @return data as per date type
	 */

	public String get_date(String addToDay, String dateType) {
		String result = "";

		Date today = new Date();
		TimeZone timezone = TimeZone.getTimeZone("EST");
		Calendar cal = Calendar.getInstance(timezone);
		cal.setTime(today); // Mon Jun 17 20:32:12 IST 2019

		LocalDate currentDate = LocalDate.now(); // 2019-06-17

		DayOfWeek dow = currentDate.getDayOfWeek();// MONDAY

		if (dateType.equalsIgnoreCase("date")) {
			cal.add(Calendar.DATE, Integer.parseInt(addToDay));
			int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); // get date
			result = Integer.toString(dayOfMonth);
		} else if (dateType.equalsIgnoreCase("todayMonth")) {
			Month m = currentDate.getMonth();// JUNE
			result = m.name();
		} else if (dateType.equalsIgnoreCase("ESTHourAndTime")) {
			DateFormat formatter = new SimpleDateFormat("H:mm a");
			formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));

			String HoursTime = formatter.format(today).toString();

			result = HoursTime;

			System.out.println(result);

		}

		System.out.println("result date is : " + result);
		return result;
	}

	/**
	 * Employee--Home page -- verify-- Your Time tile loading Precondition : should
	 * be on home page
	 */
	public void emp_HomePage_Verify_Webclocking_Homepage_loading() {

		imgIcon_startWork_or_endWork_endMeal.waitUntilEnabled();
		// waitForElementToLoad(imgIcon_startWork_or_endWork_endMeal);
		imgIcon_startWork_or_endWork_endMeal.waitUntilVisible();
		WaitForAjax();
		WaitForPageLoad();
		assertTrue("Web clocking page not loading successfully", imgIcon_startWork_or_endWork_endMeal.isPresent());

	}

	/**
	 * employee --- get punch time
	 * 
	 * @return punchTime --- Exampled 10:30 AM
	 */
	public String emp_yourTime_GetPunchTime() {
		String punchTime = "";
		WaitForAjax();
		// waitForElementToLoad(lbl_lastPunchTime);
		lbl_lastPunchTime.waitUntilPresent();
		punchTime = lbl_lastPunchTime.getText();
		punchTime = punchTime.replace("at ", "").trim();
		System.out.println("Punch time is " + punchTime);
		return punchTime;
	}

	/**
	 * employee -- your time -- missed punches navigation
	 */
	public void emp_yourTime_missedPunches_navigation() {
		waitForElementToLoad(lnk_missedPunches);
		lnk_missedPunches.waitUntilClickable().click();// lnk_missedPunches
		tblrow_missedPunch.waitUntilPresent().shouldBePresent();// tblrow_missedPunch
	}

	/**
	 * employee -- yourTime --- get current time from yourtime
	 * 
	 * @return --- current time on application
	 */
	public String emp_yourTime_get_currentTime() {
		waitForElementToLoad(lbl_time_onYourTimePage);

		String time = lbl_time_onYourTimePage.getText();
		return time.trim();
	}

	public void emp_HomePage_WebclockingPopup(String message) {

		assertTrue("Incorrect Success Message", lbl_success_popup.getText().equalsIgnoreCase(message));
		waitForElementToLoad(lbl_popup_confirmation);
		lbl_popup_confirmation.waitUntilPresent().shouldBePresent();
		assertTrue("Popup message not displayed", lbl_popup_confirmation.isPresent());

	}

	public void emp_HomePage_WebclockingPopup_clickon_KeepmeLoggedin() {

		waitForElementToLoad(btn_KeepMeloggedin);
		btn_KeepMeloggedin.waitUntilClickable().click();
	}

	public void emp_Screen_is_Navigated_to_webclocking_homescreen() {
		// waitForElementToLoad(webclocking_homescreen);
		webclocking_homescreen.waitUntilPresent();
		assertTrue("web clocking home screen not loaded ", webclocking_homescreen.isCurrentlyEnabled());

	}

	public void i_validate_that_Web_clocking_is_in_offline() {
		// TODO Auto-generated method stub
		waitForElementToLoad(webclocking_offline_confirmation);
		assertTrue("Web clocking offline screen not loaded ", webclocking_offline_confirmation.isDisplayed());
	}

	public void clickButtonWebClocking(String btnName) {
		try {
			switch (btnName.toUpperCase()) {
			case "START WORK":
				waitABit(2000);
				btn_StartWork.click();
				break;
			case "END WORK":
				waitABit(2000);
				btn_EndWork.click();
				break;
			case "TAKE MEAL":
				waitABit(2000);
				btn_TakeMeal.click();
				break;
			case "END MEAL":
				waitABit(2000);
				btn_EndMeal.click();
				break;
			case "APPROVE TIMECARD":
				waitABit(2000);
				lbl_ttdApproveTimecard.click();
				break;
			case "MISSED PUNCHES":
				waitABit(2000);
				lbl_ttdMissedPunches.click();
				break;
			case "TIMECARD":
				waitABit(2000);
				btn_Timecard.click();
				break;
			case "LOGOUT":
				waitABit(2000);
				btn_logOut_rightPanel.click();
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void i_validate_smart_button_displayed_in_webclocking_Home_screen(String smartbutton) {
		try {
			switch (smartbutton.toUpperCase()) {
			case "START WORK":
				btn_StartWork.waitUntilPresent().shouldBePresent();
				assertTrue(smartbutton + " is not displayed in Web clocking", btn_StartWork.isDisplayed());
				break;
			case "END WORK":
				btn_EndWork.waitUntilPresent().shouldBePresent();
				assertTrue(smartbutton + " is not displayed in Web clocking", btn_EndWork.isDisplayed());
				break;
			case "TAKE MEAL":
				//btn_TakeMeal.waitUntilPresent().shouldBePresent();
				assertTrue(smartbutton + " is not displayed in Web clocking", btn_TakeMeal.isDisplayed());
				break;
			case "END MEAL":
				btn_EndMeal.waitUntilPresent().shouldBePresent();
				assertTrue(smartbutton + " is not displayed in Web clocking", btn_EndMeal.isDisplayed());
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void i_Validate_User_successfully_logged_Out_in_WebClocking() {

		waitForElementToLoad(lbl_webclocking_loginPage_loaded_confirmation);
		assertTrue("Web clocking Not successfully logged out",
				lbl_webclocking_loginPage_loaded_confirmation.isDisplayed());
	}

	public void i_Verify_Timer_in_Web_clocking_screen() {

		if (lbl_timer.isCurrentlyEnabled()) {
			int total_seconds;
			int count = 0;
			do {
				if (count > 0) {
					waitABit(15000);
					getDriver().navigate().refresh();
				}

				String TimeStamp = lbl_timer.getText();
				String hh_mm_ss[] = TimeStamp.split(":");
				int hours = Integer.parseInt(hh_mm_ss[0]);
				int minutes = Integer.parseInt(hh_mm_ss[1]);
				int seconds = Integer.parseInt(hh_mm_ss[2]);
				total_seconds = (hours * 60 * 60) + (minutes * 60) + seconds;
				System.out.println(total_seconds);
				count++;
			} while (total_seconds < 180);
			access_carousel_buttons = true;
		}

	}

	public void i_Click_Button_under_on_carousel_Web_Clocking_Page(String btnName) {

		try {
			switch (btnName.toUpperCase()) {
			case "START WORK":
				lnk_viewMoreActions.waitUntilClickable().click();
				waitABit(2000);
				imgIcon_startWork_carousel.click();
				break;
			case "END WORK":
				waitABit(2000);
				btn_EndWork.click();
				break;
			case "TAKE MEAL":
				waitABit(2000);
				btn_TakeMeal.click();
				break;
			case "END MEAL":
				waitABit(2000);
				btn_EndMeal.click();
				break;
			default:
				throw new IllegalArgumentException("please provide right button name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void i_Click_Button_with_notes_under_on_carousel_Web_Clocking_Page(String btnName) {

		try {
			switch (btnName.toUpperCase()) {
			case "START WORK":
				lnk_viewMoreActions.waitUntilClickable().click();
				waitABit(2000);
				mouseover(imgIcon_startWork_carousel);
				imgIcon_startWork_carousel.findBy(dots_in_smartBtn).waitUntilClickable().click();
				assertTrue("popup not displyed", popover_smart_btns.getText().contains("Start work"));
				popover_smart_btns.waitUntilClickable().click();
				waitABit(2000);
				break;
			case "END WORK":
				waitABit(2000);
				btn_EndWork.click();
				break;
			case "TAKE MEAL":
				waitABit(2000);
				btn_TakeMeal.click();
				break;
			case "END MEAL":
				waitABit(2000);
				btn_EndMeal.click();
				break;
			default:
				throw new IllegalArgumentException("please provide right button name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void i_Click_Button_with_notes_on_Web_Clocking_Page(String btnName) {

		try {
			System.out.println("");
			switch (btnName.toUpperCase()) {
			case "START WORK":
				mouseover(btn_StartWork);
				btn_StartWork.findBy(dots_in_smartBtn).waitUntilClickable().click();
				assertTrue("popup not displyed", popover_smart_btns.getText().contains("Start work"));
				popover_smart_btns.waitUntilClickable().click();
				waitABit(2000);
				break;
			case "END WORK":
				mouseover(btn_EndWork);
				btn_EndWork.findBy(dots_in_smartBtn).waitUntilClickable().click();
				assertTrue("popup not displyed", popover_smart_btns.getText().contains("End work"));
				popover_smart_btns.waitUntilClickable().click();

				waitABit(2000);
				break;
			case "TAKE MEAL":
				mouseover(btn_TakeMeal);
				btn_TakeMeal.findBy(dots_in_smartBtn_takeMeal).click();
				//btn_TakeMeal.findBy(dots_in_smartBtn).waitUntilClickable().click();
				assertTrue("popup not displyed", popover_smart_btns.getText().contains("Take meal"));
				popover_smart_btns.waitUntilClickable().click();

				waitABit(2000);
				break;
			case "END MEAL":
				mouseover(btn_EndMeal);
				btn_EndMeal.findBy(dots_in_smartBtn).waitUntilClickable().click();
				assertTrue("popup not displyed", popover_smart_btns.getText().contains("End meal"));
				popover_smart_btns.waitUntilClickable().click();

				waitABit(2000);
				break;
			default:
				throw new IllegalArgumentException("please provide right button name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void i_validate_Add_a_Note_slider_is_opened() {
		lbl_add_aNote_slider.waitUntilVisible();
		assertTrue("Add a note slider not opened", lbl_add_aNote_slider.isDisplayed());

	}

	public void mouseover(WebElementFacade webElementFacade_element) {
		try {
			WebElement element = (WebElement) webElementFacade_element;
			Actions act = new Actions(getDriver());

			act.moveToElement(element).build().perform();
		} catch (Exception e) {
			assertTrue("Mouse Over failed for :" + webElementFacade_element, false);
		}
	}

	public void i_enter_in_Add_a_Note_slider_and_click_on(String notes, String btnName) {

		tbx_notes_textArea.waitUntilVisible().type(notes);
		btn_submit_notesSlider.waitUntilClickable().click();
	}

	public void emp_HomePage_verify_mytime_status(String message) {

		System.out.println(" ");
		lbl_mytimestatus_message.waitUntilVisible();
		waitForTextToAppear(message);
		assertTrue(message + "is not displayed in Web clocking",
				lbl_mytimestatus_message.getText().equalsIgnoreCase(message));
	}

	public void i_validate_that_view_more_actions_link_displayed_in_webclocking_Home_screen() {

		lnk_viewMoreActions.waitUntilVisible();
		assertTrue("View more actions link not displayed", lnk_viewMoreActions.isDisplayed());

	}

	public void i_validate_that_carousel_should_not_be_display_in_webclocking_Home_screen(
			boolean carousel_PresenceFlag) {

		if (carousel_PresenceFlag) {
			imgIcon_startWork_carousel.waitUntilEnabled();
			assertTrue("verify that carousel should be display", imgIcon_startWork_carousel.isCurrentlyEnabled());
		} else {

			imgIcon_startWork_carousel.waitUntilNotVisible();
			assertTrue("carousel displyed", !imgIcon_startWork_carousel.isPresent());

		}

	}

}
