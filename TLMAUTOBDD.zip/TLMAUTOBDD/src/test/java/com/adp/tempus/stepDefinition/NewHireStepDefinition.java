package com.adp.tempus.stepDefinition;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import com.adp.tempus.steps.NewHireSteps;

public class NewHireStepDefinition {
	
	@Steps
	NewHireSteps newHireSteps;
	
	@Then("^I verify Hire/Rehire page is loaded properly$")
	public void verify_HireRehire_page_is_loaded_properly() {
		newHireSteps.verify_HireRehire_page_is_loaded_properly();
	}
	
	@Then("^I validate HR Only Template is displayed$")
	public void validate_HR_Only_Template_is_displayed() {
		newHireSteps.validate_HR_Only_Template_is_displayed();
	}
	
	@When("^I navigate to HR Only Template$")
	public void navigate_to_HR_Only_Template() {
		newHireSteps.navigate_to_HR_Only_Template();
	}
	
	@Then("^I verify time section is not displayed on HR Only template$")
	public void verify_time_section_is_not_displayed_on_HR_Only_template() {
		newHireSteps.verify_time_section_is_not_displayed();
	}
	
	@When("^I Cancel the New Hire creation$")
	public void Cancel_the_New_Hire_creation() {
		newHireSteps.Cancel_the_New_Hire_creation();
	}
	
	@Then("^I verify navigate back to HireRehire page$")
	public void verify_navigate_back_to_HireRehire_page() {
		newHireSteps.verify_navigate_back_to_HireRehire_page();
	}
	
	@Then("^I validate Paid Contractor Template is displayed$")
	public void validate_Paid_Contractor_Template_is_displayed() {
		newHireSteps.validate_Paid_Contractor_Template_is_displayed();
	}
	
	@When("^I navigate to Paid Contractor Template$")
	public void navigate_to_Paid_Contractor_Template() {
		newHireSteps.navigate_to_Paid_Contractor_Template();
	}
	
	@Then("^I verify time section is not displayed on Paid Contractor template$")
	public void verify_time_section_is_not_displayed_on_Paid_Contractor_template() {
		newHireSteps.verify_time_section_is_not_displayed();
	}
	
	@Then("^I validate Paid Employee Template is displayed$")
	public void validate_Paid_Employee_Template_is_displayed() {
		newHireSteps.validate_Paid_Employee_Template_is_displayed();
	}
	
	@When("^I navigate to Paid Employee Template$")
	public void navigate_to_Paid_Employee_Template() {
		newHireSteps.navigate_to_Paid_Employee_Template();
	}
	
	@Then("^I verify time section is not displayed on Paid Employee template$")
	public void verify_time_section_is_not_displayed_on_Paid_Employee_template() {
		newHireSteps.verify_time_section_is_not_displayed();
	}
	
	@Then("^I verify time section is displayed on HR Only template$")
	public void verify_time_section_is_displayed_on_HR_Only_template() {
		newHireSteps.verify_time_section_is_displayed();
	}
	
	@Then("^I verify time section is displayed on Paid Contractor template$")
	public void verify_time_section_is_displayed_on_Paid_Contractor_template() {
		newHireSteps.verify_time_section_is_displayed();
	}
	
	@Then("^I verify time section is displayed on Paid Employee template$")
	public void verify_time_section_is_displayed_on_Paid_Employee_template() {
		newHireSteps.verify_time_section_is_displayed();
	}
}
