package com.adp.tempus.stepDefinition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.adp.tempus.steps.PolicyManagerSteps;
//import com.adp.tlmbdd.stepDefinition.TeamDashboardStepDefinition;
import com.adp.tlmbdd.common.DateUtils;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class PolicyManagerStepDefinition {
	
	
	@Steps
	PolicyManagerSteps policyManagerSteps;
	
	@Then("^I verify policy manager is loaded properly$")
	public void i_verify_policy_manager_page_is_loaded_properly() throws Throwable {
		policyManagerSteps.verifyPolicyManagerPageLoading();
	}

	@Then("^I verify time and attendance under setup new$")
	public void i_verify_time_and_attendance_under_setup_new() throws Throwable {
		//policyManagerSteps.verifyTimeAndAttendanceOptionUnderSetupNew();
	}

	@Then("^I create a \"([^\"]*)\" policy with name \"([^\"]*)\" rounding type \"([^\"]*)\" and date \"([^\"]*)\"$")
	public void i_create_a_policy_with_name_rounding_type_and_date(String policyType,String policyname, String roundingtype, String dateformat) throws Throwable {
		String effDate = getEffectiveDate(dateformat);
		policyManagerSteps.createTimeAndAttendanceRoundingPolicy(policyType,policyname, roundingtype,effDate );
	}
/*
	@Then("^I create a \"([^\"]*)\" policy with name \"([^\"]*)\" timeEntry type \"([^\"]*)\" and date \"([^\"]*)\"$")
	public void i_create_a_policy_with_name_timeEntry_type_and_date(String policyType, String policyname, String roundingtype, String dateformat) throws Throwable {
		String effDate = getEffectiveDate(dateformat);
		policyManagerSteps.createTimeAndAttendanceTimeEntryPolicy(policyType, policyname, roundingtype, effDate);
    
	}*/
	
	@Then("^I create a \"([^\"]*)\" policy with name \"([^\"]*)\" timeEntry type \"([^\"]*)\" date \"([^\"]*)\" with sources \"([^\"]*)\" and actions \"([^\"]*)\"$")
	public void i_create_a_policy_with_name_timeEntry_type_date_with_sources_and_actions(String policyType, String policyname, String timeEntryTpe, String dateformat, String sourceType, String actionType) throws Throwable {
		String effDate = getEffectiveDate(dateformat);
		policyManagerSteps.createTimeAndAttendanceTimeEntryPolicy(policyType, policyname, timeEntryTpe, effDate,sourceType,actionType);
	}


	@Then("^I create a \"([^\"]*)\" policy with name \"([^\"]*)\" timeEntry type \"([^\"]*)\" date \"([^\"]*)\"$")
	public void i_create_a_policy_with_name_timeEntry_type_date(String policyType, String policyname, String timeEntryTpe, String dateformat) throws Throwable {
		String effDate = getEffectiveDate(dateformat);
		policyManagerSteps.createTimeAndAttendanceTimeEntryPolicy(policyType, policyname, timeEntryTpe, effDate,null,null);
		 
	}
	

	@Then("^I delete \"([^\"]*)\" policy$")
	public void i_delete_policy(String policyname) throws Throwable {
		policyManagerSteps.deletePolicy(policyname);
	}
	
	@Then("^I Navigate Back to Policy List Page$")
	public void i_navigate_back_to_policy_list_page() throws Throwable {
		policyManagerSteps.navigateBackPolicyList();
	}
	
	public static String getEffectiveDate(String dateformat){
		
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("M/dd/yyyy");	
		LocalDate requireddate = DateUtils.getRequiredDate(dateformat);
		String requireddate1 = requireddate.format(formatters).toString();
		return requireddate1;
		
	}
}
