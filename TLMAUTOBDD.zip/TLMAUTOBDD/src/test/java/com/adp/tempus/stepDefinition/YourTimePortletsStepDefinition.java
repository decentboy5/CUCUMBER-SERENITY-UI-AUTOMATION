package com.adp.tempus.stepDefinition;

import static org.junit.Assert.assertTrue;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.adp.tempus.pages.YourTimecard;
import com.adp.tempus.steps.YourTimePortletsSteps;
import com.adp.tempus.steps.YourTimecardSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class YourTimePortletsStepDefinition {

	@Steps
	YourTimecardSteps timecardSteps;

	@Steps
	YourTimePortletsSteps yourTimePortletsSteps;

	public static String clockInTime = "";
	public static String clockOutTime = "";
	public static String mealOutTime = "";
	public static String mealReturnTime = "";
	public static String note = "";

	@Given("^I login as Tempus employee user with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_as_Tempus_employee_user_with_and(String arg1, String arg2) throws Throwable {

		yourTimePortletsSteps.tempus_EmployeeLogin(arg1, arg2);
		
         
		yourTimePortletsSteps.emp_HomePage_Verify_YourTime_loading();
        
	}

	
	
	@And("^I click on  take meal button for clock employee$")
	public void iClickOnTakeMealButtonForClockEmployee() throws Throwable {

		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealOut")) {
			if (yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealReturn")) {
				yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
				yourTimePortletsSteps.wait_For_ThreeMinutes();
			} else {
				yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
				yourTimePortletsSteps.wait_For_ThreeMinutes();
			}
		}

		yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
		yourTimePortletsSteps.wait_For_ThreeMinutes();
	}
	
	@When("^I click on click in button$")
	public void i_click_on_click_in_button() throws Throwable {
		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockIn")) {
			if(!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockOut"))
			{
				yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
				yourTimePortletsSteps.wait_For_ThreeMinutes();
				
			}
			yourTimePortletsSteps.emp_yourTimecard_clockOn_clockOut();
			yourTimePortletsSteps.wait_For_ThreeMinutes();

		}
		yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
		yourTimePortletsSteps.wait_For_ThreeMinutes();

	}
	
	@When("^I click on meal return button$")
	public void i_click_on_meal_return_button() throws Throwable {

		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealReturn")) {
			if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealOut")) {
				yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
				yourTimePortletsSteps.wait_For_ThreeMinutes();

				yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
				yourTimePortletsSteps.wait_For_ThreeMinutes();
			} else {
				yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
				yourTimePortletsSteps.wait_For_ThreeMinutes();
			}
		}

		yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
		yourTimePortletsSteps.wait_For_ThreeMinutes();
	}
	
	@When("^I click on clock out button$")
	public void i_click_on_clock_out_button() throws Throwable {

		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockOut")) {
			if (yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockIn")) {
				yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
				yourTimePortletsSteps.wait_For_ThreeMinutes();

			} else {
				yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
				yourTimePortletsSteps.wait_For_ThreeMinutes();
			}
		}

		yourTimePortletsSteps.emp_yourTimecard_clockOn_clockOut();
		yourTimePortletsSteps.wait_For_ThreeMinutes();

	}
	
	@Given("^I login as tempus employee user '<EmployeeUserID>' and '<EmployeePassword>'$")
	public void i_login_as_tempus_employee_user_EmployeeUserID_and_EmployeePassword() throws Throwable {

	}

	@Then("^I validate Home page with time portlets should be display$")
	public void i_validate_Home_page_with_time_portlets_should_be_display() throws Throwable {

		yourTimePortletsSteps.emp_HomePage_Verify_YourTime_loading();
	}

	@When("^I navigate to my time portlets first time$")
	public void i_navigate_to_my_time_portlets_first_time() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
	}

	@Then("^I validate clock in to start your shift message$")
	public void iValidateClockInStartYourShiftMessage() throws Throwable {

		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("startYourShift")) {

			String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

			System.out.println(" month is :" + monthName);

			String date = yourTimePortletsSteps.get_date("0", "date");

			System.out.println(" date is :" + date);

			timecardSteps.emp_YourTimcard_Navigation();

			String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
					Integer.parseInt(date));

			System.out.println("pay period :" + timePeriod);

			timecardSteps.emp_YourTimcard_Navigation();

			timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

			timecardSteps.emp_yourTimecard_Verify_PageLoading();

			List<String> dates = timecardSteps.emp_getListOfDates_withTimePairs();
			for (String day : dates) {
				timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));
				timecardSteps.emp_yourTimecard_deleteTimePair(true);
				timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
			}

			yourTimePortletsSteps.emp_HomePage_Naviagation();
		}

		yourTimePortletsSteps.emp_HomePage_YourTime_Verify_ClockInToStartYourShift_Msg(true);

	}

	@Then("^I validate clock in start your shift message for clock employee$")
	public void i_validate_clock_in_start_your_shift_message() throws Throwable {

		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("startYourShift")) {
			boolean result = false;

			String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

			System.out.println(" month is :" + monthName);

			String date = yourTimePortletsSteps.get_date("0", "date");

			System.out.println(" date is :" + date);

			timecardSteps.emp_YourTimcard_Navigation();

			timecardSteps.emp_yourTimecard_enable_showDetails(true);

			String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
					Integer.parseInt(date));

			System.out.println(" timepeiod is :" + timePeriod);

			timecardSteps.emp_YourTimcard_Navigation();

			timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

			timecardSteps.emp_yourTimecard_Verify_PageLoading();

			List<String> timePunchs = timecardSteps.emp_yourTimecard_timecardGrid_GetPunchTime(Integer.parseInt(date));

			for (String timePunch : timePunchs) {

				System.out.println("time card punches : " + timePunch);
				if (timePunch.length() > 3) {
					result = true;
					break;
				}
			}
			assertTrue("timepair not present in timecard ", result);

		} else {
			yourTimePortletsSteps.emp_HomePage_YourTime_Verify_ClockInToStartYourShift_Msg(true);
		}
	}

	@Then("^I validate only clock in button should be display for clock employee$")
	public void i_validate_only_clocking_button_should_be_display_for_clock_employee() throws Throwable {

		yourTimePortletsSteps.emp_HomePage_Naviagation();

		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockIn")) {
			yourTimePortletsSteps.emp_Homepage_Verify_ClockOutImgIcon_Existance(true);
		} else {
			yourTimePortletsSteps.emp_Homepage_Verify_ClockINImgIcon_Existance(true);
		}
	}

	@Then("^I validate only clock in button should be display$")
	public void i_validate_only_clocking_button_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_Homepage_Verify_ClockINImgIcon_Existance(true);
		yourTimePortletsSteps.emp_Homepage_Verify_ClockOutImgIcon_Existance(false);
		yourTimePortletsSteps.emp_Homepage_Verify_MealOutImgIcon_Existance(false);
		yourTimePortletsSteps.emp_Homepage_Verify_mealReturnImgIcon_Existance(false);
	}

	@When("^I navigate to Employe home page$")
	public void i_navigate_to_Employe_home_page() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
	}

	

	@Then("^I validate that clocked in at time should be display$")
	public void i_validate_that_clocked_in_at_time_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_YourTime_verify_ClockIn_successful();
		clockInTime = yourTimePortletsSteps.emp_yourTime_GetPunchTime();
	}

	@Then("^I validate that Take Meal button should be available$")
	public void i_validate_that_Take_Meal_button_should_be_available() throws Throwable {
		yourTimePortletsSteps.emp_Homepage_Verify_MealOutImgIcon_Existance(true);
	}

	@Then("^I validate that clock out button should be available$")
	public void i_validate_that_clock_out_button_should_be_available() throws Throwable {
		yourTimePortletsSteps.emp_Homepage_Verify_ClockOutImgIcon_Existance(true);
	}

	@When("^I click on  take meal button$")
	public void i_click_on_take_meal_button() throws Throwable {

		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealOut")) {
			String monthName = yourTimePortletsSteps.get_date("0", "todayMonth").toLowerCase();

			System.out.println(" month is :" + monthName);

			String date = yourTimePortletsSteps.get_date("0", "date");

			System.out.println(" date is :" + date);

			timecardSteps.emp_YourTimcard_Navigation();

			String timePeriod = timecardSteps.emp_yourTimecard_Select_currentPayPeriod(monthName.toLowerCase(),
					Integer.parseInt(date));

			System.out.println("pay period :" + timePeriod);

			timecardSteps.emp_YourTimcard_Navigation();

			timecardSteps.emp_yourTimecard_select_timePeriod(timePeriod);

			timecardSteps.emp_yourTimecard_Verify_PageLoading();
			List<String> dates = timecardSteps.emp_getListOfDates_withTimePairs();
			for (String day : dates) {
				timecardSteps.emp_yourTimecard_editTimePair(Integer.parseInt(day));
				timecardSteps.emp_yourTimecard_deleteTimePair(true);
				timecardSteps.emp_yourTimecard_clickOn_backToTimecard();
			}

			yourTimePortletsSteps.emp_HomePage_Naviagation();

			yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}

		yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
		yourTimePortletsSteps.wait_For_ThreeMinutes();

	}

	

	@Then("^I validate that out for meal at time should be display$")
	public void i_validate_that_out_for_meal_at_time_should_be_display() throws Throwable {

		mealOutTime = yourTimePortletsSteps.emp_yourTime_GetPunchTime();

	}

	@Then("^I validate that meal retun button should be display$")
	public void i_validate_that_meal_retun_button_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_Homepage_Verify_mealReturnImgIcon_Existance(true);
	}

	@Then("^I Navigate to you timecard page$")
	public void i_Navigate_to_you_timecard_page() throws Throwable {
		timecardSteps.emp_YourTimcard_Navigation();
	}

	@Then("^I validate that time pair total hours updated correctly$")
	public void i_validate_that_time_pair_total_hours_updated_correctly() throws Throwable {

	}

	@When("^I naviagte to employe home page$")
	public void i_naviagte_to_employe_home_page() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
	}

	

	@Then("^I validate that returned from meal at time message should be display$")
	public void i_validate_that_returned_from_meal_at_time_message_should_be_display() throws Throwable {

		mealReturnTime = yourTimePortletsSteps.emp_yourTime_GetPunchTime();
		System.out.println("meal return time is : " + mealReturnTime);
	}

	@Then("^I validate that Take meal button should be display$")
	public void i_validate_that_Take_meal_button_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_Homepage_Verify_MealOutImgIcon_Existance(true);
	}

	@Then("^I validate that Clock out button should be display$")
	public void i_validate_that_Clock_out_button_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_Homepage_Verify_ClockOutImgIcon_Existance(true);
	}

	@Then("^I validate that new time pair row should be created with meal retun punch$")
	public void i_validatet_that_new_time_pair_row_should_be_created_with_meal_retun_punch() throws Throwable {

	}

	@Then("^I validate that clock out will be blank$")
	public void i_validate_that_clock_out_will_be_blank() throws Throwable {

	}

	@When("^I navigate to employee home page$")
	public void i_navigate_to_employee_home_page() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
	}

	

	@Then("^I validate that have nice day! clocked out at time should be display$")
	public void i_validate_that_have_nice_day_clocked_out_at_time_should_be_display() throws Throwable {

		clockOutTime = yourTimePortletsSteps.emp_yourTime_GetPunchTime();

	}

	@Then("^I validate that take meal button should be display$")
	public void i_validate_that_take_meal_button_should_be_display() throws Throwable {

	}

	@Then("^I validate that clock out button should be display$")
	public void i_validate_that_clock_out_button_should_be_display() throws Throwable {

	}

	@When("^I Navigate to your timecard page$")
	public void i_Navigate_to_your_timecard_page() throws Throwable {
		timecardSteps.emp_YourTimcard_Navigation();
	}

	@Then("^I validate that timecard should be edit$")
	public void i_validate_that_timecard_should_be_edit() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_readOnlyStatus(false);
	}

	@When("^I navigate to employee home page and your time portlets$")
	public void i_navigate_to_employee_home_page_and_your_time_portlets() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
	}

	@Then("^I validate that Clocked in at time message should be display$")
	public void i_validate_that_Clocked_in_at_time_message_should_be_display() throws Throwable {

		yourTimePortletsSteps.emp_HomePage_YourTime_verify_ClockIn_successful();

	}

	@Then("^I validate that Take Meal button should be display$")
	public void i_validate_that_Take_Meal_button_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_Homepage_Verify_MealOutImgIcon_Existance(true);
	}

	@When("^I navigate to homepage and your time portlets$")
	public void i_navigate_to_homepage_and_your_time_portlets() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
	}

	@Then("^I validate that Have a nice day! clocked out at time message should be display$")
	public void i_validate_that_Have_a_nice_day_clocked_out_at_time_message_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_verify_clockOut_successful();
	}

	@Then("^I validate clock in start your shift message should be display$")
	public void i_validate_clock_in_start_your_shift_message_should_be_display() throws Throwable {

		yourTimePortletsSteps.emp_HomePage_YourTime_Verify_ClockInToStartYourShift_Msg(true);

	}

	@When("^I navigate to home page and your time portlets$")
	public void i_navigate_to_home_page_and_your_time_portlets() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
	}

	@Then("^I verify That missed punches link should be not present$")
	public void i_verify_That_missed_punches_link_should_be_not_present() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_verify_missedPunches_existance(false);
	}

	@Then("^I verify That missed punches link should be present$")
	public void i_verify_That_missed_punches_link_should_be_present() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_verify_missedPunches_existance(true);
	}

	@When("^I click on missed punches link$")
	public void i_click_on_missed_punches_link() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_missedPunches_navigation();
	}

	@Then("^I verify that missed punches slider page should be display$")
	public void i_verify_that_missed_punches_slider_page_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_verify_missedPunches_pageloading();
	}

	@When("^I resolve missed punches exceptions$")
	public void i_resolve_missed_punches_exceptions() throws Throwable {
		List<String> missPunchDates = yourTimePortletsSteps.emp_homePage_get_missedPunchesDates();
		for (String date : missPunchDates) {
			yourTimePortletsSteps.emp_homePage_enter_missedPunchData(date, "01:30 PM");
		}
		yourTimePortletsSteps.emp_homepage_save_missedPunchesData();
		yourTimePortletsSteps.emp_homePage_close_missedPunches_slider();
	}

	@Then("^I validate that missed puches link shoud not be visible from you time portlets$")
	public void i_validate_that_missed_puches_link_shoud_not_be_visible_from_you_time_portlets() throws Throwable {
		yourTimePortletsSteps.emp_HomePage_Naviagation();
		yourTimePortletsSteps.emp_yourTime_verify_missedPunches_existance(false);
	}

	@Then("^I verify That approve timecard link should be not present$")
	public void i_verify_That_approve_timecard_link_should_be_not_present() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_verify_approveTimecard_existance(false);
	}

	@Then("^I verify That approve timecard link should be present$")
	public void i_verify_That_approve_timecard_link_should_be_present() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_verify_approveTimecard_existance(true);
	}

	@When("^I click on approve time card link from your time portlets$")
	public void i_click_on_approve_time_card_link_from_your_time_portlets() throws Throwable {
		yourTimePortletsSteps.emp_youTime_approveTimecard_navigation();
	}

	@When("^I click on approve timecard button$")
	public void i_click_on_approve_timecard_button() throws Throwable {
		timecardSteps.emp_yourTimecard_clickOn_approveTimecard();
		
		
	}

	@Then("^I verify that timecard should be approved$")
	public void i_verify_that_timecard_should_be_approved() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_approvedTimecard();
	}

	@Then("^I validate that approve timecard link should not be visible$")
	public void i_validate_that_approve_timecard_link_should_not_be_visible() throws Throwable {
		yourTimePortletsSteps.emp_yourTime_verify_approveTimecard_existance(false);
	}

	@Then("^I Validated that error message should be display$")
	public void i_Validated_that_error_message_should_be_display() throws Throwable {
		yourTimePortletsSteps.emp_yourTimecard_verify_donotHaveAccess_msg(true);
	}

@When("^I click on timecard button from thing to do$")
public void i_click_on_timecard_button_from_thing_to_do() throws Throwable {
    yourTimePortletsSteps.emp_yourTimecard_Navigation_FromYourTime();
	
}








@And("^I validate successfull message$")
public void iValidateSuccessfullMessage() throws Throwable {

	
	String clockIN = "08:00 AM";
	String takeaMeal = "09:30 AM";
     
	String calculatedHours =  timecardSteps.calculate_hours(clockIN,takeaMeal);
	
	System.out.println("hours is "+calculatedHours);
	
}


@When("^I click on click in with notes$")
public void i_click_on_click_in_with_notes_and_wait_for_three_minutes() throws Throwable {
	
	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockIn")) {
		if(!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockOut"))
		{
			yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
			
		}
		yourTimePortletsSteps.emp_yourTimecard_clockOn_clockOut();
		yourTimePortletsSteps.wait_For_ThreeMinutes();

	}
	
	yourTimePortletsSteps.emp_yourTime_clickOn_clockIn_notesIcon();
	
}

@When("^I enter note from note slider \"([^\"]*)\" and click on save and wait for three minutes$")
public void i_enter_note_from_note_slider_and_click_on_save_and_wait_for_three_minutes(String arg1) throws Throwable {
	note = arg1;  //--- static string for validating date
	yourTimePortletsSteps.emp_yourTime_enterNotes_from_notesSlider(arg1);
	yourTimePortletsSteps.wait_For_ThreeMinutes();
}

@Then("^I validate that Take Meal a smart button should be display$")
public void i_validate_that_Take_Meal_smart_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_Homepage_Verify_MealOutImgIcon_Existance(true);
}

@Then("^I validate that clock out smart button should be display$")
public void i_validate_that_clock_out_smart_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_Homepage_Verify_ClockOutImgIcon_Existance(true);
}

@Then("^I validate that view more actions link should be display$")
public void i_validate_that_view_more_actions_link_should_be_display() throws Throwable {
     yourTimePortletsSteps.emp_yourTime_verify_viewMoreOptions_existance(true);
}

@Then("^I validate that carousel should not be display$")
public void i_validate_that_carousel_should_not_be_display() throws Throwable {
	yourTimePortletsSteps.emp_yourTime_verify_carousel_existence(false);
}

@Then("^I validate that Take a Meal smart button should be display$")
public void i_validate_that_Take_a_Meal_smart_button_should_be_display() throws Throwable {
    yourTimePortletsSteps.emp_Homepage_Verify_MealOutImgIcon_Existance(true);
}

@When("^I click on take a meal with note$")
public void i_click_on_take_a_meal_with_note() throws Throwable {
    
	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealOut")) {
		if(yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealReturn"))
		{
			yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}else {
		    yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
		    yourTimePortletsSteps.wait_For_ThreeMinutes();
		}
	}
	yourTimePortletsSteps.emp_yourTime_clickOn_takeMeal_notesIcon();
 }


@Then("^I validate that meal return button should be display$")
public void i_validate_that_meal_return_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_Homepage_Verify_mealReturnImgIcon_Existance(true);
}


@When("^I click on meal return with notes$")
public void i_click_on_meal_return_with_notes() throws Throwable {

	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealReturn")) {
		if(yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealOut"))
		{
			yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}else {
		    yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
		    yourTimePortletsSteps.wait_For_ThreeMinutes();
		    yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}
	}
	yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn_notesIcon();
	
}

@When("^I click on clock out with note$")
public void i_click_on_clock_out_with_note() throws Throwable {
    
	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockOut")) {  //clockOut
		if(yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealReturn"))  //mealReturn
		{
			yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}else {
		    yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
		    yourTimePortletsSteps.wait_For_ThreeMinutes();
		  
		}
	}
	yourTimePortletsSteps.emp_yourTime_clickOn_clockOut_notesIcon();
	
}

@Then("^I validate that clock in button should be display$")
public void i_validate_that_clock_in_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_Homepage_Verify_ClockINImgIcon_Existance(true);
}

@When("^I validate that time portlets smart buttons should be display$")
public void i_validate_that_time_portlets_smart_buttons_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.smartButtons,true);
}

@When("^I validate that view more options link should be present$")
public void i_validate_that_view_more_options_link_should_be_display() throws Throwable {
   yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.viewMoreOptions,true);	
}

@When("^I validate that time portlets carousel buttons should not be display$")
public void i_validate_that_time_portlets_carousel_buttons_should_not_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.carouselButtons,false);	
}

@When("^I validate that hide more options link should not be display$")
public void i_validate_that_hide_more_options_link_should_not_be_display() throws Throwable { 
	yourTimePortletsSteps.emp_yourTime_verify_hideMoreOptins_existence(false);
}

@When("^I click on view more options link$")
public void i_click_on_view_more_actions_link() throws Throwable {
    yourTimePortletsSteps.emp_yourTime_clickOn_viewMoreOptions();	
}

@Then("^I validate that time portlets smart buttons should not be display$")
public void i_validate_that_time_portlets_smart_buttons_should_not_be_display() throws Throwable { 
	yourTimePortletsSteps.emp_yourTime_verify_smartbutton_existence(false);
}

@Then("^I validate that time portlets carousel buttons should be display$")
public void i_validate_that_time_portlets_carousel_buttons_should_be_display() throws Throwable {  
	yourTimePortletsSteps.emp_yourTime_verify_carousel_existence(true);
}

@Then("^I validate that clock in carousel button should be display$")
public void i_validate_that_clock_in_carousel_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.clockIn_carousel,true);
}

@Then("^I validate that meal return carousel button should be display$")
public void i_validate_that_meal_return_carousel_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.mealReturn_carousel,true);
}

@Then("^I validate that clock out carousel button should be display$")
public void i_validate_that_clock_out_carousel_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.clockIn_carousel,true);
}

@Then("^I validate that hide more options link should be display$")
public void i_validate_that_hide_more_options_link_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.hideMoreOptons,true);
}

@Then("^I validate that view more options link should not be display$")
public void i_validate_that_view_more_options_link_should_not_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.viewMoreOptions,false);
	
}

@When("^I click on hide more options link$")
public void i_click_on_hide_more_options_link() throws Throwable {
   yourTimePortletsSteps.emp_yourTime_clickOn_hideMoreOptions();
	
}

@Then("^I validate that take a meal carousel button should be display$")
public void i_validate_that_take_a_meal_carousel_button_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.takeAMeal_carousel,true);
}


@When("^I click on clock in carousel button and wait for three minutes$")
public void i_click_on_clock_in_carousel_button_and_wait_for_three_minutes() throws Throwable {
    
	yourTimePortletsSteps.emp_yourtime_clickOn_clockIn_carousel();
	yourTimePortletsSteps.wait_For_ThreeMinutes();
	
}

@When("^I click on take a meal carousel button and wait for three minutes$")
public void i_click_on_take_a_meal_carousel_button_and_wait_for_three_minutes() throws Throwable {
   
	yourTimePortletsSteps.emp_yourTime_clickOn_takeAMeal_carousel();
	yourTimePortletsSteps.wait_For_ThreeMinutes();
	
}

@Then("^I validate that meal return smart button should be display$")
public void i_validate_that_meal_return_smart_button_should_be_display() throws Throwable {
    yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.mealReturn,true);
}


@When("^I click on meal return carousel button and wait for three minutes$")
public void i_click_on_meal_return_carousel_button_and_wait_for_three_minutes() throws Throwable {
    yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn_carousel();
	yourTimePortletsSteps.wait_For_ThreeMinutes();
}

@When("^I click on clock out carousel button and wait for three minutes$")
public void i_click_on_clock_out_carousel_button_and_wait_for_three_minutes() throws Throwable {
   yourTimePortletsSteps.emp_yourTime_clickOn_clockOut_carousel();
   yourTimePortletsSteps.wait_For_ThreeMinutes();
}

@Then("^I validate that clock in smart button should be display$")
public void i_validate_that_clock_in_smart_button_should_be_display() throws Throwable {
    
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.clockIn,true);
}

@When("^I click on carousel clock in with notes$")
public void i_click_on_carousel_clock_in_with_notes() throws Throwable {

	yourTimePortletsSteps.emp_yourTime_clickOn_clockIn_noteIcon_carousel();	
}

@When("^I click on carousel take a meal with notes$")
public void i_click_on_carousel_take_a_meal_with_notes() throws Throwable {
	yourTimePortletsSteps.emp_yourTime_clickOn_takeMeal_notesIcon_carousel();
}

@When("^I click on carousel meal return with notes$")
public void i_click_on_carousel_meal_return_with_notes() throws Throwable {
    
	yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn_notesIcon_carousel();
}

@When("^I click on carousel clock out with notes$")
public void i_click_on_carousel_clock_out_with_notes() throws Throwable {
    yourTimePortletsSteps.emp_yourTime_clickOn_clockOut_notesIcon_carousel();
}

@When("^I click on clock in smart button$")
public void i_click_on_clock_in_smart_button() throws Throwable {
	
	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockIn")) {
		if(!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockOut"))
		{
			yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
			
		}
		yourTimePortletsSteps.emp_yourTimecard_clockOn_clockOut();
		yourTimePortletsSteps.wait_For_ThreeMinutes();

	}
	
	yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.clockIn);
	
}

@When("^I click on carousel clock in button$")
public void i_click_on_carousel_clock_in_button() throws Throwable {
    yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.clockIn_carousel);
}
@Then("^I validate that wait for three minutes to clock in message should be display$")
public void i_validate_that_wait_for_three_minutes_to_clock_in_message_should_be_display() throws Throwable {
    yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.clockIn,true);
}

@When("^I enter note and click on save$")
public void i_enter_note_and_click_on_save() throws Throwable {
   
	yourTimePortletsSteps.emp_yourTime_enterNotes_from_notesSlider("Note message");
}

@Then("^I verify that wait for three minutes to clock in with notes message should be display$")
public void i_verify_that_wait_for_three_minutes_to_clock_in_with_notes_message_should_be_display() throws Throwable {
    
	yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.clockIn,true);
	yourTimePortletsSteps.emp_homePage_close_missedPunches_slider();
}
@When("^I wait for three minutes$")
public void i_wait_for_three_minutes() throws Throwable {

 yourTimePortletsSteps.wait_For_ThreeMinutes();
}

@When("^I click on clock out smart button$")
public void i_click_on_clock_out_smart_button() throws Throwable {
    
	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockOut")) {
		if (yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("clockIn")) {
			yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();

		} else {
			yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}
	}
	
	yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.clockOut);
}

@Then("^I verify that clock in smart button should be display$")
public void i_verify_that_clock_in_smart_button_should_be_display() throws Throwable {
   yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.clockIn, true);
}

@When("^I click on carousel take a meal button$")
public void i_click_on_carousel_take_a_meal_button() throws Throwable {
    
	yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.takeAMeal_carousel);
}

@Then("^I click on take a meal smart button$")
public void i_click_on_take_a_meal_smart_button() throws Throwable {
    
	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealOut")) {
		if (yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealReturn")) {
			yourTimePortletsSteps.emp_yourTime_clickOn_mealReturn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		} else {
			yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}
	}
	
	yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.takeAMeal);
	
}

@Then("^I validate that wait for three minutes to take a meal message should be display$")
public void i_validate_that_wait_for_three_minutes_to_take_a_meal_message_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.takeAMeal, true);
}

@When("^I click on carousel meal return button$")
public void i_click_on_carousel_meal_return_button() throws Throwable {
	
	yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.mealReturn_carousel);
}

@Then("^I validate that wait for three minutes to meal return message should be display$")
public void i_validate_that_wait_for_three_minutes_to_meal_return_message_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.mealReturn, true);
}

@Then("^I verify that wait for three minutes to meal return with notes message should be display$")
public void i_verify_that_wait_for_three_minutes_to_meal_return_with_notes_message_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.mealReturn, true);
	yourTimePortletsSteps.emp_homePage_close_missedPunches_slider();
}

@When("^I click on carousel clock out button$")
public void i_click_on_carousel_clock_out_button() throws Throwable {
	
	yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.clockOut_carousel);
}

@Then("^I validate that wait for three minutes to clock out message should be display$")
public void i_validate_that_wait_for_three_minutes_to_clock_out_message_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.clockOut, true);
}

@Then("^I verify that wait for three minutes to clock out with notes message should be display$")
public void i_verify_that_wait_for_three_minutes_to_clock_out_with_notes_message_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.clockOut, true);
	yourTimePortletsSteps.emp_homePage_close_missedPunches_slider();
	
}

@When("^I navigate to home page$")
public void i_navigate_to_home_page() throws Throwable {
   yourTimePortletsSteps.emp_HomePage_Naviagation();
}

@When("^I click on hide more options$")
public void i_click_on_hide_more_options() throws Throwable {
    yourTimePortletsSteps.emp_yourTime_clickOn_hideMoreOptions();
}


@When("^I click on meal return smart button$")
public void i_click_on_meal_return_smart_button() throws Throwable {
    
	if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealReturn")) {
		if (!yourTimePortletsSteps.emp_yourTime_verify_webElement_presence("mealOut")) {
			yourTimePortletsSteps.emp_HomePage_YourTime_ClickOn_ClockIn();
			yourTimePortletsSteps.wait_For_ThreeMinutes();

			yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		} else {
			yourTimePortletsSteps.emp_yourTime_clickOn_mealOut();
			yourTimePortletsSteps.wait_For_ThreeMinutes();
		}
		
		
	}
	
	yourTimePortletsSteps.emp_yourTime_clickOn_element(YourTimecard.data.mealReturn);
	
}

@Then("^I verify that wait for three minutes to take a meal with notes message should be display$")
public void i_verify_that_wait_for_three_minutes_to_take_a_meal_with_notes_message_should_be_display() throws Throwable {
    
	yourTimePortletsSteps.emp_yourTime_verify_errorMessage_existence(YourTimecard.data.takeAMeal, true);
	yourTimePortletsSteps.emp_homePage_close_missedPunches_slider();
	
}

@When("^I enter out time \"([^\"]*)\" for first  row for previous day$")
public void i_enter_out_time_for_first_row_for_previous_day(String arg1) throws Throwable {
    
    List<String> timePairs = new ArrayList<String>();
    String date = yourTimePortletsSteps.get_date("-1", "date");
    
	timePairs.add(" "+"-"+arg1+"-"+"1"+"-"+date);
	
	yourTimePortletsSteps.emp_yourTime_missedPunchesSlider_addTimePair(timePairs, true);
	
	
}

@When("^I enter out time \"([^\"]*)\" for first  row for previous day and not click on Save$")
public void i_enter_out_time_for_first_row_for_previous_day_and_not_click_on_Save(String arg1) throws Throwable {
   
	 List<String> timePairs = new ArrayList<String>();
	    String date = yourTimePortletsSteps.get_date("-1", "date");
	    
		timePairs.add(" "+"-"+arg1+"-"+"1"+"-"+date);
		
		yourTimePortletsSteps.emp_yourTime_missedPunchesSlider_addTimePair(timePairs, false);
		
}

@Then("^I verify that time pair overlapping message should be display$")
public void i_verify_that_time_pair_overlapping_message_should_be_display() throws Throwable {
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.timePairOverlaps, true);
}


@When("^I enter out times as \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" for previous day$")
public void i_enter_out_times_as_and_and_for_previous_day(String arg1, String arg2, String arg3) throws Throwable {

	 List<String> timePairs = new ArrayList<String>();
	    String date = yourTimePortletsSteps.get_date("-1", "date");
	    
	    timePairs.add(" "+"-"+arg1+"-"+"1"+"-"+date);
	    timePairs.add(" "+"-"+arg2+"-"+"2"+"-"+date);
	    timePairs.add(" "+"-"+arg3+"-"+"3"+"-"+date);
	    
		yourTimePortletsSteps.emp_yourTime_missedPunchesSlider_addTimePair(timePairs, true);
	
}

@Then("^I verify that all missed punches resolved$")
public void i_verify_that_all_missed_punches_resolved() throws Throwable {
   
	yourTimePortletsSteps.emp_verify_element_existence(YourTimecard.data.fixedAllPunches, true);
	
}

@When("^I click note icon for previous day missed punch$")
public void i_click_note_icon_for_today_missed_punch() throws Throwable {
   
	String date = yourTimePortletsSteps.get_date("-1", "date");
	
	yourTimePortletsSteps.emp_yourTime_missedPunchesSlider_clickOn_addNote(date, 1);
	
}

@When("^I enter note from note slider and click on save$")
public void i_enter_note_from_note_slider_and_click_on_save() throws Throwable {
   
	YourTimePortletsStepDefinition.note = "note message";
	yourTimePortletsSteps.emp_yourTime_missedPunchesSlider_enter_noteMessage(YourTimePortletsStepDefinition.note);
}

@When("^I close missed punches slider$")
public void i_close_missed_punches_slider() throws Throwable {
   
	yourTimePortletsSteps.emp_homePage_close_missedPunches_slider();
}

@Then("^I verify that updated missed punches note message$")
public void i_verify_that_updated_missed_punches_note_message() throws Throwable {
	
	yourTimePortletsSteps.em_yourTime_missedPunches_verify_noteMessage(YourTimePortletsStepDefinition.note, true);
	
	yourTimePortletsSteps.emp_yourTime_missedPunches_close_notePopup();
	
}







}
