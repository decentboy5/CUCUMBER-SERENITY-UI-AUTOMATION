package com.adp.tempus.stepDefinition;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.adp.tempus.pages.WebClockingHomePage;
import com.adp.tempus.pages.YourTimecard;
import com.adp.tempus.steps.WebClockingSteps;
import com.adp.tempus.steps.YourTimecardSteps;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class WebClockingStepDefinition {

	@Steps
	YourTimecardSteps timecardSteps;

	@Steps
	WebClockingSteps webclockingSteps;

	public static String clockInTime = "";
	public static String clockOutTime = "";
	public static String mealOutTime = "";
	public static String mealReturnTime = "";
	public static String note = "";

	@Given("^I login as Web clocking employee user with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_as_Web_clocking_employee_user_with_and(String userid, String password) throws Throwable {

		webclockingSteps.WebClocking_EmployeeLogin(userid, password, "");
		webclockingSteps.emp_HomePage_Verify_Webclocking_Homepage_loading();
	}

	@Then("^I Verify Timer in Web clocking screen$")
	public void i_Verify_Timer_in_Web_clocking_screen() throws Throwable {
		webclockingSteps.i_Verify_Timer_in_Web_clocking_screen();
	}

	@Then("^I validate Add a Note slider is openedww$")
	public void i_validate_Add_a_Note_slider_is_openedww(Map<String, String> arg1) throws Throwable {
		System.out.println(arg1);
		System.out.println(arg1.toString());
	}

	@When("^I Click Button on Web Clocking Page \"([^\"]*)\"$")
	public void i_Click_Button_on_Web_Clocking_Page(String smartButton) throws Throwable {

		if (WebClockingHomePage.access_carousel_buttons && smartButton.equalsIgnoreCase("START WORK")) {
			webclockingSteps.i_Click_Button_under_on_carousel_Web_Clocking_Page(smartButton);
		} else {
			webclockingSteps.i_Click_Button_on_Web_Clocking_Page(smartButton);
		}
		WebClockingHomePage.access_carousel_buttons = false;

	}

	@When("^I Click Button with notes on Web Clocking Page \"([^\"]*)\"$")
	public void i_Click_Button_with_notes_on_Web_Clocking_Page(String smartButton) throws Throwable {

		if (WebClockingHomePage.access_carousel_buttons && smartButton.equalsIgnoreCase("START WORK")) {
			webclockingSteps.i_Click_Button_with_notes_under_on_carousel_Web_Clocking_Page(smartButton);
		} else {
			webclockingSteps.i_Click_Button_with_notes_on_Web_Clocking_Page(smartButton);
		}
		WebClockingHomePage.access_carousel_buttons = false;

	}

	@Then("^I validate Add a Note slider is opened$")
	public void i_validate_Add_a_Note_slider_is_opened() throws Throwable {
		webclockingSteps.i_validate_Add_a_Note_slider_is_opened();
	}

	@Given("^I enter \"([^\"]*)\" in Add a Note slider and click on \"([^\"]*)\"$")
	public void i_enter_in_Add_a_Note_slider_and_click_on(String notes, String btnName) throws Throwable {
		webclockingSteps.i_enter_in_Add_a_Note_slider_and_click_on(notes, btnName);
	}

	@Given("^I validate \"([^\"]*)\" popup with Keep Me loggedIn and Logout buttons$")
	public void i_validate_popup_with_Keep_Me_loggedIn_and_Logout_buttons(String message) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		webclockingSteps.emp_HomePage_WebclockingPopup(message);
	}

	@And("^I click on KEEP ME LOGGED IN button$")
	public void i_click_on_KEEP_ME_LOGGED_IN_button() throws Throwable {

		webclockingSteps.emp_HomePage_WebclockingPopup_clickon_KeepmeLoggedin();
	}

	@Then("^I validate that Screen is navigating to Web clocking home screen$")
	public void i_validate_that_Screen_is_navigating_to_Web_clocking_home_screen() throws Throwable {

		webclockingSteps.emp_Screen_is_Navigated_to_webclocking_homescreen();
	}

	@Then("^I validate that \"([^\"]*)\" at time should be display$")
	public void i_validate_message_at_time_should_be_display(String message) throws Throwable {

		webclockingSteps.emp_HomePage_verify_mytime_status(message);
		clockInTime = webclockingSteps.emp_yourTime_GetPunchTime();
	}

	@Given("^I validate \"([^\"]*)\" smart button displayed in webclocking Home screen$")
	public void i_validate_smart_button_displayed_in_webclocking_Home_screen(String smartbutton) throws Throwable {

		webclockingSteps.i_validate_smart_button_displayed_in_webclocking_Home_screen(smartbutton);
	}

	@Given("^I validate that view more actions link displayed in webclocking Home screen$")
	public void i_validate_that_view_more_actions_link_displayed_in_webclocking_Home_screen() throws Throwable {
		webclockingSteps.i_validate_that_view_more_actions_link_displayed_in_webclocking_Home_screen();
	}

	@Given("^I validate that carousel should not be display in webclocking Home screen$")
	public void i_validate_that_carousel_should_not_be_display_in_webclocking_Home_screen() throws Throwable {
		webclockingSteps.i_validate_that_carousel_should_not_be_display_in_webclocking_Home_screen(false);
	}

	@Then("^I validate that timecard should be loaded successfully in web clocking$")
	public void i_validate_that_timecard_should_be_loaded_successfully_in_web_clocking() throws Throwable {

		webclockingSteps.i_validate_that_timecard_should_be_loaded_successfully_in_web_clocking();
	}

	@Then("^I validate punch on timecard$")
	public void i_validare_Clocked_in_punch_on_timecard() throws Throwable {

		String monthName = webclockingSteps.get_date("0", "todayMonth").toLowerCase();

		System.out.println(" month is :" + monthName);

		String date = webclockingSteps.get_date("0", "date");

		System.out.println(" date is :" + date);

		webclockingSteps.emp_yourTimecard_Select_ActualPayPeriod(monthName.toLowerCase(), Integer.parseInt(date));

		// System.out.println("Time period: Naidu" + timePeriod);

		webclockingSteps.selectPayPeriodTimecardPage(WebClockingSteps.payperiod);

		webclockingSteps.emp_yourTimecard_Verify_PageLoading();

		webclockingSteps.emp_yourTimecard_editTimePair(Integer.parseInt(date));

		List<String> timePunchs = webclockingSteps.emp_youtTimecard_GetPunchTime();

		for (String timePunch : timePunchs) {
			System.out.println("time card punches : " + timePunch);

		}
		webclockingSteps.emp_yourTimecard_CheckTimePair_Existence(timePunchs, WebClockingStepDefinition.clockInTime);

	}

	@When("^I Click Button on Add Time Pair Page \"([^\"]*)\" in Web Clocking$")
	public void i_Click_Button_on_Add_Time_Pair_Page_in_Web_Clocking(String Button) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		webclockingSteps.i_Click_Button_on_Add_Time_Pair_Page_in_Web_Clocking(Button);
	}

	@Given("^I Click on Back button in Time card screen in web clocking$")
	public void i_Click_on_Back_button_in_Time_card_screen_in_web_clocking() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		webclockingSteps.i_Click_on_Back_button_in_Time_card_screen_in_web_clocking();

	}

	@Then("^I validate Web clocking Home screen successfully loaded$")
	public void i_validate_Web_clocking_Home_screen_successfully_loaded() throws Throwable {
		webclockingSteps.emp_HomePage_Verify_Webclocking_Homepage_loading();
		Thread.sleep(5000);
	}

	@Then("^I Validate User successfully logged Out in Web Clocking$")
	public void i_Validate_User_successfully_logged_Out_in_WebClocking() throws Throwable {

		webclockingSteps.i_Validate_User_successfully_logged_Out_in_WebClocking();

	}

	@Then("^I validate Home page with time portlets should be display1$")
	public void i_validate_Home_page_with_time_portlets_should_be_display() throws Throwable {

		webclockingSteps.emp_HomePage_Verify_Webclocking_Homepage_loading();
	}

	@Then("^I Navigate to you timecard page1$")
	public void i_Navigate_to_you_timecard_page() throws Throwable {
		timecardSteps.emp_YourTimcard_Navigation();
	}

	@Then("^I validate that time pair total hours updated correctly1$")
	public void i_validate_that_time_pair_total_hours_updated_correctly() throws Throwable {

	}

	@When("^I Navigate to your timecard page1$")
	public void i_Navigate_to_your_timecard_page() throws Throwable {
		timecardSteps.emp_YourTimcard_Navigation();
	}

	@When("^I click on missed punches link1$")
	public void i_click_on_missed_punches_link() throws Throwable {
		webclockingSteps.emp_yourTime_missedPunches_navigation();
	}

	@When("^I click on approve timecard button1$")
	public void i_click_on_approve_timecard_button() throws Throwable {
		timecardSteps.emp_yourTimecard_clickOn_approveTimecard();

	}

	@Then("^I verify that timecard should be approved1$")
	public void i_verify_that_timecard_should_be_approved() throws Throwable {
		timecardSteps.emp_yourTimecard_verify_approvedTimecard();
	}

	// ----------- web clocking offline things

	@Given("^I validate that Web clocking is in offline mode$")
	public void i_validate_that_Web_clocking_is_in_offline() throws Throwable {

		webclockingSteps.i_validate_that_Web_clocking_is_in_offline();
	}
}
