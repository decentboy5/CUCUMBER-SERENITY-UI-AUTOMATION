package com.adp.tempus.pages;

import static org.junit.Assert.assertTrue;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.tlmbdd.pages.GenericPageObject;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class YourTimePortlets extends GenericPageObject {

	// start --- WFN login page elements
	@FindBy(xpath = "//input[@id='user_id']")
	private WebElementFacade tbx_UserID;

	@FindBy(xpath = "//input[@id='password']")
	private WebElementFacade tbx_Password;

	@FindBy(xpath = "//button[@id='subBtn']")
	private WebElementFacade btn_Submit;

	@FindBy(xpath = "//i[contains(@title,'Log Out')]")
	private WebElementFacade imgIcon_LogOut;

	// --end ------WFN login page -----

	@FindBy(xpath = "//div[contains(text(),'Start Work') and contains(@class,'mytime-action-label')]/..")
	private WebElementFacade imgIcon_startWork_portlets;
	
	@FindBy(xpath = "//div[contains(text(),'End Meal') and contains(@class,'mytime-action-label')]/..")
	private WebElementFacade imgIcon_endMeal_portlets;
	
	@FindBy(xpath = "//div[contains(text(),'End Work') and contains(@class,'mytime-action-label')]/..")
	private WebElementFacade imgIcon_endWork_portlets;

	@FindBy(xpath = "//div[contains(text(),'Take Meal') or contains(text(),'Take a Meal') and contains(@class,'mytime-action-label')]/..")
	private WebElementFacade imgIcon_takeMeal_portlets;
	

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Start Work')]/..")
	private WebElementFacade imgIcon_startWork_carousel;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'End Work')]/..")
	private WebElementFacade imgIcon_endWork_carousel;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Take Meal')]/..")
	private WebElementFacade imgIcon_takeMeal_carousel;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'End Meal')]/..")
	private WebElementFacade imgIcon_endMeal_carousel;
	
	
	@FindBy(xpath = "//div[text()='Transfer' and contains(@class,'mytime-action-label')]")
	private WebElementFacade imgIcon_Transfer_portlets;

	@FindBy(xpath = "//div[contains(text(),'Click the button to start your shift') and contains(@class,'mytime-status mytime-grey')]")
	private WebElementFacade lbl_startYourShift;

	@FindBy(xpath = "//div[contains(text(),'Started Work') and contains(@class,'mytime-status mytime-green')]")
	private WebElementFacade lbl_startedWork_message;

	@FindBy(xpath = "//div[contains(text(),'Meal Ended') and contains(@class,'mytime-status mytime-green')]")
	private WebElementFacade lbl_mealEnded_message;

	@FindBy(xpath = "//div[contains(text(),'Things to Do') and contains(@class,'mytime-header-things-to-do')]")
	private WebElementFacade lbl_ThingsToDo;

	@FindBy(xpath = "//*[@id='thingsToDoLinks']/descendant::span[text()='Timecard']/..")
	private WebElementFacade btn_Timecard;


	@FindBy(xpath = "//div[text()='Approve Timecard' and contains(@class,'thingstodo-tile-todolistviewname')]")
	private WebElementFacade lnk_ApproveTimecard;

	@FindBy(xpath = "//div[text()='pending approval']")
	private WebElementFacade lbl_PendingApproval;

	
	@FindBy(xpath = "//div[contains(@class,'mytime-status-time')]")
	private WebElementFacade lbl_lastPunchTime;

	@FindBy(xpath = "//div[text()='Ended Work']")
	private WebElementFacade lbl_endedWork_message;

	@FindBy(xpath = "//div[text()='Approve Timecard']")
	private WebElementFacade btn_approveTimecard;

	@FindBy(xpath = "//span[text()='APPROVE TIMECARD']/..")
	private WebElementFacade btn_approveTimecard_timecard;

	@FindBy(xpath = "//div[text()='Missed Punches' and contains(@class,'todolistviewname')]")
	private WebElementFacade lnk_missedPunches;

	@FindBy(xpath = "//div[contains(@class,'missed-punch-grid')]/descendant::div[@class='msdpunchesdata'][1]")
	private WebElementFacade tblrow_missedPunch;

	@FindBy(xpath = "//span[text()='Back']/parent::button[contains(@class,'slide-in-close')]")
	private WebElementFacade btn_back_missedPunchSlider;
	

	@FindBy(xpath = "//span[text()='SUBMIT']/..")
	private WebElementFacade btn_submit_missedPunchesSlide;

	@FindBy(xpath = "//div[contains(text(),'You fixed all your missed punches') or contains(text(),'Great job') ]")
	private WebElementFacade lbl_success_awesome_message;

	@FindBy(xpath = "//*[@id='lastPunchTimeDuration']/span[1]")
	private WebElementFacade lbl_time_lastPunchSession;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'End Work')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_endWork_carousel;
	
	@FindBy(xpath = "//div[contains(text(),'End Work')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_endWork;
	
	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Start Work')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_startWork_carousel;
	
	@FindBy(xpath = "//div[contains(text(),'Start Work')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_startWork;
	
	
	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Take Meal')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_takeMeal_carousel;
	
	@FindBy(xpath = "//div[contains(text(),'Take Meal')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_takeMeal;
	
	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'End Meal')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_endMeal_carousel;
	
	@FindBy(xpath = "//div[contains(text(),'End Meal')]/../descendant::*[contains(@class,'notes-icon-ellipsis')][1]")
	private WebElementFacade imgIcon_note_endMeal;

	@FindBy(xpath = "//div[contains(@class,'popover')]/descendant::span[contains(text(),'End work with notes')][1]")
	private WebElementFacade lbl_endWorkWithNotes_popover;
	
	@FindBy(xpath = "//div[contains(@class,'popover')]/descendant::span[contains(text(),'Start work with notes')][1]")
	private WebElementFacade lbl_startWorkWithNotes_popover;
	
	@FindBy(xpath = "//div[contains(@class,'popover')]/descendant::span[contains(text(),'Take meal with notes')][1]")
	private WebElementFacade lbl_takeMealWithNotes_popover;
	
	@FindBy(xpath = "//div[contains(@class,'popover')]/descendant::span[contains(text(),'End meal with notes')][1]")
	private WebElementFacade lbl_endMealWithNotes_popover;

	@FindBy(xpath = "//span[text()='SUBMIT']/..")
	private WebElementFacade btn_submit_notesSlider;
	
	@FindBy(xpath = "//span[text()='SAVE']/..")
	private WebElementFacade btn_save_notesSlider;
	
	

	@FindBy(xpath = "//*[@id='timeCard_root']/descendant::div[contains(@class,'panel timecard')]")
	private WebElementFacade tbl_Timecard;

	@FindBy(xpath = "//span[contains(text(),'VIEW MORE ACTIONS')]/..")
	private WebElementFacade lnk_viewMoreActions;

	@FindBy(xpath = "//div[@class='carouselClass']/descendant::div[contains(text(),'Take Meal') or contains(text(),'End Work')]")
	private WebElementFacade imgIcon_carousel;

	@FindBy(xpath = "//*[@id='currenttime_id']/span")
	private WebElementFacade lbl_time_onYourTimePage;

	@FindBy(xpath = "//div[contains(text(),'not have access to view this section')]")
	private WebElementFacade lbl_youDoNotHaveAccess_message;
	
	@FindBy(xpath = "//div[contains(text(),'Start Work') or contains(text(),'End Meal') or contains(text(),'End Work') or contains(text(),'not have access to view this section')]")
	private WebElementFacade imgIcon_startWork_or_endWork_endMeal;
	
	@FindBy(xpath="//div[contains(@class,'mytime-status mytime-orange') and text()='Out for a Meal']")
	private WebElementFacade lbl_mealOut;
	
	@FindBy(xpath="//button[text()='Home']")
	private WebElementFacade btn_home;
	
	@FindBy(xpath="//span[contains(text(),'HIDE MORE OPTIONS')]/..")
	private WebElementFacade lnk_hideMoreOptions;
	
	@FindBy(xpath="//textarea[contains(@class,'action-notes-text-area vdl-textarea')]")
	private WebElementFacade tbx_notes_textArea;
	
	@FindBy(xpath="//textarea[contains(@class,'vdl-textarea')]")
	private WebElementFacade tbx_notes_textArea_missedPunchSlider;
	
	@FindBy(xpath="//span[text()='CANCEL' and contains(@class,'container')]/..")
	private WebElementFacade btn_cancel_notePopOver;
	
	@FindBy(xpath="(//span[text()='CANCEL'])[last()]/parent::button")
	private WebElementFacade btn_cancel_notePopOver_missedpunches;
	
	
	
	@FindBy(xpath="//div[contains(text(),'Out Punch can\'t be less than or equal to In Punch')]")
	private WebElementFacade lbl_lessThan_or_equal_to_error_message;
	    
	@FindBy(xpath="//div[contains(text(),'Out Punch can't be greater than or equal to next In Punch')]")
	private WebElementFacade lbl_greaterThan_or_equal_to_error_message;
	
	@FindBy(xpath="//div[contains(text(),'Take Meal') or contains(text(),'Start Work') or contains(text(),'End Meal')]/parent::div/../../*[not(@class='carouselClass')]")
	private WebElementFacade imgIcon_smartButton;
	
	@FindBy(xpath="//div[contains(text(),'You can') and contains(text(),'t end your shift just yet')]")
	private WebElementFacade lbl_cannotEndYourShiftJustYet;
	
	@FindBy(xpath="//div[contains(text(),'Try again after 3 minutes to end your shift')]")
	private WebElementFacade lbl_threeMinutesToEndYourShift;
	
	@FindBy(xpath="//div[contains(text(),'You can') and contains(text(),'t start work just yet')]")
	private WebElementFacade lbl_cannotStartWorkJustYet;
	
	@FindBy(xpath="//div[contains(text(),'Try again after 3 minutes to start work')]")
	private WebElementFacade lbl_threeMinutesToStartWork;
	
	@FindBy(xpath="//div[contains(text(),'You can') and contains(text(),'t take meal just yet')]")
	private WebElementFacade lbl_cannotTakeMealJustYet;
	
	@FindBy(xpath="//div[contains(text(),'Try again after 3 minutes to take meal')]")
	private WebElementFacade lbl_threeMinutesToTakeMeal;
	
	@FindBy(xpath="//div[contains(text(),'You can') and contains(text(),'t end your meal just yet')]")
	private WebElementFacade lbl_cannotEndMealJustYet;
	
	@FindBy(xpath="//div[contains(text(),'Try again after 3 minutes to end your meal')]")
	private WebElementFacade lbl_threeMinutesToEndMeal;
	
	@FindBy(xpath = "//div[contains(text(),'The time pair overlaps with another time pair') or contains(text(),'The time pair overlaps with other time pair')]")
	private WebElementFacade lbl_timePairOverlaps;
	
	@FindBy(xpath = "//div[contains(text(),'resolved some missed punches')]")
	private WebElementFacade lbl_resolvedSomePunches;
	
	@FindBy(xpath = "//div[contains(text(),'fixed all your missed punches')]")
	private WebElementFacade lbl_fixedAllPunches;
	
	@FindBy(xpath = "//button[.='Log Out']")
	private WebElementFacade btn_webClockingLogout;
	
	
	
	By tbx_missedOutpunch_list = By
			.xpath("//div[@class='missed-punch-detail']/../../descendant::div[@class='msdpunchesdata'][1]");
	By lbl_time_lastPunch = By
			.xpath("//div[@class='missed-punch-detail']/../../descendant::div[@class='msdpunchesdata'][1]");

	// YourTimecard yourTimecard = null;

	
	
	
	
	
	// --------------------------- genral functions -----------------------------//

//		public void yourTimecardObject()
//		{
//			if(yourTimecard==null)
//			{
//				yourTimecard = new YourTimecard();
//			}
//		}
//		
	
	/**
	 * Tempus -- Employee login
	 * 
	 * @param user     id -- Employee login Id
	 * @param password -- Employee password
	 */
	public void tempus_EmployeeLogin(String userid, String password) {
		browserLaunch();
		tbx_UserID.waitUntilVisible();
		tbx_UserID.type(userid);
		tbx_Password.type(password);
		btn_Submit.click();
		imgIcon_LogOut.waitUntilVisible();
		imgIcon_LogOut.shouldBePresent();
		waitForPageLoad(5);

	}

	/**
	 * Tempus Menu navigation common function
	 * 
	 * @param mianMenu      ---- Main menu name
	 * @param subMenu       ----submenu naem
	 * @param subMenuOption ------ submenuOptionName
	 */
	public void tempus_MenuNavigation(String mianMenu, String subMenu, String subMenuOption, String pageHeader) {

		// getDriver().findElement(By.xpath("//button[contains(text(),'" + mianMenu +
		// "')]")).click();

		// getDriver().findElement(By.xpath("//button[text()='" + mianMenu +
		// "']/../descendant::div[text()='EXPAND MENU']")).click();

		$("//button[contains(text(),'" + mianMenu + "')]").waitUntilClickable().click(); // btn_Main_menu
		if ($("//button[text()='" + mianMenu + "']/../descendant::div[text()='EXPAND MENU']").isVisible()) // link_expandMenu
		{
			$("//button[text()='" + mianMenu + "']/../descendant::div[text()='EXPAND MENU']").waitUntilClickable()
					.click(); // link_expandMenu
		}

		$("//button[text()='" + mianMenu + "']/../descendant::div[text()='" + subMenu
				+ "']/../descendant::button[text()='" + subMenuOption + "']").waitUntilClickable().click();// link_subMenuOption_Menu

		$("//span[contains(text(),'" + pageHeader + "')]").waitUntilPresent().shouldBePresent();// lbl_pageHeading
		WaitForAjax();
	}

	/**
	 * Get date and time
	 * 
	 * @param addToDay -- number of dates to be add
	 * @param dateType -- date type will be date
	 * @return data as per date type
	 */

	public String get_date(String addToDay, String dateType) {
		String result = "";

		Date today = new Date();
		TimeZone timezone = TimeZone.getTimeZone("EST");
		Calendar cal = Calendar.getInstance(timezone);
		cal.setTime(today); // Mon Jun 17 20:32:12 IST 2019

//		int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK); // 2 -- secound week
//
//		int dayOfYear = cal.get(Calendar.DAY_OF_YEAR); // 168 --
//		int month = cal.get(Calendar.MONTH); // 5
//		int year = cal.get(Calendar.YEAR);// 2019

		LocalDate currentDate = LocalDate.now(); // 2019-06-17

		DayOfWeek dow = currentDate.getDayOfWeek();// MONDAY
//		int dom = currentDate.getDayOfMonth();// 17
//		int doy = currentDate.getDayOfYear();// 168
//
//		int y = currentDate.getYear();// 2019

		if (dateType.equalsIgnoreCase("date")) {
			cal.add(Calendar.DATE, Integer.parseInt(addToDay));
			int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); // get date
			result = Integer.toString(dayOfMonth);
		} else if (dateType.equalsIgnoreCase("todayMonth")) {
			Month m = currentDate.getMonth();// JUNE
			result = m.name();
		} else if (dateType.equalsIgnoreCase("ESTHourAndTime")) {
			DateFormat formatter = new SimpleDateFormat("H:mm a");
			formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));

			String HoursTime = formatter.format(today).toString();

			result = HoursTime;

			System.out.println(result);

		}

		System.out.println("result date is : " + result);
		return result;
	}

	public void WaitUntilJSLoad() {
		JavascriptExecutor js = ((JavascriptExecutor) getDriver());
		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		ExpectedCondition<Boolean> waituntil_jsLoad = d -> js.executeScript("return document.readyState").toString()
				.equals("complete");

		Boolean status = js.executeScript("return document.readyState").toString().equals("complete");
		if (!status) {
			wait.until(waituntil_jsLoad);
		}
	}

	public void WaitUntilJQueryLoad() {
		JavascriptExecutor js = ((JavascriptExecutor) getDriver());
		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		ExpectedCondition<Boolean> waituntil_jQueryLoad = d -> ((long) js.executeScript("return jQuery.active") == 0);

		Boolean status = (Boolean) js.executeScript("return jQuery.active==0");
		if (!status) {
			wait.until(waituntil_jQueryLoad);
		}
	}

	public void PageLoadwait() {
		JavascriptExecutor js = ((JavascriptExecutor) getDriver());
		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		Boolean jQueryDefined = (Boolean) js.executeScript("return typeof jQuery !='undefined'");
		if (jQueryDefined) {
			WaitUntilJQueryLoad();

			WaitUntilJSLoad();
		}
	}

	public void waitForPageLoad(int time) {

		try {
			for (int i = 1; i <= time; i++) {
				PageLoadwait();
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Convert string to date time and adding and subtract minutes
	 * 
	 * @param time           -- passing time as string ex: 02:34 , 11:45, 05:03
	 * @param minuts         ---- minutes need to add or subtract
	 * @param addMinutesFlag --- true -- adding minutes , false --subtract minutes
	 * @return -- return time as string ex: 02:34 , 11:45, 05:03
	 * @throws ParseException
	 */

	public String convert_toTime_addingMinutes(String time, int minutes, boolean addMinutesFlag) throws ParseException {
		minutes = minutes * 60;
		DateFormat formatter = new SimpleDateFormat("HH:mm");
		Date date = new Date();
		date = formatter.parse(time);
		if (addMinutesFlag) {
			date.setTime(date.getTime() + minutes * 1000);
		} else {
			date.setTime(date.getTime() - minutes * 1000);
		}
		String HoursTime = formatter.format(date).toString();
		System.out.println(HoursTime);

		return HoursTime;
	}

	/**
	 * check for string null or empty
	 * 
	 * @param string --- String value to be check
	 * @return ---- returns boolean value
	 */
	public boolean isNullOrEmpty(String string) {
		if (string != null && !string.trim().isEmpty())
			return false;
		return true;
	}
	// -------------------------end genral functions-------------------------------------------//

	
	
	
	//-------------------------- your timecard actions functions -------------------------------------//
	
	
	
	
	/**
	 * employee home page navigation
	 */
	public void emp_HomePage_Naviagation() {
		waitForPageLoad(2);
		waitForElementToLoad(btn_home);
		btn_home.click(); // btn_Home_menu
		emp_HomePage_Verify_YourTime_loading();
		waitForPageLoad(5);
	}

	/**
	 * Employee verify clock in to start your shift on your time tile
	 */
	public void emp_HomePage_YourTime_Verify_ClockInToStartYourShift_Msg(boolean startYourShiftFlag) {

		if (startYourShiftFlag) {
			waitForElementToLoad(lbl_startYourShift);
			lbl_startYourShift.shouldBeCurrentlyVisible();
		} else {

			lbl_startYourShift.waitUntilNotVisible();
			lbl_startYourShift.shouldNotBePresent();
		}
	}

	/**
	 * Employee click on clock in from your time
	 */
	public void emp_HomePage_YourTime_ClickOn_ClockIn() {
		waitForElementToLoad(imgIcon_startWork_portlets);
		imgIcon_startWork_portlets.waitUntilClickable().click();
		lbl_startedWork_message.waitUntilPresent().shouldBePresent();
	}

	/**
	 * Employee click on clock in from your time
	 */
	public void emp_HomePage_YourTime_verify_ClockIn_successful() {
		waitForElementToLoad(lbl_startedWork_message);
		lbl_startedWork_message.waitUntilPresent().shouldBePresent();
	}

	/**
	 * Employee click on meal out from your time
	 */
	public void emp_yourTime_clickOn_mealOut() {
		waitForElementToLoad(imgIcon_takeMeal_portlets);
		imgIcon_takeMeal_portlets.waitUntilClickable().click();
		lbl_mealOut.waitUntilPresent()
				.shouldBePresent();// lbl_mealOut
	}

	/**
	 * employee click on meal return
	 */
	public void emp_yourTime_clickOn_mealReturn() {
		waitForElementToLoad(imgIcon_endMeal_portlets);
		imgIcon_endMeal_portlets.waitUntilClickable().click();
		lbl_mealEnded_message.waitUntilPresent().shouldBePresent();
	}

	/**
	 * Employee--Home page -- verify-- Your Time tile loading Precondition : should
	 * be on home page
	 */
	public void emp_HomePage_Verify_YourTime_loading() {

		waitForElementToLoad(imgIcon_startWork_or_endWork_endMeal);
		imgIcon_startWork_or_endWork_endMeal.waitUntilVisible(); 
		waitForPageLoad(3); 
		assertTrue("verify yourtime portlets loading",imgIcon_startWork_or_endWork_endMeal.isPresent());
		
	}

	/**
	 * employee _ verify __clockin icon existence prerequisite : should be on home
	 * page
	 * 
	 * @param clockingIconPresenceFlag True -- element should be presence , False
	 *                                 --- should not be presence
	 */
	public void emp_Homepage_Verify_ClockINImgIcon_Existance(boolean clockInIconPresenceFlag) {

		if (clockInIconPresenceFlag) {
			waitForElementToLoad(imgIcon_startWork_portlets);
			imgIcon_startWork_portlets.waitUntilPresent().shouldBePresent();

		} else {

			imgIcon_startWork_portlets.waitUntilNotVisible();
			imgIcon_startWork_portlets.shouldNotBePresent();
		}
	}

	/**
	 * employee _ verify __clockout icon existence 
	 * @prerequisite : should be on home page
	 * 
	 * @param clockOutIconPresenceFlag True -- element should be presence , False
	 *                                 --- should not be presence
	 */
	public void emp_Homepage_Verify_ClockOutImgIcon_Existance(boolean clockOutIconPresenceFlag) {

		if (clockOutIconPresenceFlag) {
			waitForElementToLoad(imgIcon_endWork_portlets);
			imgIcon_endWork_portlets.waitUntilPresent().shouldBePresent();

		} else {

			imgIcon_endWork_portlets.waitUntilNotVisible();
			imgIcon_endWork_portlets.shouldNotBePresent();
		}
	}

	public void emp_yourTimecard_clockOn_clockOut() {
		waitForElementToLoad(imgIcon_endWork_portlets);
		imgIcon_endWork_portlets.click();
		emp_yourTime_verify_clockOut_successful();
	}

	public void emp_yourTime_verify_clockOut_successful() {
		waitForElementToLoad(lbl_endedWork_message);
		lbl_endedWork_message.shouldBePresent();
	}

	/**
	 * employee _ verify __mealout icon existence 
	 * prerequisite : should be on home page
	 * 
	 * @param mealOutIconPresenceFlag True -- element should be presence , False ---
	 *                                should not be presence
	 */
	public void emp_Homepage_Verify_MealOutImgIcon_Existance(boolean mealOutIconPresenceFlag) {
		if (mealOutIconPresenceFlag) {
			waitForElementToLoad(imgIcon_takeMeal_portlets);
			imgIcon_takeMeal_portlets.waitUntilPresent().shouldBePresent();

		} else {

			imgIcon_takeMeal_portlets.waitUntilNotVisible();
			imgIcon_takeMeal_portlets.shouldNotBePresent();
		}
	}

	/**
	 * employee _ verify __transfer icon existence 
	 * Precondition : should be on home page
	 * 
	 * @param transferIconPresenceFlag True -- element should be presence , False
	 *                                 --- should not be presence
	 */
	public void emp_Homepage_Verify_TransferImgIcon_Existance(boolean transferIconPresenceFlag) {
		if (transferIconPresenceFlag) {
			waitForElementToLoad(imgIcon_Transfer_portlets);
			imgIcon_Transfer_portlets.waitUntilPresent().shouldBePresent();

		} else {

			imgIcon_Transfer_portlets.waitUntilNotVisible();
			imgIcon_Transfer_portlets.shouldNotBePresent();
		}
	}

	/**
	 * employee _ verify __meal return icon existence Precondition : should be on
	 * home page
	 * 
	 * @param transferIconPresenceFlag True -- element should be presence , False
	 *                                 --- should not be presence
	 */
	public void emp_Homepage_Verify_mealReturnImgIcon_Existance(boolean mealReturnIconPresenceFlag) {
		if (mealReturnIconPresenceFlag) {
			waitForElementToLoad(imgIcon_endMeal_portlets);
			imgIcon_endMeal_portlets.waitUntilPresent().shouldBePresent();

		} else {

			imgIcon_endMeal_portlets.waitUntilNotVisible();
			imgIcon_endMeal_portlets.shouldNotBePresent();
		}
	}

	/**
	 * employee --- get punch time
	 * 
	 * @return punchTime --- Exampled 10:30 AM
	 */
	public String emp_yourTime_GetPunchTime() {
		String punchTime = "";
		waitForElementToLoad(lbl_lastPunchTime);
		lbl_lastPunchTime.waitUntilPresent();
		punchTime = lbl_lastPunchTime.getText();
		punchTime = punchTime.replace("at ", "").trim();
		System.out.println("Punch time is " + punchTime);
		return punchTime;
	}

	/**
	 * your timecard navigation from your time tile
	 */
	public void emp_yourTimecard_Navigation_FromYourTime() {
		//YourTimecard timecard = new YourTimecard();
		//yourTimecardObject();
		waitForElementToLoad(btn_Timecard);
		btn_Timecard.waitUntilClickable();
		btn_Timecard.click();
		waitForPageLoad(3);
	}

	/**
	 * employee -- your time -- approve timecard navigation
	 */
	public void emp_youTime_approveTimecard_navigation() {
		YourTimecard yourTimecard = new YourTimecard();
		// yourTimecardObject();
		waitForElementToLoad(btn_approveTimecard);
		btn_approveTimecard.waitUntilClickable().click();// link_approveTimecard
		waitForElementToLoad(btn_approveTimecard_timecard);
		btn_approveTimecard_timecard.waitUntilPresent().shouldBePresent();// btn_approveTimecard
		waitForPageLoad(6);
		//yourTimecard.emp_yourTimecard_Verify_PageLoading();
	}

	/**
	 * employee -- homepage -- yourtime -- verify approve timecard link existance
	 * 
	 * @param approveTimecardPresenceFlag
	 */
	public void emp_yourTime_verify_approveTimecard_existance(boolean approveTimecardPresenceFlag) {
		if (approveTimecardPresenceFlag) {
			waitForElementToLoad(btn_approveTimecard);
			btn_approveTimecard.waitUntilPresent().shouldBePresent();// lnk_approveTimecard

		} else {
			btn_approveTimecard.waitUntilNotVisible();
			btn_approveTimecard.shouldNotBePresent(); // lnk_approveTimecard
		}
	}

	/**
	 * employee -- your time -- missed punches navigation
	 */
	public void emp_yourTime_missedPunches_navigation() {
		waitForElementToLoad(lnk_missedPunches);
		lnk_missedPunches.waitUntilClickable().click();// lnk_missedPunches
		tblrow_missedPunch.waitUntilPresent().shouldBePresent();// tblrow_missedPunch
	}

	/**
	 * employee -- your time -- missed punches page loading
	 */
	public void emp_yourTime_verify_missedPunches_pageloading() {
		waitForElementToLoad(tblrow_missedPunch);
		tblrow_missedPunch.waitUntilPresent().shouldBePresent();// tblrow_missedPunch
		waitForPageLoad(2);
	}

	/**
	 * employee -- homepage -- yourtime -- verify missed punches link existance
	 * 
	 * @param missedPunchesPresenceFlag
	 */
	public void emp_yourTime_verify_missedPunches_existance(boolean missedPunchesPresenceFlag) {
		if (missedPunchesPresenceFlag) {
			waitForElementToLoad(lnk_missedPunches);
			lnk_missedPunches.waitUntilPresent().shouldBePresent();

		} else {
			lnk_missedPunches.waitUntilNotVisible();
			lnk_missedPunches.shouldNotBePresent();
		}
	}

	/**
	 * employee --- your time --- close missed punches slider
	 */
	public void emp_homePage_close_missedPunches_slider() {
		waitForElementToLoad(btn_back_missedPunchSlider);
		btn_back_missedPunchSlider.waitUntilClickable().click();// btn_back
		emp_HomePage_Verify_YourTime_loading();
		waitForPageLoad(4);
	}

	/**
	 * employee --- homepage --missedpunch slider -- enter out time date
	 * 
	 * @param date --- dates need to enter out time
	 * @param outTime  --- out time to be passing to resolve exceptions
	 */
	public void emp_homePage_enter_missedPunchData(String date, String outTime) {
		$("//div[@class='msdpunchesdata' and contains(text(),'" + date + "')]/following::input[1]").waitUntilClickable()
				.typeAndTab(outTime);

	}
	
	/**
	 * employee --- homepage --missedpunch slider -- enter out time date
	 * 
	 * @param date --- list of dates need to enter out time
	 * @param outTime  --- out time to be passing to resolve exceptions
	 */
	public void emp_homePage_enter_missedPunchData(String date,String inTime, String outTime, int rowNo) {
		
		
		if (rowNo == 0) {
			if (!isNullOrEmpty(inTime)) {
				$("//div[@class='msdpunchesdata' and contains(text(),'" + date + "')]/following::input[1]").waitUntilClickable()
				.typeAndTab(inTime);
			}
			if (!isNullOrEmpty(outTime)) {
				$("//div[@class='msdpunchesdata' and contains(text(),'" + date + "')]/following::input[1]").waitUntilClickable()
				.typeAndTab(outTime);
			}
		} else {

			if (!isNullOrEmpty(inTime)) {
				$("//div[@class='msdpunchesdata' and contains(text(),'" + date + "')]/following::input["+rowNo+"]").waitUntilClickable()
				.typeAndTab(inTime);
			}
			if (!isNullOrEmpty(outTime)) {
				$("//div[@class='msdpunchesdata' and contains(text(),'" + date + "')]/following::input["+rowNo+"]").waitUntilClickable()
				.typeAndTab(outTime);
			}
		}
		
	}

	/**
	 * employee -- home page -- get missed punches dates
	 * 
	 * @return List<String> --- return list of dates
	 */

	public List<String> emp_homePage_get_missedPunchesDates() {
		List<String> missedPunchDates = new ArrayList<String>();
		waitForPageLoad(2);
		List<WebElement> missedPunchDateElements = getDriver().findElements(tbx_missedOutpunch_list);

		for (WebElement element : missedPunchDateElements) {
			String missedPunchDate = element.getText();

			String[] tempData = missedPunchDate.split(" ");
			missedPunchDate = tempData[1];

			System.out.println("missed punch date is " + missedPunchDate);
			missedPunchDates.add(missedPunchDate);
		}

		return missedPunchDates;

	}

	/**
	 * employee -- homepage -- save -- missed punches data
	 */
	public void emp_homepage_save_missedPunchesData() {
		waitForElementToLoad(btn_submit_missedPunchesSlide);
		btn_submit_missedPunchesSlide.waitUntilClickable().click();
		lbl_success_awesome_message.waitUntilPresent().shouldBePresent();
	}
	
	/**
	 * employee -- homepage -- save -- missed punches
	 */
	public void emp_homepage_save_missedPunches() {
		waitForElementToLoad(btn_submit_missedPunchesSlide);
		btn_submit_missedPunchesSlide.waitUntilClickable().click();
	    waitForPageLoad(4);
	}

	/**
	 * Wait for three minutes
	 */
	public void wait_For_ThreeMinutes() {

		try {
			Thread.sleep(185000);
		} catch (InterruptedException e) {

		}

	}
	/**
	 *  employee -- your time -- get time -- wait for three minutes 
	 * @throws InterruptedException
	 */

	public void emp_yourTime_waitFor_threeMinutes() throws InterruptedException {
		int i = 1;
		while (i <= 160) {
			String currentTime = lbl_time_lastPunchSession.getText();// lbl_lastPunchTime

			String minutes = currentTime.split(":")[1].trim();

			if (Integer.parseInt(minutes) >= 3) {
				break;
			}
			i++;
			Thread.sleep(2000);

		}

	}
/**
 *  employee --your time --verify -- elements presence 
 * @param imgIconName  -- element name to check ex: clock in , clock out
 * @return    true-- element exist , false --- element not exist
 */
	
	public Boolean emp_yourTime_verify_webElement_presence(String imgIconName) {
		System.out.println("  ");
		Boolean result = false;
		switch (imgIconName) {
		case "clockIn":
			result = imgIcon_startWork_portlets.isPresent();
			break;
		case "clockOut":
			result = imgIcon_endWork_portlets.isPresent();
			break;
		case "mealOut":
			result = imgIcon_takeMeal_portlets.isPresent();
			break;

		case "mealReturn":
			result = imgIcon_endMeal_portlets.isPresent();
			break;
		case "startYourShift":
			result = lbl_startYourShift.isPresent();

		}
		return result;

	}

	public enum e_iconName {
		mealOut, mealReturn, inPunch, OutPunch;
	}
	
	/**
	 * employee ---your time ---verify -- you do not have access message   
	 * @param accessMsgPresenceFlag  true --should be exist , false -- should not be exist
	 */

	public void emp_yourTimecard_verify_donotHaveAccess_msg(boolean accessMsgPresenceFlag) {
		if (accessMsgPresenceFlag) {
			waitForElementToLoad(lbl_youDoNotHaveAccess_message);
			assertTrue("verify exist of don't have access message", lbl_youDoNotHaveAccess_message.isDisplayed());
		} else {
			emp_HomePage_Verify_YourTime_loading();
		}

	}

	/**
	 * employee -- yourTime --- get current time from yourtime
	 * 
	 * @return --- current time on application
	 */
	public String emp_yourTime_get_currentTime() {
		waitForElementToLoad(lbl_time_onYourTimePage);
		waitForPageLoad(5);
		String time = lbl_time_onYourTimePage.getText();
		return time.trim();
	}

	/**
	 * employee -- yourTime---click on--- view more options link
	 */
	public void emp_yourTime_clickOn_viewMoreOptions() {
		waitForElementToLoad(lnk_viewMoreActions); // lnk_viewMoreOptions
		lnk_viewMoreActions.click();
		waitForElementToLoad(imgIcon_carousel);
		waitForPageLoad(2);
		assertTrue("verify loading of carousel icons loading", imgIcon_carousel.isDisplayed());
	}
	
	/** 
	 *  employee-- your time --- verify view more actions link existence 
	 * @param viewMoreOptionsFlag
	 */
	
	public void emp_yourTime_verify_viewMoreOptions_existance(boolean viewMoreOptionsFlag) {
		
		if (viewMoreOptionsFlag) {
			waitForElementToLoad(lnk_viewMoreActions);
			assertTrue("verify that view more options should be available", lnk_viewMoreActions.isDisplayed());
			
		} else {
			lnk_viewMoreActions.waitUntilNotVisible();
			assertTrue("verify that view more options should not be available", !lnk_viewMoreActions.isDisplayed());
		}
		
	}

	/**
	 * employee -- your time --- click on -- hide more options
	 */
	public void emp_yourTime_clickOn_hideMoreOptions() {
      waitForElementToLoad(lnk_hideMoreOptions);
	  lnk_hideMoreOptions.click();
	  imgIcon_carousel.waitUntilNotVisible();
	  assertTrue("Verify not exist carousel",!imgIcon_carousel.isPresent());
	}
	
	
	/**
	 * employee --- yourTime---carousel--verify--- clock in image icon ---presence
	 * 
	 * @param clockInIconPresence --- true -- presence , false --- not presence
	 */
	public void emp_yourTime_carousel_verify_clockInIcon_presence(boolean clockInIconPresence) {

		if (clockInIconPresence) {
			waitForElementToLoad(imgIcon_startWork_carousel);// img_clockin_carousel
			assertTrue("Verify exist of clock in carousel image icon", imgIcon_startWork_carousel.isDisplayed());
		} else {
			imgIcon_startWork_carousel.waitUntilNotVisible();
			assertTrue("Verify not exist of clock in carousel image icon", !imgIcon_startWork_carousel.isDisplayed());
		}

	}
	
	
	/**
	 * employee --- yourTime---carousel--verify--- clock out image icon ---presence
	 * 
	 * @param clockOutIconPresence --- true -- presence , false --- not presence
	 */
	public void emp_yourTime_carousel_verify_clockOutIcon_presence(boolean clockOutIconPresence) {

		if (clockOutIconPresence) {
			waitForElementToLoad(imgIcon_endWork_carousel);// img_clockin_carousel
			assertTrue("Verify exist of clock out carousel image icon", imgIcon_endWork_carousel.isDisplayed());
		} else {
			imgIcon_endWork_carousel.waitUntilNotVisible();
			assertTrue("Verify not exist of clock out carousel image icon", !imgIcon_endWork_carousel.isDisplayed());
		}

	}
	
	
	
		

	

	
	
	

	
	
	/**
	 * employee -- yourTime --- click on --- clock in notes from carousel
	 * 
	 */

	public void emp_yourTime_clickOn_clockIn_noteIcon_carousel()
	 {
		 
		WebElement element = (WebElement) imgIcon_startWork_carousel;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();

		imgIcon_note_startWork_carousel.waitUntilClickable().click();// lnk_note_clockIn

		lbl_startWorkWithNotes_popover.waitUntilClickable().click();

		waitForElementToLoad(btn_submit_notesSlider);

		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());
		 
		 
	 }
	
	
	/**
	 * employee -- yourTime --- click on --- clock in notes from carousel
	 * 
	 */

	public void emp_yourTime_clickOn_clockIn_notesIcon() {
		
		WebElement element = (WebElement) imgIcon_startWork_portlets;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();

		imgIcon_note_startWork.waitUntilClickable().click();// lnk_note_clockIn

		lbl_startWorkWithNotes_popover.waitUntilClickable().click();
        
		waitForElementToLoad(btn_submit_notesSlider);

		waitForPageLoad(3);
		
		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());

	}
	
	
	/**
	 * employee -- yourTime --- click on --- clock out notes
	 * 
	 */

	public void emp_yourTime_clickOn_clockOut_notesIcon() {
		
		
		WebElement element = (WebElement) imgIcon_endWork_portlets;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();

		imgIcon_note_endWork.waitUntilClickable().click();

		lbl_endWorkWithNotes_popover.waitUntilClickable().click();

		waitForElementToLoad(btn_submit_notesSlider);

		waitForPageLoad(2);

		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());

	}
	
	/**
	 * employee -- yourTime --- click on --- clock out notes-- from carousel
	 * 
	 */

	public void emp_yourTime_clickOn_clockOut_notesIcon_carousel() {
		
		WebElement element = (WebElement) imgIcon_endWork_carousel;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();

		imgIcon_note_endWork_carousel.waitUntilClickable().click();

		lbl_endWorkWithNotes_popover.waitUntilClickable().click();

		waitForElementToLoad(btn_submit_notesSlider);

		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());

	}
	
	
	
	
	

	/**
	 * employee -- yourTime --- click on --- take meal notes
	 * 
	 */

	public void emp_yourTime_clickOn_takeMeal_notesIcon() {
		
		waitForElementToLoad(imgIcon_takeMeal_portlets);
		
		WebElement element = (WebElement) imgIcon_takeMeal_portlets;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();
       
		waitForElementToLoad(imgIcon_note_takeMeal);
		
		imgIcon_note_takeMeal.click();

		lbl_takeMealWithNotes_popover.waitUntilClickable().click();

		waitForElementToLoad(btn_submit_notesSlider);

		waitForPageLoad(2);
		
		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());

	}
	
	
	/**
	 * employee -- yourTime --- click on --- take meal notes--carousel
	 * 
	 */

	public void emp_yourTime_clickOn_takeMeal_notesIcon_carousel() {
		
		waitForElementToLoad(imgIcon_takeMeal_carousel);
		
		WebElement element = (WebElement) imgIcon_takeMeal_carousel;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();
       
		waitForElementToLoad(imgIcon_note_takeMeal_carousel);
		
		imgIcon_note_takeMeal_carousel.click();

		lbl_takeMealWithNotes_popover.waitUntilClickable().click();

		waitForElementToLoad(btn_submit_notesSlider);

		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());

	}
	
	/**
	 * employee -- yourTime --- click on --- meal return notes
	 * 
	 */

	public void emp_yourTime_clickOn_mealReturn_notesIcon() {
		
		waitForElementToLoad(imgIcon_endMeal_portlets);
		
		WebElement element = (WebElement) imgIcon_endMeal_portlets;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();

		waitForElementToLoad(imgIcon_endMeal_portlets);
		
		imgIcon_note_endMeal.waitUntilClickable().click();

		lbl_endMealWithNotes_popover.waitUntilClickable().click();

		waitForElementToLoad(btn_submit_notesSlider);
		
		waitForPageLoad(2);

		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());

	}
	
	
	
	/**
	 * employee -- yourTime --- click on --- meal return notes  --- carousel
	 * 
	 */

	public void emp_yourTime_clickOn_mealReturn_notesIcon_carousel() {
		
		WebElement element = (WebElement) imgIcon_endMeal_carousel;

		Actions act = new Actions(getDriver());

		act.moveToElement(element).build().perform();

		imgIcon_note_endMeal_carousel.waitUntilClickable().click();

		lbl_endMealWithNotes_popover.waitUntilClickable().click();

		waitForElementToLoad(btn_submit_notesSlider);

		assertTrue("Verifying notes slider page loading", btn_submit_notesSlider.isDisplayed());

	}
	
	
	
	
	
/**
 *  employee -- your time ---- adding notes 	
 * @param noteMessage        -- message need to add to note 
 */
 public void emp_yourTime_enterNotes_from_notesSlider(String noteMessage)
 {
	 try {
		 
		 waitForElementToLoad(tbx_notes_textArea);
		 waitForPageLoad(2);
		 tbx_notes_textArea.type(noteMessage);
        btn_submit_notesSlider.waitUntilClickable().click();
        emp_HomePage_Verify_YourTime_loading();
	 }catch(Exception e)
	 {
		 e.printStackTrace();
	 }finally {
//		 if(checkElementVisible(btn_cancel_notePopOver))
//		 {
//			 btn_cancel_notePopOver.click();
//			 emp_HomePage_Verify_YourTime_loading();
//		 }
	 }
	 
 }

 /**
  * employee-- yourTime -----verify  carousel existence
  * @param carouselPresenceFlag
  */

 public void emp_yourTime_verify_carousel_existence(boolean carouselPresenceFlag)
 {
	 if (carouselPresenceFlag) {
			waitForElementToLoad(imgIcon_startWork_carousel);
			assertTrue("verify that carousel should be display",imgIcon_startWork_carousel.isPresent());
		} else {

			imgIcon_startWork_carousel.waitUntilNotVisible();
			assertTrue("verify that carousel should not be display",!imgIcon_startWork_carousel.isPresent());
			btn_webClockingLogout.click();
			
		}
 }
 
 /**  employee --yourtime -- verify smart button existence
  * 
  * @param smartButtonPresenceFlag   -- true -- should be exist  , false -- should not exist
  */
 public void emp_yourTime_verify_smartbutton_existence(boolean smartButtonPresenceFlag)
 {
	 
//	 if (smartButtonPresenceFlag) {
//			waitForElementToLoad(imgIcon_smartButton);
//			assertTrue("verify that carousel should be display",imgIcon_smartButton.isPresent());
//		} else {
//			imgIcon_smartButton.waitUntilNotVisible();
//			assertTrue("verify that carousel should not be display",!imgIcon_smartButton.isPresent());
//		}
	 
	 if (smartButtonPresenceFlag) {
		 imgIcon_startWork_carousel.waitUntilNotVisible();
			assertTrue("verify that smart buttons should be display",!imgIcon_startWork_carousel.isPresent());
		} else {
			waitForElementToLoad(imgIcon_startWork_carousel);
			assertTrue("verify that smart buttons should not be display",imgIcon_startWork_carousel.isPresent());
		}
	 
 }

 
 /**  employee --yourtime -- verify hide more options link existence
  * 
  * @param hideMoreOptionsPresenceFlag   -- true -- should be exist  , false -- should not exist
  */
 public void emp_yourTime_verify_hideMoreOptins_existence(boolean hideMoreOptionsPresenceFlag)
 {
	 if (hideMoreOptionsPresenceFlag) {
			waitForElementToLoad(lnk_hideMoreOptions);
			assertTrue("verify that carousel should be display",lnk_hideMoreOptions.isPresent());
		} else {
			lnk_hideMoreOptions.waitUntilNotVisible();
			assertTrue("verify that carousel should not be display",!lnk_hideMoreOptions.isPresent());
		}
 }
 
 /** employee -- your time - check element availability
  * 
  * @param element   --- webElementFacade element need to pass
  * @param elementPresenceFlag  true-- should be presence, false --should not be presence
  */
 
 public void emp_yourTime_verify_element_existence(WebElementFacade element, boolean elementPresenceFlag)
 {
	 if (elementPresenceFlag) {
			waitForElementToLoad(element);
			assertTrue("verify that element should be display",element.isPresent());
		} else {
			element.waitUntilNotVisible();
			assertTrue("verify that element should not be display",!element.isPresent());
		}
	 
 }
 
 
 
 /** employee -- your time ---- verify carousel and smart buttons availability
  * 
  * @param existenceFalg  -- true -- should be available , false --- should not be available
  */
 public void emp_verify_element_existence(YourTimecard.data elementName,boolean existenceFalg)
 {
	 
	 System.out.println("");
	 
	 switch(elementName)
	 {
	 case clockIn_carousel:
		  if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_startWork_carousel,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_startWork_carousel,false);
			}
		  break;
	 case clockOut_carousel:	
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_endWork_carousel,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_endWork_carousel,false);
			}
		  break;
	
	 case takeAMeal_carousel:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_takeMeal_carousel,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_takeMeal_carousel,false);
			}
		  break;
	 
	 case mealReturn_carousel:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_endMeal_portlets,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_endMeal_portlets,false);
			}
		  break;
	 case clockIn:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_startWork_portlets,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_startWork_portlets,false);
			}
		  break;
	 case clockOut:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_endWork_portlets,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_endWork_portlets,false);
			}
		  break;
	 case takeAMeal:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_takeMeal_portlets,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_takeMeal_portlets,false);
			}
		  break;
	 case mealReturn:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_endMeal_portlets,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_endMeal_portlets,false);
			}
		  break;  
	 case viewMoreOptions:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lnk_viewMoreActions,true);
		  }else {
			  emp_yourTime_verify_element_existence(lnk_viewMoreActions,false);
			}
		  break;
	 case hideMoreOptons:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lnk_hideMoreOptions,true);
		  }else {
			  emp_yourTime_verify_element_existence(lnk_hideMoreOptions,false);
			}
		  break;
	 case smartButtons:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_smartButton,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_smartButton,false);
			}
		  break;
		  
	 case carouselButtons:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(imgIcon_carousel,true);
		  }else {
			  emp_yourTime_verify_element_existence(imgIcon_carousel,false);
			}
		  break;
	 case timePairOverlaps:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_timePairOverlaps,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_timePairOverlaps,false);
			}
		  break;
	 case fixedAllPunches:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_fixedAllPunches,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_timePairOverlaps,false);
			}
		  break;
		 
	  default:
		throw new IllegalArgumentException("please provide right button name");
		 
	 }
  
 }
 
 
 /**
  *   emp --- yourtime --- click on - clock in carousel
  */
 public void emp_yourtime_clickOn_clockIn_carousel()
 {
   waitForElementToLoad(imgIcon_startWork_carousel);
		imgIcon_startWork_carousel.click();
   waitForElementToLoad(lbl_startedWork_message);
   waitForPageLoad(1);
    assertTrue("Verify clocked in successful message",lbl_startedWork_message.isPresent());
  }
 
 /**
  * employee -- yourTime--- click on -- take a meal carousel
  */
 public void emp_yourTime_clickOn_takeAMeal_carousel()
 {
	 waitForElementToLoad(imgIcon_takeMeal_carousel);
	 imgIcon_takeMeal_carousel.click();
	 waitForElementToLoad(lbl_mealOut);
	 assertTrue("Verify take a meal successful message",lbl_mealOut.isPresent());
 }
 
 /**
  * employee -- yourTime-- click on -- meal return carousel
  */
 public void emp_yourTime_clickOn_mealReturn_carousel()
 {
	 waitForElementToLoad(imgIcon_endMeal_carousel);
		imgIcon_endMeal_carousel.click();
	 waitForElementToLoad(lbl_mealEnded_message);
    assertTrue("Verify meal return successful message",lbl_mealEnded_message.isPresent());
	 
 }
 
 /**
  * employee -- yourTime -- click on -- clock out carousel
  */
 public void emp_yourTime_clickOn_clockOut_carousel()
 {
	 waitForElementToLoad(imgIcon_endWork_carousel);
		imgIcon_endWork_carousel.click();
	 waitForElementToLoad(lbl_endedWork_message);
	 assertTrue("Verify clocked out successful message",lbl_endedWork_message.isPresent());
}
 

 
 
 
 /** employee -- verify  --button - error message existence
  * 
  * @param buttonName  -- button name as clock in , clock out 
  */
 public void emp_yourTime_verify_errorMessage_existence(YourTimecard.data buttonName, boolean existenceFalg)
 {
	 waitForPageLoad(1);
		
	 switch(buttonName)
	 {
	 case clockIn_carousel:	
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotStartWorkJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToStartWork,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotStartWorkJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToStartWork,false);
			}
		  break;
	 case clockOut_carousel:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotEndYourShiftJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndYourShift,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotEndYourShiftJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndYourShift,false);
			}
		  break;
	 case takeAMeal_carousel:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotTakeMealJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToTakeMeal,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotTakeMealJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToTakeMeal,false);
			}
		  break;
	 case mealReturn_carousel:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotEndMealJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndMeal,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotEndMealJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndMeal,false);
			}
		  break;
	 case clockIn:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotStartWorkJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToStartWork,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotStartWorkJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToStartWork,false);
			}
		  break;
	 case clockOut:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotEndYourShiftJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndYourShift,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotEndYourShiftJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndYourShift,false);
			}
		  break;
	 case takeAMeal:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotTakeMealJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToTakeMeal,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotTakeMealJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToTakeMeal,false);
			}
		  break;
	 case mealReturn:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_cannotEndMealJustYet,true);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndMeal,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_cannotEndMealJustYet,false);
			  emp_yourTime_verify_element_existence(lbl_threeMinutesToEndMeal,false);
			}
		  break;
		  
	 case timePairOverlaps:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_timePairOverlaps,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_timePairOverlaps,false);
			}
		  break;
		  
	 case resolvedSomePunches:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_resolvedSomePunches,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_resolvedSomePunches,false);
			}
		  break;
		  
	 case fixedAllPunches:
		 if(existenceFalg)
		  {
			  emp_yourTime_verify_element_existence(lbl_fixedAllPunches,true);
		  }else {
			  emp_yourTime_verify_element_existence(lbl_fixedAllPunches,false);
			}
		  break;
	
	  default:
			throw new IllegalArgumentException("please provide right button name");
	 }
		 
	 }
	 
	 /**
	  * emp-- yourtime-- click on element
	  * @param buttonName  --- button naem as clock in , clock out
	  */
	 
	 public void emp_yourTime_clickOn_element(YourTimecard.data buttonName)
	 {
		 waitForPageLoad(2);
			
		 switch(buttonName)
		 {
		 case clockIn_carousel:	
			 imgIcon_startWork_carousel.click();
			  break;
		 case clockOut_carousel:
			 imgIcon_endWork_carousel.click();
			  break;
		 case takeAMeal_carousel:
			 imgIcon_takeMeal_carousel.click();
			  break;
		 case mealReturn_carousel:
			 imgIcon_endMeal_carousel.click();
			  break;
		 case clockIn:
			 imgIcon_startWork_portlets.click();
			  break;
		 case clockOut:
			 imgIcon_endWork_portlets.click();
			  break;
		 case takeAMeal:
			 imgIcon_takeMeal_portlets.click();
			  break;
		 case mealReturn:
			 imgIcon_endMeal_portlets.click();
			  break;
		  default:
				throw new IllegalArgumentException("please provide right button name");
			
			 
		 }
		 waitForPageLoad(2);
	  
 }
	 
 /** employee -- your timecard -- missed punches slider --click on add note
  * 	 
  * @param date   -- date -- note icon
   
  */
 public void emp_yourTime_missedPunchesSlider_clickOn_addNote(String date, int rowNo)
 {
	waitForElementToLoad($("//div[@class='msdpunchesdata' and contains(text(),'"+date+"')]/ancestor::div[contains(@class,'mdf-grid-row')][1]/descendant::div[contains(@class,'missedpunches-notes-icon')]["+rowNo+"]"));
		waitForPageLoad(1);
	 $("//div[@class='msdpunchesdata' and contains(text(),'"+date+"')]/ancestor::div[contains(@class,'mdf-grid-row')][1]/descendant::div[contains(@class,'missedpunches-notes-icon')]["+rowNo+"]").click();
	 
	 
	 waitForElementToLoad(tbx_notes_textArea_missedPunchSlider);
	 waitForPageLoad(4);
	 
 }
 
 /** employee -- your timecard -- missed punches slider --enter -- note message
  * 	 
  * @param noteMessage   --- note message 
  */
 public void emp_yourTime_missedPunchesSlider_enter_noteMessage(String noteMessage)
 {
	 waitForElementToLoad(tbx_notes_textArea_missedPunchSlider);
	 waitForPageLoad(2);
	 tbx_notes_textArea_missedPunchSlider.type(noteMessage);
	 btn_save_notesSlider.waitUntilClickable().click();
	 waitForPageLoad(6);
 }
 /** employee -- yourtime -- missedpuches slider  -- verify note existence 
  * 
  * @param expectedNoteMessage  -- expected error message 
  * @param noteExistenceFlg   -- true -note should be available , false -- should not be present 
  */
 public void em_yourTime_missedPunches_verify_noteMessage(String expectedNoteMessage,boolean noteExistenceFlg)
 {
	 waitForElementToLoad(tbx_notes_textArea_missedPunchSlider);
	 waitForPageLoad(2);
	String actualNoteMessage =  tbx_notes_textArea_missedPunchSlider.getText().trim();
	
	boolean resultFlag = expectedNoteMessage.equals(actualNoteMessage);
	
	
	if(noteExistenceFlg)
	{
		assertTrue("Verify that note should be present",resultFlag);	
	}else {
		assertTrue("Verify that note should not be present",!resultFlag);
	}
	
 }
 /**
  * employee -- yourtime -- missedpunches -- close note popup
  */
 public void emp_yourTime_missedPunches_close_notePopup()
 {
   waitForElementToLoad(btn_cancel_notePopOver_missedpunches);
	btn_cancel_notePopOver_missedpunches.click();
	waitForPageLoad(4);
 }
 
 
 
 
 
	 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 
 
	
	
	
	
	
	
	
	
	
	
	
	
	
}
