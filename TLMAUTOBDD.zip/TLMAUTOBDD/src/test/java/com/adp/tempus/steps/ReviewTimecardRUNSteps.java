package com.adp.tempus.steps;

import com.adp.tempus.pages.ReviewTimecardRUN;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;


public class ReviewTimecardRUNSteps extends ScenarioSteps{
	
	ReviewTimecardRUN reviewTimecardRUN;
	
	@Step
	public void verifyReviewTimecard() {
		reviewTimecardRUN.reviewTimecard();
	}

	@Step
	public void SelectEmpDropDown(String EmpName, String Visibility) {
		reviewTimecardRUN.SelectEmpDropDown(EmpName,Visibility);
	}
	
	@Step
	public void SelectToggleButton() {
		reviewTimecardRUN.SelectToggleButton();
	}
	
	@Step
	public void SelectTimePicker(String intime, String outtime) {
		reviewTimecardRUN.SelectTimePickerIcon(intime,outtime);
	}
	
	@Step
	public void verifyPayCodeSummary(String PayCodeSummaryHours) {
		reviewTimecardRUN.VerifyPayCodeSummary(PayCodeSummaryHours);
	}
	
	@Step
	public void verifyHourDistType(String HourDistType) {
		reviewTimecardRUN.VerifyHourDistType(HourDistType);
	}
	
	@Step
	public void validateExceptions(String ExceptionType) {
		reviewTimecardRUN.validateExceptions(ExceptionType);
	}
	
	@Step
	public void ClickTimeIconMyADP() {
		reviewTimecardRUN.ClickTimeIcon();
	}
	
	@Step
	public void ClickDashboardIconMyADP() {
		reviewTimecardRUN.ClickDashboardIcon();
	}
	
	@Step
	public void clickButtonMyADPTimecardGrid(String strDate, String strButton) {
		reviewTimecardRUN.clickButtonMyADPTimecardGrid(strDate,strButton);
	}
	
	@Step
	public void deleteTimepairsMyADPTimecards() {
		reviewTimecardRUN.deleteTimepairsMyADPTimecards();
	}
	
	@Step
	public void employeesubmitTimePairMyADP(String strPunchType,String findInPunch, String inPunch, String outPunch) {
		reviewTimecardRUN.submitTimePairMyADP(strPunchType,findInPunch,inPunch,outPunch);
	}
	
		
	@Step
	public void clickButtonAddTimePairMyADP(String btnName) {
		reviewTimecardRUN.clickButtonMyADPAddTimePair(btnName);
	}
	
	@Step
	public void clickonHomeandRunPayroll() {
		reviewTimecardRUN.clickonHomeandRunPayrollTempus();
	}
	
	@Step
	public void SearchClientRUN(String TLMClientID) {
		reviewTimecardRUN.SearchRUNClient(TLMClientID);
	}
	
	@Step
	public void SearchClientRUNNonTLM(String NonTLMClientID) {
		reviewTimecardRUN.SearchRUNNonTLM(NonTLMClientID);
	}
	
	@Step
	public void AddTimePairTLM() {
		reviewTimecardRUN.AddTimePairTLM();
	}
	
	@Step
	public void ResolveExceptions() {
		reviewTimecardRUN.ResolveExceptionsTLM();
	}
	
	@Step
	public void SearchClientNonTLM(String NonTLMClientID) {
		reviewTimecardRUN.SearchClientNonTLM(NonTLMClientID);
	}
	
	@Step
	public void AddEditNotesToTimePairRUN(String inPunch, String outPunch, String instance, String noteType,
			String noteText) {
		reviewTimecardRUN.AddEditNotesToTimePairRUN(inPunch,outPunch,instance,noteType,noteText);
	}
	
	@Step
	public void ValidateTCGridGrayed() {
		reviewTimecardRUN.ValidateTCGridGrayed();
	}
	
	@Step
	public void SearchEmployee(String Employee) {
		reviewTimecardRUN.SearchEmployee(Employee);
	}
	
	@Step
	public void TerminateEmployee(String Employee) {
		reviewTimecardRUN.TerminateEmployee(Employee);
	}
	
	@Step
	public void RehireEmployee(String Employee) {
		reviewTimecardRUN.RehireEmployee(Employee);
	}
	
	@Step
	public void PrintTimecard() {
		reviewTimecardRUN.PrintTimecard();
	}
	
	@Step
	public void SubmitPTOMyADP(String PTOPayCode, String Hours) {
		reviewTimecardRUN.enterHoursMyADP(PTOPayCode, Hours);
	}
	
	@Step
	public void SubmitPTOTimecard(String PTOPayCode, String Hours) {
		reviewTimecardRUN.enterPTOTimecard(PTOPayCode, Hours);
	}
	
	@Step
	public void Punch(String PunchType) {
		reviewTimecardRUN.PunchOperation(PunchType);
	}
		
	@Step
	public void editPTO(String updatedhours) {
		reviewTimecardRUN.editPTOTimecard(updatedhours);
	}
	
}
