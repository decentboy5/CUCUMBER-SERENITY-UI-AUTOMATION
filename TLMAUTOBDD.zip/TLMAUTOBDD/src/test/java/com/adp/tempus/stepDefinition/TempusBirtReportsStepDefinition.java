package com.adp.tempus.stepDefinition;

import com.adp.tlmbdd.steps.TempusReportSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class TempusBirtReportsStepDefinition {

	@Steps
	TempusReportSteps tempusReportSteps;

	@And("^I run as \"([^\"]*)\"$")
	public void i_run_as(String runFormat) {
		tempusReportSteps.runAs(runFormat);
	}
	@And("^I select employees with \"([^\"]*)\"$")
	public void i_select_employees_with(String employeeType) {
		tempusReportSteps.selectEmployeeType(employeeType);
	}
	@And("^I select employees with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_select_employees_with(String employeeType, String employeeType1) {
		tempusReportSteps.selectEmployeeType(employeeType,employeeType1);
	}
	@And("^I select all types of employees")
	public void i_select_all_types_of_employees() {
		tempusReportSteps.selectAllTypesOfEmployees();
	}
	@And("^I verify save my settings shows")
	public void i_verify_save_my_settings_shows() {
		tempusReportSteps.verifySaveMySettings();
	}

	@And("^I click apply")
	public void i_click_apply() throws Throwable {
		tempusReportSteps.apply();
	}

	@And("^I select one department")
	public void i_select_one_department() throws Throwable {
		tempusReportSteps.selectOneDepartment();
	}

	@And("^I select all departments")
	public void i_select_all_department() throws Throwable {
		tempusReportSteps.selectAllDepartment();
	}

	@And("^I select define at runtime")
	public void i_select_define_at_runtime() throws Throwable {
		tempusReportSteps.selectTimeFrame("Define at Runtime");
	}

	@And("^I select Current Pay Period")
	public void i_select_current_pay_period() throws Throwable {
		tempusReportSteps.selectTimeFrame("Current Pay Period");
	}

	@And("^I select This Week Pay Period")
	public void i_select_this_week_pay_period() throws Throwable {
		tempusReportSteps.selectTimeFrame("This Week");
	}
	@And("^I select all fields")
	public void i_select_all_fields() throws Throwable {
		tempusReportSteps.selectAllFields();
	}
	@And("^I select some fields")
	public void i_select_some_fields() throws Throwable {
		tempusReportSteps.selectSomeFields();
	}
	@And("^I select some other fields")
	public void i_select_some_other_fields() throws Throwable {
		tempusReportSteps.selectSomeOtherFields();
	}

	@And("^I select Last Month Time Frame")
	public void i_select_last_month_time_frame() throws Throwable {
		tempusReportSteps.selectTimeFrame("Last Month");
	}
	
	@And("^I select Include Notes")
	public void i_select_include_notes() throws Throwable {
		tempusReportSteps.includeNotes();
	}
	
	@And("^I select Include Pending Time Off")
	public void i_select_include_pending_time_off () throws Throwable {
		tempusReportSteps.includePendingTimeOff();
	}
	
	@And("^I select payroll adjustment as per pay day")
	public void i_select_payroll_adjustment_as_per_pay_day() throws Throwable {
		tempusReportSteps.includePayrollAdjustment(0);
	}
	
	@And("^I select payroll adjustment as adjusted transaction date")
	public void i_select_payroll_adjustment_as_adjusted_transaction_date() throws Throwable {
		tempusReportSteps.includePayrollAdjustment(1); 
	}
	
	@And("^I select Payroll Adjustment Hours option")
	public void i_select_payroll_adjustment_hours_option() throws Throwable {
		tempusReportSteps.includePayrollAdjustmentHours();
	}
	
	@And("^I select Print Runtime Setting")
	public void i_select_print_runtime_setting() throws Throwable {
		tempusReportSteps.includePrintOption();
	}
	
	@And("^I select all options in appearance section")
	public void i_select_all_options_in_appearance_section() throws Throwable {
		tempusReportSteps.selectAllOptionsInAppearance();
	}
	
	@And("^I click on notes and add a note")
	public void i_click_on_notes_and_add_a_note() throws Throwable {
		tempusReportSteps.addNotes();
	}
	
	@And("^I select all the oprions in who appears")
	public void i_select_all_the_oprions_in_who_appears() throws Throwable {
		tempusReportSteps.selectAllOptionsInWhoApppears();
	}
	@And("^I select all the options in what is displayed section")
	public void i_select_all_the_options_in_what_is_displayed_section() throws Throwable {
		tempusReportSteps.selectAllOptionsInWhatIsDisplayedSection();
	}
	@And("^I select only company code")
	public void i_select_only_company_code() throws Throwable {
		tempusReportSteps.selectOnlyCompanyCode();
	}
	
	@And("^I click on the cancel button")
	public void i_click_on_the_cancel_button() throws Throwable {
		tempusReportSteps.cancelButton();
	}
	@And("^I verify it is shown in My Reports section as default")
	public void  i_verify_it_is_shown_in_My_Reports_section_as_default() throws Throwable {
		tempusReportSteps.validateReport();
	}
	@And("^I verify it is shown in My Reports section as CSV")
	public void i_verify_it_is_shown_in_My_Reports_section_as_CSV() throws Throwable {
		tempusReportSteps.validateReportAsCSV();
	} 
	
	@And("^I verify it is shown in My Reports section as Excel")
	public void i_verify_it_is_shown_in_My_Reports_section_as_Excel() throws Throwable {
		tempusReportSteps.validateReportAsExcel();
	}
	
	@And("^I click on the report with \"([^\"]*)\"$")
	public void i_click_on_the_report_with(String reportname) throws Throwable {
		tempusReportSteps.clickOnReport(reportname);
	}
	@And("^I navigate to output tab")
	public void i_navigate_to_output_tab() throws Throwable {
		tempusReportSteps.gotoOutputTab();
	}
	@And("^I run it as Excel and open the timecard report")
	public void  i_run_it_as_excel_and_open_the_timecard_report() throws Throwable {
		tempusReportSteps.runAsExcelAndOpenReport();
	}
	@And("^I run it as PDF and open the timecard report")
	public void i_run_it_as_PDF_and_open_the_timecard_report() throws Throwable {
		tempusReportSteps.runAsPDFAndOpenReport();
	}
	@And("^I run it as CSV and open the timecard report")
	public void i_run_it_as_CSV_and_open_the_timecard_report() throws Throwable {
		tempusReportSteps.runAsCSVAndOpenReport();
	}
	@And("^I navigate to My Reports Tab")
	public void i_navigate_to_my_reportS_tab() throws Throwable {
		tempusReportSteps.gotoReportsTab();
	}
	@And("^I validate the headers of the report")
	public void i_validate_the_headers_of_the_report() throws Throwable {
		tempusReportSteps.verifyHeaders();
	}
	@Then("^I verify run as and save settings options are displayed")
	public void i_verify_run_as_and_save_settings_options_are_displayed() throws Throwable {
		tempusReportSteps.verifyAllOptionsDisplayed();
	}
	@Then("^I verify that all three components are displayed")
	public void i_verify_that_all_three_components_are_displayed() throws Throwable {
		tempusReportSteps.verifyAllComponentsAreDisplayed();
		
	}
	@Then("^I navigate to standard tab")
	public void i_navigate_to_standard_tab() throws Throwable {
		tempusReportSteps.gotoStandardTab();
	}
 	@Then("^I enter to and from dates with fromDate \"([^\"]*)\"$")
	public void i_enter_to_and_from_dates_with_fromDates(String date) throws Throwable {
		tempusReportSteps.enterDatesForTimeFrame(date);
	}
    @Then("^I search for report with \"([^\"]*)\"$")
    public void i_search_for_report_with(String reportName) throws Throwable {
    	tempusReportSteps.searchForReport(reportName);
    }

	@Then("^I click on TimeFrame")
	public void i_click_on_TimeFrame() throws Throwable {
		tempusReportSteps.clickOnTimeframe();
	}

	@Then("^I run as Excel$")
	public void i_run_as_excel() throws Throwable {
		tempusReportSteps.runAsExcel();
	}

	@Then("^I run as PDF$")
	public void i_run_as_pdf() throws Throwable {
		tempusReportSteps.runAsPDF();
	}

	@Then("^I run as CSV$")
	public void i_run_as_csv() throws Throwable {
		tempusReportSteps.runAsCSV();
	}

	@Then("^I click on Employee List")
	public void i_click_on_employee_list() throws Throwable {
		tempusReportSteps.employeeList();
	}

	@Then("^I click on Company code")
	public void i_click_on_company_code() throws Throwable {
		tempusReportSteps.companyCode();
	}

	@Then("I select one company code")
	public void i_click_on_one_company_code() throws Throwable {
		tempusReportSteps.selectOneCompany();
	}

	@Then("^I click on department")
	public void i_click_on_department() throws Throwable {
		tempusReportSteps.department();
	}

	@Then("^I Navigate to Who Appears on the Report")
	public void i_navigate_to_who_appears_on_the_report() throws Throwable {
		tempusReportSteps.navigateToWhoAppearsOnTheReport();
	}

	@Then("^I navigate to What is displayed on the report section")
	public void i_navigate_to_what_is_displayed_on_the_report_section() throws Throwable {
		tempusReportSteps.navigateToWhatIsDisplayedSection();
	}
	
	@Then("^I navigate to appearance section")
	public void i_navigate_to_appearance_section() throws Throwable {
		tempusReportSteps.navigateToAppearanceSection();
	}

	@Then("^I select specific employee")
	public void i_select_specific_employee() throws Throwable {
		tempusReportSteps.selectSpecificEmployee();
	}

	@Then("^I select five specific employees")
	public void i_select_five_specific_employees() throws Throwable {
		tempusReportSteps.selectFiveEmployees();
	}
	
	@Then("^I click on save my settings")
	public void i_click_on_save_my_settings() throws Throwable {
		tempusReportSteps.saveSettingsWithDEfaultOptions();
	}
	@Then("^I click CSV and save my settings")
	public void i_click_CSV_and_save_my_settings() throws Throwable {
		tempusReportSteps.saveSettingsAsCSV();
	}
	@Then("^I click Excel and save my settings")
	public void i_click_Excel_and_save_my_settings() throws Throwable {
		tempusReportSteps.saveSettingsAsExcel();
	} 	
	@Then("^I click on save my settings with non-default options")
	public void i_click_on_save_my_settings_with_non_default_options() throws Throwable {
		tempusReportSteps.saveSettingsWithNonDefaultOptions();
	}
	@Then("^I click CSV and save my settings with non-default options")
	public void i_click_CSV_and_save_my_settings_with_non_default_oprions() throws Throwable {
		tempusReportSteps.saveSettingsAsCSVWithNonDefaultOptions();
	}
	@Then("^I click Excel and save my settings with non-default options")
	public void i_click_Excel_and_save_my_settings_with_non_default_options() throws Throwable {
		tempusReportSteps.saveSettingsAsExcelWithNonDefaultOptions();
	} 
	@Then("^I click on save my settings and cancel")
	public void i_click_on_save_my_settings_and_cancel() throws Throwable {
		tempusReportSteps.saveSettingAndCancel();
	}
	@Then("^I click on the dots on the right side")
	public void i_click_on_the_dots_on_the_right_side() throws Throwable {
		tempusReportSteps.clickOnThreeDots();
		
	}
	@Then("^I navigate to reports tab")
	public void i_navigate_to_reports_tab() throws Throwable {
		tempusReportSteps.navigateToReportsTab();
	}
	

}
