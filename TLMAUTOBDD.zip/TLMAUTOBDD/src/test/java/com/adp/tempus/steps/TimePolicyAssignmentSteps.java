package com.adp.tempus.steps;

import com.adp.tempus.pages.TimePolicyAssignment;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class TimePolicyAssignmentSteps extends ScenarioSteps {
	
	TimePolicyAssignment timePolicyAssignment;
	
	@Step
	public void verifyEmployeeProfilePageLoading() {
		timePolicyAssignment.verifyEmployeeProfilePageLoading();
	}
	
	@Step
	public void verifyTimeTitleDisplayed() {
		timePolicyAssignment.verifyTimeTitleDisplayed();
	}
	
	@Step
	public void verifyClockiconIsDisplayed() {
		timePolicyAssignment.verifyClockiconIsDisplayed();
	}
	
	@Step
	public void verify_Time_Attendence_text_is_displayed() {
		timePolicyAssignment.verify_Time_Attendence_text_is_displayed();
	}
	
	@Step
	public void verify_NAME_label_is_displayed() {
		timePolicyAssignment.verify_NAME_label_is_displayed();
	}
	
	@Step
	public void verify_CATEGORY_label_is_displayed() {
		timePolicyAssignment.verify_CATEGORY_label_is_displayed();
	}
	
	@Step
	public void verify_Time_Settings_Link_is_displayed() {
		timePolicyAssignment.verify_Time_Settings_Link_is_displayed();
	}
	
	@Step
	public void verify_History_Link_is_displayed() {
		timePolicyAssignment.verify_History_Link_is_displayed();
	}
	
	@Step
	public void verify_Edit_button_is_displayed() {
		timePolicyAssignment.verify_Edit_button_is_displayed();
	}
	
	@Step
	public void select_edit_button() {
		timePolicyAssignment.select_edit_button();
	}
	
	@Step
	public void should_navigate_to_Time_Policy_Assignment_page() {
		timePolicyAssignment.should_navigate_to_Time_Policy_Assignment_page();
	}
	
	@Step
	public void select_Back_button() {
		timePolicyAssignment.select_Back_button();
	}
	
	@Step
	public void select_Back_button_on_history() {
		timePolicyAssignment.select_Back_button_on_history();
	}
	
	@Step
	public void should_navigate_to_employee_profile_page() {
		timePolicyAssignment.should_navigate_to_employee_profile_page();
	}
	
	@Step
	public void select_Time_Attendance_History_link() {
		timePolicyAssignment.select_Time_Attendance_History_link();
	}
	
	@Step
	public void navigate_to_Time_Attendance_History_page() {
		timePolicyAssignment.navigate_to_Time_Attendance_History_page();
		
	}
	
	@Step
	public void select_Other_Time_Attendance_Settings_link() {
		timePolicyAssignment.select_Other_Time_Attendance_Settings_link();
		
	}
	
	@Step
	public void navigate_to_Other_Time_Attendance_Settings_page() {
		timePolicyAssignment.navigate_to_Other_Time_Attendance_Settings_page();
	}
	
	@Step
	public void validate_HISTORY_link_is_displayed() {
		timePolicyAssignment.validate_HISTORY_link_is_displayed();
	}
	
	@Step
	public void select_HISTORY_link_Time_Policy_Assignment_Page() {
		timePolicyAssignment.select_HISTORY_link_Time_Policy_Assignment_Page();
	}
	
	@Step
	public void pick_effective_date(String effDate) {
		timePolicyAssignment.pick_effective_date(effDate);
	}
	
	@Step
	public void select_rounding_Options_and_Time_Entry_and_Meal_Breaks_and_Time_Holiday() {
		timePolicyAssignment.select_rounding_Options_and_Time_Entry_and_Meal_Breaks_and_Time_Holiday();
	}
	
	@Step
	public void verifyTimeTileDisplayedPayProfile() {
		timePolicyAssignment.verifyTimeTileDisplayedPayProfile();
	}
	
	@Step
	public void verifyTimeandAttendenceLinkDisplayed() {
		timePolicyAssignment.verifyTimeandAttendenceLinkDisplayed();
	}
	
	@Step
	public void selectTimeandAttendanceLink() {
		timePolicyAssignment.selectTimeandAttendanceLink();
	}
	
	@Step
	public void should_navigate_to_pay_profile_page() {
		timePolicyAssignment.verifyTimeandAttendenceLinkDisplayed();
	}
	
	@Step
	public void validate_new_time_line_is_created() {
		timePolicyAssignment.validate_new_time_line_is_created();
	}
	
	@Step
	public void verifyTimeTitleNotDisplayed() {
		timePolicyAssignment.verifyTimeTitleNotDisplayed();
	}
}
