package com.adp.tempus.stepDefinition;

import java.time.format.DateTimeFormatter;

import com.adp.tempus.steps.ReviewTimecardRUNSteps;
import com.adp.tlmbdd.stepDefinition.TeamDashboardStepDefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ReviewTimecardRUNStepDefinition {
	
	@Steps
	ReviewTimecardRUNSteps reviewTimecardRUNSteps;
	
	@When("^I click on Review Timecards icon$")
	public void iClickOnReviewTimecardsIcon() throws Throwable {
		
		reviewTimecardRUNSteps.verifyReviewTimecard();
	}
	
	@And("^I toggle the Enable Details button$")
	public void iToggleTheEnableDetailsButton() throws Throwable {
		reviewTimecardRUNSteps.SelectToggleButton();
	}

	@Then("^I should view the Hours on the Timecard$")
	public void iShouldViewTheHoursOnTheTimecard() throws Throwable {
		
	}

/*	@And("^I select an employee \"([^\"]*)\" from the select employee dropdown$")
	public void iSelectAnEmployeeFromTheSelectEmployeeDropdown(String EmpName) throws Throwable {
		reviewTimecardRUNSteps.SelectEmpDropDown(EmpName);
	}*/

	@Then("^I should view the Timecard Grid$")
	public void iShouldViewTheTimecardGrid() throws Throwable {
		reviewTimecardRUNSteps.SelectToggleButton();
	}

	@When("^I Click on Time picker icon \"([^\"]*)\",\"([^\"]*)\"$")
	public void iClickOnTimePickerIcon(String intime, String outtime) throws Throwable {
		reviewTimecardRUNSteps.SelectTimePicker(intime,outtime);
	}

	@Then("^I Verify \"([^\"]*)\" on Paycode summary Tile$")
	public void iVerifyOnPaycodeSummaryTile(String PayCodeSummaryHours) throws Throwable {
		reviewTimecardRUNSteps.verifyPayCodeSummary(PayCodeSummaryHours);
	}

	@Then("^display the \"([^\"]*)\" under Paycode summary section$")
	public void displayTheUnderPaycodeSummarySection(String HourDistType) throws Throwable {
		reviewTimecardRUNSteps.verifyHourDistType(HourDistType);
	}

	@Then("^I Verify the \"([^\"]*)\" exception$")
	public void iVerifyTheException(String ExceptionType) throws Throwable {
		reviewTimecardRUNSteps.validateExceptions(ExceptionType);
	}

	@When("^I click on Time icon$")
	public void iClickOnTimeIcon() throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.ClickTimeIconMyADP();
	}

	@When("^I Click Button on MyADPTimecard Grid \"([^\"]*)\",\"([^\"]*)\"$")
	public void iClickButtonOnMyADPTimecardGrid(String strDate,String strButton) throws Throwable {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("d");
		strDate = TeamDashboardStepDefinition.getRequiredDate(strDate).format(formatters).toString();
		reviewTimecardRUNSteps.clickButtonMyADPTimecardGrid(strDate,strButton);	}

	@And("^I Clear all Timepairs or Hours on MyADP Timecard$")
	public void iClearAllTimepairsOrHoursOnMyADPTimecard() throws Throwable {
		reviewTimecardRUNSteps.deleteTimepairsMyADPTimecards();

	}

	@When("^I Employee Enters Time Pair on MyADP Timecard Page \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void iEmployeeEntersTimePairOnMyADPTimecardPage(String strPunchType, String findInPunch, String inPunch, String outPunch)
			throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.employeesubmitTimePairMyADP(strPunchType,findInPunch,inPunch,outPunch);

	}

	@When("^I Click Button on My ADP Time Pair Page \"([^\"]*)\"$")
	public void iClickButtonOnMyADPTimePairPage(String btnName) throws Throwable {
		reviewTimecardRUNSteps.clickButtonAddTimePairMyADP(btnName);
	}

	
	@When("^I click on Home and Run Payroll$")
	public void iClickOnHomeAndRunPayroll() throws Throwable {
		reviewTimecardRUNSteps.clickonHomeandRunPayroll();
	}

	
	@When("^I search the client and login to the \"([^\"]*)\"$")
	public void iSearchTheClientAndLoginToThe(String TLMClientID) throws Throwable {
		reviewTimecardRUNSteps.SearchClientRUN(TLMClientID);
	}

	@And("^I then select a \"([^\"]*)\" and load the Time Management$")
	public void iThenSelectAAndLoadTheTimeManagement(String NonTLMClientID) throws Throwable {
		reviewTimecardRUNSteps.SearchClientRUNNonTLM(NonTLMClientID);
		}

	@And("^I add a missed out Punch$")
	public void iAddAMissedOutPunch() throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.AddTimePairTLM();
	}

	@And("^I then resolve exceptions from Payroll Run slider$")
	public void iThenResolveExceptionsFromPayrollRunSlider() throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.ResolveExceptions();
	}

	@And("^I then select a \"([^\"]*)\"$")
	public void iThenSelectA(String NonTLMClientID) throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.SearchClientNonTLM(NonTLMClientID);
	}

	@Then("^I see that Timecard Grid is grayed out$")
	public void iSeeThatTimecardGridIsGrayedOut() throws Throwable {
		reviewTimecardRUNSteps.ValidateTCGridGrayed();
	}

	@When("^I search for \"([^\"]*)\" from Directory$")
	public void iSearchForFromDirectory(String EmpName) throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.SearchEmployee(EmpName);
	}

	@Then("^I terminate the \"([^\"]*)\"$")
	public void iTerminateThe(String EmpName) throws Throwable {
		reviewTimecardRUNSteps.TerminateEmployee(EmpName);
	}

	@And("^I select an employee \"([^\"]*)\" from the select employee dropdown with Employee visibility \"([^\"]*)\"$")
	public void iSelectAnEmployeeFromTheSelectEmployeeDropdownWithEmployeeVisibility(String EmpName, String Visibility)
			throws Throwable {
		reviewTimecardRUNSteps.SelectEmpDropDown(EmpName, Visibility);

	}

	@Then("^I Rehire the \"([^\"]*)\"$")
	public void iRehireThe(String EmpName) throws Throwable {
		reviewTimecardRUNSteps.RehireEmployee(EmpName);
	}

	@Then("^I click on Print Timecard Icon and validate$")
	public void iClickOnPrintTimecardIconAndValidate() throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.PrintTimecard();
		
	}

	@When("^I Employee Enters PTO on MyADP Timecard Page with PayCode \"([^\"]*)\", \"([^\"]*)\"$")
	public void iEmployeeEntersPTOOnMyADPTimecardPageWithPayCode(String PTOPayCode, String Hours) throws Throwable {
		reviewTimecardRUNSteps.SubmitPTOMyADP(PTOPayCode, Hours);
		
	}

	
	@And("^I click on SubmitTimeOffButton and request PTO with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iClickOnSubmitTimeOffButtonAndRequestPTOWithAnd(String PTOPayCode, String Hours) throws Throwable {
		reviewTimecardRUNSteps.SubmitPTOTimecard(PTOPayCode, Hours);
	}

	
	@When("^I click on Dashboard icon$")
	public void iClickOnDashboardIcon() throws Throwable {
		//throw new PendingException();
		reviewTimecardRUNSteps.ClickDashboardIconMyADP();
	}

	@When("^I Edit Time Off and Save with Hours \"([^\"]*)\"$")
	public void iEditTimeOffAndSaveWithHours(String updatedhours) throws Throwable {
		reviewTimecardRUNSteps.editPTO(updatedhours);
	}

	@And("^I click on the \"([^\"]*)\" button$")
	public void iClickOnTheButton(String PunchType) throws Throwable {
		reviewTimecardRUNSteps.Punch(PunchType);
	}
	
	
	}
