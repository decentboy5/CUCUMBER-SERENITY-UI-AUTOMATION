package com.adp.tempus.steps;
import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.By;

import com.adp.tempus.pages.TimeDashboard;
import com.adp.tlmbdd.pages.TeamDashboard;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class TimeDashboardSteps extends ScenarioSteps {

	TimeDashboard timeDashboard;
	TeamDashboard teamDashboard;

	@Step
	public void clickOnTTDTile(String tilename) {
		timeDashboard.clickOnTTDTile(tilename);
	}

	@Step
	public void resolveMissedPunch(String employeename, String outPunch, String date) {
		timeDashboard.resolveMissedPunch(employeename, outPunch, date);
	}

	@Step
	public void clickButtonOnSlider(String buttonName) {
		timeDashboard.clickButtonOnSlider(buttonName);
	}

	@Step
	public void selectEmployeeTimecardApprovalGrid(String empName, String positionId, String value) {
		timeDashboard.selectEmployeeTimecardApprovalGrid(empName, positionId, value);
	}

	@Step
	public void verifyEmployeeRecordTimecardApprovalGrid(String empName, String positionId, String status) {
		timeDashboard.verifyEmployeeRecordTimecardApprovalGrid(empName, positionId, status);
	}

	@Step
	public void verifyTimecardCountTimecardApprovalStatusTile(String approved, String readyForApproval,
			String pendingActions) {
		timeDashboard.verifyTimecardCountTimecardApprovalStatusTile(approved, readyForApproval, pendingActions);
	}

	@Step
	public void clickOnTimecardApprovalStatusTile(String buttonName) {
		timeDashboard.clickOnTimecardApprovalStatusTile(buttonName);
	}

	@Step
	public void verifybuttonStatusOnSlider(String btnName, String status) {
		timeDashboard.verifybuttonStatusOnSlider(btnName, status);
	}

	@Step
	public void resolveMultipleMissedPunch(String employeename, String date, List<String> timepairs) {
		timeDashboard.resolveMultipleMissedPunch(employeename, date, timepairs);
	}

	@Step
	public void saveMissedPunchesAndEmployeeCountOnTTDTile() {
		timeDashboard.saveMissedPunchesAndEmployeeCountOnTTDTile();

	}

	@Step
	public void saveMissedPunchesAndEmployeeCountOnSlider() {
		timeDashboard.saveMissedPunchesAndEmployeeCountOnSlider();

	}

	@Step
	public void verifyMissedPunchesAndEmployeeOnTTDTile(String employeedifference, String missedpunchesdifference) {
		timeDashboard.verifyMissedPunchesAndEmployeeOnTTDTile(employeedifference, missedpunchesdifference);
	}

	@Step
	public void verifyMissedPunchesAndEmployeeOnSlider(String employeedifference, String missedpunchesdifference) {
		timeDashboard.verifyMissedPunchesAndEmployeeOnSlider(employeedifference, missedpunchesdifference);
	}
	
	@Step
	public void verifyEmployeeDetailsTimecardApprovalGrid(String empName, String positionId, String status,
			String totalHrs) {
		timeDashboard.verifyEmployeeDetailsTimecardApprovalGrid(empName,positionId,status,totalHrs);		
	}
	
	@Step
	public void verifyTmecardApprovalSubTile(String tcCount) {
		timeDashboard.verifyTmecardApprovalSubTile(tcCount);
	}

	@Step
	public void selectEmployee(String empName) {
		teamDashboard.selectEmployee(empName);		
	}
	
	@Step
	public void verifyTileInVisibilityOnTTDTIle(String TileName) {
		timeDashboard.verifyTileInVisibilityOnTTDTIle(TileName);
	}
	
	@Step
	public void clickTimeCardLinkAndVerifyLoading(String employeename)
	{
		timeDashboard.clickTimeCardLinkAndVerifyLoading(employeename);
	}
	
	@Step
	public void verifyColorOfNote(String color,String employeename,String date)
	{
		timeDashboard.verifyColorOfNote(color, employeename, date);
	}
	
	@Step
	public void clickOnSpecificNote(String employeename,String date)
	{
		timeDashboard.clickOnSpecificNote(employeename, date);
	}
	
	@Step
	public void verifyEmployeeNote(String note,String employeename)
	{
		timeDashboard.verifyEmployeeNote(note, employeename);
	}
	

}
